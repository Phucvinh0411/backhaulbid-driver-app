package vn.cccd.bacreader.protocol

import java.security.MessageDigest
import vn.cccd.bacreader.crypto.BacCipher
import vn.cccd.bacreader.crypto.RetailMac
import vn.cccd.bacreader.domain.Dg2ChunkFailureType
import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.lds.BerTlvHeader
import vn.cccd.bacreader.lds.BerTlvLengthReader
import vn.cccd.bacreader.lds.LdsParseException
import vn.cccd.bacreader.nfc.ApduTransport
import vn.cccd.bacreader.nfc.TagLostTransportException
import vn.cccd.bacreader.nfc.TransportDiagnostics
import vn.cccd.bacreader.nfc.TransportException
import vn.cccd.bacreader.nfc.TransportTimeoutException

class SecureMessagingException(
    val error: ReaderError,
    val sw: StatusWord? = null,
    cause: Throwable? = null,
) : Exception("Secure messaging failed: $error${sw?.let { " SW=$it" } ?: ""}", cause)

/** A verified protected response. Call [close] when the payload is no longer needed. */
class ProtectedResponse internal constructor(
    val status: StatusWord,
    data: ByteArray,
) : AutoCloseable {
    private var payload: ByteArray? = data

    fun copyData(): ByteArray = requireNotNull(payload) { "Protected response is closed" }.copyOf()

    override fun close() {
        payload?.fill(0)
        payload = null
    }

    override fun toString(): String = "ProtectedResponse(status=$status, data=<redacted>)"
}

interface ProtectedChannel : AutoCloseable {
    val maxReadBinaryLength: Int
    fun selectFile(fileId: Int): ProtectedResponse
    fun readBinary(offset: Int, length: Int): ProtectedResponse

    /** READ BINARY using a short-APDU short-file identifier (SFI). */
    fun readBinaryBySfi(sfi: Int, offset: Int, length: Int): ProtectedResponse =
        throw SecureMessagingException(ReaderError.PROTECTED_STATUS_ERROR)
}

/**
 * BAC 3DES secure messaging. It owns copies of session material, increments SSC
 * before every command and response MAC, and authenticates response data before
 * decrypting it.
 */
class SecureMessagingChannel(
    private val transport: ApduTransport,
    session: BacSession,
) : ProtectedChannel, ProtectedChannelDiagnostics {
    private val readBinaryLimit = maxPlainReadLength(transport.maxTransceiveLength)

    init {
        // This is intentionally before the session copies below: a rejected
        // transport must not allocate key or SSC copies that cannot be closed.
        require(transport.maxTransceiveLength >= MIN_PROTECTED_SELECT_COMMAND_LENGTH) {
            "ISO-DEP transceive limit is too small for protected SELECT FILE"
        }
        require(readBinaryLimit > 0) {
            "ISO-DEP transceive limit is too small for a protected READ BINARY response"
        }
    }

    private var encKey: ByteArray? = session.copySessionEncKey()
    private var macKey: ByteArray? = session.copySessionMacKey()
    private var ssc: ByteArray? = session.copySsc()

    /**
     * Largest short-APDU READ BINARY plaintext that still fits the maximum
     * protected DO87 response after method-2 padding and DO/outer-SW overhead.
     */
    override val maxReadBinaryLength: Int
        get() = readBinaryLimit

    override val effectiveTransceiveMaximum: Int
        get() = transport.maxTransceiveLength

    override val secureMessagingOverhead: Int
        get() = protectedResponseLength(maxReadBinaryLength) - maxReadBinaryLength

    override fun selectFile(fileId: Int): ProtectedResponse {
        require(fileId in 0..0xFFFF) { "File ID must fit two bytes" }
        return exchange(
            instruction = 0xA4,
            p1 = 0x02,
            p2 = 0x0C,
            data = byteArrayOf((fileId ushr 8).toByte(), fileId.toByte()),
            expectedLe = null,
        )
    }

    override fun readBinary(offset: Int, length: Int): ProtectedResponse {
        require(offset in 0..0x7FFF) { "READ BINARY offset is outside short APDU range" }
        require(length in 1..maxReadBinaryLength) { "READ BINARY length exceeds transport-derived bound" }
        return exchange(
            instruction = 0xB0,
            p1 = (offset ushr 8) and 0x7F,
            p2 = offset and 0xFF,
            data = null,
            expectedLe = length,
        )
    }

    override fun readBinaryWithDiagnostics(
        offset: Int,
        length: Int,
        onTrace: (ProtectedTransceiveTrace) -> Unit,
    ): ProtectedResponse {
        require(offset in 0..0x7FFF) { "READ BINARY offset is outside short APDU range" }
        require(length in 1..maxReadBinaryLength) { "READ BINARY length exceeds transport-derived bound" }
        return exchange(
            instruction = 0xB0,
            p1 = (offset ushr 8) and 0x7F,
            p2 = offset and 0xFF,
            data = null,
            expectedLe = length,
            onTrace = onTrace,
        )
    }

    override fun readBinaryBySfi(sfi: Int, offset: Int, length: Int): ProtectedResponse {
        require(sfi in 1..0x1F) { "SFI must fit five bits" }
        require(offset in 0..0x7FFF) { "READ BINARY offset is outside short APDU range" }
        require(length in 1..maxReadBinaryLength) { "READ BINARY length exceeds transport-derived bound" }
        return exchange(
            instruction = 0xB0,
            p1 = 0x80 or sfi,
            p2 = offset and 0xFF,
            data = null,
            expectedLe = length,
        )
    }

    override fun readBinaryBySfiWithDiagnostics(
        sfi: Int,
        offset: Int,
        length: Int,
        onTrace: (ProtectedTransceiveTrace) -> Unit,
    ): ProtectedResponse {
        require(sfi in 1..0x1F) { "SFI must fit five bits" }
        require(offset in 0..0x7FFF) { "READ BINARY offset is outside short APDU range" }
        require(length in 1..maxReadBinaryLength) { "READ BINARY length exceeds transport-derived bound" }
        return exchange(
            instruction = 0xB0,
            p1 = 0x80 or sfi,
            p2 = offset and 0xFF,
            data = null,
            expectedLe = length,
            onTrace = onTrace,
        )
    }

    private fun exchange(
        instruction: Int,
        p1: Int,
        p2: Int,
        data: ByteArray?,
        expectedLe: Int?,
        onTrace: ((ProtectedTransceiveTrace) -> Unit)? = null,
    ): ProtectedResponse {
        val header = byteArrayOf(0x0C, instruction.toByte(), p1.toByte(), p2.toByte())
        val do87 = data?.let(::encryptedDo87)
        val do97 = expectedLe?.let(::do97)
        val commandBodyWithoutMac = concat(do87, do97)
        val command = try {
            incrementSsc()
            val sscForMac = currentSsc()
            val paddedHeader = padMethod2(header)
            val macInput = concat(sscForMac, paddedHeader, commandBodyWithoutMac)
            val mac = try {
                RetailMac.computeWithDesEdeKey(requireMacKey(), macInput)
            } finally {
                sscForMac.fill(0)
                paddedHeader.fill(0)
                macInput.fill(0)
            }
            try {
                val do8e = tlv(TAG_DO8E, mac)
                val body = concat(commandBodyWithoutMac, do8e)
                try {
                    if (body.size > 0xFF) throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
                    ByteArray(header.size + 1 + body.size + 1).also { apdu ->
                        header.copyInto(apdu)
                        apdu[4] = body.size.toByte()
                        body.copyInto(apdu, 5)
                        apdu[apdu.lastIndex] = 0x00 // short protected Le
                    }
                } finally {
                    body.fill(0)
                    do8e.fill(0)
                }
            } finally {
                mac.fill(0)
            }
        } finally {
            header.fill(0)
            do87?.fill(0)
            do97?.fill(0)
            commandBodyWithoutMac.fill(0)
            data?.fill(0)
        }

        try {
            if (command.size > transport.maxTransceiveLength) {
                throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
            }
            val transportDiagnostics = transport as? TransportDiagnostics
            val connectedBefore = transportDiagnostics?.isConnected
            val startedAt = System.nanoTime()
            val rawResponse = try {
                transceive(command)
            } catch (error: SecureMessagingException) {
                onTrace?.invoke(
                    ProtectedTransceiveTrace(
                        encodedCommandLength = command.size,
                        transceiveDurationMillis = elapsedMillis(startedAt),
                        statusWord = error.sw?.value,
                        isoDepConnected = connectedBefore,
                        isoDepTimeoutMillis = transportDiagnostics?.configuredTimeoutMillis,
                        isoDepMaxTransceiveLength = transport.maxTransceiveLength,
                        failureType = classifyFailure(error, connectedBefore),
                    ),
                )
                throw error
            }
            try {
                val outerStatus = rawResponse.takeIf { it.size >= 2 }?.let(StatusWord::from)?.value
                return try {
                    val response = verifyResponse(rawResponse)
                    val payload = response.copyData()
                    try {
                        onTrace?.invoke(
                            ProtectedTransceiveTrace(
                                encodedCommandLength = command.size,
                                transceiveDurationMillis = elapsedMillis(startedAt),
                                statusWord = outerStatus,
                                receivedPlainLength = payload.size,
                                isoDepConnected = connectedBefore,
                                isoDepTimeoutMillis = transportDiagnostics?.configuredTimeoutMillis,
                                isoDepMaxTransceiveLength = transport.maxTransceiveLength,
                            ),
                        )
                    } finally {
                        payload.fill(0)
                    }
                    response
                } catch (error: SecureMessagingException) {
                    onTrace?.invoke(
                        ProtectedTransceiveTrace(
                            encodedCommandLength = command.size,
                            transceiveDurationMillis = elapsedMillis(startedAt),
                            statusWord = error.sw?.value ?: outerStatus,
                            isoDepConnected = connectedBefore,
                            isoDepTimeoutMillis = transportDiagnostics?.configuredTimeoutMillis,
                            isoDepMaxTransceiveLength = transport.maxTransceiveLength,
                            failureType = classifyFailure(error, connectedBefore),
                        ),
                    )
                    throw error
                }
            } finally {
                rawResponse.fill(0)
            }
        } finally {
            command.fill(0)
        }
    }

    private fun elapsedMillis(startedAt: Long): Long =
        ((System.nanoTime() - startedAt) / 1_000_000L).coerceAtLeast(0)

    private fun classifyFailure(error: SecureMessagingException, connectedBefore: Boolean?): Dg2ChunkFailureType =
        when {
            error.cause is TagLostTransportException && connectedBefore == false ->
                Dg2ChunkFailureType.TAG_LOST_BEFORE_TRANSCEIVE
            error.cause is TagLostTransportException -> Dg2ChunkFailureType.TAG_LOST_DURING_TRANSCEIVE
            error.cause is TransportTimeoutException || error.error == ReaderError.TIMEOUT ->
                Dg2ChunkFailureType.TRANSCEIVE_TIMEOUT
            error.error == ReaderError.UNEXPECTED_STATUS || error.error == ReaderError.PROTECTED_STATUS_ERROR ->
                Dg2ChunkFailureType.APDU_STATUS_ERROR
            error.error == ReaderError.MAC_MISMATCH || error.error == ReaderError.MALFORMED_RESPONSE ->
                Dg2ChunkFailureType.SECURE_MESSAGING_UNWRAP_ERROR
            error.cause is TransportException -> Dg2ChunkFailureType.TRANSPORT_ERROR
            else -> Dg2ChunkFailureType.SECURE_MESSAGING_UNWRAP_ERROR
        }

    private fun verifyResponse(rawResponse: ByteArray): ProtectedResponse {
        if (rawResponse.size < 2) throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
        val outerStatus = StatusWord.from(rawResponse)
        if (!outerStatus.isSuccess) {
            throw SecureMessagingException(ReaderError.UNEXPECTED_STATUS, outerStatus)
        }
        val protectedData = rawResponse.copyOfRange(0, rawResponse.size - 2)
        try {
            val objects = parseResponseObjects(protectedData)
            try {
                val do8e = objects.lastOrNull()?.takeIf { it.tag == TAG_DO8E }
                    ?: throw SecureMessagingException(ReaderError.MAC_MISMATCH)
                val statusObject = objects.firstOrNull { it.tag == TAG_DO99 }
                    ?: throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
                if (statusObject.value.size != 2 || objects.count { it.tag == TAG_DO99 } != 1 ||
                    objects.count { it.tag == TAG_DO8E } != 1
                ) {
                    throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
                }
                if (objects.any { it.tag !in setOf(TAG_DO85, TAG_DO87, TAG_DO99, TAG_DO8E) } ||
                    objects.indexOf(statusObject) > objects.indexOf(do8e) ||
                    objects.count { it.tag == TAG_DO85 || it.tag == TAG_DO87 } > 1
                ) {
                    throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
                }
                val payloadIndex = objects.indexOfFirst { it.tag == TAG_DO85 || it.tag == TAG_DO87 }
                if (payloadIndex >= 0 && payloadIndex > objects.indexOf(statusObject)) {
                    throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
                }

                incrementSsc()
                val responseBodyWithoutMac = protectedData.copyOfRange(0, do8e.offset)
                val sscForMac = currentSsc()
                val macInput = concat(sscForMac, responseBodyWithoutMac)
                val expectedMac = try {
                    RetailMac.computeWithDesEdeKey(requireMacKey(), macInput)
                } finally {
                    sscForMac.fill(0)
                    responseBodyWithoutMac.fill(0)
                    macInput.fill(0)
                }
                try {
                    if (do8e.value.size != MAC_LENGTH || !MessageDigest.isEqual(expectedMac, do8e.value)) {
                        throw SecureMessagingException(ReaderError.MAC_MISMATCH)
                    }
                } finally {
                    expectedMac.fill(0)
                }

                val protectedStatus = StatusWord(
                    ((statusObject.value[0].toInt() and 0xFF) shl 8) or (statusObject.value[1].toInt() and 0xFF),
                )
                if (!protectedStatus.isSuccess) {
                    throw SecureMessagingException(ReaderError.PROTECTED_STATUS_ERROR, protectedStatus)
                }
                val payloadObject = objects.firstOrNull { it.tag == TAG_DO87 || it.tag == TAG_DO85 }
                val payload = payloadObject?.let(::decryptPayload) ?: ByteArray(0)
                return ProtectedResponse(protectedStatus, payload)
            } finally {
                objects.forEach(RawDo::close)
            }
        } finally {
            protectedData.fill(0)
        }
    }

    private fun parseResponseObjects(encoded: ByteArray): List<RawDo> {
        val objects = ArrayList<RawDo>()
        var offset = 0
        try {
            while (offset < encoded.size) {
                val header: BerTlvHeader = try {
                    BerTlvLengthReader.readHeader(encoded, offset, encoded.size)
                } catch (error: LdsParseException) {
                    throw SecureMessagingException(error.error, cause = error)
                }
                if (encoded.size - offset < header.encodedLength) {
                    throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
                }
                val valueStart = offset + header.headerLength
                objects += RawDo(
                    tag = header.tag,
                    offset = offset,
                    value = encoded.copyOfRange(valueStart, valueStart + header.valueLength),
                )
                offset += header.encodedLength
            }
            return objects
        } catch (error: Throwable) {
            objects.forEach(RawDo::close)
            throw error
        }
    }

    private fun decryptPayload(payload: RawDo): ByteArray {
        val encrypted = when (payload.tag) {
            TAG_DO87 -> {
                if (payload.value.size < 2 || payload.value[0] != 0x01.toByte()) {
                    throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
                }
                payload.value.copyOfRange(1, payload.value.size)
            }
            TAG_DO85 -> payload.value.copyOf()
            else -> throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
        }
        try {
            if (encrypted.isEmpty() || encrypted.size % BLOCK_SIZE != 0) {
                throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
            }
            val plaintext = BacCipher.decrypt(encrypted, requireEncKey())
            try {
                return removeMethod2Padding(plaintext)
            } finally {
                plaintext.fill(0)
            }
        } finally {
            encrypted.fill(0)
        }
    }

    private fun encryptedDo87(data: ByteArray): ByteArray {
        val padded = padMethod2(data)
        val encrypted = try {
            BacCipher.encrypt(padded, requireEncKey())
        } finally {
            padded.fill(0)
        }
        val do87Value = ByteArray(encrypted.size + 1).also {
            it[0] = 0x01
            encrypted.copyInto(it, destinationOffset = 1)
        }
        return try {
            tlv(TAG_DO87, do87Value)
        } finally {
            encrypted.fill(0)
            do87Value.fill(0)
        }
    }

    private fun do97(length: Int): ByteArray {
        require(length in 1..0xFF) { "Protected Le must fit one byte" }
        return tlv(TAG_DO97, byteArrayOf(length.toByte()))
    }

    private fun incrementSsc() {
        val counter = requireNotNull(ssc) { "Secure messaging channel is closed" }
        for (index in counter.lastIndex downTo 0) {
            counter[index] = (counter[index].toInt() + 1).toByte()
            if (counter[index].toInt() and 0xFF != 0) break
        }
    }

    private fun currentSsc(): ByteArray = requireNotNull(ssc) { "Secure messaging channel is closed" }.copyOf()
    private fun requireEncKey(): ByteArray = requireNotNull(encKey) { "Secure messaging channel is closed" }
    private fun requireMacKey(): ByteArray = requireNotNull(macKey) { "Secure messaging channel is closed" }

    private fun transceive(command: ByteArray): ByteArray = try {
        transport.transceive(command)
    } catch (error: TagLostTransportException) {
        throw SecureMessagingException(ReaderError.TAG_LOST, cause = error)
    } catch (error: TransportTimeoutException) {
        throw SecureMessagingException(ReaderError.TIMEOUT, cause = error)
    } catch (error: TransportException) {
        throw SecureMessagingException(ReaderError.TRANSPORT_ERROR, cause = error)
    }

    override fun close() {
        encKey?.fill(0)
        macKey?.fill(0)
        ssc?.fill(0)
        encKey = null
        macKey = null
        ssc = null
    }

    private class RawDo(
        val tag: Int,
        val offset: Int,
        val value: ByteArray,
    ) : AutoCloseable {
        override fun close() = value.fill(0)
    }

    private companion object {
        const val TAG_DO85 = 0x85
        const val TAG_DO87 = 0x87
        const val TAG_DO97 = 0x97
        const val TAG_DO99 = 0x99
        const val TAG_DO8E = 0x8E
        const val BLOCK_SIZE = 8
        const val MAC_LENGTH = 8
        const val MIN_PROTECTED_SELECT_COMMAND_LENGTH = 27

        fun concat(vararg values: ByteArray?): ByteArray {
            val length = values.sumOf { it?.size ?: 0 }
            val result = ByteArray(length)
            var offset = 0
            values.forEach { value ->
                if (value != null) {
                    value.copyInto(result, offset)
                    offset += value.size
                }
            }
            return result
        }

        fun tlv(tag: Int, value: ByteArray): ByteArray {
            require(value.size <= 0xFFFF) { "Secure messaging data object is too long" }
            val length = when {
                value.size <= 0x7F -> byteArrayOf(value.size.toByte())
                value.size <= 0xFF -> byteArrayOf(0x81.toByte(), value.size.toByte())
                else -> byteArrayOf(0x82.toByte(), (value.size ushr 8).toByte(), value.size.toByte())
            }
            return try {
                byteArrayOf(tag.toByte()) + length + value
            } finally {
                length.fill(0)
            }
        }

        fun padMethod2(value: ByteArray): ByteArray =
            ByteArray(((value.size / BLOCK_SIZE) + 1) * BLOCK_SIZE).also { padded ->
                value.copyInto(padded)
                padded[value.size] = 0x80.toByte()
            }

        fun removeMethod2Padding(value: ByteArray): ByteArray {
            var index = value.lastIndex
            while (index >= 0 && value[index] == 0.toByte()) index--
            if (index < 0 || value[index] != 0x80.toByte()) {
                throw SecureMessagingException(ReaderError.MALFORMED_RESPONSE)
            }
            return value.copyOfRange(0, index)
        }

        fun maxPlainReadLength(maxTransceiveLength: Int): Int {
            for (plainLength in 0xFF downTo 1) {
                if (protectedResponseLength(plainLength) <= maxTransceiveLength) return plainLength
            }
            return 0
        }

        private fun protectedResponseLength(plainLength: Int): Int {
            val paddedLength = ((plainLength / BLOCK_SIZE) + 1) * BLOCK_SIZE
            val do87ValueLength = 1 + paddedLength
            val do87LengthLength = when {
                do87ValueLength <= 0x7F -> 1
                do87ValueLength <= 0xFF -> 2
                else -> 3
            }
            return 1 + do87LengthLength + do87ValueLength +
                4 + // DO99: tag + length + two-byte protected status
                10 + // DO8E: tag + length + eight-byte MAC
                2 // outer transport status word
        }
    }
}
