package vn.cccd.bacreader.sdk

import java.util.UUID

/**
 * Single-flight state machine for one capture attempt. [begin] refuses a new attempt while one is still open;
 * [complete] is only accepted at the last stage; every other terminal state is set by [cancel] or [fail], or by
 * [isCurrent] when the session expires.
 */
class CaptureCoordinator(private val nowMillis: () -> Long) {
    private var request: CaptureRequest? = null
    private var attemptId: String? = null
    private var stage: CaptureStage = CaptureStage.DOCUMENT

    /** Terminal outcome of the latest attempt, or null while it is still open. */
    var terminal: CaptureOutcome? = null
        private set

    @Synchronized
    fun begin(request: CaptureRequest): CaptureStart {
        if (this.request != null && terminal == null) return CaptureStart.Rejected(CaptureError.BUSY)
        if (request.role == CaptureRole.DRIVER) return CaptureStart.Rejected(CaptureError.ROLE_NOT_SUPPORTED)
        val text = listOf(request.sessionId, request.accountId, request.policyVersion)
        if (text.any { it.isBlank() || it.length > 128 }) return CaptureStart.Rejected(CaptureError.INVALID_REQUEST)
        val now = nowMillis()
        if (request.expiresAtMillis <= now) return CaptureStart.Rejected(CaptureError.SESSION_EXPIRED)
        val window = request.expiresAtMillis - now
        // The session window must be between 1 ms and 10 minutes.
        if (window !in 1L..600_000L) return CaptureStart.Rejected(CaptureError.INVALID_REQUEST)
        val id = UUID.randomUUID().toString()
        this.request = request
        attemptId = id
        stage = CaptureStage.DOCUMENT
        terminal = null
        return CaptureStart.Started(id)
    }

    @Synchronized
    fun advance(id: String, from: CaptureStage, to: CaptureStage): Boolean {
        if (!isCurrent(id) || stage != from || to.ordinal != from.ordinal + 1) return false
        stage = to
        return true
    }

    /** Ends the attempt as captured. Only accepted at [CaptureStage.FACE]. */
    @Synchronized
    fun complete(
        id: String,
        evidenceHandle: String? = null,
        conclusion: CaptureConclusion = CaptureConclusion.COMPLETED,
        checks: Map<String, String> = emptyMap(),
    ): Boolean {
        if (!isCurrent(id) || stage != CaptureStage.FACE) return false
        val current = requireNotNull(request) { "Required value was null." }
        terminal = CaptureOutcome(
            status = CaptureStatus.CAPTURED,
            attemptId = id,
            sessionId = current.sessionId,
            evidenceHandle = evidenceHandle,
            conclusion = conclusion,
            checks = checks.toMap(),
            consentVersion = current.policyVersion,
        )
        return true
    }

    @Synchronized
    fun cancel(id: String): Boolean {
        if (!isCurrent(id)) return false
        terminal = CaptureOutcome(
            status = CaptureStatus.CANCELLED,
            attemptId = id,
            sessionId = requireNotNull(request) { "Required value was null." }.sessionId,
        )
        return true
    }

    @Synchronized
    fun fail(id: String, error: CaptureError): Boolean {
        if (!isCurrent(id)) return false
        terminal = CaptureOutcome(
            status = CaptureStatus.FAILED,
            attemptId = id,
            sessionId = requireNotNull(request) { "Required value was null." }.sessionId,
            error = error,
        )
        return true
    }

    /** True while [id] is the open attempt. An attempt found expired here is ended as SESSION_EXPIRED. */
    @Synchronized
    fun isCurrent(id: String): Boolean {
        if (id != attemptId || terminal != null) return false
        val current = request ?: return false
        if (nowMillis() >= current.expiresAtMillis) {
            terminal = CaptureOutcome(
                status = CaptureStatus.FAILED,
                attemptId = id,
                sessionId = current.sessionId,
                error = CaptureError.SESSION_EXPIRED,
            )
            return false
        }
        return true
    }

}
