package vn.cccd.bacreader.sdk

/** Final state of one capture attempt as reported to the host app. */
enum class CaptureStatus { CAPTURED, CANCELLED, FAILED }

enum class CaptureRole { SHIPPER, CARRIER, DRIVER }

/** Reasons the SDK refuses or ends an attempt. Declaration order is part of the SDK contract. */
enum class CaptureError {
    BUSY,
    INVALID_REQUEST,
    ROLE_NOT_SUPPORTED,
    SESSION_EXPIRED,
    HOST_RECREATED,
    DOCUMENT_NOT_READY,
    NFC_UNAVAILABLE,
    NFC_READ_FAILED,
    REQUIRED_DATA_MISSING,
    PORTRAIT_UNAVAILABLE,
    BIOMETRIC_INCOMPLETE,
    INTERNAL_ERROR,
    BIOMETRIC_MODEL_UNAVAILABLE,
}

/** Steps of one attempt, in the only order [CaptureCoordinator.advance] accepts. */
enum class CaptureStage { DOCUMENT, NFC, FACE }

enum class CaptureConclusion { COMPLETED, NEEDS_REVIEW, INCOMPLETE, FAILED_STAGE }

data class CaptureRequest(
    val sessionId: String,
    val accountId: String,
    val role: CaptureRole,
    val expiresAtMillis: Long,
    val policyVersion: String,
)

/**
 * Terminal result of one attempt. The defaults match the shipped SDK: a server review is always required unless
 * the coordinator says otherwise, and an attempt that never reached a conclusion is [CaptureConclusion.INCOMPLETE].
 */
data class CaptureOutcome(
    val status: CaptureStatus,
    val attemptId: String,
    val sessionId: String,
    val error: CaptureError? = null,
    val evidenceHandle: String? = null,
    val requiresServerReview: Boolean = true,
    val conclusion: CaptureConclusion = CaptureConclusion.INCOMPLETE,
    val checks: Map<String, String> = emptyMap(),
    val consentVersion: String? = null,
)

/** Result of [CaptureCoordinator.begin]: either a started attempt or the reason it was refused. */
sealed interface CaptureStart {
    data class Started(val attemptId: String) : CaptureStart
    data class Rejected(val error: CaptureError) : CaptureStart
}
