package vn.cccd.bacreader.crypto

/** ICAO Doc 9303 check digit calculation (weights 7, 3, 1). */
object MrzCheckDigit {
    private val weights = intArrayOf(7, 3, 1)

    fun calculate(value: String): Char {
        require(value.isNotEmpty()) { "MRZ field must not be empty" }
        val sum = value.mapIndexed { index, character ->
            valueOf(character) * weights[index % weights.size]
        }.sum()
        return ('0'.code + (sum % 10)).toChar()
    }

    private fun valueOf(character: Char): Int = when (character) {
        in '0'..'9' -> character - '0'
        in 'A'..'Z' -> character - 'A' + 10
        '<' -> 0
        else -> throw IllegalArgumentException("Unsupported MRZ character")
    }
}
