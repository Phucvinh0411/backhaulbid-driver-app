package vn.cccd.bacreader.nfc

/** Minimal ISO-DEP transport boundary used by protocol code and JVM tests. */
interface ApduTransport : AutoCloseable {
    val maxTransceiveLength: Int
    fun connect()
    fun transceive(command: ByteArray): ByteArray
    override fun close()
}

/** Optional transport facts used only for safe diagnostics. */
interface TransportDiagnostics {
    val isConnected: Boolean?
    val configuredTimeoutMillis: Int?
}

open class TransportException(message: String, cause: Throwable? = null) : Exception(message, cause)
class TagLostTransportException(cause: Throwable? = null) : TransportException("NFC tag lost", cause)
class TransportTimeoutException(cause: Throwable? = null) : TransportException("NFC I/O timed out", cause)
