package vn.cccd.bacreader.lds

import vn.cccd.bacreader.domain.Dg2Data
import vn.cccd.bacreader.domain.Dg2Diagnostic
import vn.cccd.bacreader.domain.Dg2DiagnosticSource
import vn.cccd.bacreader.domain.Dg2DiagnosticStage
import vn.cccd.bacreader.domain.Dg2ImageFormat
import vn.cccd.bacreader.domain.Dg2Portrait
import vn.cccd.bacreader.domain.ReaderError

/** Result of parsing DG2 metadata and extracting one declared portrait payload. */
class Dg2ParseResult(
    val metadata: Dg2Data,
    val portrait: Dg2Portrait,
    val diagnostic: Dg2Diagnostic? = null,
) : AutoCloseable {
    // Source-compatible metadata accessors for callers that previously received Dg2Data.
    val format: Dg2ImageFormat get() = metadata.format
    val encodedBytes: Int get() = metadata.encodedBytes
    val imageBytes: Int get() = metadata.imageBytes

    override fun close() {
        portrait.close()
    }
}

/**
 * Parses the ISO 19794-5 facial biometric data block inside DG2.
 *
 * This parser only returns the image bytes declared by the face record. It deliberately does
 * not search arbitrary DG2 bytes for JPEG signatures because doing so can mistake unrelated
 * data for a portrait and can retain unbounded card-provided content.
 */
object Dg2Parser {
    const val MAX_ENCODED_BYTES: Int = LdsFileLimits.DG2_MAX_ENCODED_BYTES

    private const val DG2_TAG = 0x75
    private const val FACIAL_DATA_BLOCK_TAG = 0x5F2E
    private const val ISO_39794_DATA_BLOCK_TAG = 0x7F2E
    private const val MAX_NESTING_DEPTH = 32
    private const val FACE_INFO_HEADER_BYTES = 14
    private const val FACE_RECORD_FIXED_BYTES = 32 // recordLength + 16-byte FAC block + 12-byte image info
    private const val FAC_FORMAT_IDENTIFIER = 0x46414300
    private const val FAC_VERSION = 0x30313000

    fun parse(encoded: ByteArray): Dg2ParseResult = try {
        parseInternal(encoded)
    } catch (error: Dg2ParserFailure) {
        throw LdsParseException(error.error, error.message ?: "DG2 parser failure", error.cause, error.diagnostic)
    }

    private fun parseInternal(encoded: ByteArray): Dg2ParseResult {
        if (encoded.size > MAX_ENCODED_BYTES) {
            tooLarge("DG2 exceeds configured cap", Dg2DiagnosticStage.DG2_OUTER_TLV, 0, encoded.size)
        }
        val root = readSpan(encoded, 0, encoded.size, Dg2DiagnosticStage.DG2_OUTER_TLV)
        if (root.tag != DG2_TAG || root.encodedEnd != encoded.size) {
            malformed(
                detail = "DG2 must be one complete 0x75 TLV",
                stage = Dg2DiagnosticStage.DG2_OUTER_TLV,
                offset = 0,
                field = "outerTlv",
                remaining = encoded.size - root.encodedEnd,
            )
        }

        val image = findPortrait(encoded, root.valueStart, root.valueEnd, 0)
            ?: unsupported(
                detail = "DG2 has no ISO 19794-5 facial data block",
                stage = Dg2DiagnosticStage.BDB_CONTAINER,
                offset = root.valueStart,
                field = "facialDataBlock",
                remaining = root.valueEnd - root.valueStart,
            )
        val imageBytes = encoded.copyOfRange(image.start, image.end)
        val format = when (image.imageDataType) {
            0 -> Dg2ImageFormat.JPEG
            1 -> Dg2ImageFormat.JPEG2000
            else -> {
                imageBytes.fill(0)
                unsupported(
                    detail = "unsupported ISO 19794 image data type ${image.imageDataType}",
                    stage = Dg2DiagnosticStage.FAC_IMAGE_INFO,
                    offset = image.dataTypeOffset,
                    field = "imageDataType",
                    remaining = image.end - image.dataTypeOffset,
                )
            }
        }
        return Dg2ParseResult(
            metadata = Dg2Data(format, encoded.size, image.end - image.start),
            portrait = Dg2Portrait(format, imageBytes),
            diagnostic = Dg2Diagnostic(
                source = Dg2DiagnosticSource.DG2_PARSER,
                stage = Dg2DiagnosticStage.FAC_IMAGE_INFO,
                bytesRead = encoded.size,
                rawLength = encoded.size,
                firstTag = root.tag,
                declaredLength = root.valueEnd - root.valueStart,
                readerStatus = vn.cccd.bacreader.domain.Dg2ReaderStatus.COMPLETE,
                parserAccepted = true,
                facRecordLength = image.facRecordLength,
                facialRecordCount = image.facialRecordCount,
                recordStart = image.recordStart,
                recordLength = image.recordLength,
                featurePointCount = image.featurePointCount,
                imageInfoStart = image.imageInfoStart,
                imageStart = image.start,
                calculatedImageLength = image.end - image.start,
                imageDataType = image.imageDataType,
                imageWidth = image.imageWidth,
                imageHeight = image.imageHeight,
            ),
        )
    }

    private fun findPortrait(encoded: ByteArray, start: Int, end: Int, depth: Int): ImageSpan? {
        if (depth > MAX_NESTING_DEPTH) {
            malformed(
                detail = "DG2 TLV nesting exceeds limit",
                stage = Dg2DiagnosticStage.BDB_CONTAINER,
                offset = start,
                field = "nestingDepth",
                remaining = end - start,
            )
        }
        var offset = start
        while (offset < end) {
            val span = readSpan(encoded, offset, end, Dg2DiagnosticStage.BDB_CONTAINER)
            when (span.tag) {
                FACIAL_DATA_BLOCK_TAG -> return parseFaceInfo(encoded, span)
                ISO_39794_DATA_BLOCK_TAG -> unsupported(
                    detail = "ISO 39794-5 facial data block is not supported",
                    stage = Dg2DiagnosticStage.BDB_CONTAINER,
                    offset = offset,
                    field = "facialDataBlockTag",
                    remaining = end - offset,
                )
            }
            if (span.constructed) {
                val nested = findPortrait(encoded, span.valueStart, span.valueEnd, depth + 1)
                if (nested != null) return nested
            }
            offset = span.encodedEnd
        }
        if (offset != end) {
            malformed(
                detail = "DG2 child TLV exceeds its parent",
                stage = Dg2DiagnosticStage.BDB_CONTAINER,
                offset = offset,
                field = "childTlv",
                remaining = end - offset,
            )
        }
        return null
    }

    private fun parseFaceInfo(encoded: ByteArray, span: Span): ImageSpan {
        val start = span.valueStart
        val end = span.valueEnd
        val valueLength = end - start
        if (valueLength < FACE_INFO_HEADER_BYTES) {
            malformed(
                detail = "FAC record header is truncated",
                stage = Dg2DiagnosticStage.FAC_IDENTIFIER,
                offset = start,
                field = "facHeader",
                remaining = valueLength,
            )
        }
        if (readUInt32(encoded, start) != FAC_FORMAT_IDENTIFIER.toLong()) {
            unsupported(
                detail = "DG2 facial block is not ISO 19794-5 FAC",
                stage = Dg2DiagnosticStage.FAC_IDENTIFIER,
                offset = start,
                field = "formatIdentifier",
                remaining = valueLength,
            )
        }
        if (readUInt32(encoded, start + 4) != FAC_VERSION.toLong()) {
            unsupported(
                detail = "unsupported ISO 19794-5 FAC version",
                stage = Dg2DiagnosticStage.FAC_VERSION,
                offset = start + 4,
                field = "version",
                remaining = end - (start + 4),
            )
        }

        val declaredRecordLength = readUInt32(encoded, start + 8)
        if (declaredRecordLength != valueLength.toLong()) {
            malformed(
                detail = "FAC record length does not match its TLV",
                stage = Dg2DiagnosticStage.FAC_RECORD_LENGTH,
                offset = start + 8,
                field = "recordLength",
                declared = declaredRecordLength.toDiagnosticInt(),
                remaining = valueLength,
            )
        }
        val recordEnd = end
        val imageCount = readUInt16(encoded, start + 12)
        if (imageCount == 0) {
            malformed(
                detail = "FAC record contains no face images",
                stage = Dg2DiagnosticStage.FAC_IMAGE_COUNT,
                offset = start + 12,
                field = "imageCount",
                remaining = end - (start + 12),
            )
        }

        var cursor = start + FACE_INFO_HEADER_BYTES
        var firstImage: ImageSpan? = null
        repeat(imageCount) {
            if (recordEnd - cursor < 4) {
                malformed(
                    detail = "face image record length is truncated",
                    stage = Dg2DiagnosticStage.FAC_IMAGE_INFO,
                    offset = cursor,
                    field = "imageRecordLength",
                    remaining = recordEnd - cursor,
                )
            }
            val recordLength = readUInt32(encoded, cursor)
            if (recordLength < 0L || recordLength > Int.MAX_VALUE.toLong()) {
                malformed(
                    detail = "face image record length is outside supported bounds",
                    stage = Dg2DiagnosticStage.FAC_RECORD_LENGTH,
                    offset = cursor,
                    field = "imageRecordLength",
                    declared = recordLength.toDiagnosticInt(),
                    remaining = recordEnd - cursor,
                )
            }
            if (recordEnd - cursor < 20) {
                malformed(
                    detail = "facial information block is truncated",
                    stage = Dg2DiagnosticStage.FAC_FEATURE_POINTS,
                    offset = cursor,
                    field = "facialInformationBlock",
                    declared = recordLength.toDiagnosticInt(),
                    remaining = recordEnd - cursor,
                )
            }
            val featurePointCount = readUInt16(encoded, cursor + 4)
            val featurePointBytes = featurePointCount.toLong() * 8L
            val minimumRecordLength = FACE_RECORD_FIXED_BYTES.toLong() + featurePointBytes
            if (recordLength < minimumRecordLength) {
                malformed(
                    detail = "face image record is shorter than its fixed fields",
                    stage = Dg2DiagnosticStage.FAC_RECORD_LENGTH,
                    offset = cursor,
                    field = "imageRecordLength",
                    declared = recordLength.toDiagnosticInt(),
                    remaining = recordEnd - cursor,
                )
            }
            val featurePointsEndLong = cursor.toLong() + 20L + featurePointBytes
            if (featurePointsEndLong > recordEnd.toLong()) {
                malformed(
                    detail = "face feature points are truncated",
                    stage = Dg2DiagnosticStage.FAC_FEATURE_POINTS,
                    offset = featurePointsEndLong.toDiagnosticInt() ?: cursor,
                    field = "featurePoints",
                    declared = featurePointCount,
                    remaining = recordEnd - cursor,
                )
            }
            val recordEndLong = cursor.toLong() + recordLength
            if (recordEndLong > recordEnd.toLong() || recordEndLong > encoded.size.toLong()) {
                malformed(
                    detail = "face image record exceeds FAC bounds",
                    stage = Dg2DiagnosticStage.FAC_IMAGE_INFO,
                    offset = cursor,
                    field = "imageRecordLength",
                    declared = recordLength.toDiagnosticInt(),
                    remaining = recordEnd - cursor,
                )
            }
            val imageInfoStartLong = cursor.toLong() + 20L + featurePointBytes
            val imageInfoEndLong = imageInfoStartLong + 12L
            if (imageInfoStartLong < cursor.toLong() || imageInfoEndLong > recordEndLong) {
                malformed(
                    detail = "face image information is truncated",
                    stage = Dg2DiagnosticStage.FAC_IMAGE_INFO,
                    offset = imageInfoStartLong.toDiagnosticInt() ?: cursor,
                    field = "imageInformation",
                    declared = 12,
                    remaining = (recordEndLong - imageInfoStartLong).toDiagnosticInt(),
                )
            }
            val imageInfoStart = imageInfoStartLong.toInt()
            val imageDataTypeOffset = imageInfoStart + 1
            val imageDataType = encoded[imageDataTypeOffset].u()
            val imageWidth = readUInt16(encoded, imageInfoStart + 2)
            val imageHeight = readUInt16(encoded, imageInfoStart + 4)
            val imageLength = recordEndLong - imageInfoEndLong
            if (imageLength <= 0L || imageLength > MAX_ENCODED_BYTES.toLong()) {
                malformed(
                    detail = "face image payload length is invalid",
                    stage = Dg2DiagnosticStage.FAC_IMAGE_LENGTH,
                    offset = imageInfoEndLong.toDiagnosticInt() ?: cursor,
                    field = "imageLength",
                    declared = imageLength.toDiagnosticInt(),
                    remaining = recordEnd - cursor,
                )
            }
            val imageStart = imageInfoEndLong.toInt()
            val imageEnd = recordEndLong.toInt()
            when (imageDataType) {
                0 -> validateJpeg(encoded, imageStart, imageEnd)
                1 -> validateJpeg2000(encoded, imageStart, imageEnd)
                else -> unsupported(
                    detail = "unsupported ISO 19794 image data type $imageDataType",
                    stage = Dg2DiagnosticStage.FAC_IMAGE_INFO,
                    offset = imageDataTypeOffset.toInt(),
                    field = "imageDataType",
                    remaining = imageEnd - imageDataTypeOffset.toInt(),
                )
            }
            if (firstImage == null) {
                firstImage = ImageSpan(
                    start = imageStart,
                    end = imageEnd,
                    imageDataType = imageDataType,
                    dataTypeOffset = imageDataTypeOffset,
                    facRecordLength = declaredRecordLength.toDiagnosticInt() ?: valueLength,
                    facialRecordCount = imageCount,
                    recordStart = cursor,
                    recordLength = recordLength.toInt(),
                    featurePointCount = featurePointCount,
                    imageInfoStart = imageInfoStart,
                    imageWidth = imageWidth,
                    imageHeight = imageHeight,
                )
            }
            cursor = recordEndLong.toInt()
        }
        if (cursor != recordEnd) {
            malformed(
                detail = "FAC contains trailing bytes after face records",
                stage = Dg2DiagnosticStage.FAC_IMAGE_INFO,
                offset = cursor,
                field = "faceRecords",
                remaining = recordEnd - cursor,
            )
        }
        return checkNotNull(firstImage)
    }

    private fun validateJpeg(encoded: ByteArray, start: Int, end: Int) {
        if (end - start < 4 || encoded[start].u() != 0xFF || encoded[start + 1].u() != 0xD8 ||
            encoded[end - 2].u() != 0xFF || encoded[end - 1].u() != 0xD9
        ) {
            malformed(
                detail = "declared JPEG payload has invalid SOI/EOI markers",
                stage = Dg2DiagnosticStage.FAC_IMAGE_MARKER,
                offset = start,
                field = "jpegMarker",
                remaining = end - start,
            )
        }
    }

    private fun validateJpeg2000(encoded: ByteArray, start: Int, end: Int) {
        val hasFileSignature = end - start >= 12 &&
            encoded[start].u() == 0x00 && encoded[start + 1].u() == 0x00 &&
            encoded[start + 2].u() == 0x00 && encoded[start + 3].u() == 0x0C &&
            encoded[start + 4].u() == 0x6A && encoded[start + 5].u() == 0x50 &&
            encoded[start + 6].u() == 0x20 && encoded[start + 7].u() == 0x20 &&
            encoded[start + 8].u() == 0x0D && encoded[start + 9].u() == 0x0A &&
            encoded[start + 10].u() == 0x87 && encoded[start + 11].u() == 0x0A
        val hasCodestreamSignature = end - start >= 4 &&
            encoded[start].u() == 0xFF && encoded[start + 1].u() == 0x4F &&
            encoded[start + 2].u() == 0xFF && encoded[start + 3].u() == 0x51
        if (!hasFileSignature && !hasCodestreamSignature) {
            malformed(
                detail = "declared JPEG2000 payload has no JP2 signature",
                stage = Dg2DiagnosticStage.FAC_IMAGE_MARKER,
                offset = start,
                field = "jpeg2000Marker",
                remaining = end - start,
            )
        }
    }

    private fun readSpan(encoded: ByteArray, offset: Int, limit: Int, stage: Dg2DiagnosticStage): Span {
        if (offset < 0 || offset >= limit || limit > encoded.size) {
            malformed("TLV offset is outside bounds", stage, offset, "tlvOffset", remaining = (limit - offset).coerceAtLeast(0))
        }
        val header = try {
            BerTlvLengthReader.readHeader(encoded, offset, limit - offset)
        } catch (error: LdsParseException) {
            parserFailure(
                error = error.error,
                detail = error.message ?: "TLV header is malformed",
                stage = stage,
                offset = offset,
                field = "tlvHeader",
                remaining = limit - offset,
                cause = error,
            )
        }
        val encodedLength = header.encodedLength
        if (encodedLength < header.headerLength || encodedLength > limit - offset) {
            malformed(
                detail = "TLV value exceeds its parent",
                stage = stage,
                offset = offset,
                field = "tlvLength",
                declared = header.valueLength,
                remaining = limit - offset,
            )
        }
        val valueStart = offset + header.headerLength
        return Span(
            tag = header.tag,
            valueStart = valueStart,
            valueEnd = valueStart + header.valueLength,
            encodedEnd = offset + encodedLength,
            constructed = (encoded[offset].u() and 0x20) != 0,
        )
    }

    private fun readUInt16(encoded: ByteArray, offset: Int): Int =
        (encoded[offset].u() shl 8) or encoded[offset + 1].u()

    private fun readUInt32(encoded: ByteArray, offset: Int): Long =
        (encoded[offset].u().toLong() shl 24) or
            (encoded[offset + 1].u().toLong() shl 16) or
            (encoded[offset + 2].u().toLong() shl 8) or
            encoded[offset + 3].u().toLong()

    private fun Byte.u(): Int = toInt() and 0xFF

    private fun Long.toDiagnosticInt(): Int? = takeIf { it in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong() }?.toInt()

    private data class Span(
        val tag: Int,
        val valueStart: Int,
        val valueEnd: Int,
        val encodedEnd: Int,
        val constructed: Boolean,
    )

    private data class ImageSpan(
        val start: Int,
        val end: Int,
        val imageDataType: Int,
        val dataTypeOffset: Int,
        val facRecordLength: Int,
        val facialRecordCount: Int,
        val recordStart: Int,
        val recordLength: Int,
        val featurePointCount: Int,
        val imageInfoStart: Int,
        val imageWidth: Int,
        val imageHeight: Int,
    )

    private class Dg2ParserFailure(
        val error: ReaderError,
        detail: String,
        cause: Throwable?,
        val diagnostic: Dg2Diagnostic,
    ) : RuntimeException(detail, cause)

    private fun malformed(
        detail: String,
        stage: Dg2DiagnosticStage,
        offset: Int?,
        field: String?,
        declared: Int? = null,
        remaining: Int? = null,
    ): Nothing = parserFailure(ReaderError.FILE_MALFORMED, detail, stage, offset, field, declared, remaining)

    private fun unsupported(
        detail: String,
        stage: Dg2DiagnosticStage,
        offset: Int?,
        field: String?,
        declared: Int? = null,
        remaining: Int? = null,
    ): Nothing = parserFailure(ReaderError.UNSUPPORTED_LAYOUT, detail, stage, offset, field, declared, remaining)

    private fun tooLarge(
        detail: String,
        stage: Dg2DiagnosticStage,
        offset: Int?,
        remaining: Int?,
    ): Nothing = parserFailure(ReaderError.FILE_TOO_LARGE, detail, stage, offset, "encodedLength", remaining = remaining)

    private fun parserFailure(
        error: ReaderError,
        detail: String,
        stage: Dg2DiagnosticStage,
        offset: Int?,
        field: String?,
        declared: Int? = null,
        remaining: Int? = null,
        cause: Throwable? = null,
    ): Nothing = throw Dg2ParserFailure(
        error = error,
        detail = detail,
        cause = cause,
        diagnostic = Dg2Diagnostic(
            source = Dg2DiagnosticSource.DG2_PARSER,
            stage = stage,
            failureOffset = offset,
            failureField = field,
            failureStage = stage,
            declaredLength = declared,
            remainingBytes = remaining,
        ),
    )
}
