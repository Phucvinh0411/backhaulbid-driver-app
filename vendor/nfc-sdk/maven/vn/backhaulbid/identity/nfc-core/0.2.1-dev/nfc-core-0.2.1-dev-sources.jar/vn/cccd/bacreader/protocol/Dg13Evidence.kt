package vn.cccd.bacreader.protocol

import vn.cccd.bacreader.crypto.LdsHashVerifier
import vn.cccd.bacreader.domain.LdsEvidencePart
import vn.cccd.bacreader.domain.SodData
import vn.cccd.bacreader.domain.SodReadStatus

/**
 * Decides whether raw DG13 bytes may be kept as evidence. They are trusted only when the signed EF.SOD lists DG13
 * with a digest that matches them. An unlisted or mismatched DG13 is never sent: the server rejects it, and an
 * unsigned data group is not evidence.
 */
internal object Dg13Evidence {
    fun trusted(sod: SodData?, raw: ByteArray): Boolean {
        if (raw.isEmpty() || raw.size > LdsEvidencePart.DG13.maximumBytes) return false
        if (sod == null || sod.readStatus != SodReadStatus.EF_SOD_READ_OK) return false
        val expected = sod.dataGroupHashes[DG13_NUMBER] ?: return false
        val algorithm = sod.digestAlgorithm ?: return false
        return expected.equals(LdsHashVerifier.digestHex(algorithm, raw), ignoreCase = true)
    }

    private const val DG13_NUMBER = 13
}
