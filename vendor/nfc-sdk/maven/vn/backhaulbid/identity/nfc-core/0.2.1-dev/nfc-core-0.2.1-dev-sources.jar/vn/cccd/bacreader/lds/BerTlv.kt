package vn.cccd.bacreader.lds

import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.domain.Dg2Diagnostic

/** A safe, definite-length BER-TLV header. */
class BerTlvHeader internal constructor(
    val tag: Int,
    val tagLength: Int,
    val valueLength: Int,
    val headerLength: Int,
) {
    val encodedLength: Int = headerLength + valueLength

    override fun toString(): String =
        "BerTlvHeader(tag=%0${tagLength * 2}X, valueLength=$valueLength)".format(tag)
}

/** An in-memory BER-TLV value whose bytes are copied at its boundary. */
class BerTlv internal constructor(
    val header: BerTlvHeader,
    value: ByteArray,
) : AutoCloseable {
    private var valueBytes: ByteArray? = value

    fun copyValue(): ByteArray = requireNotNull(valueBytes) { "BER-TLV value has been closed" }.copyOf()

    override fun close() {
        valueBytes?.fill(0)
        valueBytes = null
    }

    override fun toString(): String = "BerTlv(tag=%0${header.tagLength * 2}X, value=<redacted>)".format(header.tag)
}

class LdsParseException(
    val error: ReaderError,
    detail: String,
    cause: Throwable? = null,
    val diagnostic: Dg2Diagnostic? = null,
) : Exception("LDS parse failed: $error ($detail)", cause)

/**
 * Reads a BER-TLV header without ever trusting a card-provided length for allocation.
 *
 * Indefinite form is deliberately unsupported: the v0.1 LDS reader needs a definite
 * encoded length before it can make bounded READ BINARY requests.
 */
object BerTlvLengthReader {
    private const val MAX_TAG_OCTETS = 4
    private const val MAX_LENGTH_OCTETS = 3

    /**
     * Returns null only when [encoded] ends in the middle of a header. Malformed headers
     * and lengths beyond [maxEncodedLength] throw [LdsParseException].
     */
    fun tryReadHeader(
        encoded: ByteArray,
        offset: Int = 0,
        maxEncodedLength: Int = Int.MAX_VALUE,
    ): BerTlvHeader? {
        require(offset in 0..encoded.size) { "offset must point inside encoded data" }
        require(maxEncodedLength >= 0) { "maxEncodedLength must not be negative" }

        val tag = tryReadTag(encoded, offset) ?: return null
        var cursor = offset + tag.length
        if (cursor == encoded.size) return null

        val firstLengthByte = encoded[cursor++].unsigned()
        val valueLength = when {
            firstLengthByte < 0x80 -> firstLengthByte
            firstLengthByte == 0x80 -> throw malformed("indefinite BER lengths are unsupported")
            else -> {
                val lengthOctets = firstLengthByte and 0x7F
                if (lengthOctets > MAX_LENGTH_OCTETS) {
                    throw malformed("BER length uses too many octets")
                }
                if (encoded.size - cursor < lengthOctets) return null

                var length = 0
                repeat(lengthOctets) {
                    length = (length shl 8) or encoded[cursor++].unsigned()
                }
                length
            }
        }
        val headerLength = cursor - offset
        if (valueLength > maxEncodedLength - headerLength) {
            throw LdsParseException(ReaderError.FILE_TOO_LARGE, "BER-TLV exceeds configured cap")
        }
        return BerTlvHeader(
            tag = tag.value,
            tagLength = tag.length,
            valueLength = valueLength,
            headerLength = headerLength,
        )
    }

    fun readHeader(
        encoded: ByteArray,
        offset: Int = 0,
        maxEncodedLength: Int = Int.MAX_VALUE,
    ): BerTlvHeader = tryReadHeader(encoded, offset, maxEncodedLength)
        ?: throw malformed("truncated BER-TLV header")

    internal fun tryReadTag(encoded: ByteArray, offset: Int): BerTag? {
        if (offset == encoded.size) return null
        var cursor = offset
        var tagValue = encoded[cursor++].unsigned()
        var tagLength = 1
        if ((tagValue and 0x1F) != 0x1F) return BerTag(tagValue, tagLength)

        var firstHighTagOctet = true
        while (true) {
            if (cursor == encoded.size) return null
            if (tagLength == MAX_TAG_OCTETS) {
                throw malformed("BER tag uses too many octets")
            }
            val octet = encoded[cursor++].unsigned()
            if (firstHighTagOctet && (octet and 0x7F) == 0) {
                throw malformed("BER high-tag number is non-canonical")
            }
            firstHighTagOctet = false
            tagValue = (tagValue shl 8) or octet
            tagLength += 1
            if ((octet and 0x80) == 0) return BerTag(tagValue, tagLength)
        }
    }

    private fun malformed(detail: String): LdsParseException =
        LdsParseException(ReaderError.FILE_MALFORMED, detail)
}

/** Reads complete BER-TLV values after a caller has bounded the encoded file. */
object BerTlvReader {
    fun read(
        encoded: ByteArray,
        offset: Int = 0,
        maxEncodedLength: Int = Int.MAX_VALUE,
    ): BerTlv {
        val header = BerTlvLengthReader.readHeader(encoded, offset, maxEncodedLength)
        if (encoded.size - offset < header.encodedLength) {
            throw LdsParseException(ReaderError.FILE_MALFORMED, "truncated BER-TLV value")
        }
        val valueStart = offset + header.headerLength
        return BerTlv(header, encoded.copyOfRange(valueStart, valueStart + header.valueLength))
    }

    /**
     * Parses an exact BER-TLV sequence. It returns a list of [BerTlv], each carrying its
     * header and a defensive copy of its value. The aggregate sequence is cap-checked first.
     */
    fun readAll(
        encoded: ByteArray,
        maxEncodedLength: Int = Int.MAX_VALUE,
    ): List<BerTlv> {
        require(maxEncodedLength >= 0) { "maxEncodedLength must not be negative" }
        if (encoded.size > maxEncodedLength) {
            throw LdsParseException(ReaderError.FILE_TOO_LARGE, "BER-TLV sequence exceeds configured cap")
        }

        val values = ArrayList<BerTlv>()
        var offset = 0
        try {
            while (offset < encoded.size) {
                val value = read(encoded, offset, maxEncodedLength)
                values += value
                offset += value.header.encodedLength
            }
            return values
        } catch (error: Throwable) {
            values.forEach(BerTlv::close)
            throw error
        }
    }
}

internal class BerTag(
    val value: Int,
    val length: Int,
)

private fun Byte.unsigned(): Int = toInt() and 0xFF
