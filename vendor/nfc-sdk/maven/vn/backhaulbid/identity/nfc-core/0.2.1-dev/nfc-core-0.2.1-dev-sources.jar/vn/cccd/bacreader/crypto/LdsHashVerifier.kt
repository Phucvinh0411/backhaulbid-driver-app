package vn.cccd.bacreader.crypto

import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Locale

/** Hash helpers used by the passive-authentication ladder. */
object LdsHashVerifier {
    fun sha1Hex(data: ByteArray): String = digestHex("SHA-1", data)

    fun sha256Hex(data: ByteArray): String = digestHex("SHA-256", data)

    /** Compares a SOD hash without leaking mutable digest buffers or accepting malformed text. */
    fun matches(data: ByteArray, expectedHex: String, algorithmHint: String? = null): Boolean {
        val algorithm = if (algorithmHint != null) {
            canonicalAlgorithm(algorithmHint) ?: return false
        } else {
            when (expectedHex.length) {
                40 -> "SHA-1"
                56 -> "SHA-224"
                64 -> "SHA-256"
                96 -> "SHA-384"
                128 -> "SHA-512"
                else -> return false
            }
        }
        if (!expectedHex.matches(HEX_PATTERN)) return false
        val actual = try {
            digestHex(algorithm, data)
        } catch (_: java.security.NoSuchAlgorithmException) {
            return false
        }
        if (actual.length != expectedHex.length) return false
        val actualBytes = actual.uppercase(Locale.ROOT).toByteArray(StandardCharsets.US_ASCII)
        val expectedBytes = expectedHex.uppercase(Locale.ROOT).toByteArray(StandardCharsets.US_ASCII)
        return try {
            MessageDigest.isEqual(actualBytes, expectedBytes)
        } finally {
            actualBytes.fill(0)
            expectedBytes.fill(0)
        }
    }

    fun matchesSha256(data: ByteArray, expectedHex: String): Boolean =
        expectedHex.length == 64 && matches(data, expectedHex)

    fun digestHex(algorithm: String, data: ByteArray): String {
        val digest = MessageDigest.getInstance(algorithm).digest(data)
        return try {
            buildString(digest.size * 2) {
                digest.forEach { append("%02X".format(Locale.ROOT, it.toInt() and 0xFF)) }
            }
        } finally {
            digest.fill(0)
        }
    }

    private fun canonicalAlgorithm(value: String): String? = when (value.uppercase(Locale.ROOT).replace("-", "")) {
        "SHA1" -> "SHA-1"
        "SHA224" -> "SHA-224"
        "SHA256" -> "SHA-256"
        "SHA384" -> "SHA-384"
        "SHA512" -> "SHA-512"
        else -> null
    }

    private val HEX_PATTERN = Regex("[0-9A-Fa-f]{40}|[0-9A-Fa-f]{56}|[0-9A-Fa-f]{64}|[0-9A-Fa-f]{96}|[0-9A-Fa-f]{128}")
}
