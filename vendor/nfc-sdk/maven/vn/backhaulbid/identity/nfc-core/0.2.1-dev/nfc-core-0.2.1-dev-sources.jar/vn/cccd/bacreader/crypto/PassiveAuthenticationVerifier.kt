package vn.cccd.bacreader.crypto

import vn.cccd.bacreader.domain.AuthenticityResult
import vn.cccd.bacreader.domain.DigestStatus
import vn.cccd.bacreader.domain.IntegrityStatus
import vn.cccd.bacreader.domain.IssuerTrustStatus
import vn.cccd.bacreader.domain.PassiveAuthenticationStatus
import vn.cccd.bacreader.domain.SignatureStatus
import vn.cccd.bacreader.domain.SodData
import vn.cccd.bacreader.domain.SodReadStatus

/** Pure SOD/DG hash verification; signature and CSCA trust require explicit evidence. */
object PassiveAuthenticationVerifier {
    fun verify(sod: SodData?, dataGroups: Map<Int, ByteArray>): AuthenticityResult {
        if (sod == null) return AuthenticityResult()
        fun status(number: Int): DigestStatus {
            if (sod.readStatus != SodReadStatus.EF_SOD_READ_OK) return DigestStatus.NOT_ATTEMPTED
            val expected = sod.dataGroupHashes[number] ?: return DigestStatus.NOT_LISTED
            val bytes = dataGroups[number] ?: return DigestStatus.NOT_ATTEMPTED
            return if (LdsHashVerifier.matches(bytes, expected, sod.digestAlgorithm)) {
                DigestStatus.MATCH
            } else {
                DigestStatus.MISMATCH
            }
        }
        val dg1 = status(1)
        val dg2 = status(2)
        val comparisons = sod.dataGroupHashes.keys.map { number ->
            status(number)
        }.filter { it == DigestStatus.MATCH || it == DigestStatus.MISMATCH }
        val integrity = when {
            sod.readStatus != SodReadStatus.EF_SOD_READ_OK || comparisons.isEmpty() -> IntegrityStatus.INTEGRITY_NOT_VERIFIED
            comparisons.all { it == DigestStatus.MATCH } -> IntegrityStatus.DG_HASH_MATCH
            else -> IntegrityStatus.DG_HASH_MISMATCH
        }
        val passive = if (integrity == IntegrityStatus.DG_HASH_MATCH) {
            // This verifier has no CSCA trust-store input, so even a valid
            // presented DS signature is explicitly incomplete at the issuer level.
            PassiveAuthenticationStatus.PASSIVE_AUTHENTICATION_INCOMPLETE
        } else {
            PassiveAuthenticationStatus.NOT_VERIFIED
        }
        return AuthenticityResult(
            sodStatus = sod.readStatus,
            integrityStatus = integrity,
            dg1Digest = dg1,
            dg2Digest = dg2,
            signatureStatus = SignatureStatus.NOT_VERIFIED,
            issuerTrustStatus = IssuerTrustStatus.TRUST_NOT_ESTABLISHED,
            passiveAuthenticationStatus = passive,
        )
    }
}
