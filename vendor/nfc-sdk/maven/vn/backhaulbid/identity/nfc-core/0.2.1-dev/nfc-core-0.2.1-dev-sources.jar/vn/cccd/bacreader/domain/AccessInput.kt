package vn.cccd.bacreader.domain

import java.time.DateTimeException
import java.time.LocalDate

/**
 * User supplied BAC access data. Values are kept as strings so that a leading
 * zero in the document number is never lost during parsing or MRZ creation.
 */
class AccessInput private constructor(
    val cardNumber12: String,
    val birthYYMMDD: String,
    val expiryYYMMDD: String,
) {
    override fun toString(): String = "AccessInput(redacted)"

    companion object {
        fun create(cardNumber12: String, birthYYMMDD: String, expiryYYMMDD: String): AccessInput {
            if (!cardNumber12.matches(Regex("\\d{12}"))) {
                throw InputValidationException(InputValidationError.INVALID_CARD_NUMBER)
            }
            validateDate(birthYYMMDD, InputValidationError.INVALID_BIRTH_DATE)
            validateDate(expiryYYMMDD, InputValidationError.INVALID_EXPIRY_DATE)
            return AccessInput(cardNumber12, birthYYMMDD, expiryYYMMDD)
        }

        private fun validateDate(value: String, error: InputValidationError) {
            if (!value.matches(Regex("\\d{6}"))) {
                throw InputValidationException(error)
            }
            try {
                // BAC receives a two-digit year. For validation only, interpret
                // it in the 2000-2099 range; this still rejects impossible
                // month/day combinations (including 2099-02-29).
                LocalDate.of(
                    2000 + value.substring(0, 2).toInt(),
                    value.substring(2, 4).toInt(),
                    value.substring(4, 6).toInt(),
                )
            } catch (_: DateTimeException) {
                throw InputValidationException(error)
            }
        }
    }
}

enum class InputValidationError {
    INVALID_CARD_NUMBER,
    INVALID_BIRTH_DATE,
    INVALID_EXPIRY_DATE,
}

class InputValidationException(
    val error: InputValidationError,
) : IllegalArgumentException("Invalid BAC input: $error")
