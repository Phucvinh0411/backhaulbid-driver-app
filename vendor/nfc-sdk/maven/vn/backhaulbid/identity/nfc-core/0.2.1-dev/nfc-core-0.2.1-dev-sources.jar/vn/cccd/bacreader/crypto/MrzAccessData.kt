package vn.cccd.bacreader.crypto

import java.nio.charset.StandardCharsets.US_ASCII
import vn.cccd.bacreader.domain.AccessInput

/** Built 24-byte BAC MRZ information, retained only in wipeable storage. */
class MrzAccessData private constructor(
    private val mrzInformation: SensitiveBytes,
) : AutoCloseable {
    fun copyMrzInformation(): ByteArray = mrzInformation.copy()

    override fun close() = mrzInformation.close()

    override fun toString(): String = "MrzAccessData(<redacted>)"

    companion object {
        fun from(input: AccessInput): MrzAccessData {
            val documentNumber = input.cardNumber12.takeLast(9)
            val value = buildString(capacity = 24) {
                append(documentNumber)
                append(MrzCheckDigit.calculate(documentNumber))
                append(input.birthYYMMDD)
                append(MrzCheckDigit.calculate(input.birthYYMMDD))
                append(input.expiryYYMMDD)
                append(MrzCheckDigit.calculate(input.expiryYYMMDD))
            }
            val bytes = value.toByteArray(US_ASCII)
            check(bytes.size == 24) { "BAC MRZ information must be 24 bytes" }
            return MrzAccessData(SensitiveBytes(bytes))
        }
    }
}
