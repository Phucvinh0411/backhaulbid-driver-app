package vn.cccd.bacreader.lds

import java.nio.charset.StandardCharsets.US_ASCII

class Dg1 internal constructor(lines: List<String>) {
    val mrzLines: List<String> = lines.toList()
    val displayMrz: String get() = mrzLines.joinToString(separator = "\n")

    override fun toString(): String = "Dg1(<redacted>)"
}

object Dg1Parser {
    const val MAX_ENCODED_BYTES: Int = LdsFileLimits.DG1_MAX_ENCODED_BYTES

    fun parse(encoded: ByteArray): Dg1 {
        val root = readCompleteLdsFile(encoded, DG1_TAG, MAX_ENCODED_BYTES)
        val contents = root.copyValue()
        try {
            val fields = BerTlvReader.readAll(contents, maxEncodedLength = MAX_ENCODED_BYTES)
            var mrz: ByteArray? = null
            try {
                for (field in fields) {
                    if (field.header.tag == MRZ_TAG) {
                        if (mrz != null) throw malformedLds("DG1 repeats its MRZ field")
                        mrz = field.copyValue()
                    }
                }
                return decodeTd1Mrz(mrz ?: throw malformedLds("DG1 has no MRZ field"))
            } finally {
                fields.forEach(BerTlv::close)
                mrz?.fill(0)
            }
        } finally {
            contents.fill(0)
            root.close()
        }
    }

    private fun decodeTd1Mrz(raw: ByteArray): Dg1 {
        if (raw.size != TD1_TOTAL_LENGTH || raw.any { !it.isMrzCharacter() }) {
            throw malformedLds("DG1 MRZ is not three 30-character TD1 lines")
        }
        val text = raw.toString(US_ASCII)
        return Dg1(
            listOf(
                text.substring(0, TD1_LINE_LENGTH),
                text.substring(TD1_LINE_LENGTH, TD1_LINE_LENGTH * 2),
                text.substring(TD1_LINE_LENGTH * 2),
            ),
        )
    }

    private fun Byte.isMrzCharacter(): Boolean {
        val value = toInt() and 0xFF
        return value in 'A'.code..'Z'.code || value in '0'.code..'9'.code || value == '<'.code
    }

    private const val DG1_TAG = 0x61
    private const val MRZ_TAG = 0x5F1F
    private const val TD1_LINE_LENGTH = 30
    private const val TD1_TOTAL_LENGTH = TD1_LINE_LENGTH * 3
}
