package vn.cccd.bacreader.domain

/** Optional LDS files requested after the mandatory EF.COM + DG1 flow. */
enum class ExtendedFile {
    DG13,
    EF_SOD,
    DG2,
}

enum class FileReadStatus {
    NOT_PRESENT,
    NOT_REQUESTED,
    READ,
    UNREADABLE,
    NOT_ATTEMPTED,
}

enum class SodReadStatus {
    EF_SOD_NOT_ATTEMPTED,
    EF_SOD_READ_OK,
    EF_SOD_NOT_FOUND_IN_SELECTED_APPLICATION,
    EF_SOD_ACCESS_DENIED,
    EF_SOD_CONDITIONS_NOT_SATISFIED,
    EF_SOD_SECURE_MESSAGING_FAILURE,
    EF_SOD_INVALID_ENCODING,
    EF_SOD_PARSE_UNSUPPORTED;

    companion object {
        // Source-compatible aliases for callers that used the concise v0.2 names.
        val NOT_ATTEMPTED: SodReadStatus get() = EF_SOD_NOT_ATTEMPTED
        val READ_OK: SodReadStatus get() = EF_SOD_READ_OK
        val NOT_FOUND_IN_SELECTED_APPLICATION: SodReadStatus get() = EF_SOD_NOT_FOUND_IN_SELECTED_APPLICATION
        val ACCESS_DENIED: SodReadStatus get() = EF_SOD_ACCESS_DENIED
        val CONDITIONS_NOT_SATISFIED: SodReadStatus get() = EF_SOD_CONDITIONS_NOT_SATISFIED
        val SECURE_MESSAGING_FAILURE: SodReadStatus get() = EF_SOD_SECURE_MESSAGING_FAILURE
        val INVALID_ENCODING: SodReadStatus get() = EF_SOD_INVALID_ENCODING
        val PARSE_UNSUPPORTED: SodReadStatus get() = EF_SOD_PARSE_UNSUPPORTED
    }
}

enum class IntegrityStatus {
    NOT_ATTEMPTED,
    DG_HASH_MATCH,
    DG_HASH_MISMATCH,
    INTEGRITY_NOT_VERIFIED,
}

enum class SignatureStatus {
    NOT_ATTEMPTED,
    VALID,
    INVALID,
    NOT_VERIFIED,
    /** CMS signature is valid against the presented DS certificate only. */
    VALID_WITH_PRESENTED_DS,
    /** CMS signer could not be checked because no matching DS certificate was available. */
    NOT_VERIFIABLE_NO_DS_CERT;

    companion object {
        val SOD_SIGNATURE_VALID_WITH_PRESENTED_DS: SignatureStatus get() = VALID_WITH_PRESENTED_DS
        val SOD_SIGNATURE_INVALID: SignatureStatus get() = INVALID
        val SOD_SIGNATURE_NOT_VERIFIABLE_NO_DS_CERT: SignatureStatus get() = NOT_VERIFIABLE_NO_DS_CERT
        val SOD_SIGNATURE_NOT_ATTEMPTED: SignatureStatus get() = NOT_ATTEMPTED
    }
}

enum class IssuerTrustStatus {
    TRUST_ESTABLISHED,
    TRUST_NOT_ESTABLISHED,
}

enum class PassiveAuthenticationStatus {
    PASSIVE_AUTHENTICATION_COMPLETE,
    PASSIVE_AUTHENTICATION_INCOMPLETE,
    /** Legacy name retained for callers that treated a verified hash as success. */
    PASSIVE_AUTHENTICATION_OK,
    NOT_VERIFIED,
}

/** Per-data-group result of comparing the raw encoded DG bytes with EF.SOD. */
enum class DigestStatus {
    MATCH,
    MISMATCH,
    NOT_LISTED,
    NOT_ATTEMPTED;

    companion object {
        val DG1_SOD_DIGEST_MATCH: DigestStatus get() = MATCH
        val DG1_SOD_DIGEST_MISMATCH: DigestStatus get() = MISMATCH
        val DG1_SOD_DIGEST_NOT_LISTED: DigestStatus get() = NOT_LISTED
        val DG1_SOD_DIGEST_NOT_ATTEMPTED: DigestStatus get() = NOT_ATTEMPTED
        val DG2_SOD_DIGEST_MATCH: DigestStatus get() = MATCH
        val DG2_SOD_DIGEST_MISMATCH: DigestStatus get() = MISMATCH
        val DG2_SOD_DIGEST_NOT_LISTED: DigestStatus get() = NOT_LISTED
        val DG2_SOD_DIGEST_NOT_ATTEMPTED: DigestStatus get() = NOT_ATTEMPTED
    }
}

/** Provenance of the certificate used for CMS signature verification. */
enum class DsCertificateStatus {
    EMBEDDED,
    EXTERNAL,
    UNAVAILABLE;

    companion object {
        val DS_CERT_EMBEDDED: DsCertificateStatus get() = EMBEDDED
        val DS_CERT_EXTERNAL: DsCertificateStatus get() = EXTERNAL
        val DS_CERT_UNAVAILABLE: DsCertificateStatus get() = UNAVAILABLE
    }
}

data class AuthenticityResult(
    val sodStatus: SodReadStatus = SodReadStatus.EF_SOD_NOT_ATTEMPTED,
    val integrityStatus: IntegrityStatus = IntegrityStatus.NOT_ATTEMPTED,
    val signatureStatus: SignatureStatus = SignatureStatus.NOT_VERIFIED,
    val issuerTrustStatus: IssuerTrustStatus = IssuerTrustStatus.TRUST_NOT_ESTABLISHED,
    val passiveAuthenticationStatus: PassiveAuthenticationStatus = PassiveAuthenticationStatus.NOT_VERIFIED,
    val dg1Digest: DigestStatus = DigestStatus.NOT_ATTEMPTED,
    val dg2Digest: DigestStatus = DigestStatus.NOT_ATTEMPTED,
    val dsCertificateStatus: DsCertificateStatus = DsCertificateStatus.UNAVAILABLE,
) {
    // Descriptive aliases keep the UI and future SDK facade readable while the
    // compact fields remain stable for existing callers.
    val dg1DigestStatus: DigestStatus get() = dg1Digest
    val dg2DigestStatus: DigestStatus get() = dg2Digest
}

data class FileReadReport(
    val file: ExtendedFile,
    val status: FileReadStatus,
    val step: ScanStep,
    val error: ReaderError? = null,
    val sw: String? = null,
    val bytesRead: Int = 0,
    val sodStatus: SodReadStatus? = null,
    val metadata: Dg13Metadata? = null,
    val dg2Diagnostic: Dg2Diagnostic? = null,
)

enum class Dg13StructureStatus {
    RAW_READ_OK,
    LAYOUT_SUPPORTED,
    LAYOUT_UNSUPPORTED,
}

enum class Dg13ReadStatus {
    DG13_RAW_READ_OK,
    DG13_LAYOUT_SUPPORTED,
    DG13_LAYOUT_UNSUPPORTED,
}

data class Dg13Metadata(
    val rawLength: Int,
    val firstTag: Int?,
    val declaredLength: Int?,
    val chunkCount: Int,
    val secureMessagingVerified: Boolean,
    val structureStatus: Dg13StructureStatus = Dg13StructureStatus.RAW_READ_OK,
    val readStatus: Dg13ReadStatus = Dg13ReadStatus.DG13_RAW_READ_OK,
)

data class Dg13Field(
    val tag: Int,
    val label: String,
    val value: String,
)

data class Dg13Data(
    val fields: List<Dg13Field>,
    val encodedBytes: Int,
    val metadata: Dg13Metadata? = null,
)

enum class Dg2ImageFormat {
    JPEG,
    JPEG2000,
}

data class Dg2Data(
    val format: Dg2ImageFormat,
    val encodedBytes: Int,
    val imageBytes: Int,
)

enum class SodSignatureStatus {
    NOT_VERIFIED,
    VALID_WITH_PRESENTED_DS,
    INVALID,
    NOT_VERIFIABLE_NO_DS_CERT,
    NOT_ATTEMPTED;

    companion object {
        val SOD_SIGNATURE_VALID_WITH_PRESENTED_DS: SodSignatureStatus get() = VALID_WITH_PRESENTED_DS
        val SOD_SIGNATURE_INVALID: SodSignatureStatus get() = INVALID
        val SOD_SIGNATURE_NOT_VERIFIABLE_NO_DS_CERT: SodSignatureStatus get() = NOT_VERIFIABLE_NO_DS_CERT
        val SOD_SIGNATURE_NOT_ATTEMPTED: SodSignatureStatus get() = NOT_ATTEMPTED
    }
}

data class SodData(
    val encodedBytes: Int,
    val cmsEnvelopePresent: Boolean,
    val signatureStatus: SodSignatureStatus,
    val readStatus: SodReadStatus = SodReadStatus.EF_SOD_READ_OK,
    val dataGroupHashes: Map<Int, String> = emptyMap(),
    /** JCA MessageDigest name extracted from LDSSecurityObject, when parseable. */
    val digestAlgorithm: String? = null,
    val dsCertificateStatus: DsCertificateStatus = DsCertificateStatus.UNAVAILABLE,
)

data class ReaderOptions(
    /** DG2 is metadata-only and can be enabled by the caller. */
    val readDg2: Boolean = false,
    /** DG13 is an optional extension and is never read by default. */
    val readDg13: Boolean = false,
    /** Signature verification is enabled by default once a CMS envelope is available. */
    val verifySodSignature: Boolean = true,
    /** No trust anchors are bundled in the app; this remains false by default. */
    val verifyCscaTrust: Boolean = false,
    /** Keeps raw LDS bytes in [ReadResult.Success.evidence]. Off by default so raw bytes stay out of memory unless requested. */
    val captureEvidence: Boolean = false,
)
