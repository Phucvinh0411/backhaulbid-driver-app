package vn.cccd.bacreader.sdk

import java.util.UUID

/**
 * Short-lived holder for captured evidence. Entries are scoped to an owner and attempt, expire on their own, and are
 * closed when disposed, swept, or when the store closes. Capacity is deliberately small.
 */
class EvidenceStore<T : AutoCloseable>(private val nowMillis: () -> Long) : AutoCloseable {
    private val entries: MutableMap<String, Entry<T>> = LinkedHashMap()
    private var closed = false

    @Synchronized
    fun put(owner: String, attempt: String, expiresAtMillis: Long, payload: T): String {
        if (closed) {
            payload.close()
            throw IllegalStateException("Evidence store closed")
        }
        if (owner.isBlank() || attempt.isBlank() || expiresAtMillis <= nowMillis()) {
            payload.close()
            throw IllegalArgumentException("Invalid evidence scope")
        }
        sweep()
        // Capacity is deliberately small: at most four evidence payloads may be held at once.
        if (entries.size >= 4) {
            payload.close()
            throw IllegalStateException("Evidence capacity exceeded")
        }
        val handle = UUID.randomUUID().toString()
        entries[handle] = Entry(owner, attempt, expiresAtMillis, payload)
        return handle
    }

    /** Returns the payload only when both owner and attempt match. Expired entries are swept first. */
    @Synchronized
    fun borrow(handle: String, owner: String, attempt: String): T? {
        sweep()
        val entry = entries[handle] ?: return null
        return if (entry.owner == owner && entry.attempt == attempt) entry.payload else null
    }

    @Synchronized
    fun dispose(handle: String, owner: String): Boolean {
        val entry = entries[handle] ?: return false
        if (entry.owner != owner) return false
        entries.remove(handle)
        runCatching { entry.payload.close() }
        return true
    }

    @Synchronized
    fun disposeOwner(owner: String) {
        val handles = entries.filterValues { it.owner == owner }.keys.toList()
        handles.forEach { dispose(it, owner) }
    }

    @Synchronized
    fun sweep() {
        val now = nowMillis()
        val expired = entries.filterValues { it.expiresAt <= now }.keys.toList()
        expired.forEach { handle ->
            val removed = entries.remove(handle)
            runCatching { removed?.payload?.close() }
        }
    }

    /** Idempotent. Closes every remaining payload and empties the store. */
    @Synchronized
    override fun close() {
        if (closed) return
        closed = true
        val payloads = entries.values.map { it.payload }
        entries.clear()
        payloads.forEach { runCatching { it.close() } }
    }

    private data class Entry<T>(val owner: String, val attempt: String, val expiresAt: Long, val payload: T)
}
