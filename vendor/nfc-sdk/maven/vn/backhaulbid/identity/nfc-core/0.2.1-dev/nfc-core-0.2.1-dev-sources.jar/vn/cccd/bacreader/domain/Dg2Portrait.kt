package vn.cccd.bacreader.domain

/**
 * A short-lived DG2 image payload whose byte ownership belongs to this object.
 *
 * The payload is never persisted, cached, or logged. Callers must close this object as
 * soon as decoding/embedding is complete. Closing wipes the byte array controlled by this
 * object; it cannot promise zeroization of copies made by platform codecs or bitmaps.
 */
class Dg2Portrait(
    val format: Dg2ImageFormat,
    encodedImage: ByteArray,
) : AutoCloseable {
    private var encodedBytes: ByteArray? = encodedImage

    val encodedLength: Int
        get() = requireBytes().size

    /** Returns a defensive copy for a decoder. The caller must not retain it longer than needed. */
    fun copyEncodedImage(): ByteArray = requireBytes().copyOf()

    override fun close() {
        encodedBytes?.fill(0)
        encodedBytes = null
    }

    private fun requireBytes(): ByteArray =
        checkNotNull(encodedBytes) { "DG2 portrait has been closed" }
}
