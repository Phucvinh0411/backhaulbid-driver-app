package vn.cccd.bacreader.domain

/**
 * Raw LDS files that can leave the reader as evidence. Declaration order and [maximumBytes] are part of the SDK
 * contract. DG13 is appended last so the ordinals of DG1, DG2 and SOD do not change.
 */
enum class LdsEvidencePart(val maximumBytes: Int) {
    DG1(16 * 1024),
    DG2(2 * 1024 * 1024),
    SOD(256 * 1024),

    /** Optional personal-data group. Its absence never makes the evidence incomplete. */
    DG13(128 * 1024),
}
