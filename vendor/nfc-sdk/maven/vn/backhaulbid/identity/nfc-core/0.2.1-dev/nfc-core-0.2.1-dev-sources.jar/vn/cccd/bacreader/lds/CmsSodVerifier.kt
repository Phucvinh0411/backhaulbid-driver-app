package vn.cccd.bacreader.lds

import java.security.cert.CertPathValidator
import java.security.cert.CertificateFactory
import java.security.cert.PKIXParameters
import java.security.cert.TrustAnchor
import java.security.cert.X509Certificate
import org.bouncycastle.cert.X509CertificateHolder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cms.CMSSignedData
import org.bouncycastle.cms.SignerInformation
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder
import org.bouncycastle.util.Selector
import vn.cccd.bacreader.domain.DsCertificateStatus
import vn.cccd.bacreader.domain.IssuerTrustStatus
import vn.cccd.bacreader.domain.SodSignatureStatus

/**
 * Verifies the CMS signature carried by EF.SOD with Bouncy Castle.
 *
 * The result deliberately stops at the cryptographic boundary: a signature that
 * verifies against an embedded DS certificate is not issuer trust. CSCA path
 * validation is opt-in and remains unestablished when no trust anchors are supplied.
 */
object CmsSodVerifier {
    data class Result(
        val signatureStatus: SodSignatureStatus,
        val dsCertificateStatus: DsCertificateStatus,
        val issuerTrustStatus: IssuerTrustStatus,
    )

    fun verify(
        encodedEfSod: ByteArray,
        verifySignature: Boolean = true,
        verifyCscaTrust: Boolean = false,
        externalDsCertificates: Collection<X509Certificate> = emptyList(),
        cscaTrustAnchors: Collection<X509Certificate> = emptyList(),
    ): Result {
        if (!verifySignature) {
            return Result(
                signatureStatus = SodSignatureStatus.NOT_ATTEMPTED,
                dsCertificateStatus = DsCertificateStatus.UNAVAILABLE,
                issuerTrustStatus = IssuerTrustStatus.TRUST_NOT_ESTABLISHED,
            )
        }
        val cmsBytes = try {
            val root = BerTlvReader.read(encodedEfSod, maxEncodedLength = SodParser.MAX_ENCODED_BYTES)
            try {
                if (root.header.tag != 0x77 || root.header.encodedLength != encodedEfSod.size) return notVerifiable()
                root.copyValue()
            } finally {
                root.close()
            }
        } catch (_: Exception) {
            return notVerifiable()
        }
        return try {
            val signedData = CMSSignedData(cmsBytes)
            val signer = signedData.signerInfos.signers.firstOrNull() ?: return Result(
                signatureStatus = SodSignatureStatus.NOT_VERIFIABLE_NO_DS_CERT,
                dsCertificateStatus = DsCertificateStatus.UNAVAILABLE,
                issuerTrustStatus = IssuerTrustStatus.TRUST_NOT_ESTABLISHED,
            )
            val embedded = matchingCertificate(signedData, signer)
            val external = if (embedded == null) matchingExternalCertificate(signer, externalDsCertificates) else null
            val certificate = embedded ?: external
            if (certificate == null) return Result(
                    signatureStatus = SodSignatureStatus.NOT_VERIFIABLE_NO_DS_CERT,
                    dsCertificateStatus = DsCertificateStatus.UNAVAILABLE,
                    issuerTrustStatus = IssuerTrustStatus.TRUST_NOT_ESTABLISHED,
                )
            val signatureValid = try {
                signer.verify(
                    JcaSimpleSignerInfoVerifierBuilder()
                        .setProvider(BC_PROVIDER)
                        .build(certificate),
                )
            } catch (_: Exception) {
                false
            }
            val trust = if (verifyCscaTrust && signatureValid && cscaTrustAnchors.isNotEmpty()) {
                if (isTrusted(certificate, cscaTrustAnchors)) {
                    IssuerTrustStatus.TRUST_ESTABLISHED
                } else {
                    IssuerTrustStatus.TRUST_NOT_ESTABLISHED
                }
            } else {
                // No CSCA trust anchors are bundled by design. Keep this explicit so a
                // future trust-store implementation cannot silently infer trust.
                IssuerTrustStatus.TRUST_NOT_ESTABLISHED
            }
            Result(
                signatureStatus = if (signatureValid) {
                    SodSignatureStatus.VALID_WITH_PRESENTED_DS
                } else {
                    SodSignatureStatus.INVALID
                },
                dsCertificateStatus = if (embedded != null) {
                    DsCertificateStatus.EMBEDDED
                } else {
                    DsCertificateStatus.EXTERNAL
                },
                issuerTrustStatus = trust,
            )
        } catch (_: Exception) {
            notVerifiable()
        } finally {
            cmsBytes.fill(0)
        }
    }

    private fun matchingCertificate(
        signedData: CMSSignedData,
        signer: SignerInformation,
    ): java.security.cert.X509Certificate? {
        @Suppress("UNCHECKED_CAST")
        val selector = signer.sid as Selector<X509CertificateHolder>
        val matches = signedData.certificates.getMatches(selector)
        val holder = matches.firstOrNull() as? X509CertificateHolder ?: return null
        return JcaX509CertificateConverter()
            .setProvider(BC_PROVIDER)
            .getCertificate(holder)
    }

    private fun matchingExternalCertificate(
        signer: SignerInformation,
        candidates: Collection<X509Certificate>,
    ): X509Certificate? = candidates.firstOrNull { certificate ->
        try {
            signer.sid.match(X509CertificateHolder(certificate.encoded))
        } catch (_: Exception) {
            false
        }
    }

    private fun isTrusted(certificate: X509Certificate, anchors: Collection<X509Certificate>): Boolean = try {
        val certFactory = CertificateFactory.getInstance("X.509")
        val path = certFactory.generateCertPath(listOf(certificate))
        val parameters = PKIXParameters(anchors.map { TrustAnchor(it, null) }.toSet()).apply {
            isRevocationEnabled = false
        }
        CertPathValidator.getInstance("PKIX").validate(path, parameters)
        true
    } catch (_: Exception) {
        false
    }

    private fun notVerifiable() = Result(
        signatureStatus = SodSignatureStatus.NOT_VERIFIABLE_NO_DS_CERT,
        dsCertificateStatus = DsCertificateStatus.UNAVAILABLE,
        issuerTrustStatus = IssuerTrustStatus.TRUST_NOT_ESTABLISHED,
    )

    // Pass the pinned provider instance directly instead of relying on the
    // platform's provider named "BC", which varies across Android releases.
    private val BC_PROVIDER = BouncyCastleProvider()
}
