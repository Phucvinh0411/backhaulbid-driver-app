package vn.cccd.bacreader.crypto

import java.security.GeneralSecurityException
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/** JCA 2-key DESede CBC primitive used by BAC and secure messaging. */
internal object BacCipher {
    fun encrypt(input: ByteArray, key24: ByteArray, iv: ByteArray = ByteArray(8)): ByteArray =
        crypt(Cipher.ENCRYPT_MODE, input, key24, iv)

    fun decrypt(input: ByteArray, key24: ByteArray, iv: ByteArray = ByteArray(8)): ByteArray =
        crypt(Cipher.DECRYPT_MODE, input, key24, iv)

    private fun crypt(mode: Int, input: ByteArray, key24: ByteArray, iv: ByteArray): ByteArray {
        require(key24.size == 24) { "DESede key must be 24 bytes" }
        require(iv.size == 8) { "DESede IV must be 8 bytes" }
        require(input.size % 8 == 0) { "DESede input must be block aligned" }
        return try {
            Cipher.getInstance("DESede/CBC/NoPadding").apply {
                init(mode, SecretKeySpec(key24, "DESede"), IvParameterSpec(iv))
            }.doFinal(input)
        } catch (error: GeneralSecurityException) {
            throw IllegalStateException("DESede is unavailable", error)
        }
    }
}
