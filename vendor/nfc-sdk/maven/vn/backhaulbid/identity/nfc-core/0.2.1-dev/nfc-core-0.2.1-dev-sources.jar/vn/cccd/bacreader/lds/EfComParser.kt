package vn.cccd.bacreader.lds

import java.nio.charset.StandardCharsets.US_ASCII

class EfCom internal constructor(
    val ldsVersion: String?,
    val unicodeVersion: String?,
    dataGroupTags: Set<Int>,
) {
    val dataGroupTags: Set<Int> = dataGroupTags.toSet()

    fun containsDataGroupTag(tag: Int): Boolean = tag in dataGroupTags

    override fun toString(): String = "EfCom(dataGroupCount=${dataGroupTags.size})"
}

object EfComParser {
    const val MAX_ENCODED_BYTES: Int = LdsFileLimits.EF_COM_MAX_ENCODED_BYTES

    fun parse(encoded: ByteArray): EfCom {
        val root = readCompleteLdsFile(encoded, EF_COM_TAG, MAX_ENCODED_BYTES)
        val contents = root.copyValue()
        try {
            val fields = BerTlvReader.readAll(contents, maxEncodedLength = MAX_ENCODED_BYTES)
            try {
                var ldsVersion: String? = null
                var unicodeVersion: String? = null
                var dataGroupTags: Set<Int>? = null
                for (field in fields) {
                    when (field.header.tag) {
                        LDS_VERSION_TAG -> {
                            if (ldsVersion != null) throw malformedLds("EF.COM repeats its LDS version")
                            ldsVersion = decodePrintableAscii(field)
                        }
                        UNICODE_VERSION_TAG -> {
                            if (unicodeVersion != null) throw malformedLds("EF.COM repeats its Unicode version")
                            unicodeVersion = decodePrintableAscii(field)
                        }
                        TAG_LIST_TAG -> {
                            if (dataGroupTags != null) throw malformedLds("EF.COM repeats its tag list")
                            dataGroupTags = parseTagList(field)
                        }
                    }
                }
                return EfCom(
                    ldsVersion = ldsVersion,
                    unicodeVersion = unicodeVersion,
                    dataGroupTags = dataGroupTags ?: throw malformedLds("EF.COM has no data group tag list"),
                )
            } finally {
                fields.forEach(BerTlv::close)
            }
        } finally {
            contents.fill(0)
            root.close()
        }
    }

    private fun parseTagList(field: BerTlv): Set<Int> {
        val bytes = field.copyValue()
        try {
            if (bytes.isEmpty()) throw malformedLds("EF.COM data group tag list is empty")
            val tags = LinkedHashSet<Int>()
            var offset = 0
            while (offset < bytes.size) {
                val tag = BerTlvLengthReader.tryReadTag(bytes, offset)
                    ?: throw malformedLds("EF.COM data group tag list is truncated")
                if (!tags.add(tag.value)) throw malformedLds("EF.COM data group tag list repeats a tag")
                offset += tag.length
            }
            return tags
        } finally {
            bytes.fill(0)
        }
    }

    private fun decodePrintableAscii(field: BerTlv): String {
        val bytes = field.copyValue()
        try {
            if (bytes.any { it.unsigned() !in 0x20..0x7E }) {
                throw malformedLds("EF.COM version is not printable ASCII")
            }
            return bytes.toString(US_ASCII)
        } finally {
            bytes.fill(0)
        }
    }

    private fun Byte.unsigned(): Int = toInt() and 0xFF

    private const val EF_COM_TAG = 0x60
    private const val LDS_VERSION_TAG = 0x5F01
    private const val UNICODE_VERSION_TAG = 0x5F36
    private const val TAG_LIST_TAG = 0x5C
}
