package vn.cccd.bacreader.protocol

import vn.cccd.bacreader.domain.Dg2ChunkFailureType

/** Safe metadata emitted around one protected transceive. */
data class ProtectedTransceiveTrace(
    val encodedCommandLength: Int,
    val transceiveDurationMillis: Long,
    val statusWord: Int? = null,
    val receivedPlainLength: Int? = null,
    val isoDepConnected: Boolean? = null,
    val isoDepTimeoutMillis: Int? = null,
    val isoDepMaxTransceiveLength: Int? = null,
    val failureType: Dg2ChunkFailureType? = null,
)

/** Optional diagnostics boundary; normal protected-channel callers remain unchanged. */
interface ProtectedChannelDiagnostics {
    val effectiveTransceiveMaximum: Int?
    val secureMessagingOverhead: Int?

    fun readBinaryWithDiagnostics(
        offset: Int,
        length: Int,
        onTrace: (ProtectedTransceiveTrace) -> Unit,
    ): ProtectedResponse

    fun readBinaryBySfiWithDiagnostics(
        sfi: Int,
        offset: Int,
        length: Int,
        onTrace: (ProtectedTransceiveTrace) -> Unit,
    ): ProtectedResponse = throw SecureMessagingException(vn.cccd.bacreader.domain.ReaderError.PROTECTED_STATUS_ERROR)
}
