package vn.cccd.bacreader.lds

import vn.cccd.bacreader.domain.SodData

/** Named parser facade matching the LDS pipeline terminology. */
object EfSodParser {
    const val MAX_ENCODED_BYTES: Int = SodParser.MAX_ENCODED_BYTES

    fun parse(encoded: ByteArray): SodData = SodParser.parse(encoded)
}
