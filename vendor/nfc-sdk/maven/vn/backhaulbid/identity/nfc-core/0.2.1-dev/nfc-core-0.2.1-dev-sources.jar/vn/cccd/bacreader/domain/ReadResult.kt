package vn.cccd.bacreader.domain

/** In-memory outcome only; no result type is Parcelable or persisted. */
sealed interface ReadResult : AutoCloseable {
    /** Releases any short-lived biometric payload owned by this outcome. */
    override fun close() = Unit

    data class Success(
        val dg1Mrz: String,
        val efComBytes: Int,
        val dg1Bytes: Int,
        val elapsedMillis: Long,
        val dg13: Dg13Data? = null,
        val dg2: Dg2Data? = null,
        val sod: SodData? = null,
        val optionalFiles: List<FileReadReport> = emptyList(),
        val authenticity: AuthenticityResult = AuthenticityResult(),
        val dg2Portrait: Dg2Portrait? = null,
        /** Raw LDS bytes for the evidence upload. Null unless [ReaderOptions.captureEvidence] was set. */
        val evidence: LdsEvidence? = null,
    ) : ReadResult {
        override fun close() {
            dg2Portrait?.close()
            evidence?.close()
        }
    }

    data class Failure(
        val step: ScanStep,
        val error: ReaderError,
        val sw: String? = null,
        val bytesRead: Int = 0,
        val elapsedMillis: Long,
    ) : ReadResult
}
