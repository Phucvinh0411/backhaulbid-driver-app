package vn.cccd.bacreader.lds

import vn.cccd.bacreader.domain.ReaderError

object LdsFileLimits {
    const val EF_COM_MAX_ENCODED_BYTES = 4 * 1024
    const val DG1_MAX_ENCODED_BYTES = 16 * 1024
    const val DG13_MAX_ENCODED_BYTES = 128 * 1024
    const val DG2_MAX_ENCODED_BYTES = 2 * 1024 * 1024
    const val EF_SOD_MAX_ENCODED_BYTES = 256 * 1024
}

internal fun readCompleteLdsFile(
    encoded: ByteArray,
    expectedTag: Int,
    maxEncodedBytes: Int,
): BerTlv {
    if (encoded.size > maxEncodedBytes) {
        throw LdsParseException(ReaderError.FILE_TOO_LARGE, "encoded LDS file exceeds configured cap")
    }
    val root = BerTlvReader.read(encoded, maxEncodedLength = maxEncodedBytes)
    if (root.header.encodedLength != encoded.size) {
        root.close()
        throw malformedLds("LDS file contains trailing bytes")
    }
    if (root.header.tag != expectedTag) {
        root.close()
        throw malformedLds("unexpected LDS outer tag")
    }
    return root
}

internal fun malformedLds(detail: String): LdsParseException =
    LdsParseException(ReaderError.FILE_MALFORMED, detail)
