package vn.cccd.bacreader.crypto

import java.security.MessageDigest

/** ICAO BAC SHA-1 KDF and two-key DESede key normalization. */
object BacKeyDeriver {
    fun derive(mrzInformation: ByteArray): BacKeyMaterial {
        require(mrzInformation.size == 24) { "MRZ information must be 24 bytes" }
        val digest = MessageDigest.getInstance("SHA-1")
        val seedDigest = digest.digest(mrzInformation)
        val kSeed = try {
            seedDigest.copyOf(16)
        } finally {
            seedDigest.fill(0)
        }
        try {
            val kEncRaw = deriveKey(digest, kSeed, 1)
            try {
                val kMacRaw = deriveKey(digest, kSeed, 2)
                try {
                    return BacKeyMaterial(kSeed, kEncRaw, kMacRaw)
                } finally {
                    kMacRaw.fill(0)
                }
            } finally {
                kEncRaw.fill(0)
            }
        } finally {
            kSeed.fill(0)
        }
    }

    /** Derives session keys from KSseed after BAC mutual authentication. */
    fun deriveFromSeed(sessionSeed: ByteArray): BacKeyMaterial {
        require(sessionSeed.size == 16) { "BAC session seed must be 16 bytes" }
        val digest = MessageDigest.getInstance("SHA-1")
        val seedCopy = sessionSeed.copyOf()
        try {
            val enc = deriveKey(digest, sessionSeed, 1)
            try {
                val mac = deriveKey(digest, sessionSeed, 2)
                try {
                    return BacKeyMaterial(seedCopy, enc, mac)
                } finally {
                    mac.fill(0)
                }
            } finally {
                enc.fill(0)
            }
        } finally {
            seedCopy.fill(0)
        }
    }

    private fun deriveKey(digest: MessageDigest, kSeed: ByteArray, counter: Int): ByteArray {
        val input = ByteArray(kSeed.size + 4)
        kSeed.copyInto(input)
        input[input.lastIndex - 3] = (counter ushr 24).toByte()
        input[input.lastIndex - 2] = (counter ushr 16).toByte()
        input[input.lastIndex - 1] = (counter ushr 8).toByte()
        input[input.lastIndex] = counter.toByte()
        return try {
            // The KDF returns raw hash bytes. DES odd parity is applied only
            // when the 16-byte material is expanded for a DESede primitive.
            val output = digest.digest(input)
            try {
                output.copyOf(16)
            } finally {
                output.fill(0)
            }
        } finally {
            input.fill(0)
        }
    }

    /** Expands 16 raw bytes to K1 || K2 || K1 and applies DES odd parity. */
    fun toDesEdeKey(raw16: ByteArray): ByteArray {
        require(raw16.size == 16) { "Two-key DESede material must be 16 bytes" }
        val expanded = ByteArray(24).also {
            raw16.copyInto(it, destinationOffset = 0, startIndex = 0, endIndex = 8)
            raw16.copyInto(it, destinationOffset = 8, startIndex = 8, endIndex = 16)
            raw16.copyInto(it, destinationOffset = 16, startIndex = 0, endIndex = 8)
        }
        return try {
            ByteArray(expanded.size) { index ->
                val withoutParity = expanded[index].toInt() and 0xFE
                val parity = if (Integer.bitCount(withoutParity) % 2 == 0) 1 else 0
                (withoutParity or parity).toByte()
            }
        } finally {
            expanded.fill(0)
        }
    }
}

class BacKeyMaterial internal constructor(
    kSeed: ByteArray,
    kEncRaw: ByteArray,
    kMacRaw: ByteArray,
) : AutoCloseable {
    private val seed = SensitiveBytes(kSeed)
    private val encRaw = SensitiveBytes(kEncRaw)
    private val macRaw = SensitiveBytes(kMacRaw)

    fun copyKSeed(): ByteArray = seed.copy()
    fun copyKEncRaw(): ByteArray = encRaw.copy()
    fun copyKMacRaw(): ByteArray = macRaw.copy()
    fun copyKEncDesEde(): ByteArray = deriveDesEde(encRaw)
    fun copyKMacDesEde(): ByteArray = deriveDesEde(macRaw)

    private fun deriveDesEde(raw: SensitiveBytes): ByteArray {
        val copy = raw.copy()
        return try {
            BacKeyDeriver.toDesEdeKey(copy)
        } finally {
            copy.fill(0)
        }
    }

    override fun close() {
        seed.close()
        encRaw.close()
        macRaw.close()
    }

    override fun toString(): String = "BacKeyMaterial(<redacted>)"
}
