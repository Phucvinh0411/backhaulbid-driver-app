package vn.cccd.bacreader.domain

import java.io.OutputStream

/**
 * Raw LDS bytes captured during one read. A single holder owns the bytes: [transfer] moves them to a new instance
 * and closes this one, and [close] wipes every buffer.
 */
class LdsEvidence : AutoCloseable {
    private val parts: MutableMap<LdsEvidencePart, ByteArray> = LinkedHashMap()
    private var closed = false

    /** Stores a private copy of [encoded], replacing and wiping any earlier bytes for [part]. */
    @Synchronized
    internal fun capture(part: LdsEvidencePart, encoded: ByteArray) {
        check(!closed) { "Evidence closed" }
        require(encoded.isNotEmpty() && encoded.size <= part.maximumBytes) { "Evidence size exceeded" }
        parts.remove(part)?.fill(0)
        parts[part] = encoded.copyOf()
    }

    /** True when DG1, DG2 and SOD are present. DG13 is optional and does not affect this result. */
    val isComplete: Boolean
        @Synchronized get() = !closed && parts.keys.containsAll(listOf(LdsEvidencePart.DG1, LdsEvidencePart.DG2, LdsEvidencePart.SOD))

    /** True when [part] is held and the evidence has not been transferred or closed. Lets callers skip optional parts. */
    @Synchronized
    fun has(part: LdsEvidencePart): Boolean = !closed && parts.containsKey(part)

    @Synchronized
    fun writeTo(part: LdsEvidencePart, output: OutputStream) {
        check(!closed) { "Evidence closed" }
        val bytes = parts[part] ?: throw IllegalStateException("Evidence part unavailable")
        output.write(bytes)
    }

    @Synchronized
    fun transfer(): LdsEvidence {
        check(!closed) { "Evidence closed" }
        val moved = LdsEvidence()
        moved.parts.putAll(parts)
        parts.clear()
        closed = true
        return moved
    }

    @Synchronized
    override fun close() {
        if (closed) return
        closed = true
        parts.values.forEach { it.fill(0) }
        parts.clear()
    }
}
