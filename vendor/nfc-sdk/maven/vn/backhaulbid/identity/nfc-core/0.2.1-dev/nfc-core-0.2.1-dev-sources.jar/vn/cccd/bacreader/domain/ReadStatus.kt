package vn.cccd.bacreader.domain

/** Compatibility alias for the generic per-file read status used by the ladder report. */
typealias ReadStatus = FileReadStatus
