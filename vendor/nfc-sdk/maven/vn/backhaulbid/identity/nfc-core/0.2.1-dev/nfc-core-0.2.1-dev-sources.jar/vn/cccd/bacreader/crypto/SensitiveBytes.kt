package vn.cccd.bacreader.crypto

import java.util.Arrays

/** Mutable, wipeable byte storage for credentials and derived BAC material. */
class SensitiveBytes(bytes: ByteArray) : AutoCloseable {
    private var value: ByteArray? = bytes.copyOf()

    fun copy(): ByteArray = value?.copyOf() ?: throw IllegalStateException("Sensitive bytes are closed")

    override fun close() {
        value?.let { Arrays.fill(it, 0) }
        value = null
    }

    override fun toString(): String = "SensitiveBytes(<redacted>)"
}
