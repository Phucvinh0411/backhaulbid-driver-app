package vn.cccd.bacreader.lds

import vn.cccd.bacreader.domain.Dg13Metadata
import vn.cccd.bacreader.domain.Dg13ReadStatus
import vn.cccd.bacreader.domain.Dg13StructureStatus
import vn.cccd.bacreader.protocol.ProtectedFileRead

/** Builds allowlisted DG13 structure evidence without retaining the raw card bytes. */
object Dg13StructureLogger {
    fun metadata(read: ProtectedFileRead, status: Dg13ReadStatus = Dg13ReadStatus.DG13_RAW_READ_OK): Dg13Metadata =
        Dg13Metadata(
            rawLength = read.rawLength,
            firstTag = read.firstTag,
            declaredLength = read.declaredLength,
            chunkCount = read.chunkCount,
            secureMessagingVerified = read.secureMessagingVerified,
            structureStatus = when (status) {
                Dg13ReadStatus.DG13_LAYOUT_SUPPORTED -> Dg13StructureStatus.LAYOUT_SUPPORTED
                Dg13ReadStatus.DG13_LAYOUT_UNSUPPORTED -> Dg13StructureStatus.LAYOUT_UNSUPPORTED
                Dg13ReadStatus.DG13_RAW_READ_OK -> Dg13StructureStatus.RAW_READ_OK
            },
            readStatus = status,
        )
}
