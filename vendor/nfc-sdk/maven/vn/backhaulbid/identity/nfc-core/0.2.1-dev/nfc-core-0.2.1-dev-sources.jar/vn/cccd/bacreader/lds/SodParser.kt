package vn.cccd.bacreader.lds

import java.util.Locale
import java.math.BigInteger
import org.bouncycastle.asn1.ASN1Integer
import org.bouncycastle.asn1.ASN1OctetString
import org.bouncycastle.asn1.ASN1Primitive
import org.bouncycastle.asn1.ASN1Sequence
import org.bouncycastle.asn1.x509.AlgorithmIdentifier
import org.bouncycastle.cms.CMSSignedData
import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.domain.SodData
import vn.cccd.bacreader.domain.SodSignatureStatus

/** Validates EF.SOD's outer wrapper and CMS envelope; signature verification is intentionally explicit. */
object SodParser {
    const val MAX_ENCODED_BYTES: Int = LdsFileLimits.EF_SOD_MAX_ENCODED_BYTES

    fun parse(encoded: ByteArray): SodData {
        val root = readCompleteLdsFile(encoded, SOD_TAG, MAX_ENCODED_BYTES)
        val contents = root.copyValue()
        try {
            if (contents.isEmpty() || contents[0] != 0x30.toByte()) {
                throw LdsParseException(ReaderError.FILE_MALFORMED, "EF.SOD does not contain a CMS SEQUENCE")
            }
            // CMS permits BER indefinite-length constructed values (notably the
            // certificate and signer sets), so do not run the strict LDS definite-
            // length reader over the CMS envelope. BC validates the full ASN.1
            // object and rejects trailing bytes for us.
            try {
                ASN1Sequence.getInstance(ASN1Primitive.fromByteArray(contents))
            } catch (error: Exception) {
                throw LdsParseException(ReaderError.FILE_MALFORMED, "EF.SOD CMS envelope is malformed", error)
            }
            // A real EF.SOD is CMS SignedData carrying an LDS Security Object. Parse
            // that structure first; the bounded recursive parser remains as a
            // compatibility path for the tiny synthetic envelope used by older tests.
            val cms = try {
                CMSSignedData(contents)
            } catch (_: Exception) {
                null
            }
            val structured = cms?.let(::parseLdsSecurityObject)
            if (cms != null && structured == null) {
                throw LdsParseException(ReaderError.UNSUPPORTED_LAYOUT, "EF.SOD has no supported LDS Security Object")
            }
            val hashes = structured?.hashes ?: collectDataGroupHashes(contents)
            return SodData(
                encodedBytes = encoded.size,
                cmsEnvelopePresent = true,
                signatureStatus = SodSignatureStatus.NOT_VERIFIED,
                dataGroupHashes = hashes,
                digestAlgorithm = structured?.digestAlgorithm,
            )
        } finally {
            contents.fill(0)
            root.close()
        }
    }

    private fun parseLdsSecurityObject(cms: CMSSignedData): ParsedLdsSecurityObject? {
        val content = cms.signedContent?.content ?: return null
        val securityObject = when (content) {
            is ByteArray -> content.copyOf()
            is ASN1OctetString -> content.octets.copyOf()
            else -> return null
        }
        return try {
            val sequence = ASN1Sequence.getInstance(ASN1Primitive.fromByteArray(securityObject))
            if (sequence.size() != 3) return null
            val versionValue = ASN1Integer.getInstance(sequence.getObjectAt(0)).value
            if (versionValue.signum() < 0) return null
            val version = boundedInt(versionValue) ?: return null
            if (version !in 0..1) return null
            val algorithm = AlgorithmIdentifier.getInstance(sequence.getObjectAt(1))
            val digestAlgorithm = digestName(algorithm.algorithm.id) ?: return null
            val hashValues = ASN1Sequence.getInstance(sequence.getObjectAt(2))
            val hashes = LinkedHashMap<Int, String>()
            for (index in 0 until hashValues.size()) {
                val pair = ASN1Sequence.getInstance(hashValues.getObjectAt(index))
                if (pair.size() != 2) return null
                val numberValue = ASN1Integer.getInstance(pair.getObjectAt(0)).value
                if (numberValue.signum() < 0) return null
                val number = boundedInt(numberValue) ?: return null
                val hash = ASN1OctetString.getInstance(pair.getObjectAt(1)).octets
                if (number !in 1..MAX_DATA_GROUP || hash.isEmpty()) return null
                hashes[number] = hash.joinToString("") { "%02X".format(Locale.ROOT, it.toInt() and 0xFF) }
            }
            ParsedLdsSecurityObject(digestAlgorithm, hashes.toMap())
        } catch (_: Exception) {
            null
        } finally {
            securityObject.fill(0)
        }
    }

    private fun digestName(oid: String): String? = when (oid) {
        "1.3.14.3.2.26" -> "SHA-1"
        "2.16.840.1.101.3.4.2.1" -> "SHA-256"
        "2.16.840.1.101.3.4.2.2" -> "SHA-384"
        "2.16.840.1.101.3.4.2.3" -> "SHA-512"
        "2.16.840.1.101.3.4.2.4" -> "SHA-224"
        else -> null
    }

    private fun boundedInt(value: BigInteger): Int? =
        if (value.bitLength() <= 31) value.toInt() else null

    /** Extracts the LDS Security Object's DG number/hash pairs without interpreting CMS bytes. */
    private fun collectDataGroupHashes(encoded: ByteArray): Map<Int, String> {
        val result = LinkedHashMap<Int, String>()
        collectDataGroupHashes(encoded, result, depth = 0)
        return result.toMap()
    }

    private fun collectDataGroupHashes(
        encoded: ByteArray,
        result: MutableMap<Int, String>,
        depth: Int,
    ) {
        if (depth > MAX_HASH_DEPTH) {
            throw LdsParseException(ReaderError.UNSUPPORTED_LAYOUT, "EF.SOD nesting is too deep")
        }
        val values = try {
            BerTlvReader.readAll(encoded, maxEncodedLength = MAX_ENCODED_BYTES)
        } catch (error: LdsParseException) {
            // CMS contains many primitive ASN.1 values. A malformed child is an invalid SOD,
            // not an opportunity to guess where a hash might be.
            throw LdsParseException(ReaderError.FILE_MALFORMED, "EF.SOD nested BER is malformed", error)
        }
        try {
            values.forEach { value ->
                val bytes = value.copyValue()
                try {
                    if (value.header.tag == DATA_GROUP_HASH_SEQUENCE && isConstructed(value.header)) {
                        parseDataGroupHashPair(bytes)?.let { (number, hash) -> result[number] = hash }
                    }
                    if (isConstructed(value.header)) {
                        collectDataGroupHashes(bytes, result, depth + 1)
                    }
                } finally {
                    bytes.fill(0)
                }
            }
        } finally {
            values.forEach(BerTlv::close)
        }
    }

    private fun parseDataGroupHashPair(encoded: ByteArray): Pair<Int, String>? {
        val children = try {
            BerTlvReader.readAll(encoded, maxEncodedLength = MAX_ENCODED_BYTES)
        } catch (_: LdsParseException) {
            return null
        }
        try {
            if (children.size != 2 || children[0].header.tag != INTEGER_TAG || children[1].header.tag != HASH_TAG) {
                return null
            }
            val numberBytes = children[0].copyValue()
            val hashBytes = children[1].copyValue()
            try {
                if (numberBytes.size != 1) return null
                val number = numberBytes[0].toInt() and 0xFF
                if (number !in 1..MAX_DATA_GROUP) return null
                if (hashBytes.size !in HASH_LENGTHS) return null
                return number to hashBytes.joinToString("") { "%02X".format(Locale.ROOT, it.toInt() and 0xFF) }
            } finally {
                numberBytes.fill(0)
                hashBytes.fill(0)
            }
        } finally {
            children.forEach(BerTlv::close)
        }
    }

    private fun isConstructed(header: BerTlvHeader): Boolean {
        val firstOctet = header.tag ushr ((header.tagLength - 1) * 8)
        return firstOctet and 0x20 != 0
    }

    private const val SOD_TAG = 0x77
    private const val DATA_GROUP_HASH_SEQUENCE = 0x30
    private const val INTEGER_TAG = 0x02
    private const val HASH_TAG = 0x04
    private const val MAX_DATA_GROUP = 16
    private const val MAX_HASH_DEPTH = 16
    private val HASH_LENGTHS = setOf(20, 28, 32, 48, 64)

    private data class ParsedLdsSecurityObject(
        val digestAlgorithm: String,
        val hashes: Map<Int, String>,
    )
}
