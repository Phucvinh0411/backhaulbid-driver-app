package vn.cccd.bacreader.protocol

import vn.cccd.bacreader.domain.AuthenticityResult
import vn.cccd.bacreader.domain.SodData

/** Compatibility facade for the v0.2 protocol package; implementation lives with crypto helpers. */
object PassiveAuthenticationVerifier {
    fun verify(sod: SodData?, dataGroups: Map<Int, ByteArray>): AuthenticityResult =
        vn.cccd.bacreader.crypto.PassiveAuthenticationVerifier.verify(sod, dataGroups)
}
