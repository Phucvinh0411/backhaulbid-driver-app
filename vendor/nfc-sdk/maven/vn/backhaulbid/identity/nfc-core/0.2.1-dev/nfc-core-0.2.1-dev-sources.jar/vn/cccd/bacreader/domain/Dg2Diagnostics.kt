package vn.cccd.bacreader.domain

/** Identifies the layer that produced the DG2 diagnostic. */
enum class Dg2DiagnosticSource {
    PROTECTED_FILE_READER,
    DG2_PARSER,
}

/** Bounded stages used to localize DG2 acquisition and structural failures. */
enum class Dg2DiagnosticStage {
    FILE_SELECT,
    BER_HEADER,
    BER_BODY,
    DG2_OUTER_TLV,
    BDB_CONTAINER,
    FAC_IDENTIFIER,
    FAC_VERSION,
    FAC_RECORD_LENGTH,
    FAC_IMAGE_COUNT,
    FAC_FEATURE_POINTS,
    FAC_IMAGE_INFO,
    FAC_IMAGE_LENGTH,
    FAC_IMAGE_MARKER,
}

enum class Dg2ReaderStatus {
    SELECTED,
    READING,
    COMPLETE,
    FAILED,
}

enum class Dg2DiagnosticInterpretation {
    ACQUISITION_FAILURE_SUSPECTED,
    STRICT_PARSER_REJECTION_CONFIRMED,
    INSUFFICIENT_EVIDENCE,
}

/** Transport/protected-APDU failure categories retained for debug diagnostics. */
enum class Dg2ChunkFailureType {
    TAG_LOST_BEFORE_TRANSCEIVE,
    TAG_LOST_DURING_TRANSCEIVE,
    TRANSCEIVE_TIMEOUT,
    APDU_STATUS_ERROR,
    SECURE_MESSAGING_UNWRAP_ERROR,
    TRANSPORT_ERROR,
}

/** Safe metadata for one protected READ BINARY operation; no command or payload bytes are kept. */
data class Dg2ChunkDiagnostic(
    val chunkIndex: Int,
    val fileOffset: Int,
    val requestedPlainLength: Int,
    val receivedPlainLength: Int? = null,
    val encodedCommandLength: Int? = null,
    val transceiveDurationMillis: Long? = null,
    val statusWord: Int? = null,
    val isoDepConnected: Boolean? = null,
    val isoDepTimeoutMillis: Int? = null,
    val isoDepMaxTransceiveLength: Int? = null,
    val failureType: Dg2ChunkFailureType? = null,
)

/** Safe, non-sensitive information retained for one DG2 read attempt. */
data class Dg2Diagnostic(
    val source: Dg2DiagnosticSource,
    val stage: Dg2DiagnosticStage,
    val bytesRead: Int = 0,
    val rawLength: Int? = null,
    val chunkCount: Int? = null,
    val firstTag: Int? = null,
    val declaredLength: Int? = null,
    val readerStatus: Dg2ReaderStatus? = null,
    val failureOffset: Int? = null,
    val failureField: String? = null,
    val failureStage: Dg2DiagnosticStage? = null,
    val remainingBytes: Int? = null,
    val jpegMarkerFound: Boolean? = null,
    val jpeg2000MarkerFound: Boolean? = null,
    val markerOffset: Int? = null,
    val bytesRemainingAfterMarker: Int? = null,
    val maxPlainChunk: Int? = null,
    val secureMessagingOverhead: Int? = null,
    val effectiveTransceiveMaximum: Int? = null,
    val failureType: Dg2ChunkFailureType? = null,
    val chunkTrace: List<Dg2ChunkDiagnostic> = emptyList(),
    val parserAccepted: Boolean? = null,
    val facRecordLength: Int? = null,
    val facialRecordCount: Int? = null,
    val recordStart: Int? = null,
    val recordLength: Int? = null,
    val featurePointCount: Int? = null,
    val imageInfoStart: Int? = null,
    val imageStart: Int? = null,
    val calculatedImageLength: Int? = null,
    val imageDataType: Int? = null,
    val imageWidth: Int? = null,
    val imageHeight: Int? = null,
    val structuralImageOffsetMatch: Boolean? = null,
) {
    val interpretation: Dg2DiagnosticInterpretation
        get() = when {
            source == Dg2DiagnosticSource.DG2_PARSER &&
                parserAccepted != true &&
                readerStatus == Dg2ReaderStatus.COMPLETE &&
                bytesRead > 0 -> Dg2DiagnosticInterpretation.STRICT_PARSER_REJECTION_CONFIRMED
            source == Dg2DiagnosticSource.PROTECTED_FILE_READER &&
                readerStatus == Dg2ReaderStatus.FAILED -> Dg2DiagnosticInterpretation.ACQUISITION_FAILURE_SUSPECTED
            else -> Dg2DiagnosticInterpretation.INSUFFICIENT_EVIDENCE
        }
}

/** Debug-only marker probe. It never returns or owns image bytes. */
data class Dg2LegacyProbe(
    val jpegMarkerFound: Boolean,
    val jpeg2000MarkerFound: Boolean,
    val markerOffset: Int?,
    val bytesRemainingAfterMarker: Int?,
)
