package vn.cccd.bacreader.protocol

import vn.cccd.bacreader.crypto.LdsHashVerifier
import vn.cccd.bacreader.domain.AuthenticityResult
import vn.cccd.bacreader.domain.DigestStatus
import vn.cccd.bacreader.domain.LdsEvidence
import vn.cccd.bacreader.domain.LdsEvidencePart
import vn.cccd.bacreader.domain.Dg13Metadata
import vn.cccd.bacreader.domain.Dg13ReadStatus
import vn.cccd.bacreader.domain.Dg13StructureStatus
import vn.cccd.bacreader.domain.Dg2Diagnostic
import vn.cccd.bacreader.domain.Dg2LegacyProbe
import vn.cccd.bacreader.domain.ReadResult
import vn.cccd.bacreader.domain.Dg13Data
import vn.cccd.bacreader.domain.Dg2Data
import vn.cccd.bacreader.domain.Dg2Portrait
import vn.cccd.bacreader.domain.ExtendedFile
import vn.cccd.bacreader.domain.FileReadReport
import vn.cccd.bacreader.domain.FileReadStatus
import vn.cccd.bacreader.domain.ReaderOptions
import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.domain.ScanStep
import vn.cccd.bacreader.domain.SodReadStatus
import vn.cccd.bacreader.domain.SodSignatureStatus
import vn.cccd.bacreader.domain.IntegrityStatus
import vn.cccd.bacreader.domain.SignatureStatus
import vn.cccd.bacreader.domain.IssuerTrustStatus
import vn.cccd.bacreader.domain.PassiveAuthenticationStatus
import vn.cccd.bacreader.lds.Dg1Parser
import vn.cccd.bacreader.lds.Dg13Parser
import vn.cccd.bacreader.lds.Dg2Parser
import vn.cccd.bacreader.lds.Dg2ParseResult
import vn.cccd.bacreader.lds.Dg2LegacyScanner
import vn.cccd.bacreader.lds.Dg13StructureLogger
import vn.cccd.bacreader.lds.EfComParser
import vn.cccd.bacreader.lds.LdsParseException
import vn.cccd.bacreader.lds.SodParser
import vn.cccd.bacreader.lds.CmsSodVerifier
import vn.cccd.bacreader.domain.SodData
import vn.cccd.bacreader.nfc.ApduTransport
import vn.cccd.bacreader.nfc.TagLostTransportException
import vn.cccd.bacreader.nfc.TransportException
import vn.cccd.bacreader.nfc.TransportTimeoutException

/** Executes BAC, mandatory LDS files, then bounded optional files over an ISO-DEP tag. */
class CardReader(
    private val bacAuthenticator: BacAuthenticator = BacAuthenticator(),
    /** Enables the DG2 legacy diagnostic probe. Disabled by default, as in the shipped SDK. */
    private val diagnosticsEnabled: Boolean = false,
) {
    /** Backward-compatible mandatory-file entry point. */
    fun read(
        transport: ApduTransport,
        mrzInformation: ByteArray,
        onStep: (ScanStep) -> Unit = {},
    ): ReadResult = read(transport, mrzInformation, ReaderOptions(), onStep)

    fun read(
        transport: ApduTransport,
        mrzInformation: ByteArray,
        options: ReaderOptions,
        onStep: (ScanStep) -> Unit = {},
    ): ReadResult {
        val startedAt = System.nanoTime()
        var step = ScanStep.TAG_DISCOVERED
        var bytesRead = 0
        // Owned by this call until a Success takes it; every other exit closes it in the finally block.
        val evidence: LdsEvidence? = if (options.captureEvidence) LdsEvidence() else null
        var evidenceTransferred = false
        // DG13 bytes wait here until EF.SOD has been read; they become evidence only if the SOD lists them.
        var dg13Raw: ByteArray? = null
        onStep(step)
        try {
            transport.connect()
            step = ScanStep.ISO_DEP_CONNECTED
            onStep(step)
            bacAuthenticator.authenticate(transport, mrzInformation) { next ->
                step = next
                onStep(next)
            }.use { session ->
                SecureMessagingChannel(transport, session).use { channel ->
                    step = ScanStep.SECURE_MESSAGING_READY
                    onStep(step)
                    val fileReader = ProtectedFileReader(channel)
                    step = ScanStep.EF_COM_SELECTED
                    onStep(step)
                    val efComBytes = fileReader.readFile(EF_COM_FILE_ID, EfComParser.MAX_ENCODED_BYTES)
                    try {
                        bytesRead += efComBytes.size
                        val efCom = EfComParser.parse(efComBytes)
                        step = ScanStep.EF_COM_READ
                        onStep(step)
                        if (!efCom.containsDataGroupTag(DG1_TAG)) {
                            return failure(step, ReaderError.FILE_NOT_FOUND, bytesRead, startedAt)
                        }
                        step = ScanStep.DG1_SELECTED
                        onStep(step)
                        val dg1Bytes = fileReader.readFile(DG1_FILE_ID, Dg1Parser.MAX_ENCODED_BYTES)
                        evidence?.capture(LdsEvidencePart.DG1, dg1Bytes)
                        try {
                            bytesRead += dg1Bytes.size
                            val dg1 = Dg1Parser.parse(dg1Bytes)
                            step = ScanStep.DG1_READ
                            onStep(step)
                            val optionalReports = ArrayList<FileReadReport>(OPTIONAL_FILE_COUNT)
                            var dg13: Dg13Data? = null
                            var sod: SodData? = null
                            var dg2: Dg2Data? = null
                            var dg2Portrait: Dg2Portrait? = null
                            var dg2AcquisitionDiagnostic: Dg2Diagnostic? = null
                            var dg2LegacyProbe: Dg2LegacyProbe? = null
                            var sodVerification: CmsSodVerifier.Result? = null
                            var terminalError: ReaderError? = null
                            val dgHashes = HashMap<Int, HashCandidates>()
                            dgHashes[1] = hashCandidates(dg1Bytes)

                            if (!efCom.containsDataGroupTag(DG13_TAG)) {
                                optionalReports += notPresent(ExtendedFile.DG13, ScanStep.DG13_SELECTED)
                            } else if (!options.readDg13) {
                                optionalReports += FileReadReport(
                                    file = ExtendedFile.DG13,
                                    status = FileReadStatus.NOT_REQUESTED,
                                    step = ScanStep.DG13_SELECTED,
                                    error = ReaderError.FILE_NOT_REQUESTED,
                                )
                            } else if (terminalError == null) {
                                val attempt = readOptional(
                                    fileReader = fileReader,
                                    file = ExtendedFile.DG13,
                                    fileId = DG13_FILE_ID,
                                    selectStep = ScanStep.DG13_SELECTED,
                                    readStep = ScanStep.DG13_READ,
                                    maxEncodedBytes = Dg13Parser.MAX_ENCODED_BYTES,
                                    parser = Dg13Parser::parse,
                                    onStep = onStep,
                                    fallbackSfi = 0x0D,
                                    metadataFactory = ::dg13Metadata,
                                    onRawRead = { bytes ->
                                        dgHashes[13] = hashCandidates(bytes)
                                        dg13Raw = bytes.copyOf()
                                    },
                                )
                                optionalReports += attempt.report
                                dg13 = attempt.value?.let { value ->
                                    value.copy(metadata = attempt.report.metadata?.copy(
                                        structureStatus = Dg13StructureStatus.LAYOUT_SUPPORTED,
                                        readStatus = Dg13ReadStatus.DG13_LAYOUT_SUPPORTED,
                                    ))
                                }
                                terminalError = attempt.terminalError
                            }

                            if (!efCom.containsDataGroupTag(DG2_TAG)) {
                                optionalReports += notPresent(ExtendedFile.DG2, ScanStep.DG2_SELECTED)
                            } else if (!options.readDg2) {
                                optionalReports += FileReadReport(
                                    file = ExtendedFile.DG2,
                                    status = FileReadStatus.NOT_REQUESTED,
                                    step = ScanStep.DG2_SELECTED,
                                    error = ReaderError.FILE_NOT_REQUESTED,
                                )
                            } else if (terminalError == null) {
                                val attempt = readOptional(
                                    fileReader = fileReader,
                                    file = ExtendedFile.DG2,
                                    fileId = DG2_FILE_ID,
                                    selectStep = ScanStep.DG2_SELECTED,
                                    readStep = ScanStep.DG2_READ,
                                    maxEncodedBytes = Dg2Parser.MAX_ENCODED_BYTES,
                                    parser = Dg2Parser::parse,
                                    onStep = onStep,
                                    onRawRead = { bytes ->
                                        dgHashes[2] = hashCandidates(bytes)
                                        evidence?.capture(LdsEvidencePart.DG2, bytes)
                                        if (diagnosticsEnabled) {
                                            dg2LegacyProbe = Dg2LegacyScanner.inspect(bytes)
                                        }
                                    },
                                    onDiagnostic = { diagnostic -> dg2AcquisitionDiagnostic = diagnostic },
                                    diagnosticsFactory = { parserDiagnostic ->
                                        mergeDg2Diagnostics(dg2AcquisitionDiagnostic, parserDiagnostic, dg2LegacyProbe)
                                    },
                                )
                                optionalReports += attempt.report
                                attempt.value?.let { value ->
                                    dg2 = value.metadata
                                    dg2Portrait = value.portrait
                                }
                                terminalError = attempt.terminalError
                            } else {
                                optionalReports += notAttempted(ExtendedFile.DG2, ScanStep.DG2_SELECTED, terminalError)
                            }

                            // EF.SOD is deliberately independent of EF.COM's 5C list. Some
                            // cards omit the tag while still exposing the security object.
                            if (terminalError == null) {
                                val attempt = readOptional(
                                    fileReader = fileReader,
                                    file = ExtendedFile.EF_SOD,
                                    fileId = SOD_FILE_ID,
                                    selectStep = ScanStep.EF_SOD_SELECTED,
                                    readStep = ScanStep.EF_SOD_READ,
                                    maxEncodedBytes = SodParser.MAX_ENCODED_BYTES,
                                    parser = SodParser::parse,
                                    onStep = onStep,
                                    fallbackSfi = 0x1D,
                                    sodFailure = SodFailureClassifier::from,
                                    sodParseFailure = { error ->
                                        when (error.error) {
                                            ReaderError.FILE_MALFORMED -> SodReadStatus.INVALID_ENCODING
                                            ReaderError.UNSUPPORTED_LAYOUT -> SodReadStatus.PARSE_UNSUPPORTED
                                            else -> null
                                        }
                                    },
                                    postParse = { bytes, parsed ->
                                        evidence?.capture(LdsEvidencePart.SOD, bytes)
                                        val verification = CmsSodVerifier.verify(
                                            bytes,
                                            verifySignature = options.verifySodSignature,
                                            verifyCscaTrust = options.verifyCscaTrust,
                                        )
                                        sodVerification = verification
                                        parsed.copy(
                                            signatureStatus = verification.signatureStatus,
                                            dsCertificateStatus = verification.dsCertificateStatus,
                                        )
                                    },
                                )
                                optionalReports += attempt.report
                                sod = attempt.value
                                terminalError = attempt.terminalError
                            } else {
                                optionalReports += notAttempted(ExtendedFile.EF_SOD, ScanStep.EF_SOD_SELECTED, terminalError)
                            }
                            if (terminalError != null) {
                                markNotAttempted(optionalReports, terminalError)
                            }
                            val sodReport = optionalReports.firstOrNull { it.file == ExtendedFile.EF_SOD }
                            val dg1Digest = digestStatus(sod, 1, dgHashes)
                            val dg2Digest = digestStatus(sod, 2, dgHashes)
                            // DG13 is evidence only when EF.SOD lists it and the hash matches. An untrusted DG13 is never sent.
                            dg13Raw?.takeIf { Dg13Evidence.trusted(sod, it) }
                                ?.let { evidence?.capture(LdsEvidencePart.DG13, it) }
                            dg13Raw?.fill(0)
                            dg13Raw = null
                            val aggregateIntegrity = integrityStatus(sod, dgHashes)
                            val signature = sodVerification?.signatureStatus.toResultStatus()
                            val trust = sodVerification?.issuerTrustStatus
                                ?: IssuerTrustStatus.TRUST_NOT_ESTABLISHED
                            val authenticity = AuthenticityResult(
                                sodStatus = sodReport?.sodStatus ?: SodReadStatus.NOT_ATTEMPTED,
                                integrityStatus = aggregateIntegrity,
                                dg1Digest = dg1Digest,
                                dg2Digest = dg2Digest,
                                signatureStatus = signature,
                                dsCertificateStatus = sodVerification?.dsCertificateStatus
                                    ?: vn.cccd.bacreader.domain.DsCertificateStatus.UNAVAILABLE,
                                issuerTrustStatus = trust,
                                passiveAuthenticationStatus = passiveStatus(aggregateIntegrity, signature, trust),
                            )
                            onStep(ScanStep.COMPLETE)
                            evidenceTransferred = true
                            return ReadResult.Success(
                                dg1Mrz = dg1.displayMrz,
                                efComBytes = efComBytes.size,
                                dg1Bytes = dg1Bytes.size,
                                elapsedMillis = elapsedMillis(startedAt),
                                dg13 = dg13,
                                dg2 = dg2,
                                dg2Portrait = dg2Portrait,
                                sod = sod,
                                optionalFiles = optionalReports.toList(),
                                authenticity = authenticity,
                                evidence = evidence,
                            )
                        } finally {
                            dg1Bytes.fill(0)
                        }
                    } finally {
                        efComBytes.fill(0)
                    }
                }
            }
        } catch (error: BacException) {
            return failure(step, error.error, bytesRead, startedAt, error.sw)
        } catch (error: SecureMessagingException) {
            return failure(step, error.error, bytesRead, startedAt, error.sw)
        } catch (error: LdsParseException) {
            return failure(step, error.error, bytesRead, startedAt)
        } catch (_: TagLostTransportException) {
            return failure(step, ReaderError.TAG_LOST, bytesRead, startedAt)
        } catch (_: TransportTimeoutException) {
            return failure(step, ReaderError.TIMEOUT, bytesRead, startedAt)
        } catch (_: TransportException) {
            return failure(step, ReaderError.TRANSPORT_ERROR, bytesRead, startedAt)
        } catch (_: IllegalArgumentException) {
            return failure(step, ReaderError.MALFORMED_RESPONSE, bytesRead, startedAt)
        } finally {
            transport.close()
            dg13Raw?.fill(0)
            if (!evidenceTransferred) evidence?.close()
        }
    }

    private fun failure(
        step: ScanStep,
        error: ReaderError,
        bytesRead: Int,
        startedAt: Long,
        sw: StatusWord? = null,
    ): ReadResult.Failure = ReadResult.Failure(
        step = step,
        error = error,
        sw = sw?.toString(),
        bytesRead = bytesRead,
        elapsedMillis = elapsedMillis(startedAt),
    )

    private fun elapsedMillis(startedAtNanos: Long): Long = (System.nanoTime() - startedAtNanos) / 1_000_000

    private fun <T> readOptional(
        fileReader: ProtectedFileReader,
        file: ExtendedFile,
        fileId: Int,
        selectStep: ScanStep,
        readStep: ScanStep,
        maxEncodedBytes: Int,
        parser: (ByteArray) -> T,
        onStep: (ScanStep) -> Unit,
        fallbackSfi: Int? = null,
        metadataFactory: ((ProtectedFileRead) -> Dg13Metadata)? = null,
        onRawRead: (ByteArray) -> Unit = {},
        onDiagnostic: ((Dg2Diagnostic) -> Unit)? = null,
        diagnosticsFactory: ((Dg2Diagnostic?) -> Dg2Diagnostic?)? = null,
        sodFailure: ((SecureMessagingException) -> SodReadStatus)? = null,
        sodParseFailure: ((LdsParseException) -> SodReadStatus?)? = null,
        postParse: ((ByteArray, T) -> T)? = null,
    ): OptionalAttempt<T> {
        onStep(selectStep)
        var read: ProtectedFileRead? = null
        return try {
            read = fileReader.readFileDetailed(fileId, maxEncodedBytes, fallbackSfi, onDiagnostic)
            onRawRead(read!!.bytes)
            onStep(readStep)
            val parsed = parser(read!!.bytes)
            val value = postParse?.invoke(read!!.bytes, parsed) ?: parsed
            val parserDiagnostic = (parsed as? Dg2ParseResult)?.diagnostic
            OptionalAttempt(
                value = value,
                report = FileReadReport(
                    file,
                    FileReadStatus.READ,
                    readStep,
                    bytesRead = read!!.rawLength,
                    sodStatus = sodFailure?.let { SodReadStatus.EF_SOD_READ_OK },
                    metadata = metadataFactory?.invoke(read!!),
                    dg2Diagnostic = diagnosticsFactory?.invoke(parserDiagnostic),
                ),
                terminalError = null,
            )
        } catch (error: SecureMessagingException) {
            OptionalAttempt(
                value = null,
                report = FileReadReport(
                    file = file,
                    status = FileReadStatus.UNREADABLE,
                    step = selectStep,
                    error = error.error,
                    sw = error.sw?.toString(),
                    sodStatus = sodFailure?.invoke(error),
                    bytesRead = read?.rawLength ?: 0,
                    metadata = read?.let { metadataFactory?.invoke(it) },
                    dg2Diagnostic = diagnosticsFactory?.invoke(null),
                ),
                terminalError = error.error.takeIf(::isTerminal),
            )
        } catch (error: LdsParseException) {
            OptionalAttempt(
                value = null,
                report = FileReadReport(
                    file,
                    FileReadStatus.UNREADABLE,
                    readStep,
                    error = error.error,
                    bytesRead = read?.rawLength ?: 0,
                    sodStatus = sodParseFailure?.invoke(error),
                    metadata = read?.let { metadataFactory?.invoke(it)?.copy(
                        structureStatus = Dg13StructureStatus.LAYOUT_UNSUPPORTED,
                        readStatus = Dg13ReadStatus.DG13_LAYOUT_UNSUPPORTED,
                    ) },
                    dg2Diagnostic = diagnosticsFactory?.invoke(error.diagnostic),
                ),
                terminalError = null,
            )
        } catch (_: TagLostTransportException) {
            optionalTransportFailure(file, selectStep, ReaderError.TAG_LOST)
        } catch (_: TransportTimeoutException) {
            optionalTransportFailure(file, selectStep, ReaderError.TIMEOUT)
        } catch (_: TransportException) {
            optionalTransportFailure(file, selectStep, ReaderError.TRANSPORT_ERROR)
        } catch (_: IllegalArgumentException) {
            OptionalAttempt(
                value = null,
                report = FileReadReport(
                    file,
                    FileReadStatus.UNREADABLE,
                    selectStep,
                    error = ReaderError.MALFORMED_RESPONSE,
                    bytesRead = read?.rawLength ?: 0,
                    metadata = read?.let { metadataFactory?.invoke(it) },
                    sodStatus = if (sodFailure != null) SodReadStatus.EF_SOD_SECURE_MESSAGING_FAILURE else null,
                    dg2Diagnostic = diagnosticsFactory?.invoke(null),
                ),
                terminalError = null,
            )
        } finally {
            read?.close()
        }
    }

    private fun dg13Metadata(read: ProtectedFileRead): Dg13Metadata = Dg13StructureLogger.metadata(read)

    private fun mergeDg2Diagnostics(
        acquisition: Dg2Diagnostic?,
        parser: Dg2Diagnostic?,
        legacy: Dg2LegacyProbe?,
    ): Dg2Diagnostic? {
        val base = parser ?: acquisition ?: return null
        return base.copy(
            bytesRead = acquisition?.bytesRead ?: base.bytesRead,
            rawLength = acquisition?.rawLength ?: base.rawLength,
            chunkCount = acquisition?.chunkCount ?: base.chunkCount,
            firstTag = acquisition?.firstTag ?: base.firstTag,
            declaredLength = acquisition?.declaredLength ?: base.declaredLength,
            readerStatus = acquisition?.readerStatus ?: base.readerStatus,
            jpegMarkerFound = legacy?.jpegMarkerFound,
            jpeg2000MarkerFound = legacy?.jpeg2000MarkerFound,
            markerOffset = legacy?.markerOffset,
            bytesRemainingAfterMarker = legacy?.bytesRemainingAfterMarker,
            maxPlainChunk = acquisition?.maxPlainChunk ?: base.maxPlainChunk,
            secureMessagingOverhead = acquisition?.secureMessagingOverhead ?: base.secureMessagingOverhead,
            effectiveTransceiveMaximum = acquisition?.effectiveTransceiveMaximum ?: base.effectiveTransceiveMaximum,
            failureType = acquisition?.failureType ?: base.failureType,
            chunkTrace = if (acquisition?.chunkTrace?.isNotEmpty() == true) acquisition.chunkTrace else base.chunkTrace,
            parserAccepted = parser?.parserAccepted ?: base.parserAccepted,
            facRecordLength = parser?.facRecordLength ?: base.facRecordLength,
            facialRecordCount = parser?.facialRecordCount ?: base.facialRecordCount,
            recordStart = parser?.recordStart ?: base.recordStart,
            recordLength = parser?.recordLength ?: base.recordLength,
            featurePointCount = parser?.featurePointCount ?: base.featurePointCount,
            imageInfoStart = parser?.imageInfoStart ?: base.imageInfoStart,
            imageStart = parser?.imageStart ?: base.imageStart,
            calculatedImageLength = parser?.calculatedImageLength ?: base.calculatedImageLength,
            imageDataType = parser?.imageDataType ?: base.imageDataType,
            imageWidth = parser?.imageWidth ?: base.imageWidth,
            imageHeight = parser?.imageHeight ?: base.imageHeight,
            structuralImageOffsetMatch = when {
                parser?.imageStart != null && legacy?.markerOffset != null -> parser.imageStart == legacy.markerOffset
                else -> parser?.structuralImageOffsetMatch ?: base.structuralImageOffsetMatch
            },
        )
    }

    private fun hashCandidates(bytes: ByteArray): HashCandidates = HashCandidates(
        sha1 = LdsHashVerifier.sha1Hex(bytes),
        sha256 = LdsHashVerifier.sha256Hex(bytes),
        sha224 = LdsHashVerifier.digestHex("SHA-224", bytes),
        sha384 = LdsHashVerifier.digestHex("SHA-384", bytes),
        sha512 = LdsHashVerifier.digestHex("SHA-512", bytes),
    )

    private fun integrityStatus(
        sod: SodData?,
        actual: Map<Int, HashCandidates>,
    ): IntegrityStatus {
        if (sod == null || sod.readStatus != SodReadStatus.EF_SOD_READ_OK || sod.dataGroupHashes.isEmpty()) {
            return IntegrityStatus.INTEGRITY_NOT_VERIFIED
        }
        val comparisons = sod.dataGroupHashes.mapNotNull { (number, expected) ->
            actual[number]?.let { candidates ->
                expected.equals(candidateFor(candidates, sod.digestAlgorithm, expected.length), ignoreCase = true)
            }
        }
        return when {
            comparisons.isEmpty() -> IntegrityStatus.INTEGRITY_NOT_VERIFIED
            comparisons.all { it } -> IntegrityStatus.DG_HASH_MATCH
            else -> IntegrityStatus.DG_HASH_MISMATCH
        }
    }

    private fun digestStatus(
        sod: SodData?,
        number: Int,
        actual: Map<Int, HashCandidates>,
    ): DigestStatus {
        if (sod == null || sod.readStatus != SodReadStatus.EF_SOD_READ_OK) {
            return DigestStatus.NOT_ATTEMPTED
        }
        val expected = sod.dataGroupHashes[number] ?: return DigestStatus.NOT_LISTED
        val candidates = actual[number] ?: return DigestStatus.NOT_ATTEMPTED
        return if (expected.equals(candidateFor(candidates, sod.digestAlgorithm, expected.length), ignoreCase = true)) {
            DigestStatus.MATCH
        } else {
            DigestStatus.MISMATCH
        }
    }

    private fun candidateFor(candidates: HashCandidates, algorithm: String?, expectedLength: Int): String = when (algorithm) {
        "SHA-1" -> candidates.sha1
        "SHA-224" -> candidates.sha224
        "SHA-256" -> candidates.sha256
        "SHA-384" -> candidates.sha384
        "SHA-512" -> candidates.sha512
        // Legacy synthetic envelopes did not carry an algorithm. Digest length
        // still identifies the supported algorithm without guessing SHA-1.
        else -> when (expectedLength) {
            40 -> candidates.sha1
            56 -> candidates.sha224
            64 -> candidates.sha256
            96 -> candidates.sha384
            128 -> candidates.sha512
            else -> ""
        }
    }

    private fun SodSignatureStatus?.toResultStatus(): SignatureStatus = when (this) {
        SodSignatureStatus.VALID_WITH_PRESENTED_DS -> SignatureStatus.VALID_WITH_PRESENTED_DS
        SodSignatureStatus.INVALID -> SignatureStatus.INVALID
        SodSignatureStatus.NOT_VERIFIABLE_NO_DS_CERT -> SignatureStatus.NOT_VERIFIABLE_NO_DS_CERT
        SodSignatureStatus.NOT_ATTEMPTED -> SignatureStatus.NOT_ATTEMPTED
        SodSignatureStatus.NOT_VERIFIED, null -> SignatureStatus.NOT_VERIFIED
    }

    private fun passiveStatus(
        integrity: IntegrityStatus,
        signature: SignatureStatus,
        trust: IssuerTrustStatus,
    ): PassiveAuthenticationStatus = when {
        integrity != IntegrityStatus.DG_HASH_MATCH -> PassiveAuthenticationStatus.NOT_VERIFIED
        signature != SignatureStatus.VALID_WITH_PRESENTED_DS -> PassiveAuthenticationStatus.PASSIVE_AUTHENTICATION_INCOMPLETE
        trust == IssuerTrustStatus.TRUST_ESTABLISHED -> PassiveAuthenticationStatus.PASSIVE_AUTHENTICATION_COMPLETE
        else -> PassiveAuthenticationStatus.PASSIVE_AUTHENTICATION_INCOMPLETE
    }

    private fun <T> optionalTransportFailure(
        file: ExtendedFile,
        step: ScanStep,
        error: ReaderError,
    ): OptionalAttempt<T> = OptionalAttempt(
        value = null,
        report = FileReadReport(
            file,
            FileReadStatus.UNREADABLE,
            step,
            error = error,
            sodStatus = if (file == ExtendedFile.EF_SOD) SodReadStatus.EF_SOD_SECURE_MESSAGING_FAILURE else null,
        ),
        terminalError = error,
    )

    private fun notPresent(file: ExtendedFile, step: ScanStep) = FileReadReport(
        file = file,
        status = FileReadStatus.NOT_PRESENT,
        step = step,
        error = ReaderError.FILE_NOT_FOUND,
        sodStatus = if (file == ExtendedFile.EF_SOD) SodReadStatus.EF_SOD_NOT_FOUND_IN_SELECTED_APPLICATION else null,
    )

    private fun notAttempted(file: ExtendedFile, step: ScanStep, error: ReaderError?) = FileReadReport(
        file = file,
        status = FileReadStatus.NOT_ATTEMPTED,
        step = step,
        error = error,
        sodStatus = if (file == ExtendedFile.EF_SOD) SodReadStatus.EF_SOD_NOT_ATTEMPTED else null,
    )

    private fun markNotAttempted(reports: MutableList<FileReadReport>, error: ReaderError?) {
        val attempted = reports.map { it.file }.toSet()
        OPTIONAL_FILES.filterNot(attempted::contains).forEach { file ->
            reports += notAttempted(file, file.selectStep(), error)
        }
    }

    private fun isTerminal(error: ReaderError): Boolean =
        error == ReaderError.TAG_LOST || error == ReaderError.TIMEOUT ||
            error == ReaderError.TRANSPORT_ERROR || error == ReaderError.CANCELLED

    private fun ExtendedFile.selectStep(): ScanStep = when (this) {
        ExtendedFile.DG13 -> ScanStep.DG13_SELECTED
        ExtendedFile.EF_SOD -> ScanStep.EF_SOD_SELECTED
        ExtendedFile.DG2 -> ScanStep.DG2_SELECTED
    }

    private data class OptionalAttempt<T>(
        val value: T?,
        val report: FileReadReport,
        val terminalError: ReaderError?,
    )

    private data class HashCandidates(
        val sha1: String,
        val sha224: String,
        val sha256: String,
        val sha384: String,
        val sha512: String,
    )

    private companion object {
        const val EF_COM_FILE_ID = 0x011E
        const val DG1_FILE_ID = 0x0101
        const val DG1_TAG = 0x61
        const val DG13_FILE_ID = 0x010D
        const val DG13_TAG = 0x6D
        const val SOD_FILE_ID = 0x011D
        const val DG2_FILE_ID = 0x0102
        const val DG2_TAG = 0x75
        const val OPTIONAL_FILE_COUNT = 3
        val OPTIONAL_FILES = listOf(ExtendedFile.DG13, ExtendedFile.EF_SOD, ExtendedFile.DG2)
    }
}
