package vn.cccd.bacreader.protocol

data class StatusWord(val value: Int) {
    val sw1: Int get() = (value ushr 8) and 0xFF
    val sw2: Int get() = value and 0xFF
    val isSuccess: Boolean get() = value == 0x9000
    override fun toString(): String = "%04X".format(value)

    companion object {
        fun from(response: ByteArray): StatusWord {
            require(response.size >= 2) { "APDU response has no status word" }
            return StatusWord(
                ((response[response.size - 2].toInt() and 0xFF) shl 8) or
                    (response.last().toInt() and 0xFF),
            )
        }
    }
}

data class ApduResponse(
    val data: ByteArray,
    val status: StatusWord,
) {
    companion object {
        fun parse(response: ByteArray): ApduResponse {
            require(response.size >= 2) { "APDU response has no status word" }
            return ApduResponse(response.copyOfRange(0, response.size - 2), StatusWord.from(response))
        }
    }
}
