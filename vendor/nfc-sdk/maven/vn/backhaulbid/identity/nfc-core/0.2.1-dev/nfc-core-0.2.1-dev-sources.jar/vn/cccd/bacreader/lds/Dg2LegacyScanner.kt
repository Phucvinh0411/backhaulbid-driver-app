package vn.cccd.bacreader.lds

import vn.cccd.bacreader.domain.Dg2LegacyProbe

/**
 * Development-only marker probe retained solely for comparing the old heuristic with the strict
 * parser. It does not return, copy, decode, or retain any candidate image payload.
 */
object Dg2LegacyScanner {
    fun inspect(encoded: ByteArray): Dg2LegacyProbe {
        val jpegStart = encoded.indexOfSequence(JPEG_START)
        val jpegEnd = if (jpegStart >= 0) encoded.indexOfSequence(JPEG_END, jpegStart + JPEG_START.size) else -1
        val jpegFound = jpegStart >= 0 && jpegEnd >= 0
        val jp2FileStart = encoded.indexOfSequence(JP2_FILE_SIGNATURE)
        val codestreamStart = encoded.indexOfSequence(JP2_CODESTREAM_SIGNATURE)
        val jp2Found = jp2FileStart >= 0 || codestreamStart >= 0
        val markerOffset = listOf(jpegStart.takeIf { jpegFound }, jp2FileStart.takeIf { jp2Found }, codestreamStart.takeIf { jp2Found })
            .filterNotNull()
            .minOrNull()
        return Dg2LegacyProbe(
            jpegMarkerFound = jpegFound,
            jpeg2000MarkerFound = jp2Found,
            markerOffset = markerOffset,
            bytesRemainingAfterMarker = markerOffset?.let { encoded.size - it },
        )
    }

    private fun ByteArray.indexOfSequence(needle: ByteArray, fromIndex: Int = 0): Int {
        if (needle.isEmpty()) return fromIndex.coerceAtMost(size)
        val start = fromIndex.coerceAtLeast(0)
        if (needle.size > size - start) return -1
        for (index in start..(size - needle.size)) {
            var matches = true
            for (offset in needle.indices) {
                if (this[index + offset] != needle[offset]) {
                    matches = false
                    break
                }
            }
            if (matches) return index
        }
        return -1
    }

    private val JPEG_START = byteArrayOf(0xFF.toByte(), 0xD8.toByte())
    private val JPEG_END = byteArrayOf(0xFF.toByte(), 0xD9.toByte())
    private val JP2_FILE_SIGNATURE = byteArrayOf(
            0x00, 0x00, 0x00, 0x0C, 0x6A, 0x50, 0x20, 0x20,
            0x0D, 0x0A, 0x87.toByte(), 0x0A,
        )
    private val JP2_CODESTREAM_SIGNATURE = byteArrayOf(0xFF.toByte(), 0x4F.toByte(), 0xFF.toByte(), 0x51.toByte())
}
