package vn.cccd.bacreader.lds

import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets.UTF_8
import vn.cccd.bacreader.domain.Dg13Data
import vn.cccd.bacreader.domain.Dg13Field
import vn.cccd.bacreader.domain.ReaderError

/** Parses DG13's discretionary BER-TLV fields without assuming a national fixed-offset layout. */
object Dg13Parser {
    const val MAX_ENCODED_BYTES: Int = LdsFileLimits.DG13_MAX_ENCODED_BYTES

    fun parse(encoded: ByteArray): Dg13Data {
        val root = readCompleteLdsFile(encoded, DG13_TAG, MAX_ENCODED_BYTES)
        val fields = ArrayList<Dg13Field>()
        val seenTags = HashSet<Int>()
        val contents = root.copyValue()
        try {
            collectFields(contents, fields, seenTags, depth = 0)
            if (fields.isEmpty()) throw unsupported("DG13 contains no supported text fields")
            return Dg13Data(fields = fields.toList(), encodedBytes = encoded.size)
        } finally {
            contents.fill(0)
            root.close()
        }
    }

    private fun collectFields(
        encoded: ByteArray,
        fields: MutableList<Dg13Field>,
        seenTags: MutableSet<Int>,
        depth: Int,
    ) {
        if (depth > MAX_DEPTH) throw unsupported("DG13 nesting is too deep")
        val values = try {
            BerTlvReader.readAll(encoded, maxEncodedLength = MAX_ENCODED_BYTES)
        } catch (error: LdsParseException) {
            throw unsupported("DG13 is not a BER-TLV field set", error)
        }
        try {
            for (field in values) {
                val value = field.copyValue()
                try {
                    if (isConstructed(field.header)) {
                        collectFields(value, fields, seenTags, depth + 1)
                    } else {
                        if (!seenTags.add(field.header.tag)) {
                            throw unsupported("DG13 repeats tag ${field.header.tag.toString(16)}")
                        }
                        fields += Dg13Field(
                            tag = field.header.tag,
                            label = LABELS[field.header.tag]
                                ?: "DG13 tag ${field.header.tag.toString(16).uppercase().padStart(field.header.tagLength * 2, '0')}",
                            value = decodeText(value),
                        )
                    }
                } finally {
                    value.fill(0)
                }
            }
        } finally {
            values.forEach(BerTlv::close)
        }
    }

    private fun decodeText(bytes: ByteArray): String {
        val decoded: CharBuffer = try {
            UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes))
        } catch (error: CharacterCodingException) {
            throw unsupported("DG13 field is not UTF-8 text", error)
        }
        val text = decoded.toString().trimEnd('\u0000', ' ')
        if (text.isEmpty() || text.any { it.isISOControl() && it != '\t' }) {
            throw unsupported("DG13 field is not printable text")
        }
        return text
    }

    private fun isConstructed(header: BerTlvHeader): Boolean {
        val firstOctet = header.tag ushr ((header.tagLength - 1) * 8)
        return firstOctet and 0x20 != 0
    }

    private fun unsupported(detail: String, cause: Throwable? = null): LdsParseException =
        LdsParseException(ReaderError.UNSUPPORTED_LAYOUT, detail, cause)

    private const val DG13_TAG = 0x6D
    private const val MAX_DEPTH = 8
    private val LABELS = mapOf(
        0x5F0E to "Họ tên",
        0x5F10 to "Số định danh cá nhân",
        0x5F11 to "Nơi sinh",
        0x5F12 to "Điện thoại",
        0x5F13 to "Nghề nghiệp",
        0x5F14 to "Chức danh",
        0x5F15 to "Thông tin cá nhân",
        0x5F18 to "Người giám hộ",
        0x5F19 to "Cơ quan cấp",
        0x5F1A to "Người liên quan",
        0x5F1B to "Xác nhận khác",
        0x5F26 to "Ngày cấp",
        0x5F2B to "Ngày sinh",
        0x5F42 to "Địa chỉ",
    )
}
