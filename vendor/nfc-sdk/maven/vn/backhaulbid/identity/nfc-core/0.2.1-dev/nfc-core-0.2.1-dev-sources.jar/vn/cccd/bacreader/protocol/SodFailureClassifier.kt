package vn.cccd.bacreader.protocol

import vn.cccd.bacreader.domain.SodReadStatus

/** Maps authenticated ISO 7816 status words to the SOD ladder's explicit outcomes. */
object SodFailureClassifier {
    fun from(error: SecureMessagingException): SodReadStatus = when (error.sw?.value) {
        0x6A82 -> SodReadStatus.EF_SOD_NOT_FOUND_IN_SELECTED_APPLICATION
        0x6982 -> SodReadStatus.EF_SOD_ACCESS_DENIED
        0x6985 -> SodReadStatus.EF_SOD_CONDITIONS_NOT_SATISFIED
        else -> SodReadStatus.EF_SOD_SECURE_MESSAGING_FAILURE
    }
}
