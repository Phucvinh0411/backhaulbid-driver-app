package vn.cccd.bacreader.protocol

import vn.cccd.bacreader.domain.Dg2Diagnostic
import vn.cccd.bacreader.domain.Dg2ChunkDiagnostic
import vn.cccd.bacreader.domain.Dg2ChunkFailureType
import vn.cccd.bacreader.domain.Dg2DiagnosticSource
import vn.cccd.bacreader.domain.Dg2DiagnosticStage
import vn.cccd.bacreader.domain.Dg2ReaderStatus
import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.lds.BerTlvHeader
import vn.cccd.bacreader.lds.BerTlvLengthReader
import vn.cccd.bacreader.lds.LdsParseException
import vn.cccd.bacreader.nfc.TagLostTransportException
import vn.cccd.bacreader.nfc.TransportException
import vn.cccd.bacreader.nfc.TransportTimeoutException

/** A bounded LDS read together with safe, non-sensitive read metadata. */
class ProtectedFileRead internal constructor(
    val bytes: ByteArray,
    val rawLength: Int,
    val firstTag: Int?,
    val declaredLength: Int?,
    val chunkCount: Int,
    val secureMessagingVerified: Boolean,
) : AutoCloseable {
    override fun close() = bytes.fill(0)
}

/** Reads a complete, definite-length LDS file with APDU-size-derived chunks and a hard cap. */
class ProtectedFileReader(
    private val channel: ProtectedChannel,
) {
    fun readFile(fileId: Int, maxEncodedBytes: Int): ByteArray =
        readFileDetailed(fileId, maxEncodedBytes).let { result ->
            try {
                result.bytes.copyOf()
            } finally {
                result.close()
            }
        }

    /**
     * Reads by FID, falling back to short-file identifier READ BINARY when SELECT returns a
     * status word. This is useful for cards whose LDS directory does not expose an optional
     * file but still permits direct SFI access.
     */
    fun readFileDetailed(
        fileId: Int,
        maxEncodedBytes: Int,
        fallbackSfi: Int? = null,
        onDiagnostic: ((Dg2Diagnostic) -> Unit)? = null,
    ): ProtectedFileRead {
        require(maxEncodedBytes > 0) { "LDS file cap must be positive" }
        try {
            channel.selectFile(fileId).use { select ->
                if (!select.status.isSuccess) {
                    throw SecureMessagingException(ReaderError.PROTECTED_STATUS_ERROR, select.status)
                }
            }
        } catch (error: SecureMessagingException) {
            if (fallbackSfi == null || error.sw == null) {
                emit(
                    onDiagnostic,
                    Dg2Diagnostic(
                        source = Dg2DiagnosticSource.PROTECTED_FILE_READER,
                        stage = Dg2DiagnosticStage.FILE_SELECT,
                        readerStatus = Dg2ReaderStatus.FAILED,
                        failureOffset = 0,
                        failureField = "selectFile",
                        failureStage = Dg2DiagnosticStage.FILE_SELECT,
                    ),
                )
                throw error
            }
            return try {
                readFileBySfi(fallbackSfi, maxEncodedBytes, onDiagnostic)
            } catch (fallbackError: SecureMessagingException) {
                // Preserve the authenticated FID status when a test double/card cannot expose
                // the SFI path. The caller can still classify the original 6A82/6982/6985.
                if (fallbackError.sw == null) throw error
                throw fallbackError
            }
        } catch (error: Throwable) {
            emit(
                onDiagnostic,
                Dg2Diagnostic(
                    source = Dg2DiagnosticSource.PROTECTED_FILE_READER,
                    stage = Dg2DiagnosticStage.FILE_SELECT,
                    readerStatus = Dg2ReaderStatus.FAILED,
                    failureOffset = 0,
                    failureField = "selectFile",
                    failureStage = Dg2DiagnosticStage.FILE_SELECT,
                ),
            )
            throw error
        }
        emit(
            onDiagnostic,
            Dg2Diagnostic(
                source = Dg2DiagnosticSource.PROTECTED_FILE_READER,
                stage = Dg2DiagnosticStage.FILE_SELECT,
                readerStatus = Dg2ReaderStatus.SELECTED,
            ),
        )
        return readSelected(
            maxEncodedBytes = maxEncodedBytes,
            onDiagnostic = onDiagnostic,
            readBinary = { offset, length -> channel.readBinary(offset, length) },
            readBinaryWithDiagnostics = (channel as? ProtectedChannelDiagnostics)?.let { diagnostics ->
                { offset, length, onTrace -> diagnostics.readBinaryWithDiagnostics(offset, length, onTrace) }
            },
        )
    }

    fun readFileBySfi(
        sfi: Int,
        maxEncodedBytes: Int,
        onDiagnostic: ((Dg2Diagnostic) -> Unit)? = null,
    ): ProtectedFileRead {
        require(sfi in 1..0x1F) { "SFI must fit five bits" }
        require(maxEncodedBytes > 0) { "LDS file cap must be positive" }
        emit(
            onDiagnostic,
            Dg2Diagnostic(
                source = Dg2DiagnosticSource.PROTECTED_FILE_READER,
                stage = Dg2DiagnosticStage.FILE_SELECT,
                readerStatus = Dg2ReaderStatus.SELECTED,
            ),
        )
        return readSelected(
            maxEncodedBytes = maxEncodedBytes,
            onDiagnostic = onDiagnostic,
            readBinary = { offset, length -> channel.readBinaryBySfi(sfi, offset, length) },
            readBinaryWithDiagnostics = (channel as? ProtectedChannelDiagnostics)?.let { diagnostics ->
                { offset, length, onTrace -> diagnostics.readBinaryBySfiWithDiagnostics(sfi, offset, length, onTrace) }
            },
        )
    }

    private fun readSelected(
        maxEncodedBytes: Int,
        onDiagnostic: ((Dg2Diagnostic) -> Unit)?,
        readBinary: (offset: Int, length: Int) -> ProtectedResponse,
        readBinaryWithDiagnostics: ((offset: Int, length: Int, onTrace: (ProtectedTransceiveTrace) -> Unit) -> ProtectedResponse)?,
    ): ProtectedFileRead {
        val accumulator = ByteArray(maxEncodedBytes)
        val chunkTrace = ArrayList<Dg2ChunkDiagnostic>(minOf(MAX_CHUNK_TRACE, 64))
        var used = 0
        var chunks = 0
        var stage = Dg2DiagnosticStage.BER_HEADER
        var failureField: String? = "berHeader"
        var completed = false
        try {
            var header: BerTlvHeader? = null
            while (header == null) {
                stage = Dg2DiagnosticStage.BER_HEADER
                failureField = "berHeader"
                val chunkIndex = ++chunks
                used = readMore(
                    buffer = accumulator,
                    offset = used,
                    remaining = minOf(4, maxEncodedBytes - used),
                    chunkIndex = chunkIndex,
                    chunkTrace = chunkTrace,
                    readBinary = readBinary,
                    readBinaryWithDiagnostics = readBinaryWithDiagnostics,
                )
                val prefix = accumulator.copyOf(used)
                try {
                    header = BerTlvLengthReader.tryReadHeader(prefix, maxEncodedLength = maxEncodedBytes)
                } catch (error: LdsParseException) {
                    throw SecureMessagingException(error.error, cause = error)
                } finally {
                    prefix.fill(0)
                }
                if (used == maxEncodedBytes && header == null) {
                    throw SecureMessagingException(ReaderError.FILE_MALFORMED)
                }
            }
            stage = Dg2DiagnosticStage.BER_BODY
            failureField = "berValue"
            val targetLength = header.encodedLength
            if (targetLength > maxEncodedBytes) {
                failureField = "declaredLength"
                throw SecureMessagingException(ReaderError.FILE_TOO_LARGE)
            }
            if (used > targetLength) {
                failureField = "encodedLength"
                throw SecureMessagingException(ReaderError.FILE_MALFORMED)
            }
            while (used < targetLength) {
                val chunkIndex = ++chunks
                used = readMore(
                    buffer = accumulator,
                    offset = used,
                    remaining = targetLength - used,
                    chunkIndex = chunkIndex,
                    chunkTrace = chunkTrace,
                    readBinary = readBinary,
                    readBinaryWithDiagnostics = readBinaryWithDiagnostics,
                )
            }
            val result = ProtectedFileRead(
                bytes = accumulator.copyOf(targetLength),
                rawLength = targetLength,
                firstTag = header.tag,
                declaredLength = header.valueLength,
                chunkCount = chunks,
                secureMessagingVerified = true,
            )
            emit(
                onDiagnostic,
                Dg2Diagnostic(
                    source = Dg2DiagnosticSource.PROTECTED_FILE_READER,
                    stage = stage,
                    bytesRead = targetLength,
                    rawLength = targetLength,
                    chunkCount = chunks,
                    firstTag = header.tag,
                    declaredLength = header.valueLength,
                    readerStatus = Dg2ReaderStatus.COMPLETE,
                    maxPlainChunk = channel.maxReadBinaryLength,
                    secureMessagingOverhead = (channel as? ProtectedChannelDiagnostics)?.secureMessagingOverhead,
                    effectiveTransceiveMaximum = (channel as? ProtectedChannelDiagnostics)?.effectiveTransceiveMaximum,
                    chunkTrace = chunkTrace.toList(),
                ),
            )
            completed = true
            return result
        } catch (error: Throwable) {
            if (!completed) {
                val observedHeader = observedHeader(accumulator, used, maxEncodedBytes)
                emit(
                    onDiagnostic,
                    Dg2Diagnostic(
                        source = Dg2DiagnosticSource.PROTECTED_FILE_READER,
                        stage = stage,
                        bytesRead = used,
                        rawLength = observedHeader?.encodedLength,
                        chunkCount = chunks,
                        firstTag = observedHeader?.tag ?: accumulator.firstTag(used),
                        declaredLength = observedHeader?.valueLength,
                        readerStatus = Dg2ReaderStatus.FAILED,
                        failureOffset = used,
                        failureField = failureField,
                        failureStage = stage,
                        remainingBytes = observedHeader?.encodedLength?.minus(used)?.coerceAtLeast(0),
                        maxPlainChunk = channel.maxReadBinaryLength,
                        secureMessagingOverhead = (channel as? ProtectedChannelDiagnostics)?.secureMessagingOverhead,
                        effectiveTransceiveMaximum = (channel as? ProtectedChannelDiagnostics)?.effectiveTransceiveMaximum,
                        failureType = chunkTrace.lastOrNull()?.failureType ?: classifyFailure(error),
                        chunkTrace = chunkTrace.toList(),
                    ),
                )
            }
            throw error
        } finally {
            accumulator.fill(0)
        }
    }

    private fun emit(callback: ((Dg2Diagnostic) -> Unit)?, diagnostic: Dg2Diagnostic) {
        callback?.invoke(diagnostic)
    }

    private fun ByteArray.firstTag(used: Int): Int? = if (used > 0) this[0].toInt() and 0xFF else null

    private fun readMore(
        buffer: ByteArray,
        offset: Int,
        remaining: Int,
        chunkIndex: Int,
        chunkTrace: MutableList<Dg2ChunkDiagnostic>,
        readBinary: (offset: Int, length: Int) -> ProtectedResponse,
        readBinaryWithDiagnostics: ((offset: Int, length: Int, onTrace: (ProtectedTransceiveTrace) -> Unit) -> ProtectedResponse)?,
    ): Int {
        if (remaining <= 0) throw SecureMessagingException(ReaderError.FILE_MALFORMED)
        val requested = minOf(remaining, channel.maxReadBinaryLength)
        val traceSizeBefore = chunkTrace.size
        val response = try {
            if (readBinaryWithDiagnostics != null) {
                readBinaryWithDiagnostics(offset, requested) { trace ->
                    appendTrace(
                        chunkTrace,
                        Dg2ChunkDiagnostic(
                            chunkIndex = chunkIndex,
                            fileOffset = offset,
                            requestedPlainLength = requested,
                            receivedPlainLength = trace.receivedPlainLength,
                            encodedCommandLength = trace.encodedCommandLength,
                            transceiveDurationMillis = trace.transceiveDurationMillis,
                            statusWord = trace.statusWord,
                            isoDepConnected = trace.isoDepConnected,
                            isoDepTimeoutMillis = trace.isoDepTimeoutMillis,
                            isoDepMaxTransceiveLength = trace.isoDepMaxTransceiveLength,
                            failureType = trace.failureType,
                        ),
                    )
                }
            } else {
                readBinary(offset, requested)
            }
        } catch (error: Throwable) {
            if (chunkTrace.size == traceSizeBefore) {
                appendTrace(
                    chunkTrace,
                    Dg2ChunkDiagnostic(
                        chunkIndex = chunkIndex,
                        fileOffset = offset,
                        requestedPlainLength = requested,
                        failureType = classifyFailure(error),
                    ),
                )
            }
            throw error
        }
        response.use { protectedResponse ->
            if (!protectedResponse.status.isSuccess) {
                if (chunkTrace.size == traceSizeBefore) {
                    appendTrace(
                        chunkTrace,
                        Dg2ChunkDiagnostic(
                            chunkIndex = chunkIndex,
                            fileOffset = offset,
                            requestedPlainLength = requested,
                            statusWord = protectedResponse.status.value,
                            failureType = Dg2ChunkFailureType.APDU_STATUS_ERROR,
                        ),
                    )
                }
                throw SecureMessagingException(ReaderError.PROTECTED_STATUS_ERROR, protectedResponse.status)
            }
            val data = protectedResponse.copyData()
            try {
                if (data.isEmpty() || data.size > requested || data.size > remaining) {
                    if (chunkTrace.size == traceSizeBefore) {
                        appendTrace(
                            chunkTrace,
                            Dg2ChunkDiagnostic(
                                chunkIndex = chunkIndex,
                                fileOffset = offset,
                                requestedPlainLength = requested,
                                receivedPlainLength = data.size,
                                statusWord = protectedResponse.status.value,
                                failureType = Dg2ChunkFailureType.SECURE_MESSAGING_UNWRAP_ERROR,
                            ),
                        )
                    }
                    throw SecureMessagingException(ReaderError.FILE_MALFORMED)
                }
                if (chunkTrace.size == traceSizeBefore) {
                    appendTrace(
                        chunkTrace,
                        Dg2ChunkDiagnostic(
                            chunkIndex = chunkIndex,
                            fileOffset = offset,
                            requestedPlainLength = requested,
                            receivedPlainLength = data.size,
                            statusWord = protectedResponse.status.value,
                        ),
                    )
                }
                data.copyInto(buffer, offset)
                return offset + data.size
            } finally {
                data.fill(0)
            }
        }
    }

    private fun observedHeader(buffer: ByteArray, used: Int, maxEncodedBytes: Int): BerTlvHeader? {
        val snapshot = buffer.copyOf(used)
        return try {
            BerTlvLengthReader.tryReadHeader(snapshot, maxEncodedLength = maxEncodedBytes)
        } catch (_: Throwable) {
            null
        } finally {
            snapshot.fill(0)
        }
    }

    private fun appendTrace(target: MutableList<Dg2ChunkDiagnostic>, trace: Dg2ChunkDiagnostic) {
        if (target.size < MAX_CHUNK_TRACE) target += trace
    }

    private fun classifyFailure(error: Throwable): Dg2ChunkFailureType? = when {
        error is TagLostTransportException -> Dg2ChunkFailureType.TAG_LOST_DURING_TRANSCEIVE
        error is SecureMessagingException && error.error == ReaderError.TAG_LOST ->
            Dg2ChunkFailureType.TAG_LOST_DURING_TRANSCEIVE
        error is TransportTimeoutException -> Dg2ChunkFailureType.TRANSCEIVE_TIMEOUT
        error is SecureMessagingException && error.error == ReaderError.TIMEOUT ->
            Dg2ChunkFailureType.TRANSCEIVE_TIMEOUT
        error is SecureMessagingException &&
            (error.error == ReaderError.PROTECTED_STATUS_ERROR || error.error == ReaderError.UNEXPECTED_STATUS) ->
            Dg2ChunkFailureType.APDU_STATUS_ERROR
        error is SecureMessagingException &&
            (error.error == ReaderError.MAC_MISMATCH || error.error == ReaderError.MALFORMED_RESPONSE) ->
            Dg2ChunkFailureType.SECURE_MESSAGING_UNWRAP_ERROR
        error is TransportException || error.cause is TransportException -> Dg2ChunkFailureType.TRANSPORT_ERROR
        else -> null
    }

    private companion object {
        const val MAX_CHUNK_TRACE = 256
    }
}
