package vn.cccd.bacreader.protocol

import java.security.MessageDigest
import java.security.SecureRandom
import vn.cccd.bacreader.crypto.BacCipher
import vn.cccd.bacreader.crypto.BacKeyDeriver
import vn.cccd.bacreader.crypto.RetailMac
import vn.cccd.bacreader.crypto.SensitiveBytes
import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.domain.ScanStep
import vn.cccd.bacreader.nfc.ApduTransport
import vn.cccd.bacreader.nfc.TagLostTransportException
import vn.cccd.bacreader.nfc.TransportException
import vn.cccd.bacreader.nfc.TransportTimeoutException

/** Test seam only. Production construction always uses [SecureRandom]. */
internal fun interface RandomSource {
    fun nextBytes(target: ByteArray)
}

private class SecureRandomSource : RandomSource {
    private val secureRandom = SecureRandom()
    override fun nextBytes(target: ByteArray) = secureRandom.nextBytes(target)
}

class BacException(
    val error: ReaderError,
    val sw: StatusWord? = null,
    cause: Throwable? = null,
) : Exception("BAC failed: $error${sw?.let { " SW=$it" } ?: ""}", cause)

/** Wipeable BAC session keys. Key copies returned by this class belong to the caller. */
class BacSession internal constructor(
    sessionEncRaw: ByteArray,
    sessionMacRaw: ByteArray,
    ssc: ByteArray,
) : AutoCloseable {
    private val encRaw = SensitiveBytes(sessionEncRaw)
    private val macRaw = SensitiveBytes(sessionMacRaw)
    private val sequence = SensitiveBytes(ssc)

    fun copySessionEncRaw(): ByteArray = encRaw.copy()
    fun copySessionMacRaw(): ByteArray = macRaw.copy()
    fun copySessionEncKey(): ByteArray = expand(encRaw)
    fun copySessionMacKey(): ByteArray = expand(macRaw)
    fun copySsc(): ByteArray = sequence.copy()

    override fun close() {
        encRaw.close()
        macRaw.close()
        sequence.close()
    }

    override fun toString(): String = "BacSession(<redacted>)"

    private fun expand(raw: SensitiveBytes): ByteArray {
        val copy = raw.copy()
        return try {
            BacKeyDeriver.toDesEdeKey(copy)
        } finally {
            copy.fill(0)
        }
    }
}

class BacAuthenticator private constructor(
    private val random: RandomSource,
) {
    constructor() : this(SecureRandomSource())

    fun authenticate(
        transport: ApduTransport,
        mrzInformation: ByteArray,
        onStep: (ScanStep) -> Unit = {},
    ): BacSession {
        require(mrzInformation.size == MRZ_INFORMATION_LENGTH) { "MRZ information must be 24 bytes" }
        val baseKeys = BacKeyDeriver.derive(mrzInformation)
        try {
            selectApplication(transport)
            onStep(ScanStep.APPLET_SELECTED)

            val rndIcc = getChallenge(transport)
            try {
                onStep(ScanStep.CHALLENGE_RECEIVED)
                val rndIfd = ByteArray(NONCE_LENGTH)
                val kIfd = ByteArray(KEY_MATERIAL_LENGTH)
                random.nextBytes(rndIfd)
                random.nextBytes(kIfd)
                try {
                    externalAuthenticate(
                        transport = transport,
                        baseKeys = baseKeys,
                        rndIcc = rndIcc,
                        rndIfd = rndIfd,
                        kIfd = kIfd,
                        onStep = onStep,
                    ).use { verified ->
                        return createSession(
                            kIfd = kIfd,
                            kIcc = verified.copyKeyIcc(),
                            rndIcc = rndIcc,
                            rndIfd = rndIfd,
                            onStep = onStep,
                        )
                    }
                } finally {
                    rndIfd.fill(0)
                    kIfd.fill(0)
                }
            } finally {
                rndIcc.fill(0)
            }
        } finally {
            baseKeys.close()
        }
    }

    private fun selectApplication(transport: ApduTransport) {
        val command = byteArrayOf(
            0x00, 0xA4.toByte(), 0x04, 0x00, 0x07,
            0xA0.toByte(), 0x00, 0x00, 0x02, 0x47, 0x10, 0x01,
        )
        val response = parseOrThrow(transport, command)
        try {
            when {
                response.status.value == 0x6A82 -> throw BacException(ReaderError.APPLET_NOT_FOUND, response.status)
                !response.status.isSuccess -> throw BacException(ReaderError.UNEXPECTED_STATUS, response.status)
                response.data.size > MAX_FCI_LENGTH -> throw BacException(ReaderError.MALFORMED_RESPONSE, response.status)
            }
        } finally {
            response.data.fill(0)
            command.fill(0)
        }
    }

    private fun getChallenge(transport: ApduTransport): ByteArray {
        val command = byteArrayOf(0x00, 0x84.toByte(), 0x00, 0x00, 0x08)
        val response = parseOrThrow(transport, command)
        try {
            if (!response.status.isSuccess) throw BacException(ReaderError.UNEXPECTED_STATUS, response.status)
            if (response.data.size != NONCE_LENGTH) {
                throw BacException(ReaderError.MALFORMED_CHALLENGE, response.status)
            }
            return response.data.copyOf()
        } finally {
            response.data.fill(0)
            command.fill(0)
        }
    }

    /** Sends exactly one EXTERNAL AUTHENTICATE command; no retry path exists. */
    private fun externalAuthenticate(
        transport: ApduTransport,
        baseKeys: vn.cccd.bacreader.crypto.BacKeyMaterial,
        rndIcc: ByteArray,
        rndIfd: ByteArray,
        kIfd: ByteArray,
        onStep: (ScanStep) -> Unit,
    ): VerifiedExternalResponse {
        val requestPlain = ByteArray(EXTERNAL_CRYPTOGRAM_LENGTH).also {
            rndIfd.copyInto(it)
            rndIcc.copyInto(it, NONCE_LENGTH)
            kIfd.copyInto(it, NONCE_LENGTH * 2)
        }
        val eIfd = ByteArray(EXTERNAL_CRYPTOGRAM_LENGTH)
        val mIfd = ByteArray(MAC_LENGTH)
        val command = ByteArray(EXTERNAL_AUTH_COMMAND_LENGTH)
        try {
            val encKey = baseKeys.copyKEncDesEde()
            try {
                val encryptedRequest = BacCipher.encrypt(requestPlain, encKey)
                try {
                    encryptedRequest.copyInto(eIfd)
                } finally {
                    encryptedRequest.fill(0)
                }
            } finally {
                encKey.fill(0)
            }
            val macKey = baseKeys.copyKMacDesEde()
            try {
                val requestMac = RetailMac.computeWithDesEdeKey(macKey, eIfd)
                try {
                    requestMac.copyInto(mIfd)
                } finally {
                    requestMac.fill(0)
                }
            } finally {
                macKey.fill(0)
            }
            command[0] = 0x00
            command[1] = 0x82.toByte()
            command[4] = EXTERNAL_DATA_LENGTH.toByte()
            eIfd.copyInto(command, 5)
            mIfd.copyInto(command, 5 + EXTERNAL_CRYPTOGRAM_LENGTH)
            command[command.lastIndex] = EXTERNAL_DATA_LENGTH.toByte()

            onStep(ScanStep.EXTERNAL_AUTH_SENT)
            val rawResponse = transceive(transport, command)
            try {
                val response = try {
                    ApduResponse.parse(rawResponse)
                } catch (error: IllegalArgumentException) {
                    throw BacException(ReaderError.MALFORMED_RESPONSE, cause = error)
                }
                try {
                    when {
                        response.status.value == 0x6982 -> throw BacException(ReaderError.ACCESS_REJECTED, response.status)
                        !response.status.isSuccess -> throw BacException(ReaderError.UNEXPECTED_STATUS, response.status)
                        response.data.size != EXTERNAL_DATA_LENGTH -> throw BacException(ReaderError.MALFORMED_RESPONSE, response.status)
                    }
                    val eIcc = response.data.copyOfRange(0, EXTERNAL_CRYPTOGRAM_LENGTH)
                    val mIcc = response.data.copyOfRange(EXTERNAL_CRYPTOGRAM_LENGTH, EXTERNAL_DATA_LENGTH)
                    val expectedMac = ByteArray(MAC_LENGTH)
                    try {
                        val responseMacKey = baseKeys.copyKMacDesEde()
                        try {
                            val responseMac = RetailMac.computeWithDesEdeKey(responseMacKey, eIcc)
                            try {
                                responseMac.copyInto(expectedMac)
                            } finally {
                                responseMac.fill(0)
                            }
                        } finally {
                            responseMacKey.fill(0)
                        }
                        // Integrity is checked before any response plaintext becomes available.
                        if (!MessageDigest.isEqual(expectedMac, mIcc)) {
                            throw BacException(ReaderError.MAC_MISMATCH, response.status)
                        }
                        val responsePlain: ByteArray
                        val responseEncKey = baseKeys.copyKEncDesEde()
                        try {
                            responsePlain = BacCipher.decrypt(eIcc, responseEncKey)
                        } finally {
                            responseEncKey.fill(0)
                        }
                        try {
                            if (!constantTimeEqualsAt(rndIcc, responsePlain, 0) ||
                                !constantTimeEqualsAt(rndIfd, responsePlain, NONCE_LENGTH)
                            ) {
                                throw BacException(ReaderError.NONCE_MISMATCH, response.status)
                            }
                            return VerifiedExternalResponse(responsePlain.copyOfRange(NONCE_LENGTH * 2, EXTERNAL_CRYPTOGRAM_LENGTH))
                        } finally {
                            responsePlain.fill(0)
                        }
                    } finally {
                        expectedMac.fill(0)
                        eIcc.fill(0)
                        mIcc.fill(0)
                    }
                } finally {
                    response.data.fill(0)
                }
            } finally {
                rawResponse.fill(0)
            }
        } finally {
            requestPlain.fill(0)
            eIfd.fill(0)
            mIfd.fill(0)
            command.fill(0)
        }
    }

    private fun createSession(
        kIfd: ByteArray,
        kIcc: ByteArray,
        rndIcc: ByteArray,
        rndIfd: ByteArray,
        onStep: (ScanStep) -> Unit,
    ): BacSession {
        val sessionSeed = ByteArray(KEY_MATERIAL_LENGTH) { index ->
            (kIfd[index].toInt() xor kIcc[index].toInt()).toByte()
        }
        try {
            BacKeyDeriver.deriveFromSeed(sessionSeed).use { sessionKeys ->
                val encRaw = sessionKeys.copyKEncRaw()
                val macRaw = sessionKeys.copyKMacRaw()
                val ssc = ByteArray(NONCE_LENGTH).also {
                    rndIcc.copyInto(it, destinationOffset = 0, startIndex = NONCE_LENGTH / 2)
                    rndIfd.copyInto(it, destinationOffset = NONCE_LENGTH / 2, startIndex = NONCE_LENGTH / 2)
                }
                try {
                    return BacSession(encRaw, macRaw, ssc).also { onStep(ScanStep.BAC_RESPONSE_VERIFIED) }
                } finally {
                    encRaw.fill(0)
                    macRaw.fill(0)
                    ssc.fill(0)
                }
            }
        } finally {
            kIcc.fill(0)
            sessionSeed.fill(0)
        }
    }

    private fun parseOrThrow(transport: ApduTransport, command: ByteArray): ApduResponse {
        val rawResponse = transceive(transport, command)
        return try {
            ApduResponse.parse(rawResponse)
        } catch (error: IllegalArgumentException) {
            throw BacException(ReaderError.MALFORMED_RESPONSE, cause = error)
        } finally {
            rawResponse.fill(0)
        }
    }

    private fun transceive(transport: ApduTransport, command: ByteArray): ByteArray = try {
        if (command.size > transport.maxTransceiveLength) {
            throw BacException(ReaderError.MALFORMED_RESPONSE)
        }
        transport.transceive(command)
    } catch (error: BacException) {
        throw error
    } catch (error: TagLostTransportException) {
        throw BacException(ReaderError.TAG_LOST, cause = error)
    } catch (error: TransportTimeoutException) {
        throw BacException(ReaderError.TIMEOUT, cause = error)
    } catch (error: TransportException) {
        throw BacException(ReaderError.TRANSPORT_ERROR, cause = error)
    }

    private class VerifiedExternalResponse(kIcc: ByteArray) : AutoCloseable {
        private val keyIcc = SensitiveBytes(kIcc)
        init {
            kIcc.fill(0)
        }
        fun copyKeyIcc(): ByteArray = keyIcc.copy()
        override fun close() = keyIcc.close()
    }

    private fun constantTimeEqualsAt(expected: ByteArray, actual: ByteArray, offset: Int): Boolean {
        if (offset < 0 || actual.size - offset < expected.size) return false
        var difference = 0
        expected.indices.forEach { index ->
            difference = difference or (expected[index].toInt() xor actual[offset + index].toInt())
        }
        return difference == 0
    }

    companion object {
        internal fun forTesting(random: RandomSource): BacAuthenticator = BacAuthenticator(random)

        private const val MRZ_INFORMATION_LENGTH = 24
        private const val NONCE_LENGTH = 8
        private const val KEY_MATERIAL_LENGTH = 16
        private const val MAC_LENGTH = 8
        private const val EXTERNAL_CRYPTOGRAM_LENGTH = 32
        private const val EXTERNAL_DATA_LENGTH = 40
        private const val EXTERNAL_AUTH_COMMAND_LENGTH = 46
        private const val MAX_FCI_LENGTH = 4 * 1024
    }
}
