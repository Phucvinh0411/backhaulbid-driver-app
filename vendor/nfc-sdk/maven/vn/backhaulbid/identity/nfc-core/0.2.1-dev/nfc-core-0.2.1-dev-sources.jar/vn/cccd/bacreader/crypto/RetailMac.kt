package vn.cccd.bacreader.crypto

import java.security.GeneralSecurityException
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/** ISO 9797-1 MAC algorithm 3 with method 2 padding and an 8-byte result. */
object RetailMac {
    fun compute(rawKey16: ByteArray, message: ByteArray): ByteArray {
        val key = BacKeyDeriver.toDesEdeKey(rawKey16)
        return try {
            computeWithDesEdeKey(key, message)
        } finally {
            key.fill(0)
        }
    }

    fun computeWithDesEdeKey(key24: ByteArray, message: ByteArray): ByteArray {
        require(key24.size == 24) { "DESede key must be 24 bytes" }
        val padded = padMethod2(message)
        var k1Bytes: ByteArray? = null
        var k2Bytes: ByteArray? = null
        var chained: ByteArray? = null
        var last: ByteArray? = null
        var decrypted: ByteArray? = null
        return try {
            k1Bytes = key24.copyOfRange(0, 8)
            k2Bytes = key24.copyOfRange(8, 16)
            val k1 = SecretKeySpec(k1Bytes, "DES")
            val k2 = SecretKeySpec(k2Bytes, "DES")
            val cbc = Cipher.getInstance("DES/CBC/NoPadding")
            cbc.init(Cipher.ENCRYPT_MODE, k1, IvParameterSpec(ByteArray(8)))
            chained = cbc.doFinal(padded)
            last = chained.copyOfRange(chained.size - 8, chained.size)

            val decrypt = Cipher.getInstance("DES/ECB/NoPadding")
            decrypt.init(Cipher.DECRYPT_MODE, k2)
            decrypted = decrypt.doFinal(last)
            val encrypt = Cipher.getInstance("DES/ECB/NoPadding")
            encrypt.init(Cipher.ENCRYPT_MODE, k1)
            encrypt.doFinal(decrypted)
        } catch (error: GeneralSecurityException) {
            throw IllegalStateException("DES MAC is unavailable", error)
        } finally {
            padded.fill(0)
            k1Bytes?.fill(0)
            k2Bytes?.fill(0)
            chained?.fill(0)
            last?.fill(0)
            decrypted?.fill(0)
        }
    }

    private fun padMethod2(message: ByteArray): ByteArray {
        val size = ((message.size / 8) + 1) * 8
        return ByteArray(size).also {
            message.copyInto(it)
            it[message.size] = 0x80.toByte()
        }
    }
}
