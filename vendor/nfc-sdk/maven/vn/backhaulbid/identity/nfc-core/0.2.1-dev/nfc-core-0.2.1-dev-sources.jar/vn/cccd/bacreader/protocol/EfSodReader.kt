package vn.cccd.bacreader.protocol

import vn.cccd.bacreader.lds.SodParser

/** Reads EF.SOD by FID and, when necessary, by SFI 1D. */
class EfSodReader(private val fileReader: ProtectedFileReader) {
    fun read(): ProtectedFileRead = read(SodParser.MAX_ENCODED_BYTES)

    fun read(maxEncodedBytes: Int): ProtectedFileRead =
        fileReader.readFileDetailed(FILE_ID, maxEncodedBytes, fallbackSfi = SFI)

    private companion object {
        const val FILE_ID = 0x011D
        const val SFI = 0x1D
    }
}
