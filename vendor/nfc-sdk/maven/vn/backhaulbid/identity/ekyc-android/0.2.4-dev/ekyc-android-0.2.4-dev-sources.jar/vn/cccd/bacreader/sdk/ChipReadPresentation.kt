package vn.cccd.bacreader.sdk

import java.time.DateTimeException
import java.time.LocalDate

/**
 * What the host app may show right after a chip read. These are values just read on the phone, not a
 * verification result: the server decides acceptance. Name, date of birth and sex come from DG1. The 12-digit
 * citizen ID comes from DG13 and is reported only as read or missing; the 9-character MRZ document number is
 * not the citizen ID, so it is never shown as one.
 */
internal object ChipReadPresentation {
    const val MISSING = "Chưa có thông tin"
    const val READ = "Đã đọc"

    data class Row(val label: String, val value: String)

    /** Release display: whether each field was read, without its value. */
    fun statusRows(
        fullName: String?, dateOfBirthYymmdd: String?, sex: String?, today: LocalDate,
        citizenIdRead: Boolean = false,
    ): List<Row> = rows(fullName, dateOfBirthYymmdd, sex, today, citizenIdRead).map { row ->
        Row(row.label, if (row.value == MISSING) MISSING else READ)
    }

    /** The DG13 row carries presence only, so it never holds a personal value. */
    fun rows(
        fullName: String?, dateOfBirthYymmdd: String?, sex: String?, today: LocalDate,
        citizenIdRead: Boolean = false,
    ): List<Row> = listOf(
        Row("Họ và tên", fullName?.trim()?.takeIf { it.isNotEmpty() } ?: MISSING),
        Row("Số CCCD", if (citizenIdRead) READ else MISSING),
        Row("Ngày sinh", birthDate(dateOfBirthYymmdd, today) ?: MISSING),
        Row("Giới tính", when (sex?.trim()) { "M" -> "Nam"; "F" -> "Nữ"; else -> MISSING }),
    )

    /**
     * MRZ keeps a 2-digit year. Policy (same as the server parser): the holder was born within the last
     * 100 years, so a year after the current one belongs to the previous century. Invalid input is missing.
     */
    fun birthDate(yymmdd: String?, today: LocalDate): String? {
        val value = yymmdd?.trim() ?: return null
        if (!Regex("\\d{6}").matches(value)) return null
        val yy = value.substring(0, 2).toInt()
        var year = today.year / 100 * 100 + yy
        if (year > today.year) year -= 100
        return try {
            val date = LocalDate.of(year, value.substring(2, 4).toInt(), value.substring(4, 6).toInt())
            if (date.isAfter(today)) null else "%02d/%02d/%04d".format(date.dayOfMonth, date.monthValue, date.year)
        } catch (invalid: DateTimeException) {
            null
        }
    }
}
