package vn.cccd.bacreader.biometric.recognition

import android.graphics.Bitmap
import vn.cccd.bacreader.biometric.RgbImage

internal object BitmapRgbConverter {
    fun convert(bitmap: Bitmap): RgbImage {
        check(!bitmap.isRecycled) { "bitmap recycled" }
        require(bitmap.width > 0 && bitmap.height > 0)
        val argb = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(argb, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        val rgb = ByteArray(argb.size * RgbImage.CHANNELS)
        argb.forEachIndexed { index, color ->
            val offset = index * RgbImage.CHANNELS
            rgb[offset] = ((color ushr 16) and 0xFF).toByte()
            rgb[offset + 1] = ((color ushr 8) and 0xFF).toByte()
            rgb[offset + 2] = (color and 0xFF).toByte()
        }
        argb.fill(0)
        return RgbImage(bitmap.width, bitmap.height, rgb)
    }
}
