package vn.cccd.bacreader.biometric

/**
 * Short-lived RGB pixels owned by the caller. The backing bytes are wiped on close and are
 * never persisted or logged. This type deliberately exposes pixels only through safe accessors.
 */
internal class RgbImage(
    val width: Int,
    val height: Int,
    internal val pixels: ByteArray,
) : AutoCloseable {
    private var closed = false

    init {
        require(width > 0 && height > 0)
        require(pixels.size == width * height * CHANNELS)
    }

    fun channelAt(x: Int, y: Int, channel: Int): Int {
        check(!closed) { "RGB image has been closed" }
        require(x in 0 until width)
        require(y in 0 until height)
        require(channel in 0 until CHANNELS)
        return pixels[(y * width + x) * CHANNELS + channel].toInt() and 0xFF
    }

    internal fun copy(): RgbImage {
        check(!closed) { "RGB image has been closed" }
        return RgbImage(width, height, pixels.copyOf())
    }

    override fun close() {
        if (!closed) {
            pixels.fill(0)
            closed = true
        }
    }

    companion object {
        const val CHANNELS = 3
    }
}
