package vn.cccd.bacreader.logging

import android.util.Log
import vn.cccd.bacreader.domain.ExtendedFile
import vn.cccd.bacreader.domain.AuthenticityResult
import vn.cccd.bacreader.domain.Dg13Metadata
import vn.cccd.bacreader.domain.Dg2Diagnostic
import vn.cccd.bacreader.domain.Dg2ImageFormat
import vn.cccd.bacreader.domain.FileReadStatus
import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.domain.ScanStep
import vn.cccd.bacreader.domain.SodReadStatus

/** Logs only the approved diagnostic allowlist; never credentials, UID, APDUs, or DG bytes. */
class SafeScanLogger {
    fun recordDg2PortraitDecode(
        scanId: String,
        format: Dg2ImageFormat,
        encodedLength: Int,
        decodeStatus: String,
        decodedWidth: Int? = null,
        decodedHeight: Int? = null,
    ) {
        Log.i(
            TAG,
            formatDg2PortraitDecode(
                scanId,
                format,
                encodedLength,
                decodeStatus,
                decodedWidth,
                decodedHeight,
            ),
        )
    }

    internal fun formatDg2PortraitDecode(
        scanId: String,
        format: Dg2ImageFormat,
        encodedLength: Int,
        decodeStatus: String,
        decodedWidth: Int? = null,
        decodedHeight: Int? = null,
    ): String = buildString {
        append("scan=").append(scanId.takeIf(SCAN_ID_PATTERN::matches) ?: "invalid")
            .append(" dg2PortraitFormat=").append(format.name)
            .append(" dg2PortraitEncodedLength=").append(encodedLength)
            .append(" dg2PortraitDecodeStatus=").append(decodeStatus)
            .append(" dg2PortraitDecodedWidth=").append(decodedWidth ?: "none")
            .append(" dg2PortraitDecodedHeight=").append(decodedHeight ?: "none")
    }

    fun record(
        scanId: String,
        step: ScanStep,
        error: ReaderError? = null,
        sw: String? = null,
        bytesRead: Int? = null,
        elapsedMillis: Long? = null,
        file: ExtendedFile? = null,
        status: FileReadStatus? = null,
        sodStatus: SodReadStatus? = null,
        authenticity: AuthenticityResult? = null,
        metadata: Dg13Metadata? = null,
        dg2Diagnostic: Dg2Diagnostic? = null,
    ) {
        Log.i(TAG, formatForLog(scanId, step, error, sw, bytesRead, elapsedMillis, file, status, sodStatus, authenticity, metadata, dg2Diagnostic))
    }

    internal fun formatForLog(
        scanId: String,
        step: ScanStep,
        error: ReaderError? = null,
        sw: String? = null,
        bytesRead: Int? = null,
        elapsedMillis: Long? = null,
        file: ExtendedFile? = null,
        status: FileReadStatus? = null,
        sodStatus: SodReadStatus? = null,
        authenticity: AuthenticityResult? = null,
        metadata: Dg13Metadata? = null,
        dg2Diagnostic: Dg2Diagnostic? = null,
    ): String = buildString {
        append("scan=").append(scanId.takeIf(SCAN_ID_PATTERN::matches) ?: "invalid")
        append(" step=").append(step.name)
        file?.let { append(" file=").append(it.name) }
        status?.let { append(" status=").append(it.name) }
        sodStatus?.let { append(" sod=").append(it.name) }
        authenticity?.let {
            append(" authSod=").append(it.sodStatus.name)
                .append(" integrity=").append(it.integrityStatus.name)
                .append(" dg1Digest=").append(it.dg1Digest.name)
                .append(" dg2Digest=").append(it.dg2Digest.name)
                .append(" signature=").append(it.signatureStatus.name)
                .append(" dsCert=").append(it.dsCertificateStatus.name)
                .append(" trust=").append(it.issuerTrustStatus.name)
                .append(" passive=").append(it.passiveAuthenticationStatus.name)
        }
        metadata?.let {
            append(" raw=").append(it.rawLength)
                .append(" firstTag=").append(it.firstTag?.toString(16)?.uppercase() ?: "none")
                .append(" declared=").append(it.declaredLength ?: "none")
                .append(" chunks=").append(it.chunkCount)
                .append(" sm=").append(it.secureMessagingVerified)
                .append(" dg13=").append(it.readStatus.name)
        }
        dg2Diagnostic?.let {
            append(" dg2Source=").append(it.source.name)
                .append(" dg2Stage=").append(it.stage.name)
                .append(" dg2Bytes=").append(it.bytesRead)
                .append(" dg2Raw=").append(it.rawLength ?: "none")
                .append(" dg2Chunks=").append(it.chunkCount ?: "none")
                .append(" dg2FirstTag=").append(it.firstTag?.toString(16)?.uppercase() ?: "none")
                .append(" dg2Declared=").append(it.declaredLength ?: "none")
                .append(" dg2Reader=").append(it.readerStatus?.name ?: "none")
                .append(" dg2FailureStage=").append(it.failureStage?.name ?: "none")
                .append(" dg2FailureField=").append(it.failureField ?: "none")
                .append(" dg2FailureOffset=").append(it.failureOffset ?: "none")
                .append(" dg2Remaining=").append(it.remainingBytes ?: "none")
                .append(" dg2Jpeg=").append(it.jpegMarkerFound ?: "none")
                .append(" dg2Jp2=").append(it.jpeg2000MarkerFound ?: "none")
                .append(" dg2MarkerOffset=").append(it.markerOffset ?: "none")
                .append(" dg2MarkerRemaining=").append(it.bytesRemainingAfterMarker ?: "none")
                .append(" dg2MaxPlainChunk=").append(it.maxPlainChunk ?: "none")
                .append(" dg2SmOverhead=").append(it.secureMessagingOverhead ?: "none")
                .append(" dg2EffectiveMax=").append(it.effectiveTransceiveMaximum ?: "none")
                .append(" dg2FailureType=").append(it.failureType?.name ?: "none")
                .append(" dg2ParserAccepted=").append(it.parserAccepted ?: "none")
                .append(" dg2FacRecordLength=").append(it.facRecordLength ?: "none")
                .append(" dg2FacialRecordCount=").append(it.facialRecordCount ?: "none")
                .append(" dg2RecordStart=").append(it.recordStart ?: "none")
                .append(" dg2RecordLength=").append(it.recordLength ?: "none")
                .append(" dg2FeaturePointCount=").append(it.featurePointCount ?: "none")
                .append(" dg2ImageInfoStart=").append(it.imageInfoStart ?: "none")
                .append(" dg2ImageStart=").append(it.imageStart ?: "none")
                .append(" dg2ImageLength=").append(it.calculatedImageLength ?: "none")
                .append(" dg2ImageDataType=").append(it.imageDataType ?: "none")
                .append(" dg2ImageWidth=").append(it.imageWidth ?: "none")
                .append(" dg2ImageHeight=").append(it.imageHeight ?: "none")
                .append(" dg2StructuralImageOffsetMatch=").append(it.structuralImageOffsetMatch ?: "none")
                .append(" dg2Interpretation=").append(it.interpretation.name)
            it.chunkTrace.forEach { chunk ->
                append(" dg2Chunk#").append(chunk.chunkIndex)
                    .append(" offset=").append(chunk.fileOffset)
                    .append(" req=").append(chunk.requestedPlainLength)
                    .append(" recv=").append(chunk.receivedPlainLength ?: "none")
                    .append(" cmd=").append(chunk.encodedCommandLength ?: "none")
                    .append(" durationMs=").append(chunk.transceiveDurationMillis ?: "none")
                    .append(" sw=").append(chunk.statusWord?.toString(16)?.uppercase() ?: "none")
                    .append(" connected=").append(chunk.isoDepConnected ?: "none")
                    .append(" timeoutMs=").append(chunk.isoDepTimeoutMillis ?: "none")
                    .append(" maxTransceive=").append(chunk.isoDepMaxTransceiveLength ?: "none")
                    .append(" failure=").append(chunk.failureType?.name ?: "none")
            }
        }
        error?.let { append(" error=").append(it.name) }
        sw?.let { append(" sw=").append(it.takeIf(STATUS_WORD_PATTERN::matches) ?: "invalid") }
        bytesRead?.let { append(" bytes=").append(it) }
        elapsedMillis?.let { append(" elapsedMs=").append(it) }
    }

    private companion object {
        const val TAG = "CccdBacReader"
        val SCAN_ID_PATTERN = Regex("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")
        val STATUS_WORD_PATTERN = Regex("[0-9A-F]{4}")
    }
}
