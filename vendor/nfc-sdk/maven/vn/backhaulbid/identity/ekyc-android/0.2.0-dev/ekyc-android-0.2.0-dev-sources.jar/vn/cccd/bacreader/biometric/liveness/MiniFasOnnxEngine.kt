package vn.cccd.bacreader.biometric.liveness

import android.content.Context
import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import java.io.IOException
import java.nio.FloatBuffer
import java.security.MessageDigest
import java.util.Locale

enum class LivenessModelStatus {
    READY,
    MODEL_MISSING,
    HASH_MISMATCH,
    CONTRACT_INVALID,
    INITIALIZATION_FAILED,
    CLOSED,
}

data class LivenessModelInfo(
    val status: LivenessModelStatus,
    val contract: LivenessModelContract,
    val actualSha256: String? = null,
    val inputName: String? = null,
    val outputName: String? = null,
    val inputShape: LongArray? = null,
    val outputShape: LongArray? = null,
)

sealed interface LivenessInferenceResult {
    data class Success(
        val realLogit: Float,
        val spoofLogit: Float,
    ) : LivenessInferenceResult {
        val decisionScore: Float get() = realLogit - spoofLogit
    }

    data class Failure(val reason: LivenessInferenceFailure) : LivenessInferenceResult
}

enum class LivenessInferenceFailure {
    MODEL_NOT_READY,
    INVALID_INPUT,
    MODEL_ERROR,
}

/** CPU-only ONNX Runtime wrapper for the debug MiniFAS baseline. */
class MiniFasOnnxEngine(
    context: Context,
    private val contract: LivenessModelContract = LivenessModelContract.DEVELOPMENT,
) : AutoCloseable {
    private val appContext = context.applicationContext
    private var environment: OrtEnvironment? = null
    private var session: OrtSession? = null
    private var inputName: String? = null
    private var outputName: String? = null
    private var closed = false

    @Volatile
    var modelInfo: LivenessModelInfo = LivenessModelInfo(LivenessModelStatus.INITIALIZATION_FAILED, contract)
        private set

    init {
        initialize()
    }

    fun infer(input: FloatArray): LivenessInferenceResult {
        if (closed || modelInfo.status != LivenessModelStatus.READY) {
            return LivenessInferenceResult.Failure(LivenessInferenceFailure.MODEL_NOT_READY)
        }
        if (input.size != 3 * 128 * 128) {
            return LivenessInferenceResult.Failure(LivenessInferenceFailure.INVALID_INPUT)
        }
        val ortEnvironment = environment ?: return LivenessInferenceResult.Failure(LivenessInferenceFailure.MODEL_NOT_READY)
        val ortSession = session ?: return LivenessInferenceResult.Failure(LivenessInferenceFailure.MODEL_NOT_READY)
        return try {
            val tensor = OnnxTensor.createTensor(
                ortEnvironment,
                FloatBuffer.wrap(input),
                longArrayOf(1L, 3L, 128L, 128L),
            )
            tensor.use { inputTensor ->
                ortSession.run(mapOf(requireNotNull(inputName) to inputTensor)).use { result ->
                    val value = result[0].value
                    val logits = FloatArray(2)
                    if (!copyFirstFloats(value, logits, 0) || !logits.all { it.isFinite() }) {
                        LivenessInferenceResult.Failure(LivenessInferenceFailure.MODEL_ERROR)
                    } else {
                        LivenessInferenceResult.Success(logits[contract.liveClassIndex], logits[contract.spoofClassIndex])
                    }
                }
            }
        } catch (_: Exception) {
            LivenessInferenceResult.Failure(LivenessInferenceFailure.MODEL_ERROR)
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        runCatching { session?.close() }
        session = null
        runCatching { environment?.close() }
        environment = null
        modelInfo = modelInfo.copy(status = LivenessModelStatus.CLOSED)
    }

    private fun initialize() {
        var modelBytes: ByteArray? = null
        try {
            modelBytes = readAsset(appContext)
            val actualSha = sha256(modelBytes)
            if (!actualSha.equals(contract.expectedSha256, ignoreCase = true)) {
                modelInfo = LivenessModelInfo(
                    status = LivenessModelStatus.HASH_MISMATCH,
                    contract = contract,
                    actualSha256 = actualSha,
                )
                return
            }

            val ortEnvironment = OrtEnvironment.getEnvironment()
            environment = ortEnvironment
            val options = OrtSession.SessionOptions()
            val ortSession = try {
                options.setExecutionMode(OrtSession.SessionOptions.ExecutionMode.SEQUENTIAL)
                options.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                options.setIntraOpNumThreads(1)
                options.setInterOpNumThreads(1)
                ortEnvironment.createSession(modelBytes, options)
            } finally {
                options.close()
            }

            val inputInfo = ortSession.inputInfo
            val outputInfo = ortSession.outputInfo
            if (inputInfo.size != 1 || outputInfo.size != 1) {
                runCatching { ortSession.close() }
                runCatching { ortEnvironment.close() }
                environment = null
                modelInfo = LivenessModelInfo(LivenessModelStatus.CONTRACT_INVALID, contract, actualSha)
                return
            }
            val inputEntry = inputInfo.entries.single()
            val outputEntry = outputInfo.entries.single()
            val inputTensor = inputEntry.value.info as? TensorInfo
            val outputTensor = outputEntry.value.info as? TensorInfo
            if (inputTensor == null || outputTensor == null ||
                inputTensor.type != OnnxJavaType.FLOAT || outputTensor.type != OnnxJavaType.FLOAT ||
                !shapeMatches(inputTensor.shape, contract.inputShape) ||
                !shapeMatches(outputTensor.shape, contract.outputShape)
            ) {
                runCatching { ortSession.close() }
                runCatching { ortEnvironment.close() }
                environment = null
                modelInfo = LivenessModelInfo(
                    LivenessModelStatus.CONTRACT_INVALID,
                    contract,
                    actualSha,
                    inputEntry.key,
                    outputEntry.key,
                    inputTensor?.shape,
                    outputTensor?.shape,
                )
                return
            }
            environment = ortEnvironment
            session = ortSession
            inputName = inputEntry.key
            outputName = outputEntry.key
            modelInfo = LivenessModelInfo(
                status = LivenessModelStatus.READY,
                contract = contract,
                actualSha256 = actualSha,
                inputName = inputName,
                outputName = outputName,
                inputShape = inputTensor.shape,
                outputShape = outputTensor.shape,
            )
        } catch (_: IOException) {
            modelInfo = LivenessModelInfo(LivenessModelStatus.MODEL_MISSING, contract)
        } catch (_: Exception) {
            modelInfo = LivenessModelInfo(LivenessModelStatus.INITIALIZATION_FAILED, contract)
        } finally {
            modelBytes?.fill(0)
        }
    }

    private fun readAsset(context: Context): ByteArray {
        return context.assets.open(LivenessModelContract.ASSET_PATH).use { input ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                if (total > MAX_MODEL_BYTES) throw IOException("model too large")
                output.write(buffer, 0, count)
            }
            output.toByteArray()
        }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes)
        .joinToString("") { "%02X".format(Locale.ROOT, it) }

    private fun shapeMatches(actual: LongArray, expected: LongArray): Boolean =
        actual.size == expected.size && actual.indices.all { index ->
            actual[index] == expected[index] || (index == 0 && actual[index] == -1L)
        }

    private fun copyFirstFloats(value: Any?, destination: FloatArray, offset: Int): Boolean {
        if (value == null || offset >= destination.size) return offset == destination.size
        return when (value) {
            is FloatArray -> {
                val count = minOf(value.size, destination.size - offset)
                value.copyInto(destination, offset, 0, count)
                copyCount(value.size, destination.size, offset, count)
            }
            is Array<*> -> value.fold(offset) { current, element ->
                if (current >= destination.size) current else if (copyFirstFloats(element, destination, current)) destination.size else current
            } == destination.size
            is List<*> -> value.fold(offset) { current, element ->
                if (current >= destination.size) current else if (copyFirstFloats(element, destination, current)) destination.size else current
            } == destination.size
            else -> false
        }
    }

    private fun copyCount(sourceSize: Int, destinationSize: Int, offset: Int, copied: Int): Boolean =
        copied > 0 && offset + copied == destinationSize && sourceSize >= copied

    private companion object {
        const val MAX_MODEL_BYTES = 20 * 1024 * 1024
    }
}
