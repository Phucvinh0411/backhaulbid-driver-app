package vn.cccd.bacreader.document.capture

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageProxy

enum class DocumentStillFailure {
    IMAGE_CAPTURE_UNAVAILABLE,
    UNSUPPORTED_FORMAT,
    DECODE_FAILED,
    ROTATION_FAILED,
    OUT_OF_MEMORY,
}

data class DocumentStill(
    val bitmap: Bitmap,
    val captureWidth: Int,
    val captureHeight: Int,
    val rotationDegrees: Int,
    val format: Int,
) : AutoCloseable {
    val uprightWidth: Int get() = bitmap.width
    val uprightHeight: Int get() = bitmap.height

    override fun close() {
        if (!bitmap.isRecycled) bitmap.recycle()
    }
}

sealed interface DocumentStillResult {
    data class Success(val still: DocumentStill) : DocumentStillResult
    data class Failure(
        val reason: DocumentStillFailure,
        val captureWidth: Int,
        val captureHeight: Int,
        val rotationDegrees: Int,
        val format: Int,
    ) : DocumentStillResult
}

/** Converts an ImageCapture ImageProxy to one upright in-memory Bitmap. */
object DocumentStillDecoder {
    @OptIn(ExperimentalGetImage::class)
    fun decode(imageProxy: ImageProxy): DocumentStillResult {
        val width = imageProxy.width
        val height = imageProxy.height
        val rotation = imageProxy.imageInfo.rotationDegrees
        val format = imageProxy.format
        if (width <= 0 || height <= 0) {
            return DocumentStillResult.Failure(DocumentStillFailure.DECODE_FAILED, width, height, rotation, format)
        }
        return try {
            val decoded = when (format) {
                ImageFormat.JPEG -> decodeJpeg(imageProxy)
                ImageFormat.YUV_420_888 -> decodeYuv(imageProxy)
                else -> null
            }
            if (decoded == null) {
                DocumentStillResult.Failure(
                    if (format == ImageFormat.JPEG || format == ImageFormat.YUV_420_888) {
                        DocumentStillFailure.DECODE_FAILED
                    } else {
                        DocumentStillFailure.UNSUPPORTED_FORMAT
                    },
                    width,
                    height,
                    rotation,
                    format,
                )
            } else {
                val upright = rotate(decoded, rotation)
                if (upright !== decoded && !decoded.isRecycled) decoded.recycle()
                if (upright == null) {
                    DocumentStillResult.Failure(DocumentStillFailure.ROTATION_FAILED, width, height, rotation, format)
                } else {
                    DocumentStillResult.Success(DocumentStill(upright, width, height, rotation, format))
                }
            }
        } catch (_: OutOfMemoryError) {
            DocumentStillResult.Failure(DocumentStillFailure.OUT_OF_MEMORY, width, height, rotation, format)
        } catch (_: RuntimeException) {
            DocumentStillResult.Failure(DocumentStillFailure.DECODE_FAILED, width, height, rotation, format)
        }
    }

    @OptIn(ExperimentalGetImage::class)
    private fun decodeJpeg(imageProxy: ImageProxy): Bitmap? {
        val plane = imageProxy.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val encoded = ByteArray(buffer.remaining())
        buffer.get(encoded)
        return try {
            BitmapFactory.decodeByteArray(encoded, 0, encoded.size)
        } finally {
            encoded.fill(0)
        }
    }

    @OptIn(ExperimentalGetImage::class)
    private fun decodeYuv(imageProxy: ImageProxy): Bitmap? {
        val image = imageProxy.image ?: return null
        if (image.planes.size < 3) return null
        val rawWidth = imageProxy.width
        val rawHeight = imageProxy.height
        val rotation = normalizeRotation(imageProxy.imageInfo.rotationDegrees)
        val outputWidth = if (rotation == 90 || rotation == 270) rawHeight else rawWidth
        val outputHeight = if (rotation == 90 || rotation == 270) rawWidth else rawHeight
        val pixels = IntArray(outputWidth * outputHeight)
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        val yBuffer = yPlane.buffer.duplicate()
        val uBuffer = uPlane.buffer.duplicate()
        val vBuffer = vPlane.buffer.duplicate()

        for (y in 0 until outputHeight) {
            for (x in 0 until outputWidth) {
                val source = sourceCoordinate(x, y, rawWidth, rawHeight, rotation)
                val yOffset = source.second * yPlane.rowStride + source.first * yPlane.pixelStride
                val chromaX = source.first / 2
                val chromaY = source.second / 2
                val uOffset = chromaY * uPlane.rowStride + chromaX * uPlane.pixelStride
                val vOffset = chromaY * vPlane.rowStride + chromaX * vPlane.pixelStride
                if (yOffset !in 0 until yBuffer.limit() ||
                    uOffset !in 0 until uBuffer.limit() ||
                    vOffset !in 0 until vBuffer.limit()
                ) return null
                val yValue = yBuffer.get(yOffset).toInt() and 0xFF
                val u = (uBuffer.get(uOffset).toInt() and 0xFF) - 128
                val v = (vBuffer.get(vOffset).toInt() and 0xFF) - 128
                val red = (yValue + 1.402f * v).toInt().coerceIn(0, 255)
                val green = (yValue - 0.344136f * u - 0.714136f * v).toInt().coerceIn(0, 255)
                val blue = (yValue + 1.772f * u).toInt().coerceIn(0, 255)
                pixels[y * outputWidth + x] = Color.rgb(red, green, blue)
            }
        }
        return Bitmap.createBitmap(pixels, outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
    }

    private fun rotate(bitmap: Bitmap, rotationDegrees: Int): Bitmap? {
        val rotation = normalizeRotation(rotationDegrees)
        if (rotation == 0) return bitmap
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun normalizeRotation(value: Int): Int = when (value) {
        0, 90, 180, 270 -> value
        else -> throw IllegalArgumentException("Unsupported rotation: $value")
    }

    private fun sourceCoordinate(x: Int, y: Int, width: Int, height: Int, rotation: Int): Pair<Int, Int> = when (rotation) {
        0 -> x to y
        90 -> y to (height - 1 - x)
        180 -> (width - 1 - x) to (height - 1 - y)
        270 -> (width - 1 - y) to x
        else -> error("unreachable")
    }
}
