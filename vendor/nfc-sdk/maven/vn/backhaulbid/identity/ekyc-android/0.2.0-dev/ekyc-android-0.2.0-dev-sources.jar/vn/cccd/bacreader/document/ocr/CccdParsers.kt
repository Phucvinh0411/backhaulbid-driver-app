package vn.cccd.bacreader.document.ocr

import java.text.Normalizer
import java.time.DateTimeException
import java.time.LocalDate
import vn.cccd.bacreader.document.mrz.MrzParser
import vn.cccd.bacreader.document.mrz.MrzResult
import vn.cccd.bacreader.document.mrz.MrzStatus

enum class FieldEvidence {
    FOUND,
    AMBIGUOUS,
    NOT_FOUND,
}

data class ParsedField(
    val value: String? = null,
    val evidence: FieldEvidence = FieldEvidence.NOT_FOUND,
)

data class CccdFrontResult(
    val documentNumber: ParsedField,
    val fullName: ParsedField,
    val dateOfBirth: ParsedField,
    val dateOfExpiry: ParsedField = ParsedField(),
    val sex: ParsedField,
    val nationality: ParsedField,
    val placeOfOrigin: ParsedField,
    val residence: ParsedField,
)

data class CccdBackResult(
    val mrz: MrzResult,
    val documentNumber: ParsedField,
    val dateOfBirth: ParsedField,
    val dateOfExpiry: ParsedField,
)

/** Conservative parser: it extracts explicit, repeated patterns and never guesses missing data. */
class CccdFrontParser {
    fun parse(rawText: String): CccdFrontResult {
        val text = normalized(rawText)
        return CccdFrontResult(
            documentNumber = findSingle(Regex("(?<!\\d)\\d{12}(?!\\d)"), text),
            fullName = findLabel(text, "HO VA TEN", "FULL NAME"),
            dateOfBirth = findDateForLabel(text, "NGAY SINH", "DATE OF BIRTH"),
            dateOfExpiry = findDateForLabel(
                text,
                "NGAY HET HAN",
                "DATE OF EXPIRY",
                "CO GIA TRI DEN",
                "EXPIRY",
            ),
            sex = findLabel(text, "GIOI TINH", "SEX"),
            nationality = findLabel(text, "QUOC TICH", "NATIONALITY"),
            placeOfOrigin = findLabel(text, "QUE QUAN", "PLACE OF ORIGIN"),
            residence = findLabel(text, "NOI THUONG TRU", "RESIDENCE"),
        )
    }
}

class CccdBackParser {
    private val mrzParser = MrzParser()

    fun parse(rawText: String): CccdBackResult {
        val normalizedText = normalized(rawText)
        val mrz = mrzParser.parse(rawText)
        val regexNumber = findSingle(Regex("(?<!\\d)\\d{12}(?!\\d)"), normalizedText)
        val regexBirth = findDateForLabel(normalizedText, "NGAY SINH", "DATE OF BIRTH")
        val regexExpiry = findDateForLabel(normalizedText, "NGAY HET HAN", "DATE OF EXPIRY", "EXPIRY")
        return CccdBackResult(
            mrz = mrz,
            documentNumber = if (mrz.status == MrzStatus.MRZ_VALID && mrz.documentNumber?.length == 12) {
                ParsedField(mrz.documentNumber, FieldEvidence.FOUND)
            } else regexNumber,
            dateOfBirth = if (mrz.status == MrzStatus.MRZ_VALID) {
                ParsedField(mrz.birthYYMMDD, FieldEvidence.FOUND)
            } else regexBirth,
            dateOfExpiry = if (mrz.status == MrzStatus.MRZ_VALID) {
                ParsedField(mrz.expiryYYMMDD, FieldEvidence.FOUND)
            } else regexExpiry,
        )
    }
}

private fun normalized(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
    .replace('\u0110'.toString(), "D")
    .replace('\u0111'.toString(), "d")
    .replace("Đ", "D")
    .replace("đ", "d")
    .replace(Regex("\\p{M}+"), "")
    .uppercase()
    .replace('\r', '\n')

private fun findSingle(pattern: Regex, text: String): ParsedField {
    val values = pattern.findAll(text).map { it.value }.distinct().toList()
    return when (values.size) {
        1 -> ParsedField(values.single(), FieldEvidence.FOUND)
        0 -> ParsedField()
        else -> ParsedField(evidence = FieldEvidence.AMBIGUOUS)
    }
}

private fun findLabel(text: String, vararg labels: String): ParsedField {
    val label = labels.joinToString("|") { Regex.escape(it) }
    val matches = Regex("(?m)^(?:.*(?:$label))\\s*[:\\-]?\\s*(.+)$")
        .findAll(text)
        .map { it.groupValues[1].trim() }
        .filter { it.isNotEmpty() }
        .distinct()
        .toList()
    return when (matches.size) {
        1 -> ParsedField(matches.single(), FieldEvidence.FOUND)
        0 -> ParsedField()
        else -> ParsedField(evidence = FieldEvidence.AMBIGUOUS)
    }
}

private fun findDateForLabel(text: String, vararg labels: String): ParsedField {
    val label = labels.joinToString("|") { Regex.escape(it) }
    val line = Regex("(?m)^.*(?:$label).*?([0-9]{1,2}\\s*[/.-]\\s*[0-9]{1,2}\\s*[/.-]\\s*[0-9]{4}).*$")
        .find(text)?.groupValues?.getOrNull(1) ?: return ParsedField()
    val parts = Regex("[0-9]+").findAll(line).map { it.value.toInt() }.toList()
    if (parts.size != 3) return ParsedField()
    return try {
        val date = LocalDate.of(parts[2], parts[1], parts[0])
        ParsedField(
            value = "%02d%02d%02d".format(date.year % 100, date.monthValue, date.dayOfMonth),
            evidence = FieldEvidence.FOUND,
        )
    } catch (_: DateTimeException) {
        ParsedField(evidence = FieldEvidence.AMBIGUOUS)
    }
}
