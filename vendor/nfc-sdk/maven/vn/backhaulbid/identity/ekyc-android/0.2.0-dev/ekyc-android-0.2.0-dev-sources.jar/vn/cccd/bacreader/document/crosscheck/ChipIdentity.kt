package vn.cccd.bacreader.document.crosscheck

import vn.cccd.bacreader.document.mrz.MrzResult
import vn.cccd.bacreader.document.mrz.MrzStatus

/** Parsed identity values exposed by the chip-side DG1/MRZ result. */
data class ChipIdentityData(
    val documentNumber: String?,
    val fullName: String?,
    val dateOfBirth: String?,
    val sex: String?,
    val nationality: String?,
    val dateOfExpiry: String?,
)

/** Maps already validated TD1 MRZ fields without changing the MRZ parser. */
object ChipIdentityMapper {
    fun from(result: MrzResult): ChipIdentityData? {
        if (result.status != MrzStatus.MRZ_VALID || result.lines.size < 3) return null
        val line2 = result.lines[1]
        val name = result.lines[2]
            .trim('<')
            .split("<<")
            .joinToString(" ") { part -> part.trim('<').replace('<', ' ').trim() }
            .replace("\\s+".toRegex(), " ")
            .trim()
            .takeIf { it.isNotBlank() }
        return ChipIdentityData(
            documentNumber = result.documentNumber,
            fullName = name,
            dateOfBirth = result.birthYYMMDD,
            sex = line2.getOrNull(7)?.takeIf { it in "MF<" }?.let { if (it == '<') null else it.toString() },
            nationality = line2.substringOrNull(15, 18)?.takeIf { it.any { character -> character != '<' } },
            dateOfExpiry = result.expiryYYMMDD,
        )
    }

    private fun String.substringOrNull(start: Int, endExclusive: Int): String? =
        takeIf { start >= 0 && endExclusive <= length && start < endExclusive }
            ?.substring(start, endExclusive)
            ?.trim('<')
            ?.takeIf { it.isNotBlank() }
}
