package vn.cccd.bacreader.biometric.recognition

/** Session-scoped biometric embedding. It is wiped when comparison is complete. */
class FaceEmbedding internal constructor(internal val values: FloatArray) : AutoCloseable {
    val dimension: Int get() = values.size
    override fun close() {
        values.fill(0f)
    }
}
