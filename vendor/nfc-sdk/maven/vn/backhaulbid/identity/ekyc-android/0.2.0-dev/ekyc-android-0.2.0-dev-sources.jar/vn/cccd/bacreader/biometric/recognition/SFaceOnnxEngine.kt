package vn.cccd.bacreader.biometric.recognition

import android.content.Context
import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import java.io.IOException
import java.nio.FloatBuffer
import java.security.MessageDigest
import java.util.Locale
import vn.cccd.bacreader.biometric.RgbImage

enum class SFaceModelStatus { READY, MODEL_MISSING, HASH_MISMATCH, CONTRACT_INVALID, INITIALIZATION_FAILED, CLOSED }
enum class SFaceInferenceFailure { MODEL_NOT_READY, INVALID_INPUT, MODEL_ERROR }

data class SFaceModelInfo(
    val status: SFaceModelStatus,
    val contract: SFaceModelContract,
    val actualSha256: String? = null,
    val inputName: String? = null,
    val outputName: String? = null,
)

sealed interface SFaceInferenceResult {
    data class Success(val embedding: FaceEmbedding, val elapsedMs: Long) : SFaceInferenceResult
    data class Failure(val reason: SFaceInferenceFailure) : SFaceInferenceResult
}

/** Reusable CPU ORT session; embeddings remain owned by the caller and are never persisted. */
internal class SFaceOnnxEngine(
    context: Context,
    private val contract: SFaceModelContract = SFaceModelContract.DEVELOPMENT,
) : AutoCloseable {
    private val appContext = context.applicationContext
    private var environment: OrtEnvironment? = null
    private var session: OrtSession? = null
    private var inputName: String? = null
    private var closed = false

    @Volatile var modelInfo: SFaceModelInfo = SFaceModelInfo(SFaceModelStatus.INITIALIZATION_FAILED, contract)
        private set

    init { initialize() }

    internal fun embed(image: RgbImage): SFaceInferenceResult {
        if (closed || modelInfo.status != SFaceModelStatus.READY) return SFaceInferenceResult.Failure(SFaceInferenceFailure.MODEL_NOT_READY)
        val input = try { SFacePreprocessor.toNchwRgb(image) } catch (_: Exception) {
            return SFaceInferenceResult.Failure(SFaceInferenceFailure.INVALID_INPUT)
        }
        return try {
            val env = environment ?: return SFaceInferenceResult.Failure(SFaceInferenceFailure.MODEL_NOT_READY)
            val ortSession = session ?: return SFaceInferenceResult.Failure(SFaceInferenceFailure.MODEL_NOT_READY)
            val started = System.nanoTime()
            val tensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(input), contract.inputShape)
            tensor.use { inputTensor ->
                ortSession.run(mapOf(requireNotNull(inputName) to inputTensor)).use { result ->
                    val values = FloatArray(SFacePreprocessor.EMBEDDING_DIMENSION)
                    if (!copyFloats(result[0].value, values) || !values.all(Float::isFinite)) {
                        values.fill(0f)
                        SFaceInferenceResult.Failure(SFaceInferenceFailure.MODEL_ERROR)
                    } else {
                        SFaceInferenceResult.Success(FaceEmbedding(values), (System.nanoTime() - started) / 1_000_000L)
                    }
                }
            }
        } catch (_: Exception) {
            SFaceInferenceResult.Failure(SFaceInferenceFailure.MODEL_ERROR)
        } finally {
            input.fill(0f)
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        runCatching { session?.close() }
        session = null
        runCatching { environment?.close() }
        environment = null
        modelInfo = modelInfo.copy(status = SFaceModelStatus.CLOSED)
    }

    private fun initialize() {
        var bytes: ByteArray? = null
        try {
            bytes = readAsset()
            val actual = sha256(bytes)
            if (!actual.equals(contract.expectedSha256, ignoreCase = true)) {
                modelInfo = SFaceModelInfo(SFaceModelStatus.HASH_MISMATCH, contract, actual)
                return
            }
            val env = OrtEnvironment.getEnvironment()
            val options = OrtSession.SessionOptions()
            val created = try {
                options.setExecutionMode(OrtSession.SessionOptions.ExecutionMode.SEQUENTIAL)
                options.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                options.setIntraOpNumThreads(1); options.setInterOpNumThreads(1)
                env.createSession(bytes, options)
            } finally { options.close() }
            if (created.inputInfo.size != 1 || created.outputInfo.size != 1) {
                created.close(); modelInfo = SFaceModelInfo(SFaceModelStatus.CONTRACT_INVALID, contract, actual); return
            }
            val input = created.inputInfo.entries.single()
            val output = created.outputInfo.entries.single()
            val inputTensor = input.value.info as? TensorInfo
            val outputTensor = output.value.info as? TensorInfo
            if (inputTensor == null || outputTensor == null ||
                inputTensor.type != OnnxJavaType.FLOAT || outputTensor.type != OnnxJavaType.FLOAT ||
                !shapeMatches(inputTensor.shape, contract.inputShape) || !shapeMatches(outputTensor.shape, contract.outputShape)
            ) {
                created.close(); modelInfo = SFaceModelInfo(SFaceModelStatus.CONTRACT_INVALID, contract, actual, input.key, output.key); return
            }
            environment = env; session = created; inputName = input.key
            modelInfo = SFaceModelInfo(SFaceModelStatus.READY, contract, actual, input.key, output.key)
        } catch (_: IOException) {
            modelInfo = SFaceModelInfo(SFaceModelStatus.MODEL_MISSING, contract)
        } catch (_: Exception) {
            modelInfo = SFaceModelInfo(SFaceModelStatus.INITIALIZATION_FAILED, contract)
        } finally { bytes?.fill(0) }
    }

    private fun readAsset(): ByteArray {
        return appContext.assets.open(SFaceModelContract.ASSET_PATH).use { input ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            var total = 0
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                if (total > 64 * 1024 * 1024) throw IOException("model too large")
                output.write(buffer, 0, count)
            }
            output.toByteArray()
        }
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes)
        .joinToString("") { "%02X".format(Locale.ROOT, it) }

    private fun shapeMatches(actual: LongArray, expected: LongArray): Boolean =
        actual.size == expected.size && actual.indices.all { actual[it] == expected[it] || (it == 0 && actual[it] == -1L) }

    private fun copyFloats(value: Any?, destination: FloatArray): Boolean = when (value) {
        is FloatArray -> value.size == destination.size && value.copyInto(destination).let { true }
        is Array<*> -> value.size == 1 && copyFloats(value[0], destination)
        is List<*> -> value.size == 1 && copyFloats(value[0], destination)
        else -> false
    }
}
