package vn.cccd.bacreader.document.ocr

import vn.cccd.bacreader.document.capture.DocumentSide

class OcrAttemptToken internal constructor(
    val sessionId: Long,
    val attemptId: Long,
    val documentSide: DocumentSide,
)

/** Owns only current-session snapshots and rejects callbacks from superseded attempts. */
class DocumentOcrSession {
    private var sessionId = 0L
    private var nextAttemptId = 0L
    private var closed = false
    private val activeAttempts = mutableMapOf<DocumentSide, OcrAttemptToken>()

    @Volatile var frontSnapshot: OcrSnapshot? = null
        private set
    @Volatile var backSnapshot: OcrSnapshot? = null
        private set

    @Synchronized fun beginAttempt(documentSide: DocumentSide): OcrAttemptToken {
        val token = OcrAttemptToken(sessionId, ++nextAttemptId, documentSide)
        if (!closed) activeAttempts[documentSide] = token
        return token
    }

    /** Returns false for a duplicate, stale, closed, or wrong-side callback. */
    @Synchronized fun complete(token: OcrAttemptToken, snapshot: OcrSnapshot?): Boolean {
        if (closed || token.sessionId != sessionId || activeAttempts[token.documentSide] != token) return false
        activeAttempts.remove(token.documentSide)
        if (snapshot != null && snapshot.documentSide != token.documentSide) return false
        when (token.documentSide) {
            DocumentSide.FRONT -> frontSnapshot = snapshot
            DocumentSide.BACK -> backSnapshot = snapshot
        }
        return true
    }

    @Synchronized fun retake(documentSide: DocumentSide) {
        activeAttempts.remove(documentSide)
        when (documentSide) {
            DocumentSide.FRONT -> frontSnapshot = null
            DocumentSide.BACK -> backSnapshot = null
        }
    }

    @Synchronized fun newSession() {
        sessionId++
        activeAttempts.clear()
        frontSnapshot = null
        backSnapshot = null
    }

    @Synchronized fun close() {
        closed = true
        activeAttempts.clear()
        frontSnapshot = null
        backSnapshot = null
    }
}
