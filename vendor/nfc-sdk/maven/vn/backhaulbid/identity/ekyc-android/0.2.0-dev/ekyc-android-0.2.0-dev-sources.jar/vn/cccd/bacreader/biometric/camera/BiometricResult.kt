package vn.cccd.bacreader.biometric.camera

import vn.cccd.bacreader.biometric.active.ActiveLivenessResult
import vn.cccd.bacreader.biometric.active.ActiveLivenessState
import vn.cccd.bacreader.biometric.liveness.LivenessSessionResult
import vn.cccd.bacreader.biometric.liveness.LivenessSessionState
import vn.cccd.bacreader.biometric.recognition.FaceMatchResult
import vn.cccd.bacreader.biometric.recognition.FaceMatchState

enum class BiometricStageStatus {
    PASS,
    DEVELOPMENT_PASS,
    FAIL,
    INCONCLUSIVE,
    ERROR,
    NOT_RUN,
    CANCELLED,
}

data class BiometricResult(
    val activeLiveness: BiometricStageStatus,
    val passiveLiveness: BiometricStageStatus,
    val faceMatch: BiometricStageStatus,
    val failureStage: BiometricStage? = null,
) {
    /** Capture may finish with development observations; this does not establish identity. */
    val isCaptureComplete: Boolean
        get() = listOf(activeLiveness, passiveLiveness, faceMatch).all {
            it == BiometricStageStatus.PASS || it == BiometricStageStatus.DEVELOPMENT_PASS
        }

    val isSuccessful: Boolean
        get() = activeLiveness == BiometricStageStatus.PASS &&
            passiveLiveness == BiometricStageStatus.PASS &&
            faceMatch == BiometricStageStatus.PASS

    companion object {
        fun cancelled() = BiometricResult(
            activeLiveness = BiometricStageStatus.CANCELLED,
            passiveLiveness = BiometricStageStatus.NOT_RUN,
            faceMatch = BiometricStageStatus.NOT_RUN,
            failureStage = BiometricStage.ACTIVE_LIVENESS,
        )

        fun fromActive(result: ActiveLivenessResult): BiometricStageStatus = when (result.state) {
            ActiveLivenessState.PASSED -> BiometricStageStatus.PASS
            ActiveLivenessState.FAILED -> BiometricStageStatus.FAIL
            ActiveLivenessState.INCONCLUSIVE -> BiometricStageStatus.INCONCLUSIVE
            else -> BiometricStageStatus.NOT_RUN
        }

        fun fromPassive(result: LivenessSessionResult): BiometricStageStatus = when (result.state) {
            LivenessSessionState.LIVE_DEVELOPMENT -> BiometricStageStatus.DEVELOPMENT_PASS
            LivenessSessionState.SPOOF_DEVELOPMENT -> BiometricStageStatus.FAIL
            LivenessSessionState.INCONCLUSIVE -> BiometricStageStatus.INCONCLUSIVE
            LivenessSessionState.MODEL_ERROR -> BiometricStageStatus.ERROR
            LivenessSessionState.COLLECTING -> BiometricStageStatus.NOT_RUN
        }

        fun fromFaceMatch(result: FaceMatchResult): BiometricStageStatus = when (result.state) {
            FaceMatchState.MATCH_DEVELOPMENT -> BiometricStageStatus.DEVELOPMENT_PASS
            FaceMatchState.NO_MATCH_DEVELOPMENT -> BiometricStageStatus.FAIL
            FaceMatchState.INCONCLUSIVE -> BiometricStageStatus.INCONCLUSIVE
            FaceMatchState.MODEL_ERROR -> BiometricStageStatus.ERROR
        }
    }
}

enum class BiometricStage {
    ACTIVE_LIVENESS,
    PASSIVE_LIVENESS,
    FACE_MATCH,
}
