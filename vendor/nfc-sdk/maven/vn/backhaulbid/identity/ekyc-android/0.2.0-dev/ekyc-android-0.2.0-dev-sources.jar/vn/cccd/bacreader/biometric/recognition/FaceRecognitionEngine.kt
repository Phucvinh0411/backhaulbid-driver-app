package vn.cccd.bacreader.biometric.recognition

import android.graphics.Bitmap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong
import vn.cccd.bacreader.biometric.RgbImage
import vn.cccd.bacreader.biometric.detection.DetectedFace
import vn.cccd.bacreader.biometric.liveness.LivenessSessionState

enum class FaceRecognitionFailure {
    DG2_FACE_NOT_FOUND,
    DG2_MULTIPLE_FACES,
    DG2_LANDMARKS_INSUFFICIENT,
    DG2_ALIGNMENT_FAILED,
    DG2_EMBEDDING_FAILED,
    LIVE_LANDMARKS_INSUFFICIENT,
    LIVE_ALIGNMENT_FAILED,
    LIVE_EMBEDDING_FAILED,
    LIVENESS_NOT_PASSED,
    STALE_SESSION,
    MODEL_ERROR,
    MATCH_ERROR,
}

sealed interface FaceRecognitionResult {
    data class Success(
        val match: FaceMatchResult,
        val dg2AlignmentMs: Long,
        val dg2EmbeddingMs: Long,
        val liveAlignmentMs: Long,
        val liveEmbeddingMs: Long,
        val cosineMs: Long,
    ) : FaceRecognitionResult

    data class Failure(val reason: FaceRecognitionFailure) : FaceRecognitionResult
}

/**
 * Session-scoped DG2/live matching pipeline. It uses one aligner and one reusable SFace ORT
 * session for both sources and never exposes or persists embeddings.
 */
internal class FaceRecognitionEngine(
    context: android.content.Context,
    private val config: FaceMatchConfig = FaceMatchConfig(),
) : AutoCloseable {
    private val sFace = SFaceOnnxEngine(context)
    private val aligner = FaceAligner()
    private val matcher = FaceMatcher(config)
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val generation = AtomicLong(0L)
    private var closed = false

    val modelInfo: SFaceModelInfo get() = sFace.modelInfo
    val developmentThreshold: Float get() = config.developmentThreshold

    fun beginSession(): Long = generation.incrementAndGet()

    fun match(
        sessionId: Long,
        livenessState: LivenessSessionState,
        dg2Bitmap: Bitmap?,
        dg2Face: DetectedFace?,
        liveImage: RgbImage,
        liveFace: DetectedFace,
        callback: (FaceRecognitionResult) -> Unit,
    ) {
        if (closed) { liveImage.close(); return }
        val current = generation.get()
        if (sessionId != current) { liveImage.close(); callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.STALE_SESSION)); return }
        if (livenessState != LivenessSessionState.LIVE_DEVELOPMENT) {
            liveImage.close(); callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.LIVENESS_NOT_PASSED)); return
        }
        if (sFace.modelInfo.status != SFaceModelStatus.READY) {
            liveImage.close(); callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.MODEL_ERROR)); return
        }
        if (dg2Bitmap == null || dg2Face == null) {
            liveImage.close(); callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.DG2_FACE_NOT_FOUND)); return
        }
        try {
            executor.execute {
                try {
                    if (sessionId != generation.get()) {
                        callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.STALE_SESSION))
                        return@execute
                    }
                    val dg2Landmarks = dg2Face.landmarks
                        ?: return@execute callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.DG2_LANDMARKS_INSUFFICIENT))
                    val liveLandmarks = liveFace.landmarks
                        ?: return@execute callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.LIVE_LANDMARKS_INSUFFICIENT))
                    val dg2Rgb = try { BitmapRgbConverter.convert(dg2Bitmap) } catch (_: Exception) {
                        return@execute callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.DG2_ALIGNMENT_FAILED))
                    }
                    try {
                        val dg2AlignStarted = System.nanoTime()
                        val dg2Aligned = try { aligner.align(dg2Rgb, dg2Landmarks) } catch (_: Exception) {
                            return@execute callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.DG2_ALIGNMENT_FAILED))
                        }
                        val dg2AlignmentMs = elapsedMs(dg2AlignStarted)
                        val dg2Embedding = try {
                            when (val result = sFace.embed(dg2Aligned)) {
                                is SFaceInferenceResult.Success -> result
                                is SFaceInferenceResult.Failure -> return@execute callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.DG2_EMBEDDING_FAILED))
                            }
                        } finally { dg2Aligned.close() }
                        try {
                            val liveAlignStarted = System.nanoTime()
                            val liveAligned = try { aligner.align(liveImage, liveLandmarks) } catch (_: Exception) {
                                return@execute callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.LIVE_ALIGNMENT_FAILED))
                            }
                            val liveAlignmentMs = elapsedMs(liveAlignStarted)
                            val liveEmbedding = try {
                                when (val result = sFace.embed(liveAligned)) {
                                    is SFaceInferenceResult.Success -> result
                                    is SFaceInferenceResult.Failure -> return@execute callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.LIVE_EMBEDDING_FAILED))
                                }
                            } finally { liveAligned.close() }
                            try {
                                val cosineStarted = System.nanoTime()
                                val cosine = FaceMatcher.cosineResult(dg2Embedding.embedding, liveEmbedding.embedding)
                                val cosineMs = elapsedMs(cosineStarted)
                                when (cosine) {
                                    is FaceCosineResult.Valid -> callback(
                                        FaceRecognitionResult.Success(
                                            matcher.match(cosine.value), dg2AlignmentMs, dg2Embedding.elapsedMs,
                                            liveAlignmentMs, liveEmbedding.elapsedMs, cosineMs,
                                        ),
                                    )
                                    is FaceCosineResult.Invalid -> callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.MATCH_ERROR))
                                }
                            } finally { liveEmbedding.embedding.close() }
                        } finally { dg2Embedding.embedding.close() }
                    } finally { dg2Rgb.close() }
                } catch (_: Exception) {
                    callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.MODEL_ERROR))
                } finally { liveImage.close() }
            }
        } catch (_: Exception) {
            liveImage.close(); callback(FaceRecognitionResult.Failure(FaceRecognitionFailure.MODEL_ERROR))
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        generation.incrementAndGet()
        executor.shutdownNow()
        sFace.close()
    }

    private fun elapsedMs(started: Long): Long = (System.nanoTime() - started) / 1_000_000L
}
