package vn.cccd.bacreader.document.crosscheck

import java.time.DateTimeException
import java.time.LocalDate
import java.util.Locale
import vn.cccd.bacreader.domain.AccessInput
import vn.cccd.bacreader.document.capture.DocumentSide
import vn.cccd.bacreader.document.mrz.MrzParser
import vn.cccd.bacreader.document.mrz.MrzStatus
import vn.cccd.bacreader.document.ocr.CccdBackResult
import vn.cccd.bacreader.document.ocr.CccdFrontResult
import vn.cccd.bacreader.document.ocr.FieldEvidence
import vn.cccd.bacreader.document.ocr.ParsedField
import vn.cccd.bacreader.document.resolver.ParsedFieldStatus
import vn.cccd.bacreader.document.resolver.ResolvedField
import vn.cccd.bacreader.document.resolver.VisualDocumentResolution

enum class CrossCheckStatus {
    MATCH,
    MISMATCH,
    NOT_AVAILABLE,
}

data class DocumentCrossCheckResult(
    val documentNumber: CrossCheckStatus,
    val dateOfBirth: CrossCheckStatus,
)

data class VisualDocumentData(
    val documentNumber: String?,
    val birthYYMMDD: String?,
    val expiryYYMMDD: String?,
)

data class ChipDocumentCrossCheckResult(
    val documentNumber: CrossCheckStatus,
    val dateOfBirth: CrossCheckStatus,
    val dateOfExpiry: CrossCheckStatus,
    val mrzStatus: MrzStatus,
)

/** Compares memory-only visual/OCR fields with the chip's validated DG1 MRZ. */
class ChipDocumentCrossChecker(
    private val mrzParser: MrzParser = MrzParser(),
) {
    fun compare(visual: VisualDocumentData?, chipMrzText: String?): ChipDocumentCrossCheckResult {
        if (visual == null || chipMrzText.isNullOrBlank()) return unavailable(MrzStatus.MRZ_NOT_FOUND)
        val chip = mrzParser.parse(chipMrzText)
        if (chip.status != MrzStatus.MRZ_VALID) return unavailable(chip.status)
        return ChipDocumentCrossCheckResult(
            documentNumber = compareDocumentNumber(visual.documentNumber, chip.documentNumber),
            dateOfBirth = compareValue(visual.birthYYMMDD, chip.birthYYMMDD),
            dateOfExpiry = compareValue(visual.expiryYYMMDD, chip.expiryYYMMDD),
            mrzStatus = chip.status,
        )
    }

    private fun compareDocumentNumber(visual: String?, chip: String?): CrossCheckStatus {
        if (visual.isNullOrBlank() || chip.isNullOrBlank()) return CrossCheckStatus.NOT_AVAILABLE
        // Vietnamese CCCD has 12 printed digits while TD1 stores the last 9.
        val normalizedVisual = if (visual.length == 12 && chip.length == 9) visual.takeLast(9) else visual
        return if (normalizedVisual == chip) CrossCheckStatus.MATCH else CrossCheckStatus.MISMATCH
    }

    private fun compareValue(visual: String?, chip: String?): CrossCheckStatus {
        if (visual.isNullOrBlank() || chip.isNullOrBlank()) return CrossCheckStatus.NOT_AVAILABLE
        return if (visual == chip) CrossCheckStatus.MATCH else CrossCheckStatus.MISMATCH
    }

    private fun unavailable(status: MrzStatus) = ChipDocumentCrossCheckResult(
        documentNumber = CrossCheckStatus.NOT_AVAILABLE,
        dateOfBirth = CrossCheckStatus.NOT_AVAILABLE,
        dateOfExpiry = CrossCheckStatus.NOT_AVAILABLE,
        mrzStatus = status,
    )
}

/** Field-level visual/MRZ comparison. A mismatch is not a document-authenticity verdict. */
class DocumentCrossChecker {
    fun compare(front: CccdFrontResult, back: CccdBackResult): DocumentCrossCheckResult =
        DocumentCrossCheckResult(
            documentNumber = compare(front.documentNumber, back.documentNumber),
            dateOfBirth = compare(front.dateOfBirth, back.dateOfBirth),
        )

    private fun compare(left: ParsedField, right: ParsedField): CrossCheckStatus {
        if (left.evidence != FieldEvidence.FOUND || right.evidence != FieldEvidence.FOUND) {
            return CrossCheckStatus.NOT_AVAILABLE
        }
        return if (left.value.equals(right.value, ignoreCase = true)) {
            CrossCheckStatus.MATCH
        } else {
            CrossCheckStatus.MISMATCH
        }
    }
}

data class DocumentInputSourceMetadata(
    val documentNumberSource: String,
    val birthDateSource: String,
    val expiryDateSource: String,
)

data class DocumentInput(
    val documentNumber: String?,
    val birthYYMMDD: String?,
    val expiryYYMMDD: String?,
    val crossCheck: DocumentCrossCheckResult,
    val sourceMetadata: DocumentInputSourceMetadata,
) {
    fun accessInputOrNull(): AccessInput? {
        val number = documentNumber ?: return null
        val birth = birthYYMMDD ?: return null
        val expiry = expiryYYMMDD ?: return null
        return runCatching { AccessInput.create(number, birth, expiry) }.getOrNull()
    }

    companion object {
        /**
         * Builds BAC input from the V2.2 layout-aware resolution.
         *
         * The legacy front/back parsers remain the source for the visual
         * cross-check, but must not be allowed to discard a value that the
         * resolver has already validated (for example `1 0/05/2029`).
         */
        fun fromVisualResolution(
            resolution: VisualDocumentResolution,
            front: CccdFrontResult,
            back: CccdBackResult,
        ): DocumentInput {
            val legacy = from(front, back)
            val number = resolvedNumber(resolution.documentNumber)
            val birth = resolvedDate(resolution.dateOfBirth)
            val expiry = resolvedDate(resolution.dateOfExpiry)
            return legacy.copy(
                documentNumber = number,
                birthYYMMDD = birth,
                expiryYYMMDD = expiry,
                sourceMetadata = DocumentInputSourceMetadata(
                    numberSource(resolution.documentNumber, number),
                    dateSource(resolution.dateOfBirth, birth),
                    dateSource(resolution.dateOfExpiry, expiry),
                ),
            )
        }

        fun from(front: CccdFrontResult, back: CccdBackResult): DocumentInput {
            val crossCheck = DocumentCrossChecker().compare(front, back)
            val number = preferredNumber(front.documentNumber, back.documentNumber)
            val birth = preferredDate(
                back.dateOfBirth,
                front.dateOfBirth,
                mrzValid = back.mrz.status == MrzStatus.MRZ_VALID,
            )
            val expiry = preferredDate(
                back.dateOfExpiry,
                front.dateOfExpiry,
                mrzValid = back.mrz.status == MrzStatus.MRZ_VALID,
            )
            return DocumentInput(
                documentNumber = number.first,
                birthYYMMDD = birth.first,
                expiryYYMMDD = expiry.first,
                crossCheck = crossCheck,
                sourceMetadata = DocumentInputSourceMetadata(number.second, birth.second, expiry.second),
            )
        }

        private fun preferredNumber(front: ParsedField, back: ParsedField): Pair<String?, String> {
            val backValue = back.value?.takeIf { back.evidence == FieldEvidence.FOUND && it.length == 12 }
            if (backValue != null) return backValue to "BACK_OCR"
            val frontValue = front.value?.takeIf { front.evidence == FieldEvidence.FOUND && it.length == 12 }
            if (frontValue != null) return frontValue to "FRONT_OCR"
            return null to "NONE"
        }

        private fun preferredDate(
            preferred: ParsedField,
            fallback: ParsedField,
            mrzValid: Boolean,
        ): Pair<String?, String> {
            if (mrzValid && preferred.evidence == FieldEvidence.FOUND && preferred.value != null) {
                return preferred.value to "MRZ"
            }
            if (preferred.evidence == FieldEvidence.FOUND) return preferred.value to "BACK_OCR"
            if (fallback.evidence == FieldEvidence.FOUND) return fallback.value to "FRONT_OCR"
            return null to "NONE"
        }

        private fun resolvedNumber(field: ResolvedField<String>): String? = field.value
            ?.takeIf { field.status == ParsedFieldStatus.FOUND }
            ?.takeIf { it.matches(Regex("\\d{12}")) }

        private fun resolvedDate(field: ResolvedField<String>): String? {
            if (field.status != ParsedFieldStatus.FOUND) return null
            val parts = field.value?.split('/') ?: return null
            if (parts.size != 3 || parts.any { !it.matches(Regex("\\d+")) }) return null
            val day = parts[0].toIntOrNull() ?: return null
            val month = parts[1].toIntOrNull() ?: return null
            val year = parts[2].toIntOrNull() ?: return null
            return try {
                val date = LocalDate.of(year, month, day)
                "%02d%02d%02d".format(Locale.ROOT, date.year % 100, date.monthValue, date.dayOfMonth)
            } catch (_: DateTimeException) {
                null
            }
        }

        private fun numberSource(field: ResolvedField<String>, value: String?): String =
            sourceFor(field, value)

        private fun dateSource(field: ResolvedField<String>, value: String?): String =
            sourceFor(field, value)

        private fun sourceFor(field: ResolvedField<String>, value: String?): String {
            if (field.status != ParsedFieldStatus.FOUND || value == null) return "NONE"
            return when (field.sourceSide) {
                DocumentSide.FRONT -> "FRONT_OCR"
                DocumentSide.BACK -> "BACK_OCR"
                null -> "VISUAL_OCR"
            }
        }
    }
}
