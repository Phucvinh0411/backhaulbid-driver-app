package vn.cccd.bacreader.biometric.liveness

import android.content.Context
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import vn.cccd.bacreader.biometric.RgbImage
import vn.cccd.bacreader.biometric.detection.DetectedFace

/**
 * Development-only passive liveness coordinator. It accepts only one good,
 * single-face frame at a time and owns all image buffers until inference ends.
 */
class PassiveLivenessEngine(
    context: Context,
    private val config: LivenessConfig = LivenessConfig(),
) : AutoCloseable {
    private val model = MiniFasOnnxEngine(context)
    private val preprocessor = LivenessPreprocessor(config)
    private val session = LivenessSession(config)
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val inFlight = AtomicBoolean(false)
    private val lastSubmittedMillis = AtomicLong(Long.MIN_VALUE)
    private val generation = AtomicLong(0L)
    private val lock = Any()
    @Volatile private var closed = false

    val modelInfo: LivenessModelInfo get() = model.modelInfo
    val requiredValidFrames: Int get() = config.requiredValidFrames

    internal fun reset(callback: ((LivenessSessionResult) -> Unit)? = null) {
        generation.incrementAndGet()
        val snapshot = synchronized(lock) { session.reset() }
        callback?.invoke(snapshot)
    }

    internal fun reject(
        reason: LivenessInconclusiveReason? = null,
        callback: ((LivenessSessionResult) -> Unit)? = null,
    ) {
        if (closed) return
        val snapshot = synchronized(lock) {
            session.timeout()
            session.reject(reason)
        }
        callback?.invoke(snapshot)
    }

    internal fun offerGoodFrame(
        face: DetectedFace,
        imageProvider: () -> RgbImage?,
        callback: (LivenessSessionResult) -> Unit,
        onLiveFrame: ((RgbImage, DetectedFace) -> Unit)? = null,
    ) {
        if (closed) return
        if (model.modelInfo.status != LivenessModelStatus.READY) {
            callback(synchronized(lock) { session.modelError() })
            return
        }
        val now = elapsedMillis()
        val shouldSubmit = synchronized(lock) {
            val timed = session.timeout(System.currentTimeMillis())
            if (timed.state != LivenessSessionState.COLLECTING ||
                model.modelInfo.status != LivenessModelStatus.READY ||
                (lastSubmittedMillis.get() != Long.MIN_VALUE &&
                    now - lastSubmittedMillis.get() < config.inferenceIntervalMillis) ||
                !inFlight.compareAndSet(false, true)
            ) {
                false
            } else {
                lastSubmittedMillis.set(now)
                true
            }
        }
        if (!shouldSubmit) {
            val snapshot = synchronized(lock) { session.snapshot() }
            callback(snapshot)
            return
        }

        val submissionGeneration = generation.get()

        val image = try {
            imageProvider()
        } catch (_: Exception) {
            null
        }
        if (image == null) {
            inFlight.set(false)
            val snapshot = synchronized(lock) {
                if (submissionGeneration == generation.get()) session.reject() else null
            }
            snapshot?.let(callback)
            return
        }

        try {
            executor.execute {
                try {
                    val started = elapsedNanos()
                    val input = preprocessor.preprocess(image, face.bounds)
                    val preprocessMillis = nanosToMillis(elapsedNanos() - started)
                    try {
                        val inferenceStarted = elapsedNanos()
                        when (val inference = model.infer(input.values)) {
                            is LivenessInferenceResult.Success -> {
                                val inferenceMillis = nanosToMillis(elapsedNanos() - inferenceStarted)
                                val endToEndMillis = nanosToMillis(elapsedNanos() - started)
                                val frame = LivenessFrameResult(
                                    realLogit = inference.realLogit,
                                    spoofLogit = inference.spoofLogit,
                                    decisionScore = inference.decisionScore,
                                    inferenceTimeMs = inferenceMillis,
                                    qualityStatus = LivenessQualityStatus.GOOD,
                                    preprocessTimeMs = preprocessMillis,
                                    endToEndTimeMs = endToEndMillis,
                                )
                                val snapshot = synchronized(lock) {
                                    if (submissionGeneration == generation.get()) session.accept(frame) else null
                                }
                                if (snapshot?.state == LivenessSessionState.LIVE_DEVELOPMENT && onLiveFrame != null) {
                                    val liveCopy = image.copy()
                                    try {
                                        onLiveFrame(liveCopy, face)
                                    } catch (_: Exception) {
                                        liveCopy.close()
                                    }
                                }
                                snapshot?.let(callback)
                            }
                            is LivenessInferenceResult.Failure -> {
                                val snapshot = synchronized(lock) {
                                    if (submissionGeneration == generation.get()) session.modelError() else null
                                }
                                snapshot?.let(callback)
                            }
                        }
                    } finally {
                        input.close()
                    }
                } catch (_: Exception) {
                    val snapshot = synchronized(lock) {
                        if (submissionGeneration == generation.get()) session.modelError() else null
                    }
                    snapshot?.let(callback)
                } finally {
                    image.close()
                    inFlight.set(false)
                }
            }
        } catch (_: RejectedExecutionException) {
            image.close()
            inFlight.set(false)
            callback(synchronized(lock) { session.invalidate(LivenessInconclusiveReason.CAMERA_INTERRUPTED) })
        }
    }

    internal fun timeout(callback: ((LivenessSessionResult) -> Unit)? = null) {
        if (closed) return
        val snapshot = synchronized(lock) { session.timeout() }
        callback?.invoke(snapshot)
    }

    internal fun snapshot(): LivenessSessionResult = synchronized(lock) { session.snapshot() }

    override fun close() {
        if (closed) return
        closed = true
        generation.incrementAndGet()
        executor.shutdownNow()
        model.close()
        synchronized(lock) { session.invalidate(LivenessInconclusiveReason.CAMERA_INTERRUPTED) }
    }

    private fun elapsedMillis(): Long = System.nanoTime() / NANOS_PER_MILLI
    private fun elapsedNanos(): Long = System.nanoTime()
    private fun nanosToMillis(value: Long): Long = value / NANOS_PER_MILLI

    private companion object {
        const val NANOS_PER_MILLI = 1_000_000L
    }
}
