package vn.cccd.bacreader.biometric.camera

enum class CameraPermissionState {
    CAMERA_PERMISSION_UNKNOWN,
    CAMERA_PERMISSION_GRANTED,
    CAMERA_PERMISSION_DENIED,
    CAMERA_PERMISSION_PERMANENTLY_DENIED,
}

/** Pure classification so permission UX can be tested without an Activity or device. */
object CameraPermissionClassifier {
    fun classify(
        isGranted: Boolean,
        shouldShowRationale: Boolean,
        requestAttempted: Boolean,
    ): CameraPermissionState = when {
        isGranted -> CameraPermissionState.CAMERA_PERMISSION_GRANTED
        shouldShowRationale -> CameraPermissionState.CAMERA_PERMISSION_DENIED
        requestAttempted -> CameraPermissionState.CAMERA_PERMISSION_PERMANENTLY_DENIED
        else -> CameraPermissionState.CAMERA_PERMISSION_UNKNOWN
    }
}
