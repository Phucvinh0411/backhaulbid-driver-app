package vn.cccd.bacreader.document.quality

import kotlin.math.max
import kotlin.math.min

/** Normalized document bounds. Values may be outside [0, 1] to represent clipping. */
data class DocumentRect(
    val left: Double,
    val top: Double,
    val right: Double,
    val bottom: Double,
) {
    val width: Double get() = (right - left).coerceAtLeast(0.0)
    val height: Double get() = (bottom - top).coerceAtLeast(0.0)
    val area: Double get() = width * height

    fun intersection(other: DocumentRect): DocumentRect = DocumentRect(
        left = max(left, other.left),
        top = max(top, other.top),
        right = min(right, other.right),
        bottom = min(bottom, other.bottom),
    )
}

data class DocumentFrameMetrics(
    val frameWidth: Int,
    val frameHeight: Int,
    val documentBounds: DocumentRect?,
    val guideBounds: DocumentRect,
    val meanLuminance: Double,
    val blurScore: Double,
    val glareRatio: Double,
    val edgeContrast: Double = 0.0,
)

data class DocumentQualityConfig(
    val guideAspectRatio: Double = 85.60 / 53.98,
    val guideWidthFraction: Double = 0.90,
    val minDocumentAreaRatio: Double = 0.38,
    val minGuideOverlapRatio: Double = 0.70,
    val darkLuminanceThreshold: Double = 45.0,
    val brightLuminanceThreshold: Double = 232.0,
    val minSharpness: Double = 8.0,
    val maxGlareRatio: Double = 0.08,
    val glareLuminanceThreshold: Int = 250,
    val stableGoodFrames: Int = 5,
    val edgeContrastThreshold: Double = 8.0,
) {
    init {
        require(guideAspectRatio > 1.0)
        require(guideWidthFraction in 0.1..1.0)
        require(minDocumentAreaRatio in 0.0..1.0)
        require(minGuideOverlapRatio in 0.0..1.0)
        require(darkLuminanceThreshold >= 0.0)
        require(brightLuminanceThreshold <= 255.0)
        require(darkLuminanceThreshold < brightLuminanceThreshold)
        require(minSharpness >= 0.0)
        require(maxGlareRatio in 0.0..1.0)
        require(glareLuminanceThreshold in 0..255)
        require(stableGoodFrames > 0)
        require(edgeContrastThreshold >= 0.0)
    }
}

enum class DocumentQualityStatus {
    NO_DOCUMENT,
    DOCUMENT_TOO_SMALL,
    DOCUMENT_OUT_OF_FRAME,
    TOO_DARK,
    TOO_BRIGHT,
    TOO_BLURRY,
    GLARE_DETECTED,
    UNSTABLE,
    GOOD,
}

data class DocumentQualityResult(
    val status: DocumentQualityStatus,
    val metrics: DocumentFrameMetrics,
    val stableGoodFrames: Int,
)

/**
 * Conservative, deterministic capture quality policy. It is deliberately not a document
 * authenticity detector; the guide and lightweight geometry probe only decide whether a frame
 * is suitable for OCR.
 */
class DocumentQualityEvaluator(
    private val config: DocumentQualityConfig = DocumentQualityConfig(),
) {
    fun evaluate(metrics: DocumentFrameMetrics, stableGoodFrames: Int = 0): DocumentQualityResult {
        val status = when {
            metrics.frameWidth <= 0 || metrics.frameHeight <= 0 || metrics.documentBounds == null ->
                DocumentQualityStatus.NO_DOCUMENT
            metrics.documentBounds.area < config.minDocumentAreaRatio ->
                DocumentQualityStatus.DOCUMENT_TOO_SMALL
            isClipped(metrics.documentBounds) || overlapRatio(metrics.documentBounds, metrics.guideBounds) < config.minGuideOverlapRatio ->
                DocumentQualityStatus.DOCUMENT_OUT_OF_FRAME
            metrics.meanLuminance < config.darkLuminanceThreshold -> DocumentQualityStatus.TOO_DARK
            metrics.meanLuminance > config.brightLuminanceThreshold -> DocumentQualityStatus.TOO_BRIGHT
            metrics.blurScore < config.minSharpness -> DocumentQualityStatus.TOO_BLURRY
            metrics.glareRatio > config.maxGlareRatio -> DocumentQualityStatus.GLARE_DETECTED
            stableGoodFrames < config.stableGoodFrames -> DocumentQualityStatus.UNSTABLE
            else -> DocumentQualityStatus.GOOD
        }
        return DocumentQualityResult(status, metrics, stableGoodFrames)
    }

    private fun isClipped(bounds: DocumentRect): Boolean =
        bounds.left < 0.0 || bounds.top < 0.0 || bounds.right > 1.0 || bounds.bottom > 1.0

    private fun overlapRatio(document: DocumentRect, guide: DocumentRect): Double {
        val smallerArea = min(document.area, guide.area)
        if (smallerArea <= 0.0) return 0.0
        return (document.intersection(guide).area / smallerArea).coerceIn(0.0, 1.0)
    }
}
