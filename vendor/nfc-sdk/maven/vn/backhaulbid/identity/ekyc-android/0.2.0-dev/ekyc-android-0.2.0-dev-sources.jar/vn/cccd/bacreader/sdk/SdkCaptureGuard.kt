package vn.cccd.bacreader.sdk

import android.app.Activity
import android.os.Handler
import android.os.Looper

/** Private adapters stop even when their parent expires/cancels while they are foreground. */
internal object SdkCaptureGuard {
    fun isValid(activity: Activity): Boolean {
        val token = activity.intent.getStringExtra(EXTRA_TOKEN) ?: return true
        val attempt = SdkRuntime.find(token) ?: return false
        return attempt.flow.isCurrent(attempt.id)
    }

    fun attach(activity: Activity): Boolean {
        if (!isValid(activity)) { activity.setResult(Activity.RESULT_CANCELED); activity.finish(); return false }
        if (!activity.intent.hasExtra(EXTRA_TOKEN)) return true
        val handler = Handler(Looper.getMainLooper())
        handler.post(object : Runnable {
            override fun run() {
                if (activity.isFinishing || activity.isDestroyed) return
                if (!isValid(activity)) { activity.setResult(Activity.RESULT_CANCELED); activity.finish() }
                else handler.postDelayed(this, 500)
            }
        })
        return true
    }
}
