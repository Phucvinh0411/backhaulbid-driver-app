package vn.cccd.bacreader.biometric.recognition

import kotlin.math.abs

data class FacePoint(val x: Float, val y: Float) {
    fun isFinite(): Boolean = x.isFinite() && y.isFinite()
}

/** Five-point landmark contract shared by DG2 and the live camera path. */
data class FaceLandmarks(
    val leftEye: FacePoint,
    val rightEye: FacePoint,
    val nose: FacePoint,
    val mouthLeft: FacePoint,
    val mouthRight: FacePoint,
) {
    val points: List<FacePoint> get() = listOf(leftEye, rightEye, nose, mouthLeft, mouthRight)
    fun isUsable(): Boolean = points.all(FacePoint::isFinite)
    fun maxCoordinateDelta(other: FaceLandmarks): Float = points.zip(other.points)
        .maxOf { abs(it.first.x - it.second.x) + abs(it.first.y - it.second.y) }
}
