package vn.cccd.bacreader.document.capture

import java.time.DateTimeException
import java.time.LocalDate
import java.util.Locale

/** Converts a validated visual date into the six-digit format required by BAC. */
object BacAccessDateNormalizer {
    private val compactDate = Regex("\\d{6}")
    private val displayDate = Regex("\\d{1,2}\\s*[/.-]\\s*\\d{1,2}\\s*[/.-]\\s*\\d{4}")

    /** Returns YYMMDD, or null when the value is missing, malformed, or not a real date. */
    fun toYyMmDd(value: String?): String? {
        val raw = value?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        // OCR may split a digit with whitespace (for example, "1 0/05/2029").
        // Removing only whitespace between digits preserves the date structure.
        val compacted = raw.replace(Regex("(?<=\\d)\\s+(?=\\d)"), "")
        if (compactDate.matches(compacted)) {
            return compactDate(compacted)
        }
        if (!displayDate.matches(compacted)) return null
        val parts = compacted.split('/', '-', '.')
        if (parts.size != 3) return null
        val day = parts[0].toIntOrNull() ?: return null
        val month = parts[1].toIntOrNull() ?: return null
        val year = parts[2].toIntOrNull() ?: return null
        return formatDate(year, month, day)
    }

    private fun compactDate(value: String): String? {
        val year = 2000 + (value.substring(0, 2).toIntOrNull() ?: return null)
        val month = value.substring(2, 4).toIntOrNull() ?: return null
        val day = value.substring(4, 6).toIntOrNull() ?: return null
        return formatDate(year, month, day)
    }

    private fun formatDate(year: Int, month: Int, day: Int): String? = try {
        val date = LocalDate.of(year, month, day)
        "%02d%02d%02d".format(Locale.ROOT, date.year % 100, date.monthValue, date.dayOfMonth)
    } catch (_: DateTimeException) {
        null
    }
}
