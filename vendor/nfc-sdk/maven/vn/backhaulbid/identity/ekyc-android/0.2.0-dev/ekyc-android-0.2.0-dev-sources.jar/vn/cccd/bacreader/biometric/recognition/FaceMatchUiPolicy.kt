package vn.cccd.bacreader.biometric.recognition

import vn.cccd.bacreader.biometric.liveness.LivenessSessionState

enum class FaceMatchUiState {
    NO_DG2,
    WAITING_LIVENESS,
    READY_TO_MATCH,
    BLOCKED_LIVENESS,
    MATCHING,
}

/** Keeps terminal liveness failures from being rendered as a ready-to-match state. */
object FaceMatchUiPolicy {
    fun classify(
        hasDg2Face: Boolean,
        livenessState: LivenessSessionState,
        matchStarted: Boolean,
    ): FaceMatchUiState = when {
        !hasDg2Face -> FaceMatchUiState.NO_DG2
        matchStarted -> FaceMatchUiState.MATCHING
        livenessState == LivenessSessionState.COLLECTING -> FaceMatchUiState.WAITING_LIVENESS
        livenessState == LivenessSessionState.LIVE_DEVELOPMENT -> FaceMatchUiState.READY_TO_MATCH
        else -> FaceMatchUiState.BLOCKED_LIVENESS
    }
}
