package vn.cccd.bacreader.biometric.recognition

import kotlin.math.sqrt

data class FaceMatchConfig(val developmentThreshold: Float = 0.363f) {
    init { require(developmentThreshold in -1f..1f) }
}

enum class FaceMatchState { MATCH_DEVELOPMENT, NO_MATCH_DEVELOPMENT, INCONCLUSIVE, MODEL_ERROR }

sealed interface FaceCosineResult {
    data class Valid(val value: Float) : FaceCosineResult
    data class Invalid(val reason: String) : FaceCosineResult
}

data class FaceMatchResult(
    val state: FaceMatchState,
    val similarity: Float? = null,
    val developmentThreshold: Float,
    val reason: String? = null,
)

class FaceMatcher(private val config: FaceMatchConfig = FaceMatchConfig()) {
    fun match(similarity: Float): FaceMatchResult {
        if (!similarity.isFinite()) return FaceMatchResult(FaceMatchState.MODEL_ERROR, developmentThreshold = config.developmentThreshold, reason = "NON_FINITE_SIMILARITY")
        return FaceMatchResult(
            state = if (similarity >= config.developmentThreshold) FaceMatchState.MATCH_DEVELOPMENT else FaceMatchState.NO_MATCH_DEVELOPMENT,
            similarity = similarity,
            developmentThreshold = config.developmentThreshold,
        )
    }

    companion object {
        fun cosine(first: FaceEmbedding, second: FaceEmbedding): Float = when (val result = cosineResult(first, second)) {
            is FaceCosineResult.Valid -> result.value
            is FaceCosineResult.Invalid -> error(result.reason)
        }

        fun cosineResult(first: FaceEmbedding, second: FaceEmbedding): FaceCosineResult {
            if (first.dimension == 0 || first.dimension != second.dimension) return FaceCosineResult.Invalid("DIMENSION_MISMATCH")
            var dot = 0.0
            var firstNorm = 0.0
            var secondNorm = 0.0
            for (i in first.values.indices) {
                val a = first.values[i].toDouble()
                val b = second.values[i].toDouble()
                if (!a.isFinite() || !b.isFinite()) return FaceCosineResult.Invalid("NON_FINITE_EMBEDDING")
                dot += a * b
                firstNorm += a * a
                secondNorm += b * b
            }
            if (firstNorm <= 0.0 || secondNorm <= 0.0) return FaceCosineResult.Invalid("ZERO_NORM")
            val value = (dot / (sqrt(firstNorm) * sqrt(secondNorm))).toFloat()
            return if (value.isFinite()) FaceCosineResult.Valid(value) else FaceCosineResult.Invalid("NON_FINITE_SIMILARITY")
        }
    }
}
