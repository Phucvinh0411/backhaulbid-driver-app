package vn.cccd.bacreader.biometric.recognition

data class SFaceModelContract(
    val inputShape: LongArray,
    val outputShape: LongArray,
    val inputColorOrder: String,
    val normalization: String,
    val expectedSha256: String,
    val developmentThreshold: Float,
    val provenanceStatus: String,
) {
    init {
        require(inputShape.contentEquals(longArrayOf(1L, 3L, 112L, 112L)))
        require(outputShape.contentEquals(longArrayOf(1L, 128L)))
        require(expectedSha256.matches(Regex("[0-9A-Fa-f]{64}")))
    }

    companion object {
        const val ASSET_PATH = "recognition/face_recognition_sface_2021dec.onnx"
        const val METADATA_ASSET_PATH = "recognition/face_recognition_sface_2021dec.metadata.json"
        const val MODEL_ID = "opencv-sface-2021dec"
        const val SOURCE_URL = "https://huggingface.co/opencv/opencv_zoo/resolve/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx?download=true"
        const val UPSTREAM_REPOSITORY = "https://github.com/opencv/opencv_zoo"
        const val UPSTREAM_COMMIT = "47534e27c9851bb1128ccc0102f1145e27f23f98"
        const val EXPECTED_SHA256 = "0BA9FBFA01B5270C96627C4EF784DA859931E02F04419C829E83484087C34E79"
        const val DEVELOPMENT_THRESHOLD = 0.363f

        val DEVELOPMENT = SFaceModelContract(
            inputShape = longArrayOf(1L, 3L, 112L, 112L),
            outputShape = longArrayOf(1L, 128L),
            inputColorOrder = "RGB",
            normalization = "float32; scale=1; mean=(0,0,0); raw 0..255",
            expectedSha256 = EXPECTED_SHA256,
            developmentThreshold = DEVELOPMENT_THRESHOLD,
            provenanceStatus = "DEVELOPMENT_EVALUATION_ONLY",
        )
    }
}
