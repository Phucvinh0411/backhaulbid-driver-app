package vn.cccd.bacreader.document.resolver

import vn.cccd.bacreader.document.capture.DocumentSide
import vn.cccd.bacreader.document.ocr.preprocess.OcrTextNormalizer
import vn.cccd.bacreader.document.ocr.preprocess.PreprocessedOcr

/** Conservative CCCD profile classifier; layout signals are priors, not acceptance gates. */
object CardProfileClassifier {
    fun classify(preprocessed: PreprocessedOcr): VietnamCardProfile {
        val front = preprocessed.lines.filter { it.side == DocumentSide.FRONT }
        val back = preprocessed.lines.filter { it.side == DocumentSide.BACK }
        val frontExpiry = front.any { line ->
            preprocessed.segments.any { it.side == DocumentSide.FRONT && it.lineIndex == line.lineIndex && it.field == DocumentField.DATE_OF_EXPIRY }
        }
        val backExpiry = back.any { line ->
            preprocessed.segments.any { it.side == DocumentSide.BACK && it.lineIndex == line.lineIndex && it.field == DocumentField.DATE_OF_EXPIRY }
        }
        val frontCore = listOf(
            DocumentField.FULL_NAME,
            DocumentField.DATE_OF_BIRTH,
            DocumentField.SEX,
            DocumentField.NATIONALITY,
        ).count { field ->
            preprocessed.segments.any { it.side == DocumentSide.FRONT && it.field == field }
        }
        val backText = back.joinToString(" ") { it.rawText }
        val normalizedBack = OcrTextNormalizer.accentInsensitive(backText)
        val backSignals = listOf("DATE OF ISSUE", "NGAY CAP", "NGAY THANG NAM", "MRZ", "QR", "IDENTITY CARD")
            .count { normalizedBack.contains(OcrTextNormalizer.accentInsensitive(it)) }
        return when {
            frontExpiry && frontCore >= 2 && !backExpiry -> VietnamCardProfile.CCCD_2021
            backExpiry && backSignals >= 1 && !frontExpiry -> VietnamCardProfile.IDENTITY_CARD_2024
            else -> VietnamCardProfile.UNKNOWN
        }
    }
}

