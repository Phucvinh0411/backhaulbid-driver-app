package vn.cccd.bacreader.ui.demo

import vn.cccd.bacreader.domain.ReaderError

/** Safe, actionable messages; no status words, card bytes or credentials. */
internal data class NfcRecovery(val title: String, val description: String, val retryAllowed: Boolean)

internal fun nfcRecovery(error: ReaderError?): NfcRecovery = when (error) {
    ReaderError.ACCESS_REJECTED -> NfcRecovery("Chưa thể mở dữ liệu trên thẻ", "Quay lại kiểm tra số căn cước và ngày tháng đã đọc từ ảnh. Không tiếp tục thử với cùng thông tin.", false)
    ReaderError.NFC_UNAVAILABLE -> NfcRecovery("NFC chưa sẵn sàng", "Bật NFC trong Cài đặt. Nếu điện thoại không hỗ trợ NFC, hãy dùng một thiết bị khác.", false)
    ReaderError.NOT_ISO_DEP, ReaderError.APPLET_NOT_FOUND -> NfcRecovery("Thẻ chưa được hỗ trợ", "Hãy dùng căn cước gắn chip được hệ thống hỗ trợ.", false)
    ReaderError.TAG_LOST, ReaderError.TIMEOUT -> NfcRecovery("Kết nối với thẻ bị gián đoạn", "Áp thẻ sát lưng điện thoại và giữ yên. Lần thử lại sẽ bắt đầu một phiên đọc mới.", true)
    ReaderError.CANCELLED -> NfcRecovery("Đã dừng đọc thẻ", "Dữ liệu của lần đọc này đã được giải phóng.", false)
    ReaderError.MAC_MISMATCH, ReaderError.NONCE_MISMATCH,
    ReaderError.FILE_MALFORMED, ReaderError.FILE_TOO_LARGE,
    ReaderError.MALFORMED_RESPONSE, ReaderError.MALFORMED_CHALLENGE ->
        NfcRecovery("Không thể kiểm tra dữ liệu thẻ", "Dừng phiên này và liên hệ hỗ trợ nếu lỗi tiếp tục xảy ra.", false)
    else -> NfcRecovery("Chưa đọc được thẻ", "Giữ thẻ ổn định và bắt đầu lại phiên đọc.", true)
}
