package vn.cccd.bacreader.ui

import androidx.lifecycle.ViewModel
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import vn.cccd.bacreader.crypto.MrzAccessData
import vn.cccd.bacreader.domain.ReadResult
import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.domain.ScanStep

sealed interface ReaderUiState {
    data object Input : ReaderUiState

    data class Scanning(
        val scanId: String,
        val step: ScanStep,
    ) : ReaderUiState

    data class Result(
        val outcome: ReadResult,
    ) : ReaderUiState
}

/** Holds only the wipeable derived MRZ while waiting for a single NFC tag. */
class ReaderViewModel : ViewModel() {
    private val _state = MutableStateFlow<ReaderUiState>(ReaderUiState.Input)
    val state: StateFlow<ReaderUiState> = _state.asStateFlow()

    private var pendingAccess: MrzAccessData? = null

    @Synchronized
    fun begin(access: MrzAccessData): String {
        clearPendingLocked()
        closeVisibleOutcomeLocked()
        pendingAccess = access
        val scanId = UUID.randomUUID().toString()
        _state.value = ReaderUiState.Scanning(scanId, ScanStep.IDLE)
        return scanId
    }

    @Synchronized
    fun takeMrzInformation(scanId: String): ByteArray? {
        val current = _state.value as? ReaderUiState.Scanning
        if (current?.scanId != scanId) return null
        val access = pendingAccess ?: return null
        pendingAccess = null
        return try {
            access.copyMrzInformation()
        } finally {
            access.close()
        }
    }

    @Synchronized
    fun updateStep(scanId: String, step: ScanStep): Boolean {
        val current = _state.value as? ReaderUiState.Scanning ?: return false
        if (current.scanId != scanId) return false
        _state.value = current.copy(step = step)
        return true
    }

    @Synchronized
    fun finish(scanId: String, outcome: ReadResult): Boolean {
        val current = _state.value as? ReaderUiState.Scanning
        if (current == null || current.scanId != scanId) {
            outcome.close()
            return false
        }
        clearPendingLocked()
        _state.value = ReaderUiState.Result(outcome)
        return true
    }

    @Synchronized
    fun cancel(scanId: String? = null): Boolean {
        val current = _state.value as? ReaderUiState.Scanning ?: return false
        if (scanId != null && current.scanId != scanId) return false
        clearPendingLocked()
        _state.value = ReaderUiState.Result(
            ReadResult.Failure(
                step = current.step,
                error = ReaderError.CANCELLED,
                elapsedMillis = 0,
            ),
        )
        return true
    }

    @Synchronized
    fun returnToInput() {
        clearPendingLocked()
        closeVisibleOutcomeLocked()
        _state.value = ReaderUiState.Input
    }

    /** A ViewModel normally survives a configuration change; this app deliberately does not. */
    @Synchronized
    fun discardForHostRecreation() {
        clearPendingLocked()
        closeVisibleOutcomeLocked()
        _state.value = ReaderUiState.Input
    }

    override fun onCleared() {
        synchronized(this) {
            clearPendingLocked()
            closeVisibleOutcomeLocked()
        }
    }

    private fun clearPendingLocked() {
        pendingAccess?.close()
        pendingAccess = null
    }

    private fun closeVisibleOutcomeLocked() {
        (_state.value as? ReaderUiState.Result)?.outcome?.close()
    }
}
