package vn.cccd.bacreader.document.display

import java.text.Normalizer
import java.util.Locale

/**
 * Presentation-only normalization for a person's full name.
 *
 * The OCR value and its evidence remain untouched. This function only creates
 * the accentless representation used by the normal user-facing review UI.
 */
fun normalizeFullNameForDisplay(rawName: String): String {
    val decomposed = Normalizer.normalize(rawName, Normalizer.Form.NFD)
    return decomposed
        .replace("Đ", "D")
        .replace("đ", "d")
        .replace("\\p{Mn}+".toRegex(), "")
        .replace("\\s+".toRegex(), " ")
        .trim()
        .uppercase(Locale.ROOT)
}
