package vn.cccd.bacreader.biometric.active

import kotlin.math.abs
import kotlin.random.Random
import vn.cccd.bacreader.biometric.detection.DetectedFace

/** Development-only active-liveness actions. */
enum class ActiveChallenge {
    LOOK_STRAIGHT,
    BLINK,
    TURN_LEFT,
    TURN_RIGHT,
}

enum class ActiveLivenessState {
    WAITING_FOR_FACE,
    WAITING_FOR_QUALITY,
    ESTABLISHING_NEUTRAL,
    CHALLENGE_ACTIVE,
    ACTION_IN_PROGRESS,
    ACTION_CONFIRMED,
    RETURN_TO_NEUTRAL,
    NEXT_CHALLENGE,
    PASSED,
    FAILED,
    INCONCLUSIVE,
}

enum class ActiveLivenessInconclusiveReason {
    NO_FACE,
    MULTIPLE_FACES,
    BLINK_SIGNAL_UNAVAILABLE,
    CHALLENGE_TIMEOUT,
    SESSION_TIMEOUT,
    CAMERA_INTERRUPTED,
}

enum class BlinkSignalStatus {
    OPEN,
    CLOSED,
    AMBIGUOUS,
    UNAVAILABLE,
}

enum class BlinkDetectorState {
    WAITING_FOR_OPEN,
    EYES_OPEN,
    EYES_CLOSED,
    CONFIRMED,
}

enum class YawSignMapping {
    /** Development default; must be checked against the device/front-camera preview. */
    NEGATIVE_IS_LEFT,
    POSITIVE_IS_LEFT,
}

data class ActiveLivenessConfig(
    val neutralYawAbsDegrees: Float = 10f,
    val turnYawDegrees: Float = 16f,
    val eyeOpenProbability: Float = 0.7f,
    val eyeClosedProbability: Float = 0.3f,
    val blinkMinClosedMillis: Long = 80L,
    val blinkMaxClosedMillis: Long = 700L,
    val neutralStableFrames: Int = 2,
    val turnStableFrames: Int = 2,
    val returnNeutralStableFrames: Int = 2,
    val minTurnDurationMillis: Long = 80L,
    val overallActiveTimeoutMillis: Long = 45_000L,
    val perChallengeTimeoutMillis: Long = 12_000L,
    val faceLossTimeoutMillis: Long = 1_500L,
    val activeActionCount: Int = 2,
    val yawSignMapping: YawSignMapping = YawSignMapping.NEGATIVE_IS_LEFT,
) {
    init {
        require(neutralYawAbsDegrees > 0f)
        require(turnYawDegrees > neutralYawAbsDegrees)
        require(eyeClosedProbability in 0f..1f)
        require(eyeOpenProbability in 0f..1f)
        require(eyeClosedProbability < eyeOpenProbability)
        require(blinkMinClosedMillis >= 0L)
        require(blinkMaxClosedMillis >= blinkMinClosedMillis)
        require(neutralStableFrames > 0)
        require(turnStableFrames > 0)
        require(returnNeutralStableFrames > 0)
        require(minTurnDurationMillis >= 0L)
        require(overallActiveTimeoutMillis > 0L)
        require(perChallengeTimeoutMillis > 0L)
        require(faceLossTimeoutMillis > 0L)
        require(activeActionCount == 2) { "Gate F V1 uses exactly two post-neutral actions" }
    }
}

fun interface ActiveChallengeGenerator {
    fun next(): List<ActiveChallenge>
}

/** Generates a fresh, non-repeating V1 sequence for every session. */
class ActiveChallengeSequenceGenerator(
    private val random: Random = Random.Default,
    private val actionCount: Int = 2,
) : ActiveChallengeGenerator {
    init {
        require(actionCount == 2) { "Gate F V1 uses two actions" }
    }

    override fun next(): List<ActiveChallenge> {
        val actions = listOf(
            ActiveChallenge.BLINK,
            ActiveChallenge.TURN_LEFT,
            ActiveChallenge.TURN_RIGHT,
        ).shuffled(random).take(actionCount)
        return listOf(ActiveChallenge.LOOK_STRAIGHT) + actions
    }
}

data class BlinkDetectionResult(
    val state: BlinkDetectorState,
    val signalStatus: BlinkSignalStatus,
    val confirmed: Boolean,
    val closedDurationMillis: Long? = null,
)

/** Requires OPEN -> CLOSED -> OPEN; a single closed frame cannot pass. */
class BlinkDetector(
    private val config: ActiveLivenessConfig = ActiveLivenessConfig(),
) {
    private var state = BlinkDetectorState.WAITING_FOR_OPEN
    private var closedAtMillis: Long? = null

    fun reset() {
        state = BlinkDetectorState.WAITING_FOR_OPEN
        closedAtMillis = null
    }

    fun observe(face: DetectedFace, timestampMillis: Long): BlinkDetectionResult {
        val left = face.leftEyeOpenProbability
        val right = face.rightEyeOpenProbability
        if (!isProbability(left) || !isProbability(right)) {
            return result(BlinkSignalStatus.UNAVAILABLE)
        }
        val leftProbability = left ?: return result(BlinkSignalStatus.UNAVAILABLE)
        val rightProbability = right ?: return result(BlinkSignalStatus.UNAVAILABLE)
        val signal = when {
            leftProbability >= config.eyeOpenProbability && rightProbability >= config.eyeOpenProbability -> BlinkSignalStatus.OPEN
            leftProbability <= config.eyeClosedProbability && rightProbability <= config.eyeClosedProbability -> BlinkSignalStatus.CLOSED
            else -> BlinkSignalStatus.AMBIGUOUS
        }
        var duration: Long? = null
        when (signal) {
            BlinkSignalStatus.OPEN -> {
                when (state) {
                    BlinkDetectorState.WAITING_FOR_OPEN -> state = BlinkDetectorState.EYES_OPEN
                    BlinkDetectorState.EYES_CLOSED -> {
                        duration = (timestampMillis - (closedAtMillis ?: timestampMillis)).coerceAtLeast(0L)
                        state = if (duration in config.blinkMinClosedMillis..config.blinkMaxClosedMillis) {
                            BlinkDetectorState.CONFIRMED
                        } else {
                            BlinkDetectorState.EYES_OPEN
                        }
                        closedAtMillis = null
                    }
                    BlinkDetectorState.EYES_OPEN,
                    BlinkDetectorState.CONFIRMED,
                    -> Unit
                }
            }
            BlinkSignalStatus.CLOSED -> {
                when (state) {
                    BlinkDetectorState.EYES_OPEN -> {
                        state = BlinkDetectorState.EYES_CLOSED
                        closedAtMillis = timestampMillis
                    }
                    BlinkDetectorState.EYES_CLOSED -> {
                        val elapsed = timestampMillis - (closedAtMillis ?: timestampMillis)
                        if (elapsed > config.blinkMaxClosedMillis) {
                            state = BlinkDetectorState.WAITING_FOR_OPEN
                            closedAtMillis = null
                        }
                    }
                    BlinkDetectorState.WAITING_FOR_OPEN,
                    BlinkDetectorState.CONFIRMED,
                    -> Unit
                }
            }
            BlinkSignalStatus.AMBIGUOUS,
            BlinkSignalStatus.UNAVAILABLE,
            -> Unit
        }
        return result(signal, duration)
    }

    private fun result(signal: BlinkSignalStatus, duration: Long? = null) = BlinkDetectionResult(
        state = state,
        signalStatus = signal,
        confirmed = state == BlinkDetectorState.CONFIRMED,
        closedDurationMillis = duration,
    )

    private fun isProbability(value: Float?): Boolean =
        value != null && value.isFinite() && value in 0f..1f
}

enum class HeadTurnDetectorState {
    WAITING_FOR_NEUTRAL,
    WAITING_FOR_TURN,
    TURNING,
    RETURNING_TO_NEUTRAL,
    CONFIRMED,
}

data class HeadTurnDetectionResult(
    val state: HeadTurnDetectorState,
    val confirmed: Boolean,
    val neutral: Boolean,
    val targetReached: Boolean,
    val stableFrames: Int,
    val requiredStableFrames: Int,
)

/** Hysteretic yaw detector: neutral -> target for stable frames -> neutral. */
class HeadTurnDetector(
    private val config: ActiveLivenessConfig = ActiveLivenessConfig(),
) {
    private var state = HeadTurnDetectorState.WAITING_FOR_NEUTRAL
    private var neutralFrames = 0
    private var targetFrames = 0
    private var turnStartedAtMillis: Long? = null

    fun reset() {
        state = HeadTurnDetectorState.WAITING_FOR_NEUTRAL
        neutralFrames = 0
        targetFrames = 0
        turnStartedAtMillis = null
    }

    fun snapshot(): HeadTurnDetectionResult = result(
        neutral = state == HeadTurnDetectorState.WAITING_FOR_TURN ||
            state == HeadTurnDetectorState.WAITING_FOR_NEUTRAL,
        targetReached = state == HeadTurnDetectorState.TURNING ||
            state == HeadTurnDetectorState.RETURNING_TO_NEUTRAL ||
            state == HeadTurnDetectorState.CONFIRMED,
    )

    fun observe(
        yawDegrees: Float,
        target: ActiveChallenge,
        timestampMillis: Long,
    ): HeadTurnDetectionResult {
        require(target == ActiveChallenge.TURN_LEFT || target == ActiveChallenge.TURN_RIGHT)
        if (!yawDegrees.isFinite()) return result(false, false)
        val neutral = abs(yawDegrees) <= config.neutralYawAbsDegrees
        val targetReached = reachesTarget(yawDegrees, target)
        when (state) {
            HeadTurnDetectorState.WAITING_FOR_NEUTRAL -> {
                if (neutral) {
                    neutralFrames++
                    if (neutralFrames >= config.neutralStableFrames) {
                        state = HeadTurnDetectorState.WAITING_FOR_TURN
                        neutralFrames = 0
                    }
                } else {
                    neutralFrames = 0
                }
            }
            HeadTurnDetectorState.WAITING_FOR_TURN -> {
                when {
                    targetReached -> {
                        state = HeadTurnDetectorState.TURNING
                        targetFrames = 1
                        turnStartedAtMillis = timestampMillis
                    }
                    neutral -> Unit
                    else -> neutralFrames = 0
                }
            }
            HeadTurnDetectorState.TURNING -> {
                when {
                    targetReached -> {
                        targetFrames++
                        val elapsed = timestampMillis - (turnStartedAtMillis ?: timestampMillis)
                        if (targetFrames >= config.turnStableFrames && elapsed >= config.minTurnDurationMillis) {
                            state = HeadTurnDetectorState.RETURNING_TO_NEUTRAL
                            neutralFrames = 0
                        }
                    }
                    neutral -> {
                        state = HeadTurnDetectorState.WAITING_FOR_NEUTRAL
                        neutralFrames = 1
                        targetFrames = 0
                        turnStartedAtMillis = null
                    }
                    else -> {
                        state = HeadTurnDetectorState.WAITING_FOR_NEUTRAL
                        neutralFrames = 0
                        targetFrames = 0
                        turnStartedAtMillis = null
                    }
                }
            }
            HeadTurnDetectorState.RETURNING_TO_NEUTRAL -> {
                if (neutral) {
                    neutralFrames++
                    if (neutralFrames >= config.returnNeutralStableFrames) {
                        state = HeadTurnDetectorState.CONFIRMED
                    }
                } else {
                    neutralFrames = 0
                }
            }
            HeadTurnDetectorState.CONFIRMED -> Unit
        }
        return result(neutral, targetReached)
    }

    private fun reachesTarget(yaw: Float, target: ActiveChallenge): Boolean = when (config.yawSignMapping) {
        YawSignMapping.NEGATIVE_IS_LEFT -> when (target) {
            ActiveChallenge.TURN_LEFT -> yaw <= -config.turnYawDegrees
            ActiveChallenge.TURN_RIGHT -> yaw >= config.turnYawDegrees
            else -> false
        }
        YawSignMapping.POSITIVE_IS_LEFT -> when (target) {
            ActiveChallenge.TURN_LEFT -> yaw >= config.turnYawDegrees
            ActiveChallenge.TURN_RIGHT -> yaw <= -config.turnYawDegrees
            else -> false
        }
    }

    private fun result(neutral: Boolean, targetReached: Boolean) = HeadTurnDetectionResult(
        state = state,
        confirmed = state == HeadTurnDetectorState.CONFIRMED,
        neutral = neutral,
        targetReached = targetReached,
        stableFrames = when (state) {
            HeadTurnDetectorState.TURNING -> targetFrames
            HeadTurnDetectorState.RETURNING_TO_NEUTRAL -> neutralFrames
            HeadTurnDetectorState.CONFIRMED -> config.returnNeutralStableFrames
            else -> 0
        },
        requiredStableFrames = if (state == HeadTurnDetectorState.RETURNING_TO_NEUTRAL ||
            state == HeadTurnDetectorState.CONFIRMED
        ) config.returnNeutralStableFrames else config.turnStableFrames,
    )
}

data class ActiveLivenessResult(
    val state: ActiveLivenessState,
    val challengeSequence: List<ActiveChallenge>,
    val currentChallengeIndex: Int,
    val completedChallengeCount: Int,
    val totalActionChallenges: Int,
    val currentChallenge: ActiveChallenge?,
    val lastAction: ActiveChallenge? = null,
    val reason: ActiveLivenessInconclusiveReason? = null,
    val signalStatus: BlinkSignalStatus? = null,
    val currentYawDegrees: Float? = null,
    val turnThresholdDegrees: Float,
    val neutralThresholdDegrees: Float,
    val yawSignMapping: YawSignMapping = YawSignMapping.NEGATIVE_IS_LEFT,
    val stableFrames: Int,
    val requiredStableFrames: Int,
    val challengeTimeRemainingMillis: Long? = null,
    val overallTimeRemainingMillis: Long? = null,
) {
    val actionChallengeNumber: Int
        get() = (currentChallengeIndex).coerceIn(1, totalActionChallenges)
}

/** Pure, session-scoped active-liveness state machine. */
class ActiveLivenessSession(
    private val config: ActiveLivenessConfig = ActiveLivenessConfig(),
    private val challengeGenerator: ActiveChallengeGenerator = ActiveChallengeSequenceGenerator(
        actionCount = config.activeActionCount,
    ),
    private val clockMillis: () -> Long = { System.currentTimeMillis() },
) {
    private val blinkDetector = BlinkDetector(config)
    private val headTurnDetector = HeadTurnDetector(config)
    private var sequence = challengeGenerator.next().validated()
    private var state = ActiveLivenessState.WAITING_FOR_FACE
    private var overallStartedAtMillis: Long? = null
    private var challengeStartedAtMillis: Long? = null
    private var lastFaceAtMillis: Long? = null
    private var noFaceSinceMillis: Long? = null
    private var currentIndex = 0
    private var completedCount = 0
    private var lastAction: ActiveChallenge? = null
    private var reason: ActiveLivenessInconclusiveReason? = null
    private var signalStatus: BlinkSignalStatus? = null
    private var neutralFrames = 0
    private var interruptedState: ActiveLivenessState? = null
    private var currentYawDegrees: Float? = null
    private var lastNowMillis = clockMillis()

    @Synchronized
    fun reset(nowMillis: Long = clockMillis()): ActiveLivenessResult {
        sequence = challengeGenerator.next().validated()
        state = ActiveLivenessState.WAITING_FOR_FACE
        overallStartedAtMillis = null
        challengeStartedAtMillis = null
        lastFaceAtMillis = null
        noFaceSinceMillis = null
        currentIndex = 0
        completedCount = 0
        lastAction = null
        reason = null
        signalStatus = null
        neutralFrames = 0
        interruptedState = null
        currentYawDegrees = null
        lastNowMillis = nowMillis
        blinkDetector.reset()
        headTurnDetector.reset()
        return snapshot()
    }

    @Synchronized
    fun onFace(face: DetectedFace, nowMillis: Long = clockMillis()): ActiveLivenessResult {
        if (state.isTerminal()) return snapshot()
        lastNowMillis = nowMillis
        checkTimeout(nowMillis)?.let { return it }
        lastFaceAtMillis = nowMillis
        noFaceSinceMillis = null
        currentYawDegrees = face.headEulerAngleY.takeIf { it.isFinite() }
        if (state == ActiveLivenessState.WAITING_FOR_FACE || state == ActiveLivenessState.WAITING_FOR_QUALITY) {
            if (currentIndex == 0) {
                state = ActiveLivenessState.ESTABLISHING_NEUTRAL
                neutralFrames = 0
                return snapshot()
            }
            state = if (interruptedState == ActiveLivenessState.ACTION_CONFIRMED ||
                interruptedState == ActiveLivenessState.RETURN_TO_NEUTRAL
            ) {
                ActiveLivenessState.RETURN_TO_NEUTRAL
            } else {
                ActiveLivenessState.CHALLENGE_ACTIVE
            }
            interruptedState = null
            blinkDetector.reset()
            headTurnDetector.reset()
        }
        if (state == ActiveLivenessState.ACTION_CONFIRMED) {
            state = ActiveLivenessState.RETURN_TO_NEUTRAL
            neutralFrames = 0
        }
        if (state == ActiveLivenessState.RETURN_TO_NEUTRAL) {
            if (isNeutral(face)) neutralFrames++ else neutralFrames = 0
            if (neutralFrames >= config.returnNeutralStableFrames) {
                currentIndex++
                if (currentIndex >= sequence.size) {
                    challengeStartedAtMillis = null
                    state = ActiveLivenessState.PASSED
                    return snapshot()
                }
                state = ActiveLivenessState.NEXT_CHALLENGE
            }
            return snapshot()
        }
        if (state == ActiveLivenessState.NEXT_CHALLENGE) {
            state = ActiveLivenessState.CHALLENGE_ACTIVE
            challengeStartedAtMillis = nowMillis
            blinkDetector.reset()
            headTurnDetector.reset()
            signalStatus = null
        }
        if (state == ActiveLivenessState.ESTABLISHING_NEUTRAL) {
            if (isNeutral(face)) neutralFrames++ else neutralFrames = 0
            if (neutralFrames >= config.neutralStableFrames) {
                completeLookStraight(nowMillis)
            }
            return snapshot()
        }
        if (state == ActiveLivenessState.CHALLENGE_ACTIVE || state == ActiveLivenessState.ACTION_IN_PROGRESS) {
            return observeAction(face, nowMillis)
        }
        return snapshot()
    }

    @Synchronized
    fun onQualityRejected(nowMillis: Long = clockMillis()): ActiveLivenessResult {
        if (state.isTerminal()) return snapshot()
        lastNowMillis = nowMillis
        checkTimeout(nowMillis)?.let { return it }
        currentYawDegrees = null
        interruptedState = state
        state = ActiveLivenessState.WAITING_FOR_QUALITY
        return snapshot()
    }

    @Synchronized
    fun onNoFace(nowMillis: Long = clockMillis()): ActiveLivenessResult {
        if (state.isTerminal()) return snapshot()
        lastNowMillis = nowMillis
        checkTimeout(nowMillis)?.let { return it }
        currentYawDegrees = null
        val noFaceSince = noFaceSinceMillis ?: nowMillis.also { noFaceSinceMillis = it }
        if (nowMillis - noFaceSince >= config.faceLossTimeoutMillis) {
            return invalidate(ActiveLivenessInconclusiveReason.NO_FACE)
        }
        interruptedState = interruptedState ?: state
        state = ActiveLivenessState.WAITING_FOR_FACE
        return snapshot()
    }

    @Synchronized
    fun onMultipleFaces(nowMillis: Long = clockMillis()): ActiveLivenessResult {
        lastNowMillis = nowMillis
        return invalidate(ActiveLivenessInconclusiveReason.MULTIPLE_FACES)
    }

    @Synchronized
    fun onCameraInterrupted(nowMillis: Long = clockMillis()): ActiveLivenessResult {
        lastNowMillis = nowMillis
        return invalidate(ActiveLivenessInconclusiveReason.CAMERA_INTERRUPTED)
    }

    @Synchronized
    fun timeout(nowMillis: Long = clockMillis()): ActiveLivenessResult {
        lastNowMillis = nowMillis
        checkTimeout(nowMillis)
        return snapshot()
    }

    @Synchronized
    fun snapshot(): ActiveLivenessResult {
        val nowMillis = lastNowMillis
        val overallRemaining = overallStartedAtMillis?.let {
            (config.overallActiveTimeoutMillis - (nowMillis - it)).coerceAtLeast(0L)
        }
        val challengeRemaining = challengeStartedAtMillis?.let {
            (config.perChallengeTimeoutMillis - (nowMillis - it)).coerceAtLeast(0L)
        }
        val turnState = headTurnDetector.snapshot()
        return ActiveLivenessResult(
        state = state,
        challengeSequence = sequence,
        currentChallengeIndex = currentIndex,
        completedChallengeCount = completedCount,
        totalActionChallenges = sequence.size - 1,
        currentChallenge = sequence.getOrNull(currentIndex),
        lastAction = lastAction,
        reason = reason,
        signalStatus = signalStatus,
        currentYawDegrees = currentYawDegrees,
        turnThresholdDegrees = config.turnYawDegrees,
        neutralThresholdDegrees = config.neutralYawAbsDegrees,
        yawSignMapping = config.yawSignMapping,
        stableFrames = turnState.stableFrames,
        requiredStableFrames = turnState.requiredStableFrames,
        challengeTimeRemainingMillis = challengeRemaining,
        overallTimeRemainingMillis = overallRemaining,
        )
    }

    private fun observeAction(face: DetectedFace, nowMillis: Long): ActiveLivenessResult {
        val challenge = sequence.getOrNull(currentIndex) ?: return snapshot()
        when (challenge) {
            ActiveChallenge.BLINK -> {
                val blink = blinkDetector.observe(face, nowMillis)
                signalStatus = blink.signalStatus
                if (blink.confirmed) completeAction(challenge)
            }
            ActiveChallenge.TURN_LEFT,
            ActiveChallenge.TURN_RIGHT,
            -> {
                val turn = headTurnDetector.observe(face.headEulerAngleY, challenge, nowMillis)
                state = if (turn.confirmed) {
                    completeAction(challenge)
                    ActiveLivenessState.ACTION_CONFIRMED
                } else if (turn.state == HeadTurnDetectorState.TURNING ||
                    turn.state == HeadTurnDetectorState.RETURNING_TO_NEUTRAL
                ) {
                    ActiveLivenessState.ACTION_IN_PROGRESS
                } else {
                    ActiveLivenessState.CHALLENGE_ACTIVE
                }
            }
            ActiveChallenge.LOOK_STRAIGHT -> completeLookStraight(nowMillis)
        }
        return snapshot()
    }

    private fun completeLookStraight(nowMillis: Long) {
        lastAction = ActiveChallenge.LOOK_STRAIGHT
        completedCount = 1
        currentIndex = 1
        if (currentIndex >= sequence.size) {
            challengeStartedAtMillis = null
            state = ActiveLivenessState.PASSED
        } else {
            overallStartedAtMillis = nowMillis
            challengeStartedAtMillis = nowMillis
            state = ActiveLivenessState.CHALLENGE_ACTIVE
        }
        headTurnDetector.reset()
        blinkDetector.reset()
    }

    private fun completeAction(challenge: ActiveChallenge) {
        lastAction = challenge
        completedCount++
        challengeStartedAtMillis = null
        state = ActiveLivenessState.ACTION_CONFIRMED
    }

    private fun checkTimeout(nowMillis: Long): ActiveLivenessResult? {
        if (state.isTerminal()) return snapshot()
        val overallStarted = overallStartedAtMillis
        if (overallStarted != null && nowMillis - overallStarted >= config.overallActiveTimeoutMillis) {
            return invalidate(ActiveLivenessInconclusiveReason.SESSION_TIMEOUT)
        }
        val challengeStarted = challengeStartedAtMillis
        if (challengeStarted != null && nowMillis - challengeStarted >= config.perChallengeTimeoutMillis) {
            return invalidate(ActiveLivenessInconclusiveReason.CHALLENGE_TIMEOUT)
        }
        return null
    }

    private fun isNeutral(face: DetectedFace): Boolean =
        face.headEulerAngleY.isFinite() && abs(face.headEulerAngleY) <= config.neutralYawAbsDegrees

    private fun invalidate(inconclusiveReason: ActiveLivenessInconclusiveReason): ActiveLivenessResult {
        state = ActiveLivenessState.INCONCLUSIVE
        reason = inconclusiveReason
        return snapshot()
    }

    private fun List<ActiveChallenge>.validated(): List<ActiveChallenge> {
        require(size == config.activeActionCount + 1)
        require(firstOrNull() == ActiveChallenge.LOOK_STRAIGHT)
        require(drop(1).distinct().size == config.activeActionCount)
        require(drop(1).none { it == ActiveChallenge.LOOK_STRAIGHT })
        return toList()
    }

    private fun ActiveLivenessState.isTerminal(): Boolean =
        this == ActiveLivenessState.PASSED ||
            this == ActiveLivenessState.FAILED ||
            this == ActiveLivenessState.INCONCLUSIVE
}
