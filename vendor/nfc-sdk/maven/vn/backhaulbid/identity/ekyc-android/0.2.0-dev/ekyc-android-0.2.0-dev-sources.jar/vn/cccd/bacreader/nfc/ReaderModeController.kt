package vn.cccd.bacreader.nfc

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag

/** Enables Reader Mode only while an explicit scan is active. */
class ReaderModeController(
    private val activity: Activity,
    private val adapter: NfcAdapter?,
    private val onTag: (Tag) -> Unit,
) {
    private var enabled = false

    val isAvailable: Boolean
        get() = adapter?.isEnabled == true

    /** Returns false when the device has no enabled NFC adapter. Call while the Activity is resumed. */
    fun start(): Boolean {
        val currentAdapter = adapter ?: return false
        if (!currentAdapter.isEnabled) return false
        if (enabled) return true
        currentAdapter.enableReaderMode(
            activity,
            NfcAdapter.ReaderCallback { tag -> onTag(tag) },
            NfcAdapter.FLAG_READER_NFC_A or
                NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
            null,
        )
        enabled = true
        return true
    }

    fun stop() {
        if (enabled) adapter?.disableReaderMode(activity)
        enabled = false
    }
}
