package vn.cccd.bacreader.ui.demo

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Nfc
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import vn.cccd.bacreader.document.crosscheck.NfcDocumentResult
import vn.cccd.bacreader.document.crosscheck.NfcOverallStatus
import vn.cccd.bacreader.domain.ScanStep
import vn.cccd.bacreader.domain.ReaderError

enum class ProductionNfcPhase {
    PREPARING,
    WAITING_FOR_TAG,
    READING,
    RESULT,
}

data class ProductionNfcUiState(
    val phase: ProductionNfcPhase = ProductionNfcPhase.PREPARING,
    val step: ScanStep? = null,
    val result: NfcDocumentResult? = null,
)

/** Production-facing NFC host. It only renders engine state; it never invents a result. */
@Composable
fun ProductionNfcHost(
    state: ProductionNfcUiState,
    onRetry: () -> Unit,
    onClose: () -> Unit,
) {
    val result = state.result
    val success = result?.overallStatus == NfcOverallStatus.SUCCESS
    val recovery = nfcRecovery(result?.failureReason)
    EkycScaffold(
        title = "Đọc chip NFC", step = 2, onExit = onClose,
        bottom = {
            if (state.phase == ProductionNfcPhase.RESULT && !success && recovery.retryAllowed) {
                SecondaryButton("Thử đọc lại", onRetry)
            }
            SecondaryButton("Hủy đọc chip", onClose)
        },
    ) {
        Text("Đọc chip NFC", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            when (state.phase) {
                ProductionNfcPhase.PREPARING -> "Đang chuẩn bị phiên đọc"
                ProductionNfcPhase.WAITING_FOR_TAG -> "Đặt mặt sau CCCD sát vùng NFC của điện thoại."
                ProductionNfcPhase.READING -> nfcProgressLabel(state.step)
                ProductionNfcPhase.RESULT -> if (success) "Đã đọc dữ liệu chip" else recovery.title
            },
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 16.sp,
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = EkycColors.BrandSoft),
        ) {
            Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(
                    imageVector = if (success) Icons.Outlined.CheckCircle else if (state.phase == ProductionNfcPhase.RESULT) Icons.Outlined.WarningAmber else Icons.Outlined.Nfc,
                    contentDescription = null,
                    tint = if (success) EkycColors.Success else EkycColors.Brand,
                )
                Text(
                    when (state.phase) {
                        ProductionNfcPhase.PREPARING -> "Chuẩn bị căn cước có gắn chip của bạn."
                        ProductionNfcPhase.WAITING_FOR_TAG -> "Giữ nguyên thẻ trong suốt quá trình đọc."
                        ProductionNfcPhase.READING -> "Giữ nguyên vị trí thẻ đến khi điện thoại báo đã đọc xong."
                        ProductionNfcPhase.RESULT -> if (success) "Đã thu thập dữ liệu trên chip. Bước này chưa xác minh danh tính." else recovery.description
                    },
                    fontWeight = FontWeight.Medium,
                )
            }
        }
        if (state.phase == ProductionNfcPhase.READING) LinearProgressIndicator(Modifier.fillMaxWidth())
        when {
            state.phase == ProductionNfcPhase.RESULT && !success -> Unit
            state.phase == ProductionNfcPhase.RESULT && success -> Text("Đang chuyển sang kết quả…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            else -> Text("Đưa thẻ ra khỏi vùng đọc chỉ khi có thông báo hoàn tất.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
        if (state.phase == ProductionNfcPhase.WAITING_FOR_TAG) {
            InfoCard("Tìm vị trí đọc trên điện thoại", "Tháo ốp dày, áp thẻ vào lưng máy và di chuyển chậm đến khi máy nhận thẻ.")
        }
    }
}

internal fun nfcProgressLabel(step: ScanStep?): String = when (step) {
    null, ScanStep.IDLE -> "Đang chờ thẻ…"
    ScanStep.TAG_DISCOVERED -> "Đã phát hiện chip, đang kết nối…"
    ScanStep.BAC_RESPONSE_VERIFIED -> "Đang thiết lập phiên bảo vệ…"
    ScanStep.SECURE_MESSAGING_READY -> "Đang đọc thông tin chip…"
    ScanStep.EF_COM_READ,
    ScanStep.EF_COM_SELECTED,
    -> "Đang đọc thông tin chip…"
    ScanStep.DG1_READ,
    ScanStep.DG1_SELECTED,
    -> "Đang đọc dữ liệu định danh…"
    ScanStep.DG2_READ,
    ScanStep.DG2_SELECTED,
    -> "Đang đọc ảnh chân dung…"
    ScanStep.DG13_READ,
    ScanStep.DG13_SELECTED,
    -> "Đang đọc dữ liệu bổ sung…"
    ScanStep.EF_SOD_READ,
    ScanStep.EF_SOD_SELECTED,
    -> "Đang kiểm tra dữ liệu…"
    ScanStep.COMPLETE -> "Đã hoàn tất đọc chip"
    ScanStep.ERROR -> "Đã xảy ra lỗi khi đọc chip"
    else -> "Đang thiết lập phiên bảo vệ…"
}

@Composable
private fun TextButtonLike(label: String, onClick: () -> Unit) {
    SecondaryButton(label, onClick)
}
