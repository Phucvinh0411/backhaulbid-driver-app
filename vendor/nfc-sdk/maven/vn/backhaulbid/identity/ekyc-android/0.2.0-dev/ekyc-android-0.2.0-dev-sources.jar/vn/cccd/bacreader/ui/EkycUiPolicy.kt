package vn.cccd.bacreader.ui

/**
 * Build-mode policy for the eKYC presentation layer.
 *
 * Domain decisions stay in the NFC/OCR/biometric layers; this object only
 * controls which diagnostics and development affordances are presented.
 */
data class EkycUiPolicy(
    val showTechnicalDetails: Boolean,
    val showDevelopmentScenarios: Boolean,
    val showThresholds: Boolean,
    val allowScreenCapture: Boolean,
    val showDebugDiagnostics: Boolean,
) {
    companion object {
        fun forBuild(isDebug: Boolean): EkycUiPolicy = if (isDebug) {
            EkycUiPolicy(
                showTechnicalDetails = true,
                showDevelopmentScenarios = true,
                showThresholds = true,
                allowScreenCapture = false,
                showDebugDiagnostics = true,
            )
        } else {
            EkycUiPolicy(
                showTechnicalDetails = false,
                showDevelopmentScenarios = false,
                showThresholds = false,
                allowScreenCapture = false,
                showDebugDiagnostics = false,
            )
        }
    }
}
