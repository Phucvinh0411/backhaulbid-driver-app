package vn.cccd.bacreader.biometric.liveness

import kotlin.math.roundToInt

enum class LivenessSessionState {
    COLLECTING,
    LIVE_DEVELOPMENT,
    SPOOF_DEVELOPMENT,
    INCONCLUSIVE,
    MODEL_ERROR,
}

enum class LivenessInconclusiveReason {
    NO_FACE,
    MULTIPLE_FACES,
    INSUFFICIENT_VALID_FRAMES,
    QUALITY_TIMEOUT,
    CAMERA_INTERRUPTED,
}

data class LivenessSessionResult(
    val state: LivenessSessionState,
    val validFrameCount: Int,
    val rejectedFrameCount: Int,
    val medianScore: Float? = null,
    val latestFrame: LivenessFrameResult? = null,
    val inconclusiveReason: LivenessInconclusiveReason? = null,
)

/** Stateful multi-frame policy. It never labels a single frame as the final result. */
class LivenessSession(
    private val config: LivenessConfig = LivenessConfig(),
    private val clockMillis: () -> Long = { System.currentTimeMillis() },
) {
    private val scores = ArrayList<Float>(config.requiredValidFrames)
    private var startedAtMillis = clockMillis()
    private var state = LivenessSessionState.COLLECTING
    private var rejectedFrameCount = 0
    private var latestFrame: LivenessFrameResult? = null
    private var medianScore: Float? = null
    private var reason: LivenessInconclusiveReason? = null

    fun reset(nowMillis: Long = clockMillis()): LivenessSessionResult {
        scores.clear()
        startedAtMillis = nowMillis
        state = LivenessSessionState.COLLECTING
        rejectedFrameCount = 0
        latestFrame = null
        medianScore = null
        reason = null
        return snapshot()
    }

    fun accept(frame: LivenessFrameResult): LivenessSessionResult {
        if (state != LivenessSessionState.COLLECTING) return snapshot()
        if (frame.qualityStatus != LivenessQualityStatus.GOOD) {
            rejectedFrameCount++
            return snapshot()
        }
        require(frame.decisionScore == frame.realLogit - frame.spoofLogit) {
            "decisionScore must equal realLogit - spoofLogit"
        }
        scores += frame.decisionScore
        latestFrame = frame
        if (scores.size >= config.requiredValidFrames) {
            medianScore = median(scores)
            state = if (medianScore!! >= config.developmentThreshold) {
                LivenessSessionState.LIVE_DEVELOPMENT
            } else {
                LivenessSessionState.SPOOF_DEVELOPMENT
            }
        }
        return snapshot()
    }

    fun reject(reason: LivenessInconclusiveReason? = null): LivenessSessionResult {
        if (state == LivenessSessionState.COLLECTING) {
            rejectedFrameCount++
            if (reason == LivenessInconclusiveReason.MULTIPLE_FACES) {
                invalidate(reason)
            }
        }
        return snapshot()
    }

    fun timeout(nowMillis: Long = clockMillis()): LivenessSessionResult {
        if (state == LivenessSessionState.COLLECTING &&
            nowMillis - startedAtMillis >= config.sessionTimeoutMillis
        ) {
            invalidate(LivenessInconclusiveReason.QUALITY_TIMEOUT)
        }
        return snapshot()
    }

    fun invalidate(inconclusiveReason: LivenessInconclusiveReason): LivenessSessionResult {
        scores.clear()
        medianScore = null
        latestFrame = null
        state = LivenessSessionState.INCONCLUSIVE
        reason = inconclusiveReason
        return snapshot()
    }

    fun modelError(): LivenessSessionResult {
        scores.clear()
        medianScore = null
        latestFrame = null
        state = LivenessSessionState.MODEL_ERROR
        reason = null
        return snapshot()
    }

    fun snapshot(): LivenessSessionResult = LivenessSessionResult(
        state = state,
        validFrameCount = scores.size,
        rejectedFrameCount = rejectedFrameCount,
        medianScore = medianScore,
        latestFrame = latestFrame,
        inconclusiveReason = reason,
    )

    private fun median(values: List<Float>): Float {
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 1) {
            sorted[middle]
        } else {
            ((sorted[middle - 1] + sorted[middle]) / 2.0f * 1_000_000f).roundToInt() / 1_000_000f
        }
    }

}
