package vn.cccd.bacreader.ui.demo

import android.content.Intent
import vn.cccd.bacreader.biometric.camera.BiometricResult
import vn.cccd.bacreader.biometric.camera.BiometricStage
import vn.cccd.bacreader.biometric.camera.BiometricStageStatus
import vn.cccd.bacreader.biometric.camera.CameraActivity

object BiometricResultBridge {
    fun fromIntent(data: Intent?): BiometricResult? {
        val intent = data ?: return null
        val active = status(intent.getStringExtra(CameraActivity.EXTRA_BIOMETRIC_ACTIVE)) ?: return null
        val passive = status(intent.getStringExtra(CameraActivity.EXTRA_BIOMETRIC_PASSIVE)) ?: return null
        val faceMatch = status(intent.getStringExtra(CameraActivity.EXTRA_BIOMETRIC_FACE_MATCH)) ?: return null
        return BiometricResult(
            activeLiveness = active,
            passiveLiveness = passive,
            faceMatch = faceMatch,
            failureStage = intent.getStringExtra(CameraActivity.EXTRA_BIOMETRIC_FAILURE_STAGE)
                ?.let { runCatching { BiometricStage.valueOf(it) }.getOrNull() },
        )
    }

    private fun status(value: String?): BiometricStageStatus? =
        value?.let { runCatching { BiometricStageStatus.valueOf(it) }.getOrNull() }
}
