package vn.cccd.bacreader.biometric.detection

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import vn.cccd.bacreader.biometric.recognition.FaceLandmarks
import vn.cccd.bacreader.biometric.recognition.FacePoint

/** One-shot DG2 detector. The bitmap remains owned by the caller and is not cached here. */
class MlKitBitmapFaceDetector : AutoCloseable {
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .build(),
    )

    fun detect(bitmap: Bitmap, callback: (List<DetectedFace>?) -> Unit) {
        detector.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { callback(it.map(::mapFace)) }
            .addOnFailureListener { callback(null) }
    }

    override fun close() { detector.close() }

    private fun mapFace(face: Face): DetectedFace = DetectedFace(
        bounds = FaceBounds(face.boundingBox.left, face.boundingBox.top, face.boundingBox.right, face.boundingBox.bottom),
        trackingId = face.trackingId,
        headEulerAngleX = face.headEulerAngleX,
        headEulerAngleY = face.headEulerAngleY,
        headEulerAngleZ = face.headEulerAngleZ,
        landmarks = landmarks(face),
    )

    private fun landmarks(face: Face): FaceLandmarks? {
        val leftEye = face.getLandmark(com.google.mlkit.vision.face.FaceLandmark.LEFT_EYE)?.position
        val rightEye = face.getLandmark(com.google.mlkit.vision.face.FaceLandmark.RIGHT_EYE)?.position
        val nose = face.getLandmark(com.google.mlkit.vision.face.FaceLandmark.NOSE_BASE)?.position
        val mouthLeft = face.getLandmark(com.google.mlkit.vision.face.FaceLandmark.MOUTH_LEFT)?.position
        val mouthRight = face.getLandmark(com.google.mlkit.vision.face.FaceLandmark.MOUTH_RIGHT)?.position
        return if (leftEye != null && rightEye != null && nose != null && mouthLeft != null && mouthRight != null) FaceLandmarks(
            FacePoint(leftEye.x, leftEye.y), FacePoint(rightEye.x, rightEye.y), FacePoint(nose.x, nose.y),
            FacePoint(mouthLeft.x, mouthLeft.y), FacePoint(mouthRight.x, mouthRight.y),
        ) else null
    }
}
