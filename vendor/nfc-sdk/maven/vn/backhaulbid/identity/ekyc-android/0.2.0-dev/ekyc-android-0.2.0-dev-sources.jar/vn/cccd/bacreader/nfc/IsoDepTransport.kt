package vn.cccd.bacreader.nfc

import android.nfc.tech.IsoDep
import android.nfc.TagLostException
import java.io.IOException

/** Android adapter for IsoDep; protocol code never touches Android NFC classes. */
class IsoDepTransport(
    private val isoDep: IsoDep,
    private val timeoutMillis: Int = DEFAULT_TIMEOUT_MILLIS,
) : ApduTransport, TransportDiagnostics {
    override val isConnected: Boolean?
        get() = runCatching { isoDep.isConnected }.getOrNull()

    override val configuredTimeoutMillis: Int?
        get() = timeoutMillis

    override val maxTransceiveLength: Int
        get() = isoDep.maxTransceiveLength

    override fun connect() {
        try {
            isoDep.connect()
            isoDep.timeout = timeoutMillis
        } catch (error: IOException) {
            throw TransportException("Unable to connect to ISO-DEP tag", error)
        }
    }

    override fun transceive(command: ByteArray): ByteArray {
        require(command.size <= maxTransceiveLength) {
            "APDU exceeds IsoDep.maxTransceiveLength"
        }
        return try {
            isoDep.transceive(command)
        } catch (error: TagLostException) {
            throw TagLostTransportException(error)
        } catch (error: IOException) {
            if (error.message?.contains("timeout", ignoreCase = true) == true) {
                throw TransportTimeoutException(error)
            }
            throw TransportException("ISO-DEP transceive failed", error)
        }
    }

    override fun close() {
        try {
            if (isoDep.isConnected) isoDep.close()
        } catch (_: IOException) {
            // Closing is best effort; the session is already being invalidated.
        }
    }

    private companion object {
        const val DEFAULT_TIMEOUT_MILLIS = 10_000
    }
}
