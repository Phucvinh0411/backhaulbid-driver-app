package vn.cccd.bacreader.ui

import vn.cccd.bacreader.domain.ReadResult
import vn.cccd.bacreader.domain.AuthenticityResult
import vn.cccd.bacreader.domain.Dg13Field
import vn.cccd.bacreader.domain.Dg2Data
import vn.cccd.bacreader.domain.FileReadReport
import vn.cccd.bacreader.domain.SodData
import vn.cccd.bacreader.domain.ScanStep

/** Pure, non-persistent mapping from a protocol outcome to fields shown on the result screen. */
internal data class ResultScreenModel(
    val isSuccess: Boolean,
    val step: ScanStep,
    val code: String,
    val statusWord: String?,
    val bytesRead: Int,
    val elapsedMillis: Long,
    val efComBytes: Int? = null,
    val dg1Bytes: Int? = null,
    val dg1Mrz: String? = null,
    val dg1Details: Dg1ScreenModel? = null,
    val dg13Fields: List<Dg13Field> = emptyList(),
    val dg2: Dg2Data? = null,
    val sod: SodData? = null,
    val optionalFiles: List<FileReadReport> = emptyList(),
    val authenticity: AuthenticityResult = AuthenticityResult(),
)

internal object ResultScreenModelMapper {
    fun map(outcome: ReadResult): ResultScreenModel = when (outcome) {
        is ReadResult.Success -> ResultScreenModel(
            isSuccess = true,
            step = ScanStep.COMPLETE,
            code = "SUCCESS",
            statusWord = null,
            bytesRead = outcome.efComBytes + outcome.dg1Bytes + outcome.optionalFiles.sumOf { it.bytesRead },
            elapsedMillis = outcome.elapsedMillis,
            efComBytes = outcome.efComBytes,
            dg1Bytes = outcome.dg1Bytes,
            dg1Mrz = outcome.dg1Mrz,
            dg1Details = Dg1ScreenModelMapper.map(outcome.dg1Mrz),
            dg13Fields = outcome.dg13?.fields.orEmpty(),
            dg2 = outcome.dg2,
            sod = outcome.sod,
            optionalFiles = outcome.optionalFiles,
            authenticity = outcome.authenticity,
        )
        is ReadResult.Failure -> ResultScreenModel(
            isSuccess = false,
            step = outcome.step,
            code = outcome.error.name,
            statusWord = outcome.sw,
            bytesRead = outcome.bytesRead,
            elapsedMillis = outcome.elapsedMillis,
        )
    }
}
