package vn.cccd.bacreader.ui

/** A single TD1 field prepared for the diagnostic result screen. */
internal data class Dg1FieldPresentation(
    val label: String,
    val value: String,
    val maskedValue: String,
    val sensitive: Boolean,
)

internal data class Dg1ScreenModel(
    val rawMrz: String,
    val fields: List<Dg1FieldPresentation>,
    val isStructured: Boolean,
)

/**
 * Maps the already-validated TD1 MRZ into named fields for on-device
 * diagnostics. This is presentation-only; it does not change LDS parsing or
 * retain a second copy outside the in-memory result state.
 */
internal object Dg1ScreenModelMapper {
    fun map(mrz: String): Dg1ScreenModel {
        val lines = mrz.split('\n')
        if (lines.size != 3 || lines.any { it.length != TD1_LINE_LENGTH }) {
            return Dg1ScreenModel(rawMrz = mrz, fields = emptyList(), isStructured = false)
        }

        val first = lines[0]
        val second = lines[1]
        val third = lines[2]
        return Dg1ScreenModel(
            rawMrz = mrz,
            isStructured = true,
            fields = listOf(
                field("Loại giấy tờ", clean(first.slice(0..1)), sensitive = false),
                field("Quốc gia cấp", clean(first.slice(2..4)), sensitive = false),
                field("Số giấy tờ", clean(first.slice(5..13)), sensitive = true),
                field("Ngày sinh", clean(second.slice(0..5)), sensitive = true),
                field("Giới tính", clean(second.slice(7..7)), sensitive = false),
                field("Ngày hết hạn", clean(second.slice(8..13)), sensitive = true),
                field("Quốc tịch", clean(second.slice(15..17)), sensitive = false),
                field("Họ tên", decodeName(third), sensitive = true),
                field(
                    "Dữ liệu tùy chọn",
                    listOf(clean(first.slice(15..29)), clean(second.slice(18..28)))
                        .filter { it.isNotBlank() }
                        .joinToString(" / "),
                    sensitive = true,
                ),
            ),
        )
    }

    private fun field(label: String, value: String, sensitive: Boolean): Dg1FieldPresentation =
        Dg1FieldPresentation(
            label = label,
            value = value.ifBlank { "—" },
            maskedValue = if (sensitive && value.isNotBlank()) "••••••" else value.ifBlank { "—" },
            sensitive = sensitive,
        )

    private fun clean(value: String): String = value
        .replace('<', ' ')
        .trim()
        .replace(Regex("\\s+"), " ")

    private fun decodeName(value: String): String {
        val separator = value.indexOf("<<")
        if (separator < 0) return clean(value)
        val surname = clean(value.substring(0, separator))
        val given = clean(value.substring(separator + 2))
        return listOf(surname, given).filter { it.isNotBlank() }.joinToString(" ")
    }

    private const val TD1_LINE_LENGTH = 30
}
