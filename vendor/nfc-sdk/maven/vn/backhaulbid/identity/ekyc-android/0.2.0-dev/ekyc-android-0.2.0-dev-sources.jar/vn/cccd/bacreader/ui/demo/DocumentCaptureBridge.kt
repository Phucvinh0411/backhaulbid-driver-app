package vn.cccd.bacreader.ui.demo

import android.content.Intent
import vn.cccd.bacreader.document.capture.DocumentCaptureActivity
import vn.cccd.bacreader.document.resolver.ParsedFieldStatus

/** Lightweight state exposed by the document Activity bridge. */
enum class DocumentCaptureFlowState {
    IDLE,
    LAUNCHING,
    READY,
    BLOCKED,
    CANCELLED,
    ERROR,
}

data class DocumentCaptureFieldStatuses(
    val documentNumber: ParsedFieldStatus = ParsedFieldStatus.NOT_FOUND,
    val dateOfBirth: ParsedFieldStatus = ParsedFieldStatus.NOT_FOUND,
    val dateOfExpiry: ParsedFieldStatus = ParsedFieldStatus.NOT_FOUND,
)

/** Intent-free representation used to keep bridge decisions unit-testable. */
data class DocumentCapturePayload(
    val resultCode: Int,
    val requiredFieldsReady: Boolean? = null,
    val profile: String? = null,
    val documentNumber: String? = null,
    val birthYYMMDD: String? = null,
    val expiryYYMMDD: String? = null,
    val fullNameRaw: String? = null,
    val sex: String? = null,
    val nationality: String? = null,
    val readinessStatus: String? = null,
    val recommendedAction: String? = null,
    val fieldStatuses: DocumentCaptureFieldStatuses = DocumentCaptureFieldStatuses(),
    val failureReason: String? = null,
)

data class DocumentCaptureBridgeResult(
    val state: DocumentCaptureFlowState,
    val profile: String? = null,
    val document: DemoDocumentFields? = null,
    val readinessStatus: String? = null,
    val recommendedAction: String? = null,
    val fieldStatuses: DocumentCaptureFieldStatuses = DocumentCaptureFieldStatuses(),
    val failureReason: String? = null,
)

/**
 * Converts the existing DocumentCaptureActivity result into Compose state.
 * Readiness is reported by the existing activity validator; this bridge never recalculates it.
 */
object DocumentCaptureBridge {
    const val RESULT_OK = -1
    const val RESULT_CANCELED = 0

    fun fromIntent(resultCode: Int, intent: Intent?): DocumentCapturePayload =
        DocumentCapturePayload(
            resultCode = resultCode,
            requiredFieldsReady = intent?.takeIf { it.hasExtra(DocumentCaptureActivity.EXTRA_REQUIRED_FIELDS_READY) }
                ?.getBooleanExtra(DocumentCaptureActivity.EXTRA_REQUIRED_FIELDS_READY, false),
            profile = intent?.getStringExtra(DocumentCaptureActivity.EXTRA_CARD_PROFILE),
            documentNumber = intent?.getStringExtra(DocumentCaptureActivity.EXTRA_DOCUMENT_NUMBER),
            birthYYMMDD = intent?.getStringExtra(DocumentCaptureActivity.EXTRA_BIRTH_YYMMDD),
            expiryYYMMDD = intent?.getStringExtra(DocumentCaptureActivity.EXTRA_EXPIRY_YYMMDD),
            fullNameRaw = intent?.getStringExtra(DocumentCaptureActivity.EXTRA_FULL_NAME_RAW),
            sex = intent?.getStringExtra(DocumentCaptureActivity.EXTRA_SEX_RAW),
            nationality = intent?.getStringExtra(DocumentCaptureActivity.EXTRA_NATIONALITY_RAW),
            readinessStatus = intent?.getStringExtra(DocumentCaptureActivity.EXTRA_READINESS_STATUS),
            recommendedAction = intent?.getStringExtra(DocumentCaptureActivity.EXTRA_RECOMMENDED_ACTION),
            fieldStatuses = DocumentCaptureFieldStatuses(
                documentNumber = statusOf(intent?.getStringExtra(DocumentCaptureActivity.EXTRA_DOCUMENT_NUMBER_STATUS)),
                dateOfBirth = statusOf(intent?.getStringExtra(DocumentCaptureActivity.EXTRA_DATE_OF_BIRTH_STATUS)),
                dateOfExpiry = statusOf(intent?.getStringExtra(DocumentCaptureActivity.EXTRA_DATE_OF_EXPIRY_STATUS)),
            ),
            failureReason = intent?.getStringExtra(DocumentCaptureActivity.EXTRA_FAILURE_REASON),
        )

    fun parse(payload: DocumentCapturePayload): DocumentCaptureBridgeResult {
        if (payload.resultCode == RESULT_CANCELED) {
            return DocumentCaptureBridgeResult(state = DocumentCaptureFlowState.CANCELLED)
        }
        if (payload.resultCode != RESULT_OK) {
            return DocumentCaptureBridgeResult(
                state = DocumentCaptureFlowState.ERROR,
                failureReason = payload.failureReason ?: "unexpected_activity_result",
            )
        }
        if (payload.requiredFieldsReady != true) {
            return DocumentCaptureBridgeResult(
                state = DocumentCaptureFlowState.BLOCKED,
                profile = payload.profile,
                readinessStatus = payload.readinessStatus,
                recommendedAction = payload.recommendedAction,
                fieldStatuses = payload.fieldStatuses,
                failureReason = payload.failureReason,
            )
        }

        val number = payload.documentNumber
        val birth = payload.birthYYMMDD
        val expiry = payload.expiryYYMMDD
        if (number.isNullOrBlank() || birth.isNullOrBlank() || expiry.isNullOrBlank()) {
            return DocumentCaptureBridgeResult(
                state = DocumentCaptureFlowState.ERROR,
                profile = payload.profile,
                readinessStatus = payload.readinessStatus,
                recommendedAction = payload.recommendedAction,
                fieldStatuses = payload.fieldStatuses,
                failureReason = "ready_result_missing_required_value",
            )
        }

        return DocumentCaptureBridgeResult(
            state = DocumentCaptureFlowState.READY,
            profile = payload.profile,
            document = DemoDocumentFields(
                documentNumber = number,
                birthYYMMDD = birth,
                expiryYYMMDD = expiry,
                fullNameRaw = payload.fullNameRaw,
                sex = payload.sex,
                nationality = payload.nationality,
            ),
            readinessStatus = payload.readinessStatus,
            recommendedAction = payload.recommendedAction,
            fieldStatuses = payload.fieldStatuses,
        )
    }

    private fun statusOf(value: String?): ParsedFieldStatus =
        value?.let { runCatching { ParsedFieldStatus.valueOf(it) }.getOrNull() }
            ?: ParsedFieldStatus.NOT_FOUND
}
