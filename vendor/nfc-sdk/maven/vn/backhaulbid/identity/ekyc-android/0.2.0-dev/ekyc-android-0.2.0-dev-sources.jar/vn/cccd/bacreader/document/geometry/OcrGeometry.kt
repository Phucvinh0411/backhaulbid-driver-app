package vn.cccd.bacreader.document.geometry

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import vn.cccd.bacreader.document.ocr.OcrBounds
import vn.cccd.bacreader.document.resolver.NormalizedRect

/** Pure geometry primitives shared by the hybrid OCR resolver and its tests. */
enum class GeometryRelation {
    SAME_LINE_RIGHT,
    NEAR_RIGHT,
    NEAR_BELOW,
}

object OcrGeometry {
    fun normalize(bounds: OcrBounds, imageWidth: Int, imageHeight: Int): NormalizedRect {
        val width = imageWidth.coerceAtLeast(1).toDouble()
        val height = imageHeight.coerceAtLeast(1).toDouble()
        val left = min(bounds.left, bounds.right).toDouble() / width
        val right = max(bounds.left, bounds.right).toDouble() / width
        val top = min(bounds.top, bounds.bottom).toDouble() / height
        val bottom = max(bounds.top, bounds.bottom).toDouble() / height
        return NormalizedRect(
            left = left.coerceIn(0.0, 1.0),
            top = top.coerceIn(0.0, 1.0),
            right = right.coerceIn(0.0, 1.0),
            bottom = bottom.coerceIn(0.0, 1.0),
        )
    }

    fun horizontalGap(first: OcrBounds, second: OcrBounds, imageWidth: Int): Double {
        return (second.left - first.right).coerceAtLeast(0).toDouble() / imageWidth.coerceAtLeast(1)
    }

    fun verticalGap(first: OcrBounds, second: OcrBounds, imageHeight: Int): Double {
        return (second.top - first.bottom).coerceAtLeast(0).toDouble() / imageHeight.coerceAtLeast(1)
    }

    fun baselineDelta(first: OcrBounds, second: OcrBounds, imageHeight: Int): Double {
        val firstCenter = (first.top + first.bottom) / 2.0
        val secondCenter = (second.top + second.bottom) / 2.0
        return abs(secondCenter - firstCenter) / imageHeight.coerceAtLeast(1)
    }

    fun relations(
        label: OcrBounds,
        value: OcrBounds,
        imageWidth: Int,
        imageHeight: Int,
    ): Set<GeometryRelation> {
        val width = imageWidth.coerceAtLeast(1).toDouble()
        val height = imageHeight.coerceAtLeast(1).toDouble()
        val yOverlap = min(label.bottom, value.bottom) - max(label.top, value.top)
        val sameBaseline = baselineDelta(label, value, imageHeight) <= 0.04
        val gap = horizontalGap(label, value, imageWidth)
        val result = linkedSetOf<GeometryRelation>()
        if (sameBaseline && yOverlap >= -0.03 * height && value.left >= label.right - 0.04 * width) {
            if (gap <= 0.08) result += GeometryRelation.SAME_LINE_RIGHT
            if (gap <= 0.20) result += GeometryRelation.NEAR_RIGHT
        }
        if (value.top >= label.bottom && verticalGap(label, value, imageHeight) <= 0.40) {
            result += GeometryRelation.NEAR_BELOW
        }
        return result
    }
}
