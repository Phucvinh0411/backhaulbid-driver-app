package vn.cccd.bacreader.biometric.recognition

import vn.cccd.bacreader.biometric.RgbImage

/** SFace contract: RGB, NCHW, float32, scale=1, mean=0 (raw 0..255). */
object SFacePreprocessor {
    const val INPUT_SIZE = 112
    const val EMBEDDING_DIMENSION = 128

    internal fun toNchwRgb(image: RgbImage): FloatArray {
        val result = FloatArray(3 * INPUT_SIZE * INPUT_SIZE)
        val plane = INPUT_SIZE * INPUT_SIZE
        for (y in 0 until INPUT_SIZE) {
            val sourceY = ((y + 0.5) * image.height / INPUT_SIZE - 0.5).toInt().coerceIn(0, image.height - 1)
            for (x in 0 until INPUT_SIZE) {
                val sourceX = ((x + 0.5) * image.width / INPUT_SIZE - 0.5).toInt().coerceIn(0, image.width - 1)
                val pixel = y * INPUT_SIZE + x
                result[pixel] = image.channelAt(sourceX, sourceY, 0).toFloat()
                result[plane + pixel] = image.channelAt(sourceX, sourceY, 1).toFloat()
                result[2 * plane + pixel] = image.channelAt(sourceX, sourceY, 2).toFloat()
            }
        }
        return result
    }
}
