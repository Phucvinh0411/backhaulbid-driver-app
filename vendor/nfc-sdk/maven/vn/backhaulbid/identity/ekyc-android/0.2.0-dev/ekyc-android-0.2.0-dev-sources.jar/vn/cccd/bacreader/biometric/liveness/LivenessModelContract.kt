package vn.cccd.bacreader.biometric.liveness

/**
 * Contract exported by the development MiniFAS baseline.
 *
 * The model is intentionally a debug-only evaluation artifact until its
 * provenance and licensing review is complete.
 */
data class LivenessModelContract(
    val modelId: String,
    val modelVersion: String,
    val upstreamCommit: String,
    val expectedSha256: String,
    val inputShape: LongArray,
    val outputShape: LongArray,
    val inputColorOrder: String,
    val normalization: String,
    val liveClassIndex: Int,
    val spoofClassIndex: Int,
    val threshold: Float,
    val status: String,
) {
    init {
        require(expectedSha256.matches(Regex("[0-9A-Fa-f]{64}")))
        require(inputShape.contentEquals(longArrayOf(1L, 3L, 128L, 128L)))
        require(outputShape.contentEquals(longArrayOf(1L, 2L)))
        require(liveClassIndex in 0 until outputShape.last().toInt())
        require(spoofClassIndex in 0 until outputShape.last().toInt())
        require(liveClassIndex != spoofClassIndex)
    }

    companion object {
        const val ASSET_PATH = "liveness/best_model.onnx"
        const val METADATA_ASSET_PATH = "liveness/best_model.metadata.json"
        const val MODEL_ID = "minifasnetv2se"
        const val MODEL_VERSION = "best-98.20"
        const val UPSTREAM_REPOSITORY = "https://github.com/minivision-ai/Silent-Face-Anti-Spoofing"
        const val UPSTREAM_COMMIT = "fa6489fb221dcf6b803095ab4b15a0fa0f56cfe5"
        const val EXPECTED_SHA256 = "AF2381B88F38769222ED93379E12444E2A50814575DE1C46170DE570C55A42B6"
        const val INPUT_COLOR_ORDER = "RGB"
        const val NORMALIZATION = "float32 / 255.0; no mean/std"
        const val LIVE_CLASS_INDEX = 0
        const val SPOOF_CLASS_INDEX = 1
        const val DEVELOPMENT_THRESHOLD = 0.0f
        const val DEVELOPMENT_STATUS = "DEVELOPMENT_EVALUATION_ONLY"

        val DEVELOPMENT = LivenessModelContract(
            modelId = MODEL_ID,
            modelVersion = MODEL_VERSION,
            upstreamCommit = UPSTREAM_COMMIT,
            expectedSha256 = EXPECTED_SHA256,
            inputShape = longArrayOf(1L, 3L, 128L, 128L),
            outputShape = longArrayOf(1L, 2L),
            inputColorOrder = INPUT_COLOR_ORDER,
            normalization = NORMALIZATION,
            liveClassIndex = LIVE_CLASS_INDEX,
            spoofClassIndex = SPOOF_CLASS_INDEX,
            threshold = DEVELOPMENT_THRESHOLD,
            status = DEVELOPMENT_STATUS,
        )
    }
}
