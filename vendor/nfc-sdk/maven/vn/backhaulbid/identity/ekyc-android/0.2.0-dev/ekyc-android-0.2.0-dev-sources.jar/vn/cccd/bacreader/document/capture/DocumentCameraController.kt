package vn.cccd.bacreader.document.capture

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import vn.cccd.bacreader.biometric.camera.CameraFrame
import vn.cccd.bacreader.document.quality.DocumentFrameMetrics
import vn.cccd.bacreader.document.quality.DocumentQualityConfig
import vn.cccd.bacreader.document.quality.DocumentRect

enum class DocumentCameraState {
    IDLE,
    STARTING,
    RUNNING,
    STOPPED,
    ERROR,
}

enum class DocumentCameraError {
    PERMISSION_REQUIRED,
    BACK_CAMERA_UNAVAILABLE,
    BIND_FAILED,
    ANALYSIS_FAILED,
    CONTROLLER_CLOSED,
}

sealed interface DocumentCameraStatus {
    data object Idle : DocumentCameraStatus
    data object Starting : DocumentCameraStatus
    data object Running : DocumentCameraStatus
    data object Stopped : DocumentCameraStatus
    data class Error(val error: DocumentCameraError) : DocumentCameraStatus
}

/** Owns the back-camera document mode and never binds the biometric front-camera use case. */
class DocumentCameraController(
    context: Context,
) : AutoCloseable {
    private val appContext = context.applicationContext
    private val mainExecutor = ContextCompat.getMainExecutor(appContext)
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val captureExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null
    private var imageCapture: ImageCapture? = null
    private var statusListener: ((DocumentCameraStatus) -> Unit)? = null
    private var closed = false

    var state: DocumentCameraState = DocumentCameraState.IDLE
        private set

    @OptIn(ExperimentalGetImage::class)
    fun start(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView,
        onFrame: (DocumentCameraFrame) -> Unit,
        onStatus: (DocumentCameraStatus) -> Unit = {},
    ) {
        statusListener = onStatus
        if (closed) {
            publish(DocumentCameraStatus.Error(DocumentCameraError.CONTROLLER_CLOSED))
            return
        }
        publish(DocumentCameraStatus.Starting)
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            publish(DocumentCameraStatus.Error(DocumentCameraError.PERMISSION_REQUIRED))
            return
        }
        val providerFuture = ProcessCameraProvider.getInstance(appContext)
        providerFuture.addListener({
            if (closed) return@addListener
            try {
                val cameraProvider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                val stillCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setJpegQuality(95)
                    .setTargetRotation(previewView.display?.rotation ?: android.view.Surface.ROTATION_0)
                    .build()
                imageAnalysis.setAnalyzer(analysisExecutor) { imageProxy ->
                    val frame = DocumentCameraFrame(imageProxy)
                    try {
                        onFrame(frame)
                    } catch (_: Exception) {
                        frame.close()
                        publish(DocumentCameraStatus.Error(DocumentCameraError.ANALYSIS_FAILED))
                    }
                }
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageAnalysis,
                    stillCapture,
                )
                provider = cameraProvider
                analysis = imageAnalysis
                imageCapture = stillCapture
                publish(DocumentCameraStatus.Running)
            } catch (_: IllegalArgumentException) {
                publish(DocumentCameraStatus.Error(DocumentCameraError.BACK_CAMERA_UNAVAILABLE))
            } catch (_: Exception) {
                publish(DocumentCameraStatus.Error(DocumentCameraError.BIND_FAILED))
            }
        }, mainExecutor)
    }

    fun stop() {
        analysis?.clearAnalyzer()
        analysis = null
        provider?.unbindAll()
        provider = null
        imageCapture = null
        if (!closed) publish(DocumentCameraStatus.Stopped)
    }

    override fun close() {
        if (closed) return
        closed = true
        analysis?.clearAnalyzer()
        analysis = null
        provider?.unbindAll()
        provider = null
        imageCapture = null
        analysisExecutor.shutdownNow()
        captureExecutor.shutdownNow()
        publish(DocumentCameraStatus.Stopped)
    }

    /** Takes one high-resolution in-memory still; it never falls back to ImageAnalysis. */
    fun captureStill(
        onSuccess: (DocumentStill) -> Unit,
        onError: (DocumentStillFailure) -> Unit,
    ) {
        val capture = imageCapture
        if (closed || capture == null) {
            onError(DocumentStillFailure.IMAGE_CAPTURE_UNAVAILABLE)
            return
        }
        val delivered = AtomicBoolean(false)
        try {
            capture.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val result = try {
                        DocumentStillDecoder.decode(image)
                    } catch (_: OutOfMemoryError) {
                        DocumentStillResult.Failure(
                            DocumentStillFailure.OUT_OF_MEMORY,
                            image.width,
                            image.height,
                            image.imageInfo.rotationDegrees,
                            image.format,
                        )
                    } finally {
                        image.close()
                    }
                    when (result) {
                        is DocumentStillResult.Success -> if (delivered.compareAndSet(false, true)) onSuccess(result.still) else result.still.close()
                        is DocumentStillResult.Failure -> if (delivered.compareAndSet(false, true)) onError(result.reason)
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    if (delivered.compareAndSet(false, true)) onError(DocumentStillFailure.DECODE_FAILED)
                }
            })
        } catch (_: RuntimeException) {
            if (delivered.compareAndSet(false, true)) onError(DocumentStillFailure.IMAGE_CAPTURE_UNAVAILABLE)
        }
    }

    private fun publish(status: DocumentCameraStatus) {
        state = when (status) {
            DocumentCameraStatus.Idle -> DocumentCameraState.IDLE
            DocumentCameraStatus.Starting -> DocumentCameraState.STARTING
            DocumentCameraStatus.Running -> DocumentCameraState.RUNNING
            DocumentCameraStatus.Stopped -> DocumentCameraState.STOPPED
            is DocumentCameraStatus.Error -> DocumentCameraState.ERROR
        }
        statusListener?.invoke(status)
    }
}

/** Frame wrapper with one-owner close semantics and inexpensive Y-plane metrics. */
@OptIn(ExperimentalGetImage::class)
class DocumentCameraFrame internal constructor(
    imageProxy: ImageProxy,
) : AutoCloseable {
    private val delegate = CameraFrame(imageProxy)

    val width: Int get() = delegate.width
    val height: Int get() = delegate.height
    val rotationDegrees: Int get() = delegate.rotationDegrees

    fun analyze(config: DocumentQualityConfig, stableGoodFrames: Int): DocumentFrameMetrics? {
        val image = delegate.mediaImage ?: return null
        if (image.planes.isEmpty() || width <= 0 || height <= 0) return null
        val yPlane = image.planes[0]
        val yBuffer = yPlane.buffer.duplicate()
        val uprightWidth = if (rotationDegrees == 90 || rotationDegrees == 270) height else width
        val uprightHeight = if (rotationDegrees == 90 || rotationDegrees == 270) width else height
        val guideWidth = config.guideWidthFraction
        val guideHeight = guideWidth / config.guideAspectRatio
        val guide = DocumentRect(
            left = (1.0 - guideWidth) / 2.0,
            top = (1.0 - guideHeight) / 2.0,
            right = (1.0 + guideWidth) / 2.0,
            bottom = (1.0 + guideHeight) / 2.0,
        )
        fun sample(x: Double, y: Double): Int? {
            val ux = (x.coerceIn(0.0, 0.999999) * uprightWidth).toInt()
            val uy = (y.coerceIn(0.0, 0.999999) * uprightHeight).toInt()
            val source = sourceCoordinate(ux, uy, width, height, rotationDegrees)
            val position = source.second * yPlane.rowStride + source.first * yPlane.pixelStride
            if (position < 0 || position >= yBuffer.limit()) return null
            return yBuffer.get(position).toInt() and 0xFF
        }
        val values = ArrayList<Int>(1_024)
        val grid = 24
        for (row in 0 until grid) {
            val y = guide.top + guide.height * (row + 0.5) / grid
            for (column in 0 until grid) {
                val x = guide.left + guide.width * (column + 0.5) / grid
                sample(x, y)?.let(values::add)
            }
        }
        if (values.isEmpty()) return null
        val mean = values.average()
        val glareRatio = values.count { it >= config.glareLuminanceThreshold }.toDouble() / values.size
        var gradientTotal = 0.0
        var gradientCount = 0
        for (row in 0 until grid - 1) {
            for (column in 0 until grid - 1) {
                val x = guide.left + guide.width * (column + 0.5) / grid
                val y = guide.top + guide.height * (row + 0.5) / grid
                val current = sample(x, y) ?: continue
                val right = sample(x + guide.width / grid, y) ?: continue
                val below = sample(x, y + guide.height / grid) ?: continue
                gradientTotal += kotlin.math.abs(current - right) + kotlin.math.abs(current - below)
                gradientCount += 2
            }
        }
        val blurScore = if (gradientCount == 0) 0.0 else gradientTotal / gradientCount
        val edgeContrast = boundaryContrast(::sample, guide)
        val documentBounds = if (edgeContrast >= config.edgeContrastThreshold) guide else null
        return DocumentFrameMetrics(
            frameWidth = uprightWidth,
            frameHeight = uprightHeight,
            documentBounds = documentBounds,
            guideBounds = guide,
            meanLuminance = mean,
            blurScore = blurScore,
            glareRatio = glareRatio,
            edgeContrast = edgeContrast,
        )
    }

    /** Copies RGB only for an accepted frame; quality analysis never allocates a full Bitmap. */
    fun copyBitmap(): Bitmap? {
        val rgb = delegate.copyRgb() ?: return null
        return try {
            val pixels = IntArray(rgb.width * rgb.height)
            var index = 0
            for (y in 0 until rgb.height) {
                for (x in 0 until rgb.width) {
                    pixels[index++] = Color.rgb(
                        rgb.channelAt(x, y, 0),
                        rgb.channelAt(x, y, 1),
                        rgb.channelAt(x, y, 2),
                    )
                }
            }
            Bitmap.createBitmap(pixels, rgb.width, rgb.height, Bitmap.Config.ARGB_8888)
        } finally {
            rgb.close()
        }
    }

    override fun close() = delegate.close()

    private fun sourceCoordinate(
        uprightX: Int,
        uprightY: Int,
        rawWidth: Int,
        rawHeight: Int,
        rotation: Int,
    ): Pair<Int, Int> = when (rotation) {
        0 -> uprightX to uprightY
        90 -> uprightY to (rawHeight - 1 - uprightX)
        180 -> (rawWidth - 1 - uprightX) to (rawHeight - 1 - uprightY)
        270 -> (rawWidth - 1 - uprightY) to uprightX
        else -> uprightX to uprightY
    }

    private fun boundaryContrast(
        sample: (Double, Double) -> Int?,
        guide: DocumentRect,
    ): Double {
        val contrasts = ArrayList<Double>(32)
        for (index in 1..8) {
            val along = index / 9.0
            val verticalInside = sample(guide.left + 0.025, guide.top + guide.height * along)
            val verticalOutside = sample(guide.left - 0.025, guide.top + guide.height * along)
            if (verticalInside != null && verticalOutside != null) contrasts += kotlin.math.abs(verticalInside - verticalOutside).toDouble()
            val horizontalInside = sample(guide.left + guide.width * along, guide.top + 0.025)
            val horizontalOutside = sample(guide.left + guide.width * along, guide.top - 0.025)
            if (horizontalInside != null && horizontalOutside != null) contrasts += kotlin.math.abs(horizontalInside - horizontalOutside).toDouble()
        }
        return contrasts.average().takeIf { it.isFinite() } ?: 0.0
    }
}
