package vn.cccd.bacreader.biometric.recognition

enum class RecognitionDecision { ACCEPT, LIVENESS_NOT_PASSED, STALE_FRAME }

class RecognitionSessionPolicy {
    private var currentSessionId: Long = Long.MIN_VALUE

    fun begin(sessionId: Long) { currentSessionId = sessionId }

    fun canMatch(sessionId: Long, livenessPassed: Boolean): Boolean =
        sessionId == currentSessionId && livenessPassed

    fun check(sessionId: Long, livenessPassed: Boolean): RecognitionDecision = when {
        sessionId != currentSessionId -> RecognitionDecision.STALE_FRAME
        !livenessPassed -> RecognitionDecision.LIVENESS_NOT_PASSED
        else -> RecognitionDecision.ACCEPT
    }
}
