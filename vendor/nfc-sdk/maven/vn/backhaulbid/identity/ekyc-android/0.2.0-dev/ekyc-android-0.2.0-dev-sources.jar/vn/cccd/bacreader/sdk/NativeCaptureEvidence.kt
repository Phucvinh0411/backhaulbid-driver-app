package vn.cccd.bacreader.sdk

import android.graphics.Bitmap
import vn.cccd.bacreader.biometric.RgbImage
import vn.cccd.bacreader.biometric.camera.BiometricSessionHandle
import java.io.ByteArrayOutputStream

internal class NativeCaptureEvidence : AutoCloseable {
    val photos = CapturePhotoEvidence()
    var chip: BiometricSessionHandle? = null
    override fun close() {
        val previous = chip; chip = null
        try { previous?.close() } finally { photos.close() }
    }
}

/** Encodes an upright still in bounded native memory; never writes gallery/cache files. */
internal object CapturePhotoEncoder {
    fun encode(bitmap: Bitmap): ByteArray? = runCatching {
        check(!bitmap.isRecycled)
        val scale = minOf(1f, 1280f / maxOf(bitmap.width, bitmap.height))
        val smaller = if (scale < 1f) Bitmap.createScaledBitmap(bitmap,
            (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1), true) else bitmap
        try {
            WipingBuffer().use { stream ->
                check(smaller.compress(Bitmap.CompressFormat.JPEG, 88, stream))
                stream.toByteArray().takeIf { it.isNotEmpty() }
            }
        } finally { if (smaller !== bitmap) smaller.recycle() }
    }.getOrNull()

    fun encode(image: RgbImage): ByteArray? = runCatching {
        require(image.width.toLong() * image.height in 1..3_000_000L)
        val argb = IntArray(image.width * image.height)
        var bitmap: Bitmap? = null
        try {
            for (y in 0 until image.height) for (x in 0 until image.width) {
                argb[y * image.width + x] = (0xFF shl 24) or (image.channelAt(x, y, 0) shl 16) or
                    (image.channelAt(x, y, 1) shl 8) or image.channelAt(x, y, 2)
            }
            bitmap = Bitmap.createBitmap(argb, image.width, image.height, Bitmap.Config.ARGB_8888)
            encode(bitmap)
        } finally { argb.fill(0); bitmap?.recycle() }
    }.getOrNull()

    private class WipingBuffer : ByteArrayOutputStream() {
        override fun write(b: ByteArray, off: Int, len: Int) {
            require(len <= CapturePhotoEvidence.MAXIMUM_BYTES - count) { "Photo size exceeded" }
            super.write(b, off, len)
        }
        override fun write(b: Int) {
            require(count < CapturePhotoEvidence.MAXIMUM_BYTES) { "Photo size exceeded" }
            super.write(b)
        }
        override fun close() { buf.fill(0); reset() }
    }
}
