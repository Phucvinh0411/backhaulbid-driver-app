package vn.cccd.bacreader.biometric.detection

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.atomic.AtomicBoolean
import vn.cccd.bacreader.biometric.camera.CameraFrame
import vn.cccd.bacreader.biometric.camera.ImageRotation
import vn.cccd.bacreader.biometric.recognition.FaceLandmarks
import vn.cccd.bacreader.biometric.recognition.FacePoint

/** Bundled ML Kit face detector; no image bytes leave the camera analysis callback. */
class MlKitFaceDetector : FaceDetector {
    private val closed = AtomicBoolean(false)
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .enableTracking()
            .build(),
    )

    override fun process(frame: CameraFrame, onResult: (FaceDetectionResult) -> Unit) {
        if (closed.get()) {
            frame.close()
            onResult(FaceDetectionResult.Failure(FaceDetectionFailure.DETECTOR_CLOSED))
            return
        }
        val mediaImage = frame.mediaImage
        if (mediaImage == null) {
            frame.close()
            onResult(FaceDetectionResult.Failure(FaceDetectionFailure.NO_MEDIA_IMAGE))
            return
        }

        detector.process(InputImage.fromMediaImage(mediaImage, frame.rotationDegrees))
            .addOnSuccessListener { faces ->
                onResult(
                    FaceDetectionResult.Success(
                        faces = faces.map(::mapFace),
                        frameWidth = ImageRotation.uprightWidth(
                            frame.width,
                            frame.height,
                            frame.rotationDegrees,
                        ),
                        frameHeight = ImageRotation.uprightHeight(
                            frame.width,
                            frame.height,
                            frame.rotationDegrees,
                        ),
                    ),
                )
            }
            .addOnFailureListener {
                onResult(FaceDetectionResult.Failure(FaceDetectionFailure.PROCESSING_FAILED))
            }
            .addOnCompleteListener { frame.close() }
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) detector.close()
    }

    private fun mapFace(face: Face): DetectedFace = DetectedFace(
        bounds = FaceBounds(
            left = face.boundingBox.left,
            top = face.boundingBox.top,
            right = face.boundingBox.right,
            bottom = face.boundingBox.bottom,
        ),
        trackingId = face.trackingId,
        headEulerAngleX = face.headEulerAngleX,
            headEulerAngleY = face.headEulerAngleY,
            headEulerAngleZ = face.headEulerAngleZ,
            landmarks = mapLandmarks(face),
            leftEyeOpenProbability = face.leftEyeOpenProbability,
            rightEyeOpenProbability = face.rightEyeOpenProbability,
        )

    private fun mapLandmarks(face: Face): FaceLandmarks? {
        val leftEye = face.getLandmark(com.google.mlkit.vision.face.FaceLandmark.LEFT_EYE)?.position
        val rightEye = face.getLandmark(com.google.mlkit.vision.face.FaceLandmark.RIGHT_EYE)?.position
        val nose = face.getLandmark(com.google.mlkit.vision.face.FaceLandmark.NOSE_BASE)?.position
        val mouthLeft = face.getLandmark(com.google.mlkit.vision.face.FaceLandmark.MOUTH_LEFT)?.position
        val mouthRight = face.getLandmark(com.google.mlkit.vision.face.FaceLandmark.MOUTH_RIGHT)?.position
        return if (leftEye != null && rightEye != null && nose != null && mouthLeft != null && mouthRight != null) {
            FaceLandmarks(
                FacePoint(leftEye.x, leftEye.y), FacePoint(rightEye.x, rightEye.y),
                FacePoint(nose.x, nose.y), FacePoint(mouthLeft.x, mouthLeft.y), FacePoint(mouthRight.x, mouthRight.y),
            )
        } else null
    }
}
