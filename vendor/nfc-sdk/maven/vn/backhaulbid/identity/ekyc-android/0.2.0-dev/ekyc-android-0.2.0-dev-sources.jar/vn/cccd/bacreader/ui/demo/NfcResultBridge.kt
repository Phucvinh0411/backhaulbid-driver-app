package vn.cccd.bacreader.ui.demo

import android.content.Intent
import vn.cccd.bacreader.document.crosscheck.ChipDocumentCrossCheckResult
import vn.cccd.bacreader.document.crosscheck.ChipIdentityData
import vn.cccd.bacreader.document.crosscheck.CrossCheckStatus
import vn.cccd.bacreader.document.crosscheck.NfcDocumentResult
import vn.cccd.bacreader.document.crosscheck.NfcOverallStatus
import vn.cccd.bacreader.document.crosscheck.NfcReadSummary
import vn.cccd.bacreader.document.crosscheck.NfcSessionSummary
import vn.cccd.bacreader.document.mrz.MrzStatus
import vn.cccd.bacreader.domain.AuthenticityResult
import vn.cccd.bacreader.domain.FileReadStatus
import vn.cccd.bacreader.domain.IntegrityStatus
import vn.cccd.bacreader.domain.IssuerTrustStatus
import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.domain.ScanStep
import vn.cccd.bacreader.domain.SignatureStatus
import vn.cccd.bacreader.domain.SodReadStatus

/** Parses the lightweight NFC result extras returned by MainActivity. */
object NfcResultBridge {
    fun fromIntent(data: Intent?): NfcDocumentResult? {
        val intent = data ?: return null
        if (!intent.hasExtra(vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_OVERALL_STATUS)) {
            return null // A boolean is not a structured NFC result.
        }
        return NfcDocumentResult(
            overallStatus = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_OVERALL_STATUS, NfcOverallStatus.FAILURE),
            session = NfcSessionSummary(
                tagDetected = intent.getBooleanExtra(vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_TAG_DETECTED, false),
                bacEstablished = intent.getBooleanExtra(vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_BAC_ESTABLISHED, false),
                secureMessagingEstablished = intent.getBooleanExtra(vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_SM_ESTABLISHED, false),
            ),
            reads = NfcReadSummary(
                dg1 = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_DG1_STATUS, FileReadStatus.NOT_ATTEMPTED),
                dg2 = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_DG2_STATUS, FileReadStatus.NOT_ATTEMPTED),
                sod = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_SOD_STATUS, FileReadStatus.NOT_ATTEMPTED),
            ),
            mrzStatus = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_MRZ_STATUS, MrzStatus.MRZ_NOT_FOUND),
            chipIdentity = chipIdentity(intent),
            crossCheck = ChipDocumentCrossCheckResult(
                documentNumber = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_CROSS_NUMBER, CrossCheckStatus.NOT_AVAILABLE),
                dateOfBirth = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_CROSS_BIRTH, CrossCheckStatus.NOT_AVAILABLE),
                dateOfExpiry = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_CROSS_EXPIRY, CrossCheckStatus.NOT_AVAILABLE),
                mrzStatus = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_MRZ_STATUS, MrzStatus.MRZ_NOT_FOUND),
            ),
            authenticity = AuthenticityResult(
                sodStatus = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_SOD_READ_STATUS, SodReadStatus.EF_SOD_NOT_ATTEMPTED),
                integrityStatus = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_INTEGRITY_STATUS, IntegrityStatus.NOT_ATTEMPTED),
                signatureStatus = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_SIGNATURE_STATUS, SignatureStatus.NOT_VERIFIED),
                issuerTrustStatus = enumExtra(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_TRUST_STATUS, IssuerTrustStatus.TRUST_NOT_ESTABLISHED),
            ),
            failureStage = enumExtraOrNull<ScanStep>(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_FAILURE_STAGE),
            failureReason = enumExtraOrNull<ReaderError>(intent, vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_FAILURE_REASON),
        )
    }

    private fun chipIdentity(intent: Intent): ChipIdentityData? {
        val documentNumber = intent.getStringExtra(vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_CHIP_DOCUMENT_NUMBER)
        val fullName = intent.getStringExtra(vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_CHIP_FULL_NAME)
        val birth = intent.getStringExtra(vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_CHIP_BIRTH)
        val sex = intent.getStringExtra(vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_CHIP_SEX)
        val nationality = intent.getStringExtra(vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_CHIP_NATIONALITY)
        val expiry = intent.getStringExtra(vn.cccd.bacreader.ui.MainActivity.EXTRA_DEMO_NFC_CHIP_EXPIRY)
        return if (listOf(documentNumber, fullName, birth, sex, nationality, expiry).all { it == null }) {
            null
        } else {
            ChipIdentityData(documentNumber, fullName, birth, sex, nationality, expiry)
        }
    }

    private inline fun <reified T : Enum<T>> enumExtra(intent: Intent, key: String, default: T): T =
        intent.getStringExtra(key)?.let { runCatching { enumValueOf<T>(it) }.getOrNull() } ?: default

    private inline fun <reified T : Enum<T>> enumExtraOrNull(intent: Intent, key: String): T? =
        intent.getStringExtra(key)?.let { runCatching { enumValueOf<T>(it) }.getOrNull() }
}
