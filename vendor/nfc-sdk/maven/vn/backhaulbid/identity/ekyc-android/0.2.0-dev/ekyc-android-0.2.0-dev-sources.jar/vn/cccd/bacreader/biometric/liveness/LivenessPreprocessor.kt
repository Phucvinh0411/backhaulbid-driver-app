package vn.cccd.bacreader.biometric.liveness

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin
import vn.cccd.bacreader.biometric.RgbImage
import vn.cccd.bacreader.biometric.detection.FaceBounds

internal data class LivenessCropRect(
    val left: Int,
    val top: Int,
    val size: Int,
)

internal class LivenessInput(
    val values: FloatArray,
    val crop: LivenessCropRect,
) : AutoCloseable {
    override fun close() {
        values.fill(0f)
    }
}

/** Kotlin implementation of the training repository's crop and letterbox pipeline. */
class LivenessPreprocessor(
    private val config: LivenessConfig = LivenessConfig(),
) {
    internal fun preprocess(image: RgbImage, face: FaceBounds): LivenessInput {
        val cropRect = calculateCropRect(image.width, image.height, face, config.cropExpansionFactor)
        val cropped = cropSquare(image, face)
        return try {
            LivenessInput(preprocessRgb(cropped), cropRect)
        } finally {
            cropped.close()
        }
    }

    internal fun calculateCropRect(
        imageWidth: Int,
        imageHeight: Int,
        face: FaceBounds,
        expansionFactor: Double = config.cropExpansionFactor,
    ): LivenessCropRect {
        require(imageWidth > 0 && imageHeight > 0)
        require(face.width > 0 && face.height > 0)
        require(expansionFactor > 0.0)
        val maxDimension = max(face.width, face.height)
        val cropSize = (maxDimension * expansionFactor).toInt().coerceAtLeast(1)
        val centerX = face.left + face.width / 2.0
        val centerY = face.top + face.height / 2.0
        return LivenessCropRect(
            left = (centerX - maxDimension * expansionFactor / 2.0).toInt(),
            top = (centerY - maxDimension * expansionFactor / 2.0).toInt(),
            size = cropSize,
        )
    }

    internal fun cropSquare(image: RgbImage, face: FaceBounds): RgbImage {
        require(face.width > 0 && face.height > 0)
        val maxDimension = max(face.width, face.height)
        val cropSize = (maxDimension * config.cropExpansionFactor).toInt().coerceAtLeast(1)
        val centerX = face.left + face.width / 2.0
        val centerY = face.top + face.height / 2.0
        val left = (centerX - maxDimension * config.cropExpansionFactor / 2.0).toInt()
        val top = (centerY - maxDimension * config.cropExpansionFactor / 2.0).toInt()
        val pixels = ByteArray(cropSize * cropSize * RgbImage.CHANNELS)
        for (y in 0 until cropSize) {
            for (x in 0 until cropSize) {
                val sourceX = reflect101(left + x, image.width)
                val sourceY = reflect101(top + y, image.height)
                val sourceOffset = (sourceY * image.width + sourceX) * RgbImage.CHANNELS
                val targetOffset = (y * cropSize + x) * RgbImage.CHANNELS
                pixels[targetOffset] = image.pixels[sourceOffset]
                pixels[targetOffset + 1] = image.pixels[sourceOffset + 1]
                pixels[targetOffset + 2] = image.pixels[sourceOffset + 2]
            }
        }
        return RgbImage(cropSize, cropSize, pixels)
    }

    /** Exposed to JVM tests as the parity boundary; production calls this after square crop. */
    internal fun preprocessRgb(image: RgbImage): FloatArray {
        val resized = resize(image, config.inputSize, config.inputSize)
        return try {
            val values = FloatArray(3 * config.inputSize * config.inputSize)
            val planeSize = config.inputSize * config.inputSize
            for (y in 0 until config.inputSize) {
                for (x in 0 until config.inputSize) {
                    val sourceOffset = (y * config.inputSize + x) * RgbImage.CHANNELS
                    val pixelOffset = y * config.inputSize + x
                    values[pixelOffset] = (resized.pixels[sourceOffset].toInt() and 0xFF) / 255.0f
                    values[planeSize + pixelOffset] = (resized.pixels[sourceOffset + 1].toInt() and 0xFF) / 255.0f
                    values[2 * planeSize + pixelOffset] = (resized.pixels[sourceOffset + 2].toInt() and 0xFF) / 255.0f
                }
            }
            values
        } finally {
            resized.close()
        }
    }

    private fun resize(image: RgbImage, destinationWidth: Int, destinationHeight: Int): RgbImage {
        val ratio = destinationWidth.toDouble() / max(image.width, image.height).toDouble()
        val scaledWidth = (image.width * ratio).toInt().coerceAtLeast(1)
        val scaledHeight = (image.height * ratio).toInt().coerceAtLeast(1)
        val scaled = if (ratio > 1.0) {
            resizeLanczos(image, scaledWidth, scaledHeight)
        } else {
            resizeArea(image, scaledWidth, scaledHeight)
        }
        if (scaled.width == destinationWidth && scaled.height == destinationHeight) return scaled

        val pixels = ByteArray(destinationWidth * destinationHeight * RgbImage.CHANNELS)
        val left = (destinationWidth - scaled.width) / 2
        val top = (destinationHeight - scaled.height) / 2
        for (y in 0 until destinationHeight) {
            for (x in 0 until destinationWidth) {
                val sourceX = reflect101(x - left, scaled.width)
                val sourceY = reflect101(y - top, scaled.height)
                val sourceOffset = (sourceY * scaled.width + sourceX) * RgbImage.CHANNELS
                val targetOffset = (y * destinationWidth + x) * RgbImage.CHANNELS
                pixels[targetOffset] = scaled.pixels[sourceOffset]
                pixels[targetOffset + 1] = scaled.pixels[sourceOffset + 1]
                pixels[targetOffset + 2] = scaled.pixels[sourceOffset + 2]
            }
        }
        scaled.close()
        return RgbImage(destinationWidth, destinationHeight, pixels)
    }

    private fun resizeArea(image: RgbImage, destinationWidth: Int, destinationHeight: Int): RgbImage {
        val pixels = ByteArray(destinationWidth * destinationHeight * RgbImage.CHANNELS)
        for (dy in 0 until destinationHeight) {
            val yStart = dy * image.height.toDouble() / destinationHeight
            val yEnd = (dy + 1) * image.height.toDouble() / destinationHeight
            for (dx in 0 until destinationWidth) {
                val xStart = dx * image.width.toDouble() / destinationWidth
                val xEnd = (dx + 1) * image.width.toDouble() / destinationWidth
                val sums = DoubleArray(RgbImage.CHANNELS)
                var totalWeight = 0.0
                for (sy in floor(yStart).toInt() until ceil(yEnd).toInt()) {
                    val yWeight = (minOf(yEnd, sy + 1.0) - maxOf(yStart, sy.toDouble())).coerceAtLeast(0.0)
                    if (yWeight == 0.0) continue
                    for (sx in floor(xStart).toInt() until ceil(xEnd).toInt()) {
                        val xWeight = (minOf(xEnd, sx + 1.0) - maxOf(xStart, sx.toDouble())).coerceAtLeast(0.0)
                        val weight = xWeight * yWeight
                        if (weight == 0.0) continue
                        val sourceOffset = (sy * image.width + sx) * RgbImage.CHANNELS
                        for (channel in 0 until RgbImage.CHANNELS) {
                            sums[channel] += (image.pixels[sourceOffset + channel].toInt() and 0xFF) * weight
                        }
                        totalWeight += weight
                    }
                }
                val targetOffset = (dy * destinationWidth + dx) * RgbImage.CHANNELS
                for (channel in 0 until RgbImage.CHANNELS) {
                    pixels[targetOffset + channel] = (sums[channel] / totalWeight).toInt().coerceIn(0, 255).toByte()
                }
            }
        }
        return RgbImage(destinationWidth, destinationHeight, pixels)
    }

    private fun resizeLanczos(image: RgbImage, destinationWidth: Int, destinationHeight: Int): RgbImage {
        val pixels = ByteArray(destinationWidth * destinationHeight * RgbImage.CHANNELS)
        for (dy in 0 until destinationHeight) {
            val sourceY = (dy + 0.5) * image.height / destinationHeight - 0.5
            val baseY = floor(sourceY).toInt()
            for (dx in 0 until destinationWidth) {
                val sourceX = (dx + 0.5) * image.width / destinationWidth - 0.5
                val baseX = floor(sourceX).toInt()
                val sums = DoubleArray(RgbImage.CHANNELS)
                var totalWeight = 0.0
                for (tapY in -3..4) {
                    val weightY = lanczos(sourceY - (baseY + tapY))
                    if (weightY == 0.0) continue
                    for (tapX in -3..4) {
                        val weight = weightY * lanczos(sourceX - (baseX + tapX))
                        if (weight == 0.0) continue
                        val sampleX = (baseX + tapX).coerceIn(0, image.width - 1)
                        val sampleY = (baseY + tapY).coerceIn(0, image.height - 1)
                        val sourceOffset = (sampleY * image.width + sampleX) * RgbImage.CHANNELS
                        for (channel in 0 until RgbImage.CHANNELS) {
                            sums[channel] += (image.pixels[sourceOffset + channel].toInt() and 0xFF) * weight
                        }
                        totalWeight += weight
                    }
                }
                val targetOffset = (dy * destinationWidth + dx) * RgbImage.CHANNELS
                for (channel in 0 until RgbImage.CHANNELS) {
                    pixels[targetOffset + channel] = (sums[channel] / totalWeight).toInt().coerceIn(0, 255).toByte()
                }
            }
        }
        return RgbImage(destinationWidth, destinationHeight, pixels)
    }

    private fun lanczos(value: Double): Double {
        val distance = abs(value)
        if (distance < 1e-9) return 1.0
        if (distance >= 4.0) return 0.0
        return 4.0 * sin(PI * value) * sin(PI * value / 4.0) / (PI * PI * value * value)
    }

    private fun reflect101(index: Int, size: Int): Int {
        if (size <= 1) return 0
        var result = index
        while (result < 0 || result >= size) {
            result = if (result < 0) -result else 2 * size - 2 - result
        }
        return result
    }
}
