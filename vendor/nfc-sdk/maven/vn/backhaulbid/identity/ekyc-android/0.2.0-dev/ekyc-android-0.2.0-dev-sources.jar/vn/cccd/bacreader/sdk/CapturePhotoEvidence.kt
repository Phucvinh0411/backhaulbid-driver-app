package vn.cccd.bacreader.sdk

import java.io.OutputStream

enum class CapturePhotoPart { DOCUMENT_FRONT, DOCUMENT_BACK, SELFIE }

/** Owns at most three 4 MiB encoded photos; no disk, Parcelable or raw-array API. */
internal class CapturePhotoEvidence : AutoCloseable {
    private val parts = mutableMapOf<CapturePhotoPart, ByteArray>()
    private var closed = false
    val isComplete: Boolean
        @Synchronized get() = !closed && CapturePhotoPart.entries.all { parts.containsKey(it) }

    @Synchronized fun capture(part: CapturePhotoPart, bytes: ByteArray) {
        check(!closed) { "Photo proof closed" }
        require(bytes.isNotEmpty() && bytes.size <= MAXIMUM_BYTES) { "Photo size exceeded" }
        parts.remove(part)?.fill(0)
        parts[part] = bytes.copyOf()
    }

    @Synchronized fun writeTo(part: CapturePhotoPart, output: OutputStream) {
        check(!closed) { "Photo proof closed" }
        output.write(parts[part] ?: throw IllegalStateException("Photo proof unavailable"))
    }

    @Synchronized fun reset() {
        check(!closed) { "Photo proof closed" }
        parts.values.forEach { it.fill(0) }
        parts.clear()
    }

    @Synchronized override fun close() {
        if (closed) return
        reset()
        closed = true
    }

    companion object { const val MAXIMUM_BYTES = 4 * 1024 * 1024 }
}
