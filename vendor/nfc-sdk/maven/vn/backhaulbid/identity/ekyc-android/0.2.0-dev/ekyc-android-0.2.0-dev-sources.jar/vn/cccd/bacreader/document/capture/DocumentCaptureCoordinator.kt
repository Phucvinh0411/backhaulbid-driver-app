package vn.cccd.bacreader.document.capture

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import vn.cccd.bacreader.document.ocr.DocumentOcrSession
import vn.cccd.bacreader.document.ocr.DocumentTextRecognitionCallback
import vn.cccd.bacreader.document.ocr.DocumentTextRecognitionResult
import vn.cccd.bacreader.document.ocr.DocumentTextRecognitionStatus
import vn.cccd.bacreader.document.ocr.MlKitDocumentTextRecognizer
import vn.cccd.bacreader.document.ocr.OcrAttemptToken
import vn.cccd.bacreader.document.ocr.OcrSnapshot
import vn.cccd.bacreader.document.ocr.OcrSnapshotMerger
import vn.cccd.bacreader.document.ocr.OcrSourceKind
import vn.cccd.bacreader.document.ocr.OcrInputMetadata
import vn.cccd.bacreader.document.ocr.withSource
import vn.cccd.bacreader.document.ocr.roi.RoiRetryKey
import vn.cccd.bacreader.document.ocr.roi.TargetedRoiRequest
import vn.cccd.bacreader.document.ocr.roi.TargetedRoiRetryPlanner
import vn.cccd.bacreader.document.ocr.processing.DocumentOcrProcessor
import vn.cccd.bacreader.document.readiness.DocumentCaptureReadiness
import vn.cccd.bacreader.document.quality.DocumentFrameMetrics
import vn.cccd.bacreader.document.quality.DocumentQualityConfig
import vn.cccd.bacreader.document.quality.DocumentQualityEvaluator
import vn.cccd.bacreader.document.quality.DocumentQualityStatus
import vn.cccd.bacreader.document.quality.DocumentRect
import vn.cccd.bacreader.document.resolver.DocumentField
import vn.cccd.bacreader.document.resolver.NormalizedRect
import vn.cccd.bacreader.document.resolver.VisualDocumentResolution

/**
 * Coordinates the existing document engine for the production Compose host.
 * It owns only the active in-memory capture session; no state is persisted or
 * transported through navigation.
 */
class DocumentCaptureCoordinator(
    context: Context,
    private val onComplete: (ProductionDocumentCompletion) -> Unit,
    private val onPhotoEvidence: (DocumentSide, Bitmap) -> Unit = { _, _ -> },
) : AutoCloseable {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val qualityConfig = DocumentQualityConfig()
    private val qualityEvaluator = DocumentQualityEvaluator(qualityConfig)
    private val captureSession = DocumentCaptureSession(
        DocumentCaptureConfig(qualityConfig.stableGoodFrames, mode = DocumentCaptureMode.MANUAL),
    )
    private val ocrSession = DocumentOcrSession()
    private val textRecognizer = MlKitDocumentTextRecognizer()
    private val cameraController = DocumentCameraController(appContext)
    private val cropExecutor = Executors.newSingleThreadExecutor()
    /** Keeps large bitmap copies and resolver/readiness work off the main thread. */
    private val ocrExecutor = Executors.newSingleThreadExecutor()
    private val ocrProcessor = DocumentOcrProcessor()
    private val ocrBitmaps = ConcurrentHashMap<OcrAttemptToken, Bitmap>()
    private val roiBitmaps = ConcurrentHashMap<RoiRetryKey, Bitmap>()
    private val roiSnapshots = linkedMapOf<RoiRetryKey, RoiSnapshotRecord>()
    private val roiAttempts = linkedSetOf<RoiRetryKey>()
    private val roiPlanner = TargetedRoiRetryPlanner()
    private val stateLock = Any()
    private val closed = AtomicBoolean(false)
    private val completionDelivered = AtomicBoolean(false)
    private val processingInFlight = AtomicBoolean(false)
    private val ocrGeneration = AtomicLong(0L)

    private val mutableState = MutableStateFlow(
        ProductionDocumentUiState(requiredStableGoodFrames = qualityConfig.stableGoodFrames),
    )
    val state: StateFlow<ProductionDocumentUiState> = mutableState.asStateFlow()

    private var lifecycleOwner: LifecycleOwner? = null
    private var previewView: PreviewView? = null
    private var frontBitmap: Bitmap? = null
    private var backBitmap: Bitmap? = null
    private var pendingStill: DocumentStill? = null
    private var pendingSide: DocumentSide? = null
    private var frontOcrComplete = false
    private var backOcrComplete = false
    private var roiInFlightKey: RoiRetryKey? = null
    private var analyzerFrameCount = 0L

    fun startCamera(owner: LifecycleOwner, preview: PreviewView) {
        if (closed.get() || state.value.stage != ProductionDocumentStage.CAPTURE) return
        lifecycleOwner = owner
        previewView = preview
        if (cameraController.state == DocumentCameraState.RUNNING ||
            cameraController.state == DocumentCameraState.STARTING
        ) return
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            publish { it.copy(cameraStatus = DocumentCameraStatus.Error(DocumentCameraError.PERMISSION_REQUIRED)) }
            return
        }
        cameraController.start(
            lifecycleOwner = owner,
            previewView = preview,
            onFrame = ::onFrame,
            onStatus = { status -> publish { it.copy(cameraStatus = status) } },
        )
    }

    fun stopCamera() {
        if (!closed.get()) cameraController.stop()
    }

    fun capture() {
        if (closed.get()) return
        val current = state.value
        if (!current.canCapture) return
        val decision = synchronized(stateLock) {
            captureSession.requestCapture(current.quality)
        }
        if (!decision.shouldCapture) return
        publish {
            it.copy(
                captureState = decision.state,
                captureInFlight = true,
                message = null,
                error = null,
            )
        }
        cameraController.captureStill(
            onSuccess = { still -> mainHandler.post { onStillCaptured(decision.side, still) } },
            onError = { error -> mainHandler.post { onStillCaptureFailed(error) } },
        )
    }

    fun confirmCrop(quad: CropQuad): Boolean {
        val still = pendingStill ?: return false
        val side = pendingSide ?: return false
        if (!CropGeometry.isValid(quad, still.uprightWidth, still.uprightHeight)) {
            publish { it.copy(message = "Điều chỉnh đủ bốn góc quanh toàn bộ thẻ.", error = DocumentCaptureUiError.CROP_FAILED) }
            return false
        }
        synchronized(stateLock) { captureSession.onCropProcessing() }
        publish {
            it.copy(
                stage = ProductionDocumentStage.PROCESSING,
                captureState = captureSession.snapshot().state,
                captureInFlight = true,
                message = "Đang xử lý ảnh…",
                error = null,
            )
        }
        cropExecutor.execute {
            val cropped = DocumentPerspectiveCropper.crop(still.bitmap, quad)
            mainHandler.post { onCropFinished(side, still, cropped) }
        }
        return true
    }

    fun retakeCrop() {
        val side = pendingSide ?: return
        pendingStill?.close()
        pendingStill = null
        pendingSide = null
        synchronized(stateLock) { captureSession.retry(side) }
        publish {
            it.copy(
                stage = ProductionDocumentStage.CAPTURE,
                side = side,
                captureState = captureSession.snapshot().state,
                quality = DocumentQualityStatus.NO_DOCUMENT,
                stableGoodFrames = 0,
                captureInFlight = false,
                cropBitmap = null,
                message = null,
                error = null,
            )
        }
        startCameraIfPossible()
    }

    fun cancel() {
        if (closed.get()) return
        ocrGeneration.incrementAndGet()
        processingInFlight.set(false)
        ocrSession.newSession()
        pendingStill?.close()
        pendingStill = null
        pendingSide = null
        clearBitmaps()
        synchronized(stateLock) { captureSession.reset() }
        publish { it.copy(stage = ProductionDocumentStage.CANCELLED, cropBitmap = null, captureInFlight = false) }
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        ocrGeneration.incrementAndGet()
        pendingStill?.close()
        pendingStill = null
        pendingSide = null
        cameraController.close()
        textRecognizer.close()
        ocrSession.close()
        ocrBitmaps.values.forEach(::releaseBitmap)
        ocrBitmaps.clear()
        roiBitmaps.values.forEach(::releaseBitmap)
        roiBitmaps.clear()
        roiSnapshots.clear()
        roiAttempts.clear()
        clearBitmaps()
        cropExecutor.shutdownNow()
        ocrExecutor.shutdownNow()
        mainHandler.removeCallbacksAndMessages(null)
    }

    private fun onFrame(frame: DocumentCameraFrame) {
        try {
            analyzerFrameCount++
            val snapshot = synchronized(stateLock) { captureSession.snapshot() }
            val metrics = frame.analyze(qualityConfig, snapshot.goodFrameCount)
            val safeMetrics = metrics ?: noDocumentMetrics(frame.width, frame.height)
            // The first evaluation must intentionally use the configured stability
            // requirement, just like the legacy working host. This evaluates the
            // physical frame (geometry/light/sharpness/glare) without letting the
            // stability predicate prevent the session from accumulating good frames.
            // Passing snapshot.goodFrameCount here would always yield UNSTABLE,
            // reset the session counter, and leave the production button disabled.
            val baseQuality = qualityEvaluator.evaluate(
                safeMetrics,
                stableGoodFrames = qualityConfig.stableGoodFrames,
            )
            val decision = synchronized(stateLock) { captureSession.onQuality(baseQuality.status) }
            val quality = if (baseQuality.status == DocumentQualityStatus.GOOD) {
                qualityEvaluator.evaluate(safeMetrics, decision.goodFrameCount)
            } else {
                baseQuality.copy(stableGoodFrames = decision.goodFrameCount)
            }
            publish {
                it.copy(
                    side = decision.side,
                    captureState = decision.state,
                    quality = quality.status,
                    stableGoodFrames = decision.goodFrameCount,
                    cameraStatus = DocumentCameraStatus.Running,
                    analyzerFrameCount = analyzerFrameCount,
                    analysisWidth = frame.width,
                    analysisHeight = frame.height,
                    analysisRotationDegrees = frame.rotationDegrees,
                )
            }
        } finally {
            frame.close()
        }
    }

    private fun onStillCaptured(side: DocumentSide, still: DocumentStill) {
        if (closed.get()) {
            still.close()
            return
        }
        cameraController.stop()
        pendingStill?.close()
        pendingStill = still
        pendingSide = side
        synchronized(stateLock) { captureSession.onStillCaptured() }
        publish {
            it.copy(
                stage = ProductionDocumentStage.CROP,
                side = side,
                captureState = captureSession.snapshot().state,
                captureInFlight = false,
                cropBitmap = still.bitmap,
                message = null,
                error = null,
            )
        }
    }

    private fun onStillCaptureFailed(error: DocumentStillFailure) {
        if (closed.get()) return
        synchronized(stateLock) { captureSession.onCaptureCompleted(false) }
        publish {
            it.copy(
                stage = ProductionDocumentStage.CAPTURE,
                captureState = captureSession.snapshot().state,
                quality = DocumentQualityStatus.NO_DOCUMENT,
                stableGoodFrames = 0,
                captureInFlight = false,
                message = "Không thể chụp ảnh độ phân giải cao. Hãy thử lại.",
                error = DocumentCaptureUiError.STILL_CAPTURE_FAILED,
            )
        }
    }

    private fun onCropFinished(side: DocumentSide, still: DocumentStill, cropped: Bitmap?) {
        if (closed.get() || pendingStill !== still || pendingSide != side) {
            releaseBitmap(cropped)
            return
        }
        if (cropped == null) {
            publish {
                it.copy(
                    stage = ProductionDocumentStage.CROP,
                    captureState = synchronized(stateLock) { captureSession.onCropFailed().state },
                    captureInFlight = false,
                    message = "Không thể xử lý vùng cắt. Hãy điều chỉnh hoặc chụp lại.",
                    error = DocumentCaptureUiError.CROP_FAILED,
                )
            }
            return
        }
        pendingStill = null
        pendingSide = null
        still.close()
        synchronized(stateLock) { captureSession.onCropReadyForOcr() }
        if (side == DocumentSide.FRONT) {
            releaseBitmap(frontBitmap)
            frontBitmap = cropped
            frontOcrComplete = false
        } else {
            releaseBitmap(backBitmap)
            backBitmap = cropped
            backOcrComplete = false
        }
        publish {
            it.copy(
                stage = ProductionDocumentStage.PROCESSING,
                side = side,
                captureState = captureSession.snapshot().state,
                cropBitmap = null,
                captureInFlight = true,
                message = "Đang đọc thông tin trên thẻ…",
                error = null,
            )
        }
        startOcrForSide(side, cropped)
    }

    private fun startOcrForSide(side: DocumentSide, bitmap: Bitmap) {
        val token = ocrSession.beginAttempt(side)
        val generation = ocrGeneration.get()
        ocrExecutor.execute {
            if (closed.get() || generation != ocrGeneration.get()) return@execute
            // ARGB_8888 copying a 2400x1513 still is roughly 14 MB. Do not
            // perform that allocation on the UI thread while the processing
            // screen is being rendered.
            val ocrBitmap = runCatching {
                bitmap.takeIf { !it.isRecycled }?.copy(Bitmap.Config.ARGB_8888, false)
            }.getOrNull()
            if (ocrBitmap == null) {
                if (ocrSession.complete(token, null)) {
                    mainHandler.post {
                        onOcrCompleted(
                            side,
                            token,
                            DocumentTextRecognitionResult(DocumentTextRecognitionStatus.FAILED),
                        )
                    }
                }
                return@execute
            }
            if (closed.get() || generation != ocrGeneration.get()) {
                releaseBitmap(ocrBitmap)
                return@execute
            }
            ocrBitmaps[token] = ocrBitmap
            onPhotoEvidence(side, ocrBitmap)
            // close() can race with the worker between the check above and
            // registration. Remove the bitmap again if the session changed.
            if (closed.get() || generation != ocrGeneration.get()) {
                ocrBitmaps.remove(token)?.let(::releaseBitmap)
                return@execute
            }
            textRecognizer.recognize(
                bitmap = ocrBitmap,
                documentSide = side,
                rotationDegrees = 0,
                callback = DocumentTextRecognitionCallback { result ->
                    if (generation != ocrGeneration.get() || !ocrSession.complete(token, result.snapshot)) {
                        ocrBitmaps.remove(token)?.let(::releaseBitmap)
                        return@DocumentTextRecognitionCallback
                    }
                    // The recognizer has finished with the pixels; recycle the
                    // large temporary bitmap before posting the UI callback.
                    ocrBitmaps.remove(token)?.let(::releaseBitmap)
                    mainHandler.post { onOcrCompleted(side, token, result) }
                },
            )
        }
    }

    private fun onOcrCompleted(
        side: DocumentSide,
        token: OcrAttemptToken,
        result: DocumentTextRecognitionResult,
    ) {
        ocrBitmaps.remove(token)?.let(::releaseBitmap)
        if (closed.get()) return
        synchronized(stateLock) { captureSession.onCaptureCompleted(true) }
        when (side) {
            DocumentSide.FRONT -> {
                frontOcrComplete = true
                synchronized(stateLock) { captureSession.advance() }
                val frontMessage = if (result.status == DocumentTextRecognitionStatus.SUCCESS) {
                    "Mặt trước đã ghi nhận. Lật thẻ để chụp mặt sau."
                } else {
                    "Không thể đọc rõ mặt trước. Bạn vẫn có thể chụp mặt sau rồi thử lại."
                }
                publish {
                    it.copy(
                        stage = ProductionDocumentStage.CAPTURE,
                        side = DocumentSide.BACK,
                        captureState = captureSession.snapshot().state,
                        quality = DocumentQualityStatus.NO_DOCUMENT,
                        stableGoodFrames = 0,
                        captureInFlight = false,
                        message = frontMessage,
                        error = if (result.status == DocumentTextRecognitionStatus.SUCCESS) null else DocumentCaptureUiError.OCR_FAILED,
                    )
                }
                startCameraIfPossible()
            }
            DocumentSide.BACK -> {
                backOcrComplete = true
                publish { it.copy(captureInFlight = false, message = "Đang hoàn tất kiểm tra thông tin…") }
                finishOcrIfReady()
            }
        }
    }

    private fun finishOcrIfReady() {
        if (!frontOcrComplete || !backOcrComplete || closed.get()) return
        if (!processingInFlight.compareAndSet(false, true)) return
        val front = effectiveSnapshot(DocumentSide.FRONT)
        val back = effectiveSnapshot(DocumentSide.BACK)
        val generation = ocrGeneration.get()
        ocrExecutor.execute {
            if (closed.get() || generation != ocrGeneration.get()) {
                processingInFlight.set(false)
                return@execute
            }
            val processed = runCatching { ocrProcessor.process(front = front, back = back) }.getOrNull()
            mainHandler.post {
                processingInFlight.set(false)
                if (closed.get() || generation != ocrGeneration.get()) return@post
                if (processed == null) {
                    publish {
                        it.copy(
                            stage = ProductionDocumentStage.ERROR,
                            captureInFlight = false,
                            message = "OCR processing failed. Please capture again.",
                            error = DocumentCaptureUiError.OCR_FAILED,
                        )
                    }
                    return@post
                }
                if (startTargetedRoiRetry(processed.resolution, processed.readiness)) return@post
                deliverCompletion(processed.resolution, processed.readiness)
            }
        }
    }

    private fun deliverCompletion(resolution: VisualDocumentResolution, readiness: DocumentCaptureReadiness) {
        if (!completionDelivered.compareAndSet(false, true)) return
        stopCamera()
        publish {
            it.copy(
                stage = ProductionDocumentStage.COMPLETE,
                captureState = synchronized(stateLock) { captureSession.markReview().state },
                captureInFlight = false,
                message = null,
                error = null,
            )
        }
        onComplete(
            ProductionDocumentCompletion(
                profile = resolution.profile.name,
                documentNumber = resolution.documentNumber.value,
                // The resolver intentionally keeps the user-facing date as
                // DD/MM/YYYY. Convert only at this production-to-BAC
                // boundary; AccessInput requires YYMMDD.
                birthYYMMDD = BacAccessDateNormalizer.toYyMmDd(resolution.dateOfBirth.value),
                expiryYYMMDD = BacAccessDateNormalizer.toYyMmDd(resolution.dateOfExpiry.value),
                fullNameRaw = resolution.fullName.value,
                sex = resolution.sex.value,
                nationality = resolution.nationality.value,
                documentNumberStatus = resolution.documentNumber.status,
                dateOfBirthStatus = resolution.dateOfBirth.status,
                dateOfExpiryStatus = resolution.dateOfExpiry.status,
                readiness = readiness,
            ),
        )
    }

    private fun startTargetedRoiRetry(
        resolution: VisualDocumentResolution,
        readiness: DocumentCaptureReadiness,
    ): Boolean {
        if (readiness.isReady || roiInFlightKey != null) return roiInFlightKey != null
        val request = roiPlanner.plan(resolution, readiness, roiAttempts)
            .firstOrNull { roiBitmapFor(it) != null }
            ?: return false
        val sourceBitmap = bitmapForSide(request.side) ?: return false
        val rect = request.region.toPixelRect(sourceBitmap.width, sourceBitmap.height) ?: return false
        val roiBitmap = runCatching {
            Bitmap.createBitmap(sourceBitmap, rect.left, rect.top, rect.width(), rect.height())
        }.getOrNull() ?: return false
        roiAttempts += request.key
        roiInFlightKey = request.key
        roiBitmaps[request.key] = roiBitmap
        publish { it.copy(stage = ProductionDocumentStage.PROCESSING, captureInFlight = true, message = "Đang đọc lại vùng thông tin cần thiết…") }
        val metadata = OcrInputMetadata(
            analysisWidth = sourceBitmap.width,
            analysisHeight = sourceBitmap.height,
            analysisRotationDegrees = 0,
            ocrBitmapWidth = roiBitmap.width,
            ocrBitmapHeight = roiBitmap.height,
            ocrRotationDegrees = 0,
            cropWidth = roiBitmap.width,
            cropHeight = roiBitmap.height,
            sourceKind = OcrSourceKind.TARGETED_ROI,
            roiField = request.field.name,
        )
        textRecognizer.recognize(
            bitmap = roiBitmap,
            documentSide = request.side,
            rotationDegrees = 0,
            callback = DocumentTextRecognitionCallback { result ->
                roiBitmaps.remove(request.key)?.let(::releaseBitmap)
                mainHandler.post {
                    if (closed.get() || roiInFlightKey != request.key) return@post
                    roiInFlightKey = null
                    result.snapshot?.let { snapshot ->
                        roiSnapshots[request.key] = RoiSnapshotRecord(
                            snapshot.withSource(OcrSourceKind.TARGETED_ROI, request.field.toDocumentField()),
                            rect.left,
                            rect.top,
                        )
                    }
                    finishOcrIfReady()
                }
            },
        )
        return true
    }

    private fun effectiveSnapshot(side: DocumentSide): OcrSnapshot? {
        var current = when (side) {
            DocumentSide.FRONT -> ocrSession.frontSnapshot
            DocumentSide.BACK -> ocrSession.backSnapshot
        }
        roiSnapshots.filterValues { it.snapshot.documentSide == side }.values.forEach { record ->
            current = if (current == null) record.snapshot else OcrSnapshotMerger.merge(
                current!!,
                record.snapshot,
                record.left,
                record.top,
            )
        }
        return current
    }

    private fun startCameraIfPossible() {
        val owner = lifecycleOwner ?: return
        val preview = previewView ?: return
        startCamera(owner, preview)
    }

    private fun bitmapForSide(side: DocumentSide): Bitmap? = when (side) {
        DocumentSide.FRONT -> frontBitmap
        DocumentSide.BACK -> backBitmap
    }?.takeIf { !it.isRecycled }

    private fun roiBitmapFor(request: TargetedRoiRequest): Bitmap? = bitmapForSide(request.side)?.takeIf {
        request.region.toPixelRect(it.width, it.height)?.let { rect -> rect.width() >= 8 && rect.height() >= 8 } == true
    }

    private fun NormalizedRect.toPixelRect(width: Int, height: Int): Rect? {
        val left = (left * width).toInt().coerceIn(0, width)
        val top = (top * height).toInt().coerceIn(0, height)
        val right = (right * width).toInt().coerceIn(left, width)
        val bottom = (bottom * height).toInt().coerceIn(top, height)
        return Rect(left, top, right, bottom).takeIf { it.width() > 0 && it.height() > 0 }
    }

    private fun vn.cccd.bacreader.document.readiness.RequiredVisualField.toDocumentField(): DocumentField = when (this) {
        vn.cccd.bacreader.document.readiness.RequiredVisualField.DOCUMENT_NUMBER -> DocumentField.DOCUMENT_NUMBER
        vn.cccd.bacreader.document.readiness.RequiredVisualField.DATE_OF_BIRTH -> DocumentField.DATE_OF_BIRTH
        vn.cccd.bacreader.document.readiness.RequiredVisualField.DATE_OF_EXPIRY -> DocumentField.DATE_OF_EXPIRY
    }

    private fun noDocumentMetrics(width: Int, height: Int): DocumentFrameMetrics {
        val guideWidth = qualityConfig.guideWidthFraction
        val guideHeight = guideWidth / qualityConfig.guideAspectRatio
        return DocumentFrameMetrics(
            frameWidth = width,
            frameHeight = height,
            documentBounds = null,
            guideBounds = DocumentRect(
                left = (1.0 - guideWidth) / 2.0,
                top = (1.0 - guideHeight) / 2.0,
                right = (1.0 + guideWidth) / 2.0,
                bottom = (1.0 + guideHeight) / 2.0,
            ),
            meanLuminance = 0.0,
            blurScore = 0.0,
            glareRatio = 0.0,
        )
    }

    private fun clearBitmaps() {
        releaseBitmap(frontBitmap)
        releaseBitmap(backBitmap)
        frontBitmap = null
        backBitmap = null
    }

    private fun releaseBitmap(bitmap: Bitmap?) {
        if (bitmap != null && !bitmap.isRecycled) bitmap.recycle()
    }

    private fun publish(transform: (ProductionDocumentUiState) -> ProductionDocumentUiState) {
        if (!closed.get()) mutableState.update(transform)
    }

    private data class RoiSnapshotRecord(
        val snapshot: OcrSnapshot,
        val left: Int,
        val top: Int,
    )
}
