package vn.cccd.bacreader.document.capture

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint

/** Applies a four-point whole-card perspective correction without OpenCV. */
object DocumentPerspectiveCropper {
    fun crop(
        source: Bitmap,
        quad: CropQuad,
        maxDimension: Int = 2400,
    ): Bitmap? {
        if (!CropGeometry.isValid(quad, source.width, source.height)) return null
        val outputSize = CropOutputPolicy.forQuad(quad, maxDimension)
        val sourcePoints = floatArrayOf(
            quad.topLeft.x.toFloat(), quad.topLeft.y.toFloat(),
            quad.topRight.x.toFloat(), quad.topRight.y.toFloat(),
            quad.bottomRight.x.toFloat(), quad.bottomRight.y.toFloat(),
            quad.bottomLeft.x.toFloat(), quad.bottomLeft.y.toFloat(),
        )
        val destinationPoints = floatArrayOf(
            0f, 0f,
            outputSize.width.toFloat(), 0f,
            outputSize.width.toFloat(), outputSize.height.toFloat(),
            0f, outputSize.height.toFloat(),
        )
        val matrix = Matrix()
        if (!matrix.setPolyToPoly(sourcePoints, 0, destinationPoints, 0, 4)) return null
        return try {
            Bitmap.createBitmap(outputSize.width, outputSize.height, Bitmap.Config.ARGB_8888).also { output ->
                Canvas(output).apply {
                    drawColor(Color.WHITE)
                    drawBitmap(source, matrix, Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true })
                }
            }
        } catch (_: OutOfMemoryError) {
            null
        } catch (_: RuntimeException) {
            null
        }
    }
}
