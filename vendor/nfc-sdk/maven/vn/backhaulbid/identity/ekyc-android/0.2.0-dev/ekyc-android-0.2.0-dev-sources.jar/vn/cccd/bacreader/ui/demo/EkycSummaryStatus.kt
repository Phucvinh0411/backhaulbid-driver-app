package vn.cccd.bacreader.ui.demo

import vn.cccd.bacreader.biometric.camera.BiometricResult
import vn.cccd.bacreader.document.crosscheck.NfcDocumentResult
import vn.cccd.bacreader.document.crosscheck.NfcOverallStatus

enum class EkycOverallStatus { COMPLETED, NEEDS_REVIEW, INCOMPLETE, FAILED_STAGE }

/** Derives only presentation status from the real session results. */
object EkycSummaryStatus {
    fun derive(
        documentReady: Boolean,
        nfc: NfcDocumentResult?,
        biometric: BiometricResult?,
    ): EkycOverallStatus {
        return when {
            documentReady && nfc?.overallStatus == NfcOverallStatus.SUCCESS &&
                biometric?.isSuccessful == true -> EkycOverallStatus.COMPLETED
            nfc?.overallStatus == NfcOverallStatus.FAILURE -> EkycOverallStatus.FAILED_STAGE
            biometric != null && !biometric.isSuccessful -> EkycOverallStatus.NEEDS_REVIEW
            !documentReady || nfc == null || biometric == null -> EkycOverallStatus.INCOMPLETE
            else -> EkycOverallStatus.NEEDS_REVIEW
        }
    }
}
