package vn.cccd.bacreader.biometric.camera

import android.media.Image
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageProxy
import java.util.concurrent.atomic.AtomicBoolean
import vn.cccd.bacreader.biometric.RgbImage

/**
 * Ephemeral camera frame. Consumers must not retain it or its [mediaImage] after [close].
 * The owner that starts an asynchronous detector is responsible for closing it when complete.
 */
@OptIn(markerClass = [ExperimentalGetImage::class])
class CameraFrame internal constructor(
    private val imageProxy: ImageProxy,
) : AutoCloseable {
    private val closed = AtomicBoolean(false)

    val mediaImage: Image? get() = imageProxy.image
    val width: Int get() = imageProxy.width
    val height: Int get() = imageProxy.height
    val rotationDegrees: Int get() = imageProxy.imageInfo.rotationDegrees

    /** Copies the valid YUV frame into upright RGB pixels while the ImageProxy is still open. */
    internal fun copyRgb(): RgbImage? {
        val image = mediaImage ?: return null
        if (image.format != android.graphics.ImageFormat.YUV_420_888) return null

        val rawWidth = width
        val rawHeight = height
        if (rawWidth <= 0 || rawHeight <= 0 || image.planes.size < 3) return null
        val rotation = ImageRotation.normalize(rotationDegrees)
        val outputWidth = ImageRotation.uprightWidth(rawWidth, rawHeight, rotation)
        val outputHeight = ImageRotation.uprightHeight(rawWidth, rawHeight, rotation)
        val output = ByteArray(outputWidth * outputHeight * RgbImage.CHANNELS)
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        val yBuffer = yPlane.buffer.duplicate()
        val uBuffer = uPlane.buffer.duplicate()
        val vBuffer = vPlane.buffer.duplicate()

        for (y in 0 until outputHeight) {
            for (x in 0 until outputWidth) {
                val sourceX = ImageRotation.sourceX(x, y, rawWidth, rawHeight, rotation)
                val sourceY = ImageRotation.sourceY(x, y, rawWidth, rawHeight, rotation)
                val yValue = yBuffer.get(sourceY * yPlane.rowStride + sourceX * yPlane.pixelStride).toInt() and 0xFF
                val chromaX = sourceX / 2
                val chromaY = sourceY / 2
                val uValue = uBuffer.get(chromaY * uPlane.rowStride + chromaX * uPlane.pixelStride).toInt() and 0xFF
                val vValue = vBuffer.get(chromaY * vPlane.rowStride + chromaX * vPlane.pixelStride).toInt() and 0xFF
                val u = uValue - 128
                val v = vValue - 128
                val red = (yValue + 1.402f * v).toInt().coerceIn(0, 255)
                val green = (yValue - 0.344136f * u - 0.714136f * v).toInt().coerceIn(0, 255)
                val blue = (yValue + 1.772f * u).toInt().coerceIn(0, 255)
                val index = (y * outputWidth + x) * RgbImage.CHANNELS
                output[index] = red.toByte()
                output[index + 1] = green.toByte()
                output[index + 2] = blue.toByte()
            }
        }
        return RgbImage(outputWidth, outputHeight, output)
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) imageProxy.close()
    }
}
