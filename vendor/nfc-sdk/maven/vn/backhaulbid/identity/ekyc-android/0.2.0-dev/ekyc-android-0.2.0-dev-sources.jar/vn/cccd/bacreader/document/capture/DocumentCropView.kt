package vn.cccd.bacreader.document.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/** Whole-document crop editor. Coordinates exposed by this view are Bitmap pixels. */
class DocumentCropView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {
    private var bitmap: Bitmap? = null
    private var quad: CropQuad? = null
    private var viewport: CropViewport? = null
    private var activeCorner: Corner? = null
    private val density = resources.displayMetrics.density
    private val handleRadius = 24f * density
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shadePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000 }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * density
        color = Color.WHITE
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00C853.toInt() }
    private var quadChangedListener: ((CropQuad) -> Unit)? = null

    fun setBitmap(value: Bitmap?) {
        bitmap = value
        quad = value?.let { CropGeometry.initialQuad(it.width, it.height) }
        activeCorner = null
        invalidate()
    }

    fun clear() {
        bitmap = null
        quad = null
        viewport = null
        activeCorner = null
        invalidate()
    }

    fun resetQuad() {
        bitmap?.let { quad = CropGeometry.initialQuad(it.width, it.height) }
        invalidate()
        quad?.let { quadChangedListener?.invoke(it) }
    }

    fun currentQuad(): CropQuad? = quad

    fun setOnQuadChangedListener(listener: ((CropQuad) -> Unit)?) {
        quadChangedListener = listener
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.BLACK)
        val image = bitmap ?: return
        if (width <= 0 || height <= 0) return
        val fitted = CropCoordinateMapper.fitCenter(image.width, image.height, width, height)
        viewport = fitted
        canvas.drawBitmap(image, null, android.graphics.RectF(
            fitted.left.toFloat(), fitted.top.toFloat(), fitted.right.toFloat(), fitted.bottom.toFloat(),
        ), imagePaint)
        val current = quad ?: return
        val viewPoints = current.points.map { point ->
            CropCoordinateMapper.bitmapToView(point, fitted, image.width, image.height)
        }
        val path = Path().apply {
            moveTo(viewPoints[0].x.toFloat(), viewPoints[0].y.toFloat())
            viewPoints.drop(1).forEach { lineTo(it.x.toFloat(), it.y.toFloat()) }
            close()
        }
        canvas.save()
        canvas.clipOutPath(path)
        canvas.drawRect(fitted.left.toFloat(), fitted.top.toFloat(), fitted.right.toFloat(), fitted.bottom.toFloat(), shadePaint)
        canvas.restore()
        canvas.drawPath(path, edgePaint)
        viewPoints.forEach { point -> canvas.drawCircle(point.x.toFloat(), point.y.toFloat(), handleRadius, handlePaint) }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val image = bitmap ?: return false
        val currentViewport = viewport ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activeCorner = findCorner(event.x.toDouble(), event.y.toDouble(), currentViewport, image)
                return activeCorner != null
            }
            MotionEvent.ACTION_MOVE -> {
                val corner = activeCorner ?: return false
                val mapped = CropCoordinateMapper.viewToBitmap(
                    CropPoint(event.x.toDouble(), event.y.toDouble()),
                    currentViewport,
                    image.width,
                    image.height,
                )
                val clamped = CropPoint(
                    mapped.x.coerceIn(0.0, image.width.toDouble()),
                    mapped.y.coerceIn(0.0, image.height.toDouble()),
                )
                val candidate = replace(currentQuad() ?: return false, corner, clamped)
                if (CropGeometry.isValid(candidate, image.width, image.height)) {
                    quad = candidate
                    quadChangedListener?.invoke(candidate)
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL,
            -> {
                activeCorner = null
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun findCorner(
        x: Double,
        y: Double,
        currentViewport: CropViewport,
        image: Bitmap,
    ): Corner? {
        val current = quad ?: return null
        val points = current.points.map { CropCoordinateMapper.bitmapToView(it, currentViewport, image.width, image.height) }
        return points.mapIndexed { index, point ->
            index to hypot(point.x - x, point.y - y)
        }
            .minByOrNull { it.second }
            ?.takeIf { it.second <= handleRadius * 1.8 }
            ?.first
            ?.let(Corner::fromIndex)
    }

    private fun replace(quad: CropQuad, corner: Corner, point: CropPoint): CropQuad = when (corner) {
        Corner.TOP_LEFT -> quad.copy(topLeft = point)
        Corner.TOP_RIGHT -> quad.copy(topRight = point)
        Corner.BOTTOM_RIGHT -> quad.copy(bottomRight = point)
        Corner.BOTTOM_LEFT -> quad.copy(bottomLeft = point)
    }

    private enum class Corner {
        TOP_LEFT,
        TOP_RIGHT,
        BOTTOM_RIGHT,
        BOTTOM_LEFT,
        ;

        companion object {
            fun fromIndex(index: Int): Corner = entries[index]
        }
    }
}
