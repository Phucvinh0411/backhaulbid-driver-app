package vn.cccd.bacreader.document.resolver

import java.time.DateTimeException
import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import vn.cccd.bacreader.document.capture.DocumentSide
import vn.cccd.bacreader.document.geometry.OcrGeometry
import vn.cccd.bacreader.document.ocr.OcrBounds
import vn.cccd.bacreader.document.ocr.OcrSnapshot
import vn.cccd.bacreader.document.ocr.OcrSourceKind
import vn.cccd.bacreader.document.ocr.preprocess.DateCandidateAssembler
import vn.cccd.bacreader.document.ocr.preprocess.LabelMatchKind
import vn.cccd.bacreader.document.ocr.preprocess.OcrFieldSegment
import vn.cccd.bacreader.document.ocr.preprocess.OcrTextPreprocessor
import vn.cccd.bacreader.document.ocr.preprocess.PreprocessedOcr
import vn.cccd.bacreader.document.ocr.preprocess.PreprocessedLine
import vn.cccd.bacreader.document.ocr.preprocess.TextTransformation

/** Resolves visible CCCD fields without modifying the immutable OCR snapshots. */
class DocumentFieldResolver {
    fun resolve(front: OcrSnapshot?, back: OcrSnapshot?): VisualDocumentResolution {
        return resolve(OcrTextPreprocessor().process(front, back))
    }

    /** Resolves an already-preprocessed snapshot without repeating normalization. */
    fun resolve(preprocessed: PreprocessedOcr): VisualDocumentResolution {
        val allLines = preprocessed.lines.map { it.toLineNode(preprocessed) }
        val profile = CardProfileClassifier.classify(preprocessed)
        return VisualDocumentResolution(
            profile = profile,
            documentNumber = resolveField(DocumentField.DOCUMENT_NUMBER, profile, allLines),
            fullName = resolveField(DocumentField.FULL_NAME, profile, allLines),
            dateOfBirth = resolveField(DocumentField.DATE_OF_BIRTH, profile, allLines),
            sex = resolveField(DocumentField.SEX, profile, allLines),
            nationality = resolveField(DocumentField.NATIONALITY, profile, allLines),
            dateOfExpiry = resolveField(DocumentField.DATE_OF_EXPIRY, profile, allLines),
        )
    }

    private fun resolveField(
        field: DocumentField,
        profile: VietnamCardProfile,
        lines: List<LineNode>,
    ): ResolvedField<String> {
        val fieldProfile = VietnamCccdFieldProfiles.forField(field)
        val labels = lines
            .filter { it.side in fieldProfile.allowedSides && it.sourceAllowedFor(field) }
            .flatMap { findLabelOccurrences(field, fieldProfile, it, lines) }
        val candidates = labels.flatMap { label ->
            lines.filter {
                it.side == label.side &&
                    it.side in fieldProfile.allowedSides &&
                    it.sourceAllowedFor(field) &&
                    !containsOtherFieldLabel(field, it)
                }
                .flatMap { valueLine -> candidateValues(field, valueLine, label) }
                .mapNotNull { value -> scoreCandidate(fieldProfile, profile, label, value, field) }
        }
        val deduplicated = deduplicateCandidates(candidates)
        val diagnostics = FieldDiagnostics(
            frontLabelCandidates = labels.count { it.side == DocumentSide.FRONT },
            backLabelCandidates = labels.count { it.side == DocumentSide.BACK },
            valueCandidatesNearLabel = deduplicated.size,
            profile = profile,
            frontValueCandidatesNearLabel = deduplicated.count { it.side == DocumentSide.FRONT },
            backValueCandidatesNearLabel = deduplicated.count { it.side == DocumentSide.BACK },
        )
        return selectCandidate(deduplicated, diagnostics)
    }

    private fun LineNode.sourceAllowedFor(field: DocumentField): Boolean =
        sourceKind == OcrSourceKind.WHOLE_CARD || retryTargetField == field

    private fun containsOtherFieldLabel(field: DocumentField, line: LineNode): Boolean {
        if (line.segments.any { it.field == field }) return false
        return line.segments.any { it.field != field }
    }

    private fun selectCandidate(
        candidates: List<ScoredCandidate>,
        diagnostics: FieldDiagnostics,
    ): ResolvedField<String> {
        val candidateDiagnostics = candidates.map { it.toDiagnostic() }
        if (candidates.isEmpty()) {
            return ResolvedField(diagnostics = diagnostics, candidates = candidateDiagnostics)
        }
        val valid = candidates.filter { it.valid }
        if (valid.isEmpty()) {
            return ResolvedField(
                status = ParsedFieldStatus.INVALID,
                candidateCount = candidates.size,
                diagnostics = diagnostics,
                candidates = candidateDiagnostics,
            )
        }
        val ranked = valid.sortedByDescending { it.score }
        val top = ranked.first()
        val second = ranked.getOrNull(1)
        if (second != null && top.score - second.score < UNIQUE_SCORE_GAP) {
            return ResolvedField(
                status = ParsedFieldStatus.AMBIGUOUS,
                candidateCount = valid.size,
                diagnostics = diagnostics,
                bestScore = top.score,
                candidates = candidateDiagnostics,
            )
        }
        val evidence = top.evidence + FieldEvidence.UNIQUE_CANDIDATE
        return ResolvedField(
            value = top.displayValue,
            status = ParsedFieldStatus.FOUND,
            confidence = confidenceFor(evidence),
            sourceSide = top.side,
            evidence = evidence,
            candidateCount = valid.size,
            diagnostics = diagnostics,
            bestScore = top.score,
            candidates = candidateDiagnostics,
        )
    }

    private fun ScoredCandidate.toDiagnostic() = ResolvedCandidateDiagnostic(
        rawValue = rawValue,
        canonicalValue = canonicalValue,
        sourceKinds = sourceKinds,
        retryTargetFields = retryTargetFields,
        dedupGroupId = dedupGroupId,
        transformations = transformations,
        evidence = evidence,
        score = score,
        valid = valid,
    )

    private fun deduplicateCandidates(candidates: List<ScoredCandidate>): List<ScoredCandidate> {
        val groups = mutableListOf<ScoredCandidate>()
        candidates.forEach { candidate ->
            val existingIndex = groups.indexOfFirst { existing ->
                existing.canonicalValue == candidate.canonicalValue &&
                    existing.side == candidate.side &&
                    spatiallyEquivalent(existing, candidate)
            }
            if (existingIndex < 0) {
                groups += candidate.copy(dedupGroupId = groups.size + 1)
            } else {
                groups[existingIndex] = mergeSemanticCandidates(groups[existingIndex], candidate)
            }
        }
        return groups
    }

    private fun spatiallyEquivalent(first: ScoredCandidate, second: ScoredCandidate): Boolean {
        val a = first.bounds ?: return false
        val b = second.bounds ?: return false
        val intersectionWidth = (min(a.right, b.right) - max(a.left, b.left)).coerceAtLeast(0)
        val intersectionHeight = (min(a.bottom, b.bottom) - max(a.top, b.top)).coerceAtLeast(0)
        val intersection = intersectionWidth.toDouble() * intersectionHeight
        val firstArea = ((a.right - a.left).coerceAtLeast(0) * (a.bottom - a.top).coerceAtLeast(0)).toDouble()
        val secondArea = ((b.right - b.left).coerceAtLeast(0) * (b.bottom - b.top).coerceAtLeast(0)).toDouble()
        val smallerArea = min(firstArea, secondArea)
        if (smallerArea > 0.0 && intersection / smallerArea >= 0.25) return true

        val firstCenterX = (a.left + a.right) / 2.0
        val firstCenterY = (a.top + a.bottom) / 2.0
        val secondCenterX = (b.left + b.right) / 2.0
        val secondCenterY = (b.top + b.bottom) / 2.0
        val width = max(first.imageWidth, second.imageWidth).coerceAtLeast(1).toDouble()
        val height = max(first.imageHeight, second.imageHeight).coerceAtLeast(1).toDouble()
        return kotlin.math.abs(firstCenterX - secondCenterX) / width <= 0.04 &&
            kotlin.math.abs(firstCenterY - secondCenterY) / height <= 0.04
    }

    private fun mergeSemanticCandidates(
        first: ScoredCandidate,
        second: ScoredCandidate,
    ): ScoredCandidate {
        val evidence = first.evidence + second.evidence
        return first.copy(
            score = EvidenceScorer.score(evidence),
            evidence = evidence,
            valid = first.valid || second.valid,
            bounds = union(first.bounds, second.bounds),
            sourceKinds = first.sourceKinds + second.sourceKinds,
            retryTargetFields = first.retryTargetFields + second.retryTargetFields,
            transformations = first.transformations + second.transformations,
        )
    }

    private fun confidenceFor(evidence: Set<FieldEvidence>): FieldConfidence = when {
        evidence.contains(FieldEvidence.EXACT_LABEL) &&
            evidence.contains(FieldEvidence.FORMAT_VALID) &&
            (evidence.contains(FieldEvidence.SAME_LINE_RIGHT) || evidence.contains(FieldEvidence.BELOW_LABEL)) ->
            FieldConfidence.HIGH
        evidence.contains(FieldEvidence.FORMAT_VALID) &&
            evidence.any { it == FieldEvidence.ACCENT_INSENSITIVE_LABEL || it == FieldEvidence.FUZZY_LABEL || it == FieldEvidence.SPLIT_LABEL_MATCH } ->
            FieldConfidence.MEDIUM
        else -> FieldConfidence.LOW
    }

    private fun canonicalValue(field: DocumentField, value: String): String = when (field) {
        DocumentField.DOCUMENT_NUMBER -> value.filter(Char::isDigit)
        DocumentField.DATE_OF_BIRTH,
        DocumentField.DATE_OF_EXPIRY,
        -> value.replace(" ", "")
        DocumentField.FULL_NAME,
        DocumentField.SEX,
        DocumentField.NATIONALITY,
        -> OcrTextNormalizer.normalizeValue(value)
    }

    private fun scoreCandidate(
        profile: FieldProfile,
        cardProfile: VietnamCardProfile,
        label: LabelOccurrence,
        value: ExtractedValue,
        field: DocumentField,
    ): ScoredCandidate? {
        val relations = spatialRelations(label, value.line)
            .filter { it in profile.allowedRelations }
        if (relations.isEmpty()) return null
        if (field == DocumentField.SEX && value.value.length == 1 &&
            SpatialRelation.SAME_LINE_RIGHT !in relations
        ) {
            return null
        }
        val evidence = linkedSetOf<FieldEvidence>()
        evidence += label.evidence
        relations.forEach {
            evidence += it.toEvidence()
            if (it == SpatialRelation.SAME_LINE_RIGHT) evidence += FieldEvidence.SAME_LINE
        }
        if (value.valid) evidence += FieldEvidence.FORMAT_VALID
        if (value.reconstructed) evidence += FieldEvidence.TOKEN_RECONSTRUCTED

        val preferredSide = profile.preferredSideByCardProfile[cardProfile]
        if (preferredSide == value.line.side) evidence += FieldEvidence.PREFERRED_SIDE
        val expectedRegion = profile.expectedRegions[cardProfile]
        if (expectedRegion != null && value.line.normalizedCenter()?.let { expectedRegion.contains(it.first, it.second) } == true) {
            evidence += FieldEvidence.EXPECTED_REGION
        } else if (expectedRegion != null) {
            evidence += FieldEvidence.OUTSIDE_EXPECTED_REGION
        }
        if (field == DocumentField.DATE_OF_EXPIRY && isIssueDateContext(value.line)) {
            evidence += FieldEvidence.ISSUE_DATE_CONTEXT
        }
        val score = EvidenceScorer.score(evidence)
        return ScoredCandidate(
            rawValue = value.rawValue,
            displayValue = value.value,
            canonicalValue = canonicalValue(field, value.value),
            side = value.line.side,
            score = score,
            evidence = evidence,
            valid = value.valid,
            bounds = value.line.bounds,
            imageWidth = value.line.ownerImageWidth,
            imageHeight = value.line.ownerImageHeight,
            sourceKinds = setOf(value.line.sourceKind),
            retryTargetFields = setOfNotNull(value.line.retryTargetField),
            transformations = value.transformations,
        )
    }

    private fun candidateValues(field: DocumentField, line: LineNode, label: LabelOccurrence): List<ExtractedValue> {
        // A split label may span two OCR lines. Only the anchor line owns the
        // label suffix; the following line must remain available as a local
        // below-label value candidate (not have label tokens stripped from it).
        val sameLine = line.index == label.index
        val segment = line.segments.firstOrNull {
            it.field == field && it.lineIndex == line.sideLineIndex &&
                it.sourceLineIndexes.any { sourceIndex -> sourceIndex == line.sideLineIndex }
        }
        val text = if (sameLine) {
            segment?.rawValue ?: valueTextAfterLabel(line.text, label)
        } else {
            line.text
        }
        return when (field) {
            DocumentField.DOCUMENT_NUMBER -> documentNumberValues(line, text)
            DocumentField.FULL_NAME -> listOfNotNull(
                text.trim().takeIf { isPlausibleName(it) }?.let { ExtractedValue(it, line, true) },
            )
            DocumentField.DATE_OF_BIRTH,
            DocumentField.DATE_OF_EXPIRY,
            -> dateValues(text, line)
            DocumentField.SEX -> textValues(text, line, SEX_VALUES)
            DocumentField.NATIONALITY -> textValues(text, line, NATIONALITY_VALUES)
        }
    }

    private fun dateValues(text: String, line: LineNode): List<ExtractedValue> =
        DateCandidateAssembler.candidates(text, allowOToZero = true).map { candidate ->
            ExtractedValue(
                value = candidate.normalizedText,
                line = line,
                valid = true,
                reconstructed = candidate.transformations.isNotEmpty(),
                rawValue = candidate.rawText,
                transformations = candidate.transformations,
            )
        }.ifEmpty {
            // Keep an invalid date-like candidate visible to the resolver so
            // the field is INVALID rather than silently becoming NOT_FOUND.
            RECOVERABLE_DATE_PATTERN.findAll(text).map { match ->
                ExtractedValue(match.value.trim(), line, false, rawValue = match.value.trim())
            }.toList()
        }

    private fun textValues(text: String, line: LineNode, allowed: List<String>): List<ExtractedValue> {
        val words = Regex("[\\p{L}\\p{Nd}]+")
            .findAll(text)
            .map { it.value }
            .toList()
        return buildList {
            words.forEachIndexed { index, word ->
                if (allowed.any { OcrTextNormalizer.normalizeValue(word) == OcrTextNormalizer.normalizeValue(it) }) {
                    add(ExtractedValue(word, line, true))
                }
                if (index + 1 < words.size) {
                    val pair = "${words[index]} ${words[index + 1]}"
                    if (allowed.any { OcrTextNormalizer.normalizeValue(pair) == OcrTextNormalizer.normalizeValue(it) }) {
                        add(ExtractedValue(pair, line, true))
                    }
                }
            }
        }.distinctBy { it.value to it.line.index }
    }

    private fun documentNumberValues(line: LineNode, text: String): List<ExtractedValue> {
        val matches = Regex("(?<!\\d)\\d{4,15}(?!\\d)")
            .findAll(text)
            .map { it.value }
            .toList()
        val values = matches
            .filter { line.elements.isEmpty() || matches.size == 1 || it.length == 12 }
            .map { ExtractedValue(it, line, it.length == 12) }
            .toMutableList()

        // When ML Kit exposes elements, require geometry for chunk assembly so
        // unrelated numeric regions cannot be joined. If elements are absent,
        // a line-local digit/separator form remains a safe compatibility path.
        if (line.elements.isEmpty()) {
            val compact = text.trim()
                .takeIf { it.isNotEmpty() && it.all { char -> char.isDigit() || char == ' ' || char == '-' } }
                ?.filter(Char::isDigit)
            if (compact?.length == 12 && values.none { it.value == compact }) {
                values += ExtractedValue(compact, line, true, reconstructed = true)
            }
        } else {
            assembleElementNumber(line)?.let { assembled ->
                if (values.none { it.value == assembled }) values += ExtractedValue(assembled, line, true, reconstructed = true)
            }
        }
        return values
    }

    private fun assembleElementNumber(line: LineNode): String? {
        val elements = line.elements
        if (elements.isEmpty()) return null
        val chunks = mutableListOf<String>()
        var previous: ElementNode? = null
        for (element in elements) {
            val chunk = element.text.trim()
            val digitCompatible = chunk.isNotEmpty() && chunk.all { it.isDigit() || it == ' ' || it == '-' }
            if (!digitCompatible || !elementsAdjacent(previous, element, line)) {
                chunks.clear()
            }
            if (digitCompatible && (previous == null || chunks.isNotEmpty() || elementsAdjacent(previous, element, line))) {
                chunks += chunk.filter(Char::isDigit)
            }
            previous = element
            val candidate = chunks.joinToString("")
            if (candidate.length == 12) return candidate
            if (candidate.length > 12) chunks.clear()
        }
        return null
    }

    private fun elementsAdjacent(previous: ElementNode?, current: ElementNode, line: LineNode): Boolean {
        if (previous == null) return true
        val first = previous.bounds ?: return false
        val second = current.bounds ?: return false
        val horizontalGap = OcrGeometry.horizontalGap(first, second, line.ownerImageWidth)
        val centerDelta = OcrGeometry.baselineDelta(first, second, line.ownerImageHeight)
        return second.left >= first.left && horizontalGap <= MAX_ELEMENT_GAP && centerDelta <= MAX_ELEMENT_CENTER_DELTA
    }

    private fun valueTextAfterLabel(text: String, label: LabelOccurrence): String {
        val colon = text.indexOf(':')
        if (colon >= 0) return text.substring(colon + 1)
        val labelTokens = OcrTextNormalizer.tokens(label.alias)
        val words = text.trim().split(Regex("\\s+")).filter(String::isNotEmpty)
        return words.drop(min(labelTokens.size, words.size)).joinToString(" ")
    }

    private fun isPlausibleName(value: String): Boolean {
        if (value.length < 2 || value.any { it.isDigit() } || value.contains('<')) return false
        if (DATE_PATTERN.containsMatchIn(value)) return false
        if (Regex("(?<!\\d)\\d{12}(?!\\d)").containsMatchIn(value)) return false
        val normalized = OcrTextNormalizer.accentInsensitive(value)
        if (SEX_VALUES.any { normalized == it } || NATIONALITY_VALUES.any { normalized == it }) return false
        val labelText = DocumentField.values().any { field ->
            field != DocumentField.FULL_NAME && VietnamCccdFieldProfiles.forField(field).aliases.any { alias ->
                normalized.contains(OcrTextNormalizer.accentInsensitive(alias))
            }
        }
        if (labelText) return false
        return value.count { it.isLetter() } >= 2
    }

    private fun isIssueDateContext(line: LineNode): Boolean {
        val normalized = OcrTextNormalizer.normalizeLabel(line.text)
        return normalized.contains("DATE OF ISSUE") ||
            normalized.contains("NGAY CAP") ||
            normalized.contains("DATE MONTH YEAR")
    }

    private fun findLabelOccurrences(
        field: DocumentField,
        profile: FieldProfile,
        line: LineNode,
        allLines: List<LineNode>,
    ): List<LabelOccurrence> {
        val occurrences = line.segments
            .filter { it.field == field }
            .map { segment ->
                LabelOccurrence(
                    field = field,
                    side = line.side,
                    index = line.index,
                    lineIndexes = listOf(line.index),
                    bounds = segment.labelBounds ?: line.bounds,
                    alias = segment.rawLabel,
                    evidence = segment.labelMatch.toEvidence(),
                    ownerImageWidth = line.ownerImageWidth,
                    ownerImageHeight = line.ownerImageHeight,
                    segment = segment,
                )
            }
            .toMutableList()
        val next = allLines.firstOrNull {
            it.side == line.side && it.blockIndex == line.blockIndex && it.index == line.index + 1 && areAdjacent(line, it)
        }
        if (occurrences.isEmpty() && next != null && next.segments.none { it.field == field }) {
            val combined = "${line.text} ${next.text}"
            if (findLabelMatch(combined, profile.aliases) != null) {
                occurrences += LabelOccurrence(
                    field = field,
                    side = line.side,
                    index = line.index,
                    lineIndexes = listOf(line.index, next.index),
                    bounds = union(line.bounds, next.bounds),
                    alias = combined,
                    evidence = FieldEvidence.SPLIT_LABEL_MATCH,
                    ownerImageWidth = line.ownerImageWidth,
                    ownerImageHeight = line.ownerImageHeight,
                    segment = null,
                )
            }
        }
        return occurrences
    }

    private fun findLabelMatch(text: String, aliases: List<String>): LabelMatch? {
        val normalized = OcrTextNormalizer.matching(text)
        val accentInsensitive = OcrTextNormalizer.normalizeLabel(text)
        val normalizedPadded = " $normalized "
        val accentPadded = " $accentInsensitive "
        aliases.forEach { alias ->
            val aliasNormalized = OcrTextNormalizer.matching(alias)
            if (normalized == aliasNormalized || normalizedPadded.contains(" $aliasNormalized ")) {
                return LabelMatch(alias, FieldEvidence.EXACT_LABEL)
            }
        }
        aliases.forEach { alias ->
            val aliasAccent = OcrTextNormalizer.normalizeLabel(alias)
            if (accentInsensitive == aliasAccent || accentPadded.contains(" $aliasAccent ")) {
                return LabelMatch(alias, FieldEvidence.ACCENT_INSENSITIVE_LABEL)
            }
        }

        val textTokens = OcrTextNormalizer.tokens(accentInsensitive)
        aliases.forEach { alias ->
            val aliasTokens = OcrTextNormalizer.tokens(OcrTextNormalizer.normalizeLabel(alias))
            if (aliasTokens.isEmpty() || textTokens.size < aliasTokens.size) return@forEach
            textTokens.windowed(aliasTokens.size).forEach { window ->
                val distance = window.zip(aliasTokens).sumOf { (left, right) -> levenshtein(left, right) }
                val maxDistance = max(1, aliasTokens.sumOf(String::length) / 8)
                if (distance in 1..maxDistance) return LabelMatch(alias, FieldEvidence.FUZZY_LABEL)
            }
        }
        return null
    }

    private fun spatialRelations(label: LabelOccurrence, line: LineNode): Set<SpatialRelation> {
        val relations = linkedSetOf<SpatialRelation>()
        if (line.index in label.lineIndexes) {
            relations += SpatialRelation.SAME_LINE_RIGHT
            return relations
        }
        val labelBounds = label.bounds
        val valueBounds = line.bounds
        if (labelBounds == null || valueBounds == null) {
            if (line.index > label.lineIndexes.maxOrNull()!! && line.index - label.lineIndexes.maxOrNull()!! <= 2) {
                relations += SpatialRelation.BELOW
            }
            return relations
        }
        val imageHeight = max(label.ownerImageHeight, line.ownerImageHeight).toDouble().coerceAtLeast(1.0)
        val imageWidth = max(label.ownerImageWidth, line.ownerImageWidth).toDouble().coerceAtLeast(1.0)
        val verticalGap = (valueBounds.top - labelBounds.bottom).coerceAtLeast(0).toDouble() / imageHeight
        val horizontalGap = (valueBounds.left - labelBounds.right).coerceAtLeast(0).toDouble() / imageWidth
        val yOverlap = min(valueBounds.bottom, labelBounds.bottom) - max(valueBounds.top, labelBounds.top)
        val xDistance = abs(valueBounds.left - labelBounds.left).toDouble() / imageWidth
        if (yOverlap >= -0.03 * imageHeight && valueBounds.left >= labelBounds.right - imageWidth * 0.04) {
            relations += SpatialRelation.NEAR_RIGHT
        }
        val lineDistance = line.index - (label.lineIndexes.maxOrNull() ?: label.index)
        if (valueBounds.top >= labelBounds.bottom && lineDistance in 1..2 && xDistance <= 0.65) {
            if (verticalGap <= 0.20) relations += SpatialRelation.BELOW
            if (verticalGap <= 0.40) relations += SpatialRelation.NEAR_BELOW
        }
        // A local region is useful for a nearby value below a label, but a
        // date belonging to the preceding field must not be pulled upward
        // into this field's result.
        if (valueBounds.top >= labelBounds.top && lineDistance in 1..2 &&
            verticalGap <= 0.35 && horizontalGap <= 0.65
        ) {
            relations += SpatialRelation.LOCAL_REGION
        }
        return relations
    }

    private fun areAdjacent(first: LineNode, second: LineNode): Boolean {
        val firstBounds = first.bounds ?: return true
        val secondBounds = second.bounds ?: return true
        val height = max(first.ownerImageHeight, second.ownerImageHeight).toDouble().coerceAtLeast(1.0)
        val width = max(first.ownerImageWidth, second.ownerImageWidth).toDouble().coerceAtLeast(1.0)
        val gap = (secondBounds.top - firstBounds.bottom).coerceAtLeast(0).toDouble() / height
        val xDistance = abs(secondBounds.left - firstBounds.left).toDouble() / width
        return gap <= 0.15 && xDistance <= 0.65
    }

    private fun LabelMatchKind.toEvidence(): FieldEvidence = when (this) {
        LabelMatchKind.EXACT -> FieldEvidence.EXACT_LABEL
        LabelMatchKind.ACCENT_INSENSITIVE -> FieldEvidence.ACCENT_INSENSITIVE_LABEL
        LabelMatchKind.FUZZY -> FieldEvidence.FUZZY_LABEL
        LabelMatchKind.SPLIT -> FieldEvidence.SPLIT_LABEL_MATCH
    }

    private fun PreprocessedLine.toLineNode(preprocessed: vn.cccd.bacreader.document.ocr.preprocess.PreprocessedOcr): LineNode {
        val globalIndex = preprocessed.lines.indexOfFirst { it.side == side && it.lineIndex == lineIndex }
        return LineNode(
            index = globalIndex,
            sideLineIndex = lineIndex,
            blockIndex = blockIndex,
            side = side,
            text = rawText,
            bounds = bounds,
            ownerImageWidth = imageWidth,
            ownerImageHeight = imageHeight,
            elements = elements.map { ElementNode(it.rawText, it.bounds) },
            segments = preprocessed.segments.filter { it.side == side && it.lineIndex == lineIndex },
            sourceKind = sourceKind,
            retryTargetField = retryTargetField,
        )
    }

    private fun OcrBounds.center(): Pair<Double, Double> =
        ((left + right) / 2.0) to ((top + bottom) / 2.0)

    private fun LineNode.normalizedCenter(): Pair<Double, Double>? = bounds?.let {
        val normalized = OcrGeometry.normalize(it, ownerImageWidth, ownerImageHeight)
        ((normalized.left + normalized.right) / 2.0) to ((normalized.top + normalized.bottom) / 2.0)
    }

    private fun union(first: OcrBounds?, second: OcrBounds?): OcrBounds? {
        if (first == null) return second
        if (second == null) return first
        return OcrBounds(
            left = min(first.left, second.left),
            top = min(first.top, second.top),
            right = max(first.right, second.right),
            bottom = max(first.bottom, second.bottom),
        )
    }

    private fun isValidDate(value: String): Boolean {
        val parts = Regex("\\d+").findAll(value).map { it.value.toInt() }.toList()
        if (parts.size != 3) return false
        return try {
            LocalDate.of(parts[2], parts[1], parts[0])
            true
        } catch (_: DateTimeException) {
            false
        }
    }

    private fun levenshtein(first: String, second: String): Int {
        if (first == second) return 0
        if (first.isEmpty()) return second.length
        if (second.isEmpty()) return first.length
        var previous = IntArray(second.length + 1) { it }
        for (i in first.indices) {
            val current = IntArray(second.length + 1)
            current[0] = i + 1
            for (j in second.indices) {
                current[j + 1] = min(
                    min(current[j] + 1, previous[j + 1] + 1),
                    previous[j] + if (first[i] == second[j]) 0 else 1,
                )
            }
            previous = current
        }
        return previous.last()
    }

    private fun SpatialRelation.toEvidence(): FieldEvidence = when (this) {
        SpatialRelation.SAME_LINE_RIGHT -> FieldEvidence.SAME_LINE_RIGHT
        SpatialRelation.BELOW -> FieldEvidence.BELOW_LABEL
        SpatialRelation.NEAR_BELOW -> FieldEvidence.NEAR_BELOW
        SpatialRelation.NEAR_RIGHT -> FieldEvidence.NEAR_RIGHT
        SpatialRelation.LOCAL_REGION -> FieldEvidence.LOCAL_REGION
        SpatialRelation.EXPECTED_REGION -> FieldEvidence.EXPECTED_REGION
    }

    private data class LineNode(
        val index: Int,
        val sideLineIndex: Int,
        val blockIndex: Int,
        val side: DocumentSide,
        val text: String,
        val bounds: OcrBounds?,
        val ownerImageWidth: Int,
        val ownerImageHeight: Int,
        val elements: List<ElementNode> = emptyList(),
        val segments: List<OcrFieldSegment> = emptyList(),
        val sourceKind: OcrSourceKind = OcrSourceKind.WHOLE_CARD,
        val retryTargetField: DocumentField? = null,
    )

    private data class ElementNode(
        val text: String,
        val bounds: OcrBounds?,
    )

    private data class LabelMatch(val alias: String, val evidence: FieldEvidence)

    private data class LabelOccurrence(
        val field: DocumentField,
        val side: DocumentSide,
        val index: Int,
        val lineIndexes: List<Int>,
        val bounds: OcrBounds?,
        val alias: String,
        val evidence: FieldEvidence,
        val ownerImageWidth: Int,
        val ownerImageHeight: Int,
        val segment: OcrFieldSegment?,
    )

    private data class ExtractedValue(
        val value: String,
        val line: LineNode,
        val valid: Boolean,
        val reconstructed: Boolean = false,
        val rawValue: String = value,
        val transformations: Set<TextTransformation> = emptySet(),
    )

    private data class ScoredCandidate(
        val rawValue: String,
        val displayValue: String,
        val canonicalValue: String,
        val side: DocumentSide,
        val score: Int,
        val evidence: Set<FieldEvidence>,
        val valid: Boolean,
        val bounds: OcrBounds?,
        val imageWidth: Int,
        val imageHeight: Int,
        val sourceKinds: Set<OcrSourceKind>,
        val retryTargetFields: Set<DocumentField>,
        val transformations: Set<TextTransformation>,
        val dedupGroupId: Int = 0,
    )

    private companion object {
        // Keep the resolver conservative when two labels produce similarly
        // supported values; a small score lead is not enough to guess.
        const val UNIQUE_SCORE_GAP = 31
        const val MAX_ELEMENT_GAP = 0.08
        const val MAX_ELEMENT_CENTER_DELTA = 0.04
        val DATE_PATTERN = Regex("(?<!\\d)\\d{1,2}\\s*[/.-]\\s*\\d{1,2}\\s*[/.-]\\s*\\d{4}(?!\\d)")
        val RECOVERABLE_DATE_PATTERN = Regex(
            "(?<![\\p{L}\\p{Nd}])[0-9O](?:\\s*[0-9O])?\\s*[/.-]\\s*" +
                "[0-9O](?:\\s*[0-9O])?\\s*[/.-]\\s*" +
                "[0-9O](?:\\s*[0-9O]){3}(?![\\p{L}\\p{Nd}])",
            RegexOption.IGNORE_CASE,
        )
        val SEX_VALUES = listOf("NAM", "NỮ", "NU", "MALE", "FEMALE", "M", "F")
        val NATIONALITY_VALUES = listOf("VIỆT NAM", "VIET NAM", "VIETNAM", "VNM")
    }
}
