package vn.cccd.bacreader.sdk

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.nfc.NfcAdapter
import android.os.Handler
import android.os.Looper
import androidx.activity.result.contract.ActivityResultContract
import vn.cccd.bacreader.biometric.camera.BiometricSessionHandle
import vn.cccd.bacreader.domain.LdsEvidencePart
import java.io.OutputStream
import java.util.UUID
import android.graphics.Bitmap
import vn.cccd.bacreader.biometric.RgbImage

data class CaptureCapabilities(
    val nfcSupported: Boolean,
    val nfcEnabled: Boolean,
    val cameraSupported: Boolean,
    val developmentModelsAvailable: Boolean,
    val productionAssuranceAvailable: Boolean = false,
)

/** Offline native capture. Host owns authenticated pairing, upload and server decisions. */
object EkycSdk {
    const val VERSION = "0.2.0-dev"

    fun capabilities(context: Context): CaptureCapabilities {
        val adapter = NfcAdapter.getDefaultAdapter(context)
        val assets = listOf("liveness/best_model.onnx", "recognition/face_recognition_sface_2021dec.onnx")
        return CaptureCapabilities(
            nfcSupported = adapter != null,
            nfcEnabled = adapter?.isEnabled == true,
            cameraSupported = context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY),
            developmentModelsAvailable = assets.all { path -> runCatching { context.assets.open(path).use { } }.isSuccess },
        )
    }

    fun captureContract(): ActivityResultContract<CaptureRequest, CaptureOutcome> = CaptureActivityContract()

    /** Must be called by the native host on logout/account switch/cancellation. */
    fun cancel(accountId: String) = SdkRuntime.cancel(accountId)

    fun dispose(evidenceHandle: String, accountId: String): Boolean =
        SdkRuntime.evidence.dispose(evidenceHandle, accountId)

    fun disposeAccount(accountId: String) = SdkRuntime.evidence.disposeOwner(accountId)

    /** Native-only streaming hook; opaque handles never grant ownership across accounts. */
    fun writeCardEvidence(handle: String, accountId: String, attemptId: String, part: LdsEvidencePart, output: OutputStream) {
        val session = SdkRuntime.evidence.borrow(handle, accountId, attemptId)
            ?: throw IllegalStateException("Evidence unavailable")
        val proof = session.chip?.cardEvidence ?: throw IllegalStateException("Card proof unavailable")
        proof.writeTo(part, output)
    }

    fun writePhotoEvidence(handle: String, accountId: String, attemptId: String, part: CapturePhotoPart, output: OutputStream) {
        val proof = SdkRuntime.evidence.borrow(handle, accountId, attemptId)
            ?: throw IllegalStateException("Evidence unavailable")
        proof.photos.writeTo(part, output)
    }
}

private class CaptureActivityContract : ActivityResultContract<CaptureRequest, CaptureOutcome>() {
    private var launch: SdkAttempt? = null
    private var rejection: CaptureError? = null

    override fun createIntent(context: Context, input: CaptureRequest): Intent {
        val start = SdkRuntime.begin(input)
        launch = start.first
        rejection = start.second
        return Intent(context, EkycCaptureActivity::class.java).apply {
            launch?.let { putExtra(EXTRA_TOKEN, it.token) }
            rejection?.let { putExtra(EXTRA_ERROR, it.name) }
        }
    }

    override fun parseResult(resultCode: Int, intent: Intent?): CaptureOutcome {
        val attempt = launch
        launch = null
        val rejected = rejection
        rejection = null
        if (attempt == null) return CaptureOutcome(CaptureStatus.FAILED, "", "", rejected ?: CaptureError.INTERNAL_ERROR)
        // Read the terminal record owned by this process, never client result booleans.
        val result = attempt.flow.terminal
        if (resultCode != Activity.RESULT_OK || result == null) {
            SdkRuntime.finish(attempt, CaptureError.INTERNAL_ERROR)
        }
        return attempt.flow.terminal ?: CaptureOutcome(CaptureStatus.FAILED, attempt.id, attempt.request.sessionId, CaptureError.INTERNAL_ERROR)
    }
}

internal const val EXTRA_TOKEN = "vn.cccd.bacreader.sdk.LAUNCH_TOKEN"
internal const val EXTRA_ERROR = "vn.cccd.bacreader.sdk.ERROR"

internal class SdkAttempt(val request: CaptureRequest, val id: String, val flow: CaptureCoordinator) {
    val token: String = UUID.randomUUID().toString()
    var payload: NativeCaptureEvidence? = NativeCaptureEvidence()
    var biometricSession: BiometricSessionHandle?
        get() = payload?.chip
        set(value) { payload?.chip = value }
    var evidenceHandle: String? = null
    var documentFields: vn.cccd.bacreader.ui.demo.DemoDocumentFields? = null
    var nfcResult: vn.cccd.bacreader.document.crosscheck.NfcDocumentResult? = null
    var faceResult: vn.cccd.bacreader.biometric.camera.BiometricResult? = null
    fun closeCapture() {
        payload?.close()
        payload = null
        documentFields = null; nfcResult = null; faceResult = null
    }
}

internal object SdkRuntime {
    private val mainHandler = Handler(Looper.getMainLooper())
    val evidence = EvidenceStore<NativeCaptureEvidence> { System.currentTimeMillis() }
    private var active: SdkAttempt? = null

    @Synchronized fun begin(request: CaptureRequest): Pair<SdkAttempt?, CaptureError?> {
        active?.let {
            if (it.flow.isCurrent(it.id)) return null to CaptureError.BUSY
            it.closeCapture()
            active = null
        }
        val flow = CaptureCoordinator { System.currentTimeMillis() }
        return when (val start = flow.begin(request)) {
            is CaptureStart.Rejected -> null to start.error
            is CaptureStart.Started -> {
                val attempt = SdkAttempt(request, start.attemptId, flow)
                active = attempt
                mainHandler.postDelayed({ expire(attempt) }, (request.expiresAtMillis - System.currentTimeMillis()).coerceAtLeast(0))
                attempt to null
            }
        }
    }

    @Synchronized fun find(token: String?): SdkAttempt? = active?.takeIf { it.token == token }

    @Synchronized fun finish(attempt: SdkAttempt, error: CaptureError? = null, cancelled: Boolean = false) {
        if (active !== attempt) return
        if (cancelled) attempt.flow.cancel(attempt.id)
        else if (error != null) attempt.flow.fail(attempt.id, error)
        attempt.closeCapture()
        active = null
    }

    @Synchronized fun capture(attempt: SdkAttempt): Boolean {
        if (active !== attempt || !attempt.flow.isCurrent(attempt.id)) return false
        val session = attempt.biometricSession ?: return false
        if (session.cardEvidence?.isComplete != true) return false
        val payload = attempt.payload ?: return false
        if (!payload.photos.isComplete) return false
        session.takePortrait()?.let { if (!it.isRecycled) it.recycle() }
        val handle = runCatching { evidence.put(attempt.request.accountId, attempt.id, attempt.request.expiresAtMillis, payload) }
            .getOrElse {
                attempt.payload = null
                attempt.flow.fail(attempt.id, CaptureError.INTERNAL_ERROR)
                return false
            }
        attempt.payload = null
        val conclusion = vn.cccd.bacreader.ui.demo.EkycSummaryStatus.derive(
            attempt.documentFields != null, attempt.nfcResult, attempt.faceResult)
        val face = attempt.faceResult
        val checks = mapOf("documentReadiness" to if (attempt.documentFields != null) "PASS" else "NOT_RUN",
            "nfcRead" to if (attempt.nfcResult?.overallStatus == vn.cccd.bacreader.document.crosscheck.NfcOverallStatus.SUCCESS) "PASS" else "FAIL",
            "documentComparison" to if (attempt.nfcResult?.crossCheck?.let {
                listOf(it.documentNumber, it.dateOfBirth, it.dateOfExpiry).all { field -> field == vn.cccd.bacreader.document.crosscheck.CrossCheckStatus.MATCH }
            } == true) "PASS" else "FAIL",
            "activeLiveness" to (face?.activeLiveness?.name ?: "NOT_RUN"),
            "passiveLiveness" to (face?.passiveLiveness?.name ?: "NOT_RUN"),
            "faceMatch" to (face?.faceMatch?.name ?: "NOT_RUN"))
        if (!attempt.flow.complete(attempt.id, handle, CaptureConclusion.valueOf(conclusion.name), checks)) {
            evidence.dispose(handle, attempt.request.accountId)
            return false
        }
        attempt.evidenceHandle = handle
        attempt.documentFields = null; attempt.nfcResult = null; attempt.faceResult = null
        active = null
        return true
    }

    @Synchronized fun cancel(owner: String) {
        active?.takeIf { it.request.accountId == owner }?.let { finish(it, cancelled = true) }
        evidence.disposeOwner(owner)
    }

    @Synchronized fun resetPhotos(token: String) { find(token)?.payload?.photos?.reset() }

    @Synchronized fun deliverDocument(token: String, fields: vn.cccd.bacreader.ui.demo.DemoDocumentFields): Boolean {
        val current = find(token)?.takeIf { it.flow.isCurrent(it.id) } ?: return false
        current.documentFields = fields
        return true
    }

    @Synchronized fun deliverNfc(token: String, result: vn.cccd.bacreader.document.crosscheck.NfcDocumentResult?, session: BiometricSessionHandle?) {
        val current = find(token)?.takeIf { it.flow.isCurrent(it.id) }
        if (current == null) { session?.close(); return }
        current.biometricSession?.close(); current.biometricSession = session
        current.nfcResult = result
    }

    @Synchronized fun deliverFace(token: String, result: vn.cccd.bacreader.biometric.camera.BiometricResult) {
        find(token)?.takeIf { it.flow.isCurrent(it.id) }?.faceResult = result
    }

    fun recordPhoto(token: String, part: CapturePhotoPart, bitmap: Bitmap) {
        val bytes = CapturePhotoEncoder.encode(bitmap) ?: return
        storePhoto(token, part, bytes)
    }

    fun recordSelfie(token: String, image: RgbImage) {
        val bytes = CapturePhotoEncoder.encode(image) ?: return
        storePhoto(token, CapturePhotoPart.SELFIE, bytes)
    }

    @Synchronized private fun storePhoto(token: String, part: CapturePhotoPart, bytes: ByteArray) {
        try {
            val attempt = find(token) ?: return
            if (!attempt.flow.isCurrent(attempt.id)) return
            attempt.payload?.photos?.capture(part, bytes)
        } finally { bytes.fill(0) }
    }

    @Synchronized private fun expire(attempt: SdkAttempt) {
        evidence.sweep()
        if (active === attempt && !attempt.flow.isCurrent(attempt.id)) {
            attempt.closeCapture()
            active = null
        }
    }
}
