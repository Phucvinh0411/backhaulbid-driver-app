package vn.cccd.bacreader.biometric.camera

enum class CameraError {
    PERMISSION_REQUIRED,
    FRONT_CAMERA_UNAVAILABLE,
    BIND_FAILED,
    ANALYSIS_FAILED,
    CONTROLLER_CLOSED,
}

sealed interface CameraState {
    data object IDLE : CameraState
    data object STARTING : CameraState
    data object RUNNING : CameraState
    data object STOPPED : CameraState
    data class ERROR(val error: CameraError) : CameraState
}
