package vn.cccd.bacreader.document.capture

import vn.cccd.bacreader.document.quality.DocumentQualityStatus

enum class DocumentSide { FRONT, BACK }

enum class DocumentCaptureMode { MANUAL, AUTO }

enum class DocumentCaptureState {
    CAPTURE_FRONT,
    FRONT_ALIGNING,
    FRONT_READY,
    FRONT_CAPTURING,
    FRONT_CROP_REVIEW,
    FRONT_PROCESSING_CROP,
    FRONT_PROCESSING_OCR,
    FRONT_ACCEPTED,
    CAPTURE_BACK,
    BACK_ALIGNING,
    BACK_READY,
    BACK_CAPTURING,
    BACK_CROP_REVIEW,
    BACK_PROCESSING_CROP,
    BACK_PROCESSING_OCR,
    BACK_ACCEPTED,
    PROCESSING_DOCUMENT,
    REVIEW_IF_NEEDED,
    DOCUMENT_INPUT_READY,
    ERROR,
}

data class DocumentCaptureConfig(
    val stableGoodFrames: Int = 5,
    val mode: DocumentCaptureMode = DocumentCaptureMode.MANUAL,
) {
    init { require(stableGoodFrames > 0) }
}

data class DocumentCaptureSnapshot(
    val state: DocumentCaptureState,
    val side: DocumentSide,
    val goodFrameCount: Int,
    val capturedSideCount: Int,
)

data class DocumentCaptureDecision(
    val state: DocumentCaptureState,
    val side: DocumentSide,
    val goodFrameCount: Int,
    val capturedSideCount: Int,
    val shouldCapture: Boolean,
)

/** Pure front/back capture state machine; image ownership remains with the Activity. */
class DocumentCaptureSession(
    private val config: DocumentCaptureConfig = DocumentCaptureConfig(),
) {
    private var state = DocumentCaptureState.CAPTURE_FRONT
    private var side = DocumentSide.FRONT
    private var goodFrameCount = 0
    private var frontCaptured = false
    private var backCaptured = false

    fun snapshot(): DocumentCaptureSnapshot = DocumentCaptureSnapshot(
        state = state,
        side = side,
        goodFrameCount = goodFrameCount,
        capturedSideCount = listOf(frontCaptured, backCaptured).count { it },
    )

    fun reset(): DocumentCaptureSnapshot {
        state = DocumentCaptureState.CAPTURE_FRONT
        side = DocumentSide.FRONT
        goodFrameCount = 0
        frontCaptured = false
        backCaptured = false
        return snapshot()
    }

    fun onQuality(status: DocumentQualityStatus): DocumentCaptureDecision {
        if (state !in setOf(
                DocumentCaptureState.CAPTURE_FRONT,
                DocumentCaptureState.FRONT_ALIGNING,
                DocumentCaptureState.FRONT_READY,
                DocumentCaptureState.CAPTURE_BACK,
                DocumentCaptureState.BACK_ALIGNING,
                DocumentCaptureState.BACK_READY,
            )
        ) return decision(false)

        val isFront = side == DocumentSide.FRONT
        if (status != DocumentQualityStatus.GOOD) {
            goodFrameCount = 0
            state = if (isFront) DocumentCaptureState.FRONT_ALIGNING else DocumentCaptureState.BACK_ALIGNING
            return decision(false)
        }

        goodFrameCount++
        state = if (isFront) DocumentCaptureState.FRONT_READY else DocumentCaptureState.BACK_READY
        if (config.mode == DocumentCaptureMode.AUTO && goodFrameCount >= config.stableGoodFrames) {
            state = if (isFront) DocumentCaptureState.FRONT_CAPTURING else DocumentCaptureState.BACK_CAPTURING
            return decision(true)
        }
        return decision(false)
    }

    /** Starts a manual capture only after the UI has observed a quality-approved frame. */
    fun requestCapture(currentQuality: DocumentQualityStatus): DocumentCaptureDecision {
        if (config.mode != DocumentCaptureMode.MANUAL ||
            currentQuality != DocumentQualityStatus.GOOD ||
            goodFrameCount < config.stableGoodFrames ||
            state !in setOf(DocumentCaptureState.FRONT_READY, DocumentCaptureState.BACK_READY)
        ) {
            return decision(false)
        }
        state = if (side == DocumentSide.FRONT) {
            DocumentCaptureState.FRONT_CAPTURING
        } else {
            DocumentCaptureState.BACK_CAPTURING
        }
        return decision(true)
    }

    fun onCaptureCompleted(success: Boolean): DocumentCaptureSnapshot {
        if (!success) {
            goodFrameCount = 0
            state = if (side == DocumentSide.FRONT) DocumentCaptureState.FRONT_ALIGNING else DocumentCaptureState.BACK_ALIGNING
            return snapshot()
        }
        goodFrameCount = 0
        if (side == DocumentSide.FRONT) {
            frontCaptured = true
            state = DocumentCaptureState.FRONT_ACCEPTED
        } else {
            backCaptured = true
            state = DocumentCaptureState.BACK_ACCEPTED
        }
        return snapshot()
    }

    /** Moves a successful in-memory still into the whole-card crop review. */
    fun onStillCaptured(): DocumentCaptureSnapshot {
        state = when (side) {
            DocumentSide.FRONT -> DocumentCaptureState.FRONT_CROP_REVIEW
            DocumentSide.BACK -> DocumentCaptureState.BACK_CROP_REVIEW
        }
        return snapshot()
    }

    fun onCropProcessing(): DocumentCaptureSnapshot {
        state = when (side) {
            DocumentSide.FRONT -> DocumentCaptureState.FRONT_PROCESSING_CROP
            DocumentSide.BACK -> DocumentCaptureState.BACK_PROCESSING_CROP
        }
        return snapshot()
    }

    fun onCropReadyForOcr(): DocumentCaptureSnapshot {
        state = when (side) {
            DocumentSide.FRONT -> DocumentCaptureState.FRONT_PROCESSING_OCR
            DocumentSide.BACK -> DocumentCaptureState.BACK_PROCESSING_OCR
        }
        return snapshot()
    }

    fun onCropFailed(): DocumentCaptureSnapshot {
        state = when (side) {
            DocumentSide.FRONT -> DocumentCaptureState.FRONT_CROP_REVIEW
            DocumentSide.BACK -> DocumentCaptureState.BACK_CROP_REVIEW
        }
        return snapshot()
    }

    fun advance(): DocumentCaptureSnapshot {
        state = when (state) {
            DocumentCaptureState.FRONT_ACCEPTED -> {
                side = DocumentSide.BACK
                DocumentCaptureState.CAPTURE_BACK
            }
            DocumentCaptureState.BACK_ACCEPTED -> DocumentCaptureState.PROCESSING_DOCUMENT
            else -> state
        }
        goodFrameCount = 0
        return snapshot()
    }

    fun markReview(): DocumentCaptureSnapshot {
        state = DocumentCaptureState.REVIEW_IF_NEEDED
        return snapshot()
    }

    fun markInputReady(): DocumentCaptureSnapshot {
        state = DocumentCaptureState.DOCUMENT_INPUT_READY
        return snapshot()
    }

    fun retry(retrySide: DocumentSide): DocumentCaptureSnapshot {
        side = retrySide
        goodFrameCount = 0
        if (retrySide == DocumentSide.FRONT) {
            frontCaptured = false
            backCaptured = false
            state = DocumentCaptureState.CAPTURE_FRONT
        } else {
            backCaptured = false
            state = DocumentCaptureState.CAPTURE_BACK
        }
        return snapshot()
    }

    private fun decision(shouldCapture: Boolean) = DocumentCaptureDecision(
        state = state,
        side = side,
        goodFrameCount = goodFrameCount,
        capturedSideCount = listOf(frontCaptured, backCaptured).count { it },
        shouldCapture = shouldCapture,
    )
}
