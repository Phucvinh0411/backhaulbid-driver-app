package vn.cccd.bacreader.document.capture

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** A point in the upright Bitmap coordinate space used by the cropper. */
data class CropPoint(
    val x: Double,
    val y: Double,
)

/** Clockwise whole-card quadrilateral: top-left, top-right, bottom-right, bottom-left. */
data class CropQuad(
    val topLeft: CropPoint,
    val topRight: CropPoint,
    val bottomRight: CropPoint,
    val bottomLeft: CropPoint,
) {
    val points: List<CropPoint> get() = listOf(topLeft, topRight, bottomRight, bottomLeft)
}

data class CropViewport(
    val left: Double,
    val top: Double,
    val right: Double,
    val bottom: Double,
) {
    val width: Double get() = right - left
    val height: Double get() = bottom - top
}

data class CropOutputSize(
    val width: Int,
    val height: Int,
)

/** Pure validation and geometry rules for a manually selected whole-card crop. */
object CropGeometry {
    const val CARD_ASPECT_RATIO = 85.60 / 53.98
    private const val INITIAL_BORDER_FRACTION = 0.05
    private const val MIN_AREA_RATIO = 0.01
    private const val EPSILON = 1e-6

    fun initialQuad(imageWidth: Int, imageHeight: Int): CropQuad {
        require(imageWidth > 0 && imageHeight > 0)
        val width = min(
            imageWidth * (1.0 - INITIAL_BORDER_FRACTION * 2.0),
            imageHeight * (1.0 - INITIAL_BORDER_FRACTION * 2.0) * CARD_ASPECT_RATIO,
        )
        val height = width / CARD_ASPECT_RATIO
        val left = (imageWidth - width) / 2.0
        val top = (imageHeight - height) / 2.0
        return CropQuad(
            topLeft = CropPoint(left, top),
            topRight = CropPoint(left + width, top),
            bottomRight = CropPoint(left + width, top + height),
            bottomLeft = CropPoint(left, top + height),
        )
    }

    fun clamp(quad: CropQuad, width: Int, height: Int): CropQuad {
        require(width > 0 && height > 0)
        fun clampPoint(point: CropPoint) = CropPoint(
            x = point.x.coerceIn(0.0, width.toDouble()),
            y = point.y.coerceIn(0.0, height.toDouble()),
        )
        return CropQuad(
            topLeft = clampPoint(quad.topLeft),
            topRight = clampPoint(quad.topRight),
            bottomRight = clampPoint(quad.bottomRight),
            bottomLeft = clampPoint(quad.bottomLeft),
        )
    }

    fun isValid(quad: CropQuad, width: Int, height: Int): Boolean {
        if (width <= 0 || height <= 0) return false
        if (quad.points.any { it.x !in 0.0..width.toDouble() || it.y !in 0.0..height.toDouble() }) return false
        val points = quad.points
        val signedCorners = points.indices.map { index ->
            cross(points[index], points[(index + 1) % points.size], points[(index + 2) % points.size])
        }
        if (signedCorners.any { it <= EPSILON }) return false
        if (segmentsIntersect(points[0], points[1], points[2], points[3])) return false
        if (segmentsIntersect(points[1], points[2], points[3], points[0])) return false
        return area(quad) >= width.toDouble() * height.toDouble() * MIN_AREA_RATIO
    }

    fun area(quad: CropQuad): Double {
        val points = quad.points
        return kotlin.math.abs(points.indices.sumOf { index ->
            val current = points[index]
            val next = points[(index + 1) % points.size]
            current.x * next.y - next.x * current.y
        }) / 2.0
    }

    private fun cross(first: CropPoint, second: CropPoint, third: CropPoint): Double =
        (second.x - first.x) * (third.y - first.y) - (second.y - first.y) * (third.x - first.x)

    private fun segmentsIntersect(a: CropPoint, b: CropPoint, c: CropPoint, d: CropPoint): Boolean {
        val abC = cross(a, b, c)
        val abD = cross(a, b, d)
        val cdA = cross(c, d, a)
        val cdB = cross(c, d, b)
        return ((abC > EPSILON && abD < -EPSILON) || (abC < -EPSILON && abD > EPSILON)) &&
            ((cdA > EPSILON && cdB < -EPSILON) || (cdA < -EPSILON && cdB > EPSILON))
    }
}

/** Explicit FIT_CENTER transforms between displayed view pixels and Bitmap pixels. */
object CropCoordinateMapper {
    fun fitCenter(imageWidth: Int, imageHeight: Int, viewWidth: Int, viewHeight: Int): CropViewport {
        require(imageWidth > 0 && imageHeight > 0 && viewWidth > 0 && viewHeight > 0)
        val scale = min(viewWidth.toDouble() / imageWidth, viewHeight.toDouble() / imageHeight)
        val displayedWidth = imageWidth * scale
        val displayedHeight = imageHeight * scale
        return CropViewport(
            left = (viewWidth - displayedWidth) / 2.0,
            top = (viewHeight - displayedHeight) / 2.0,
            right = (viewWidth + displayedWidth) / 2.0,
            bottom = (viewHeight + displayedHeight) / 2.0,
        )
    }

    fun bitmapToView(point: CropPoint, viewport: CropViewport, imageWidth: Int, imageHeight: Int): CropPoint {
        require(imageWidth > 0 && imageHeight > 0 && viewport.width > 0.0 && viewport.height > 0.0)
        return CropPoint(
            viewport.left + point.x / imageWidth * viewport.width,
            viewport.top + point.y / imageHeight * viewport.height,
        )
    }

    fun viewToBitmap(point: CropPoint, viewport: CropViewport, imageWidth: Int, imageHeight: Int): CropPoint {
        require(imageWidth > 0 && imageHeight > 0 && viewport.width > 0.0 && viewport.height > 0.0)
        return CropPoint(
            (point.x - viewport.left) / viewport.width * imageWidth,
            (point.y - viewport.top) / viewport.height * imageHeight,
        )
    }
}

/** Bounded output policy that preserves the physical card aspect without arbitrary upscaling. */
object CropOutputPolicy {
    fun forQuad(
        quad: CropQuad,
        maxDimension: Int = 2400,
        cardAspectRatio: Double = CropGeometry.CARD_ASPECT_RATIO,
    ): CropOutputSize {
        require(maxDimension >= 2 && cardAspectRatio > 1.0)
        val points = quad.points
        val sourceWidth = (distance(points[0], points[1]) + distance(points[3], points[2])) / 2.0
        val sourceHeight = (distance(points[0], points[3]) + distance(points[1], points[2])) / 2.0
        if (sourceWidth <= 0.0 || sourceHeight <= 0.0) return CropOutputSize(2, 2)

        val unscaledWidth = min(sourceWidth, sourceHeight * cardAspectRatio)
        val scale = min(1.0, maxDimension.toDouble() / max(unscaledWidth, unscaledWidth / cardAspectRatio))
        val width = max(2, (unscaledWidth * scale).roundToInt())
        val height = max(2, (width / cardAspectRatio).roundToInt())
        return CropOutputSize(width, height)
    }

    private fun distance(first: CropPoint, second: CropPoint): Double = hypot(second.x - first.x, second.y - first.y)
}
