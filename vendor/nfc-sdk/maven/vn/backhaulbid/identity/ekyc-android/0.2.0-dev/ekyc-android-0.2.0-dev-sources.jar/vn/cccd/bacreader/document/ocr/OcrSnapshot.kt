package vn.cccd.bacreader.document.ocr

import java.util.Collections
import vn.cccd.bacreader.document.capture.DocumentSide
import vn.cccd.bacreader.document.resolver.DocumentField

data class OcrPoint(
    val x: Int,
    val y: Int,
)

data class OcrBounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
)

data class OcrElementSnapshot(
    val text: String,
    val bounds: OcrBounds?,
    val cornerPoints: List<OcrPoint>,
    val confidence: Float?,
)

data class OcrLineSnapshot(
    val text: String,
    val bounds: OcrBounds?,
    val cornerPoints: List<OcrPoint>,
    val confidence: Float?,
    val elements: List<OcrElementSnapshot>,
    /** Provenance is attached per line so merged whole-card/ROI snapshots remain auditable. */
    val sourceKind: OcrSourceKind = OcrSourceKind.WHOLE_CARD,
    val retryTargetField: DocumentField? = null,
)

data class OcrBlockSnapshot(
    val text: String,
    val bounds: OcrBounds?,
    val cornerPoints: List<OcrPoint>,
    val confidence: Float?,
    val lines: List<OcrLineSnapshot>,
)

/** ML Kit-independent, application-owned OCR result for one accepted document image. */
data class OcrSnapshot(
    val fullText: String,
    val blocks: List<OcrBlockSnapshot>,
    val imageWidth: Int,
    val imageHeight: Int,
    val rotationDegrees: Int,
    val documentSide: DocumentSide,
)

/** Internal conversion inputs. The factory always copies values and nested collections. */
internal data class OcrElementInput(
    val text: String,
    val bounds: OcrBounds?,
    val cornerPoints: List<OcrPoint>,
    val confidence: Float?,
)

internal data class OcrLineInput(
    val text: String,
    val bounds: OcrBounds?,
    val cornerPoints: List<OcrPoint>,
    val confidence: Float?,
    val elements: List<OcrElementInput>,
    val sourceKind: OcrSourceKind = OcrSourceKind.WHOLE_CARD,
    val retryTargetField: DocumentField? = null,
)

internal data class OcrBlockInput(
    val text: String,
    val bounds: OcrBounds?,
    val cornerPoints: List<OcrPoint>,
    val confidence: Float?,
    val lines: List<OcrLineInput>,
)

internal object OcrSnapshotFactory {
    fun copy(
        fullText: String,
        blocks: List<OcrBlockInput>,
        imageWidth: Int,
        imageHeight: Int,
        rotationDegrees: Int,
        documentSide: DocumentSide,
    ): OcrSnapshot = OcrSnapshot(
        fullText = fullText,
        blocks = immutableCopy(blocks.map(::copyBlock)),
        imageWidth = imageWidth,
        imageHeight = imageHeight,
        rotationDegrees = rotationDegrees,
        documentSide = documentSide,
    )

    private fun copyBlock(source: OcrBlockInput): OcrBlockSnapshot = OcrBlockSnapshot(
        text = source.text,
        bounds = source.bounds?.let(::copyBounds),
        cornerPoints = immutableCopy(source.cornerPoints.map(::copyPoint)),
        confidence = source.confidence,
        lines = immutableCopy(source.lines.map(::copyLine)),
    )

    private fun copyLine(source: OcrLineInput): OcrLineSnapshot = OcrLineSnapshot(
        text = source.text,
        bounds = source.bounds?.let(::copyBounds),
        cornerPoints = immutableCopy(source.cornerPoints.map(::copyPoint)),
        confidence = source.confidence,
        elements = immutableCopy(source.elements.map(::copyElement)),
        sourceKind = source.sourceKind,
        retryTargetField = source.retryTargetField,
    )

    private fun copyElement(source: OcrElementInput): OcrElementSnapshot = OcrElementSnapshot(
        text = source.text,
        bounds = source.bounds?.let(::copyBounds),
        cornerPoints = immutableCopy(source.cornerPoints.map(::copyPoint)),
        confidence = source.confidence,
    )

    private fun copyPoint(source: OcrPoint) = OcrPoint(source.x, source.y)

    private fun copyBounds(source: OcrBounds) = OcrBounds(source.left, source.top, source.right, source.bottom)

    private fun <T> immutableCopy(source: List<T>): List<T> =
        Collections.unmodifiableList(source.toList())
}

/** Returns a source-tagged immutable copy for a targeted ROI OCR attempt. */
fun OcrSnapshot.withSource(
    sourceKind: OcrSourceKind,
    retryTargetField: DocumentField? = null,
): OcrSnapshot = OcrSnapshotFactory.copy(
    fullText = fullText,
    blocks = blocks.map { block ->
        OcrBlockInput(
            text = block.text,
            bounds = block.bounds,
            cornerPoints = block.cornerPoints,
            confidence = block.confidence,
            lines = block.lines.map { line ->
                OcrLineInput(
                    text = line.text,
                    bounds = line.bounds,
                    cornerPoints = line.cornerPoints,
                    confidence = line.confidence,
                    elements = line.elements.map { element ->
                        OcrElementInput(
                            text = element.text,
                            bounds = element.bounds,
                            cornerPoints = element.cornerPoints,
                            confidence = element.confidence,
                        )
                    },
                    sourceKind = sourceKind,
                    retryTargetField = retryTargetField,
                )
            },
        )
    },
    imageWidth = imageWidth,
    imageHeight = imageHeight,
    rotationDegrees = rotationDegrees,
    documentSide = documentSide,
)

/** Merges a targeted ROI OCR snapshot without losing whole-card coordinates. */
object OcrSnapshotMerger {
    fun merge(
        base: OcrSnapshot,
        roi: OcrSnapshot,
        roiLeft: Int,
        roiTop: Int,
    ): OcrSnapshot {
        require(base.documentSide == roi.documentSide) { "OCR sides must match" }
        val translatedBlocks = roi.blocks.map { block ->
            OcrBlockInput(
                text = block.text,
                bounds = block.bounds?.translate(roiLeft, roiTop),
                cornerPoints = block.cornerPoints.map { it.translate(roiLeft, roiTop) },
                confidence = block.confidence,
                lines = block.lines.map { line ->
                    OcrLineInput(
                        text = line.text,
                        bounds = line.bounds?.translate(roiLeft, roiTop),
                        cornerPoints = line.cornerPoints.map { it.translate(roiLeft, roiTop) },
                        confidence = line.confidence,
                        elements = line.elements.map { element ->
                            OcrElementInput(
                                text = element.text,
                                bounds = element.bounds?.translate(roiLeft, roiTop),
                                cornerPoints = element.cornerPoints.map { it.translate(roiLeft, roiTop) },
                                confidence = element.confidence,
                            )
                        },
                        sourceKind = line.sourceKind,
                        retryTargetField = line.retryTargetField,
                    )
                },
            )
        }
        val baseBlocks = base.blocks.map { block ->
            OcrBlockInput(
                text = block.text,
                bounds = block.bounds,
                cornerPoints = block.cornerPoints,
                confidence = block.confidence,
                lines = block.lines.map { line ->
                    OcrLineInput(
                        text = line.text,
                        bounds = line.bounds,
                        cornerPoints = line.cornerPoints,
                        confidence = line.confidence,
                        elements = line.elements.map { element ->
                            OcrElementInput(element.text, element.bounds, element.cornerPoints, element.confidence)
                        },
                        sourceKind = line.sourceKind,
                        retryTargetField = line.retryTargetField,
                    )
                },
            )
        }
        return OcrSnapshotFactory.copy(
            fullText = listOf(base.fullText, roi.fullText).filter(String::isNotBlank).joinToString("\n"),
            blocks = baseBlocks + translatedBlocks,
            imageWidth = base.imageWidth,
            imageHeight = base.imageHeight,
            rotationDegrees = base.rotationDegrees,
            documentSide = base.documentSide,
        )
    }

    private fun OcrBounds.translate(left: Int, top: Int): OcrBounds =
        OcrBounds(this.left + left, this.top + top, this.right + left, this.bottom + top)

    private fun OcrPoint.translate(left: Int, top: Int): OcrPoint = OcrPoint(x + left, y + top)
}
