package vn.cccd.bacreader.ui.demo

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Shared BackHaulBid semantic palette; matches the reviewed web preview. */
object EkycColors {
    val Brand = Color(0xFF1B4965)
    val BrandSoft = Color(0xFFE6EEF4)
    val Ink = Color(0xFF0F1E2E)
    val Muted = Color(0xFF4A5B6C)
    val Canvas = Color(0xFFF3F5F8)
    val Line = Color(0xFFDCE2E9)
    val Success = Color(0xFF155C34)
    val SuccessSoft = Color(0xFFE5F4EC)
    val Warning = Color(0xFF7A4700)
    val WarningSoft = Color(0xFFFDF1DC)
    val Danger = Color(0xFF8F1C13)
    val DangerSoft = Color(0xFFFDECEA)
}

private val EkycLightColors = lightColorScheme(
    primary = EkycColors.Brand, onPrimary = Color.White,
    primaryContainer = EkycColors.BrandSoft, onPrimaryContainer = EkycColors.Brand,
    secondary = EkycColors.Brand, onSecondary = Color.White,
    secondaryContainer = EkycColors.BrandSoft, onSecondaryContainer = EkycColors.Ink,
    background = EkycColors.Canvas, onBackground = EkycColors.Ink,
    surface = Color.White, onSurface = EkycColors.Ink,
    surfaceVariant = EkycColors.Canvas, onSurfaceVariant = EkycColors.Muted,
    outline = EkycColors.Muted, outlineVariant = EkycColors.Line,
    error = EkycColors.Danger, onError = Color.White,
    errorContainer = EkycColors.DangerSoft, onErrorContainer = EkycColors.Danger,
)

private val EkycTypography = Typography(
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontSize = 24.sp, lineHeight = 32.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontSize = 13.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    labelSmall = TextStyle(fontSize = 12.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun EkycTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = EkycLightColors,
        typography = EkycTypography,
        content = content,
    )
}
