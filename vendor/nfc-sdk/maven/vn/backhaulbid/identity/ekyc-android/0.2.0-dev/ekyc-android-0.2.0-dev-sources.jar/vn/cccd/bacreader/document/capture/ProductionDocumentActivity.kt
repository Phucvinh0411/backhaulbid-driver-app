package vn.cccd.bacreader.document.capture

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.OnBackPressedCallback
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.camera.view.PreviewView
import vn.cccd.bacreader.biometric.camera.CameraPermissionClassifier
import vn.cccd.bacreader.biometric.camera.CameraPermissionState
import vn.cccd.bacreader.ui.EkycUiPolicy
import vn.cccd.bacreader.ui.SecureWindowPolicy
import vn.cccd.bacreader.ui.demo.EkycTheme

/** Production-facing Compose host for the existing document capture engine. */
class ProductionDocumentActivity : ComponentActivity() {
    private lateinit var coordinator: DocumentCaptureCoordinator
    private lateinit var previewView: PreviewView
    private lateinit var cropView: DocumentCropView
    private var permissionRequested by mutableStateOf(false)
    private var requestInFlight by mutableStateOf(false)
    private var permissionState by mutableStateOf(CameraPermissionState.CAMERA_PERMISSION_UNKNOWN)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        requestInFlight = false
        permissionRequested = true
        refreshPermissionState(granted)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SecureWindowPolicy.apply(this, EkycUiPolicy.forBuild(false))
        if (!vn.cccd.bacreader.sdk.SdkCaptureGuard.attach(this)) return
        permissionRequested = savedInstanceState?.getBoolean(KEY_PERMISSION_REQUESTED) ?: false
        previewView = PreviewView(this)
        cropView = DocumentCropView(this)
        previewView.contentDescription = "Xem trước camera để căn chỉnh toàn bộ CCCD"
        cropView.contentDescription = "Điều chỉnh bốn góc để bao quanh toàn bộ CCCD"
        coordinator = DocumentCaptureCoordinator(this, ::finishWithResult) { side, bitmap ->
            intent.getStringExtra(vn.cccd.bacreader.sdk.EXTRA_TOKEN)?.let { token ->
                vn.cccd.bacreader.sdk.SdkRuntime.recordPhoto(token,
                    if (side == DocumentSide.FRONT) vn.cccd.bacreader.sdk.CapturePhotoPart.DOCUMENT_FRONT else vn.cccd.bacreader.sdk.CapturePhotoPart.DOCUMENT_BACK,
                    bitmap)
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = finishCancelled()
        })
        setContent {
            EkycTheme {
                val state by coordinator.state.collectAsState()
                ProductionDocumentScreen(
                    state = state,
                    permissionState = permissionState,
                    previewView = previewView,
                    cropView = cropView,
                    onCapture = coordinator::capture,
                    onConfirmCrop = {
                        cropView.currentQuad()?.let(coordinator::confirmCrop)
                    },
                    onRetakeCrop = coordinator::retakeCrop,
                    onResetCrop = cropView::resetQuad,
                    onPermissionAction = ::onPermissionAction,
                    onCancel = ::finishCancelled,
                    showDebugDiagnostics = false,
                )
            }
        }
        refreshPermissionState()
    }

    override fun onResume() {
        super.onResume()
        if (::coordinator.isInitialized && !requestInFlight) {
            refreshPermissionState()
        }
    }

    override fun onPause() {
        if (::coordinator.isInitialized) coordinator.stopCamera()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean(KEY_PERMISSION_REQUESTED, permissionRequested)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (::coordinator.isInitialized) coordinator.close()
        if (::cropView.isInitialized) cropView.clear()
        super.onDestroy()
    }

    private fun refreshPermissionState(grantedOverride: Boolean? = null) {
        val granted = grantedOverride ?: ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        permissionState = CameraPermissionClassifier.classify(
            isGranted = granted,
            shouldShowRationale = shouldShowRequestPermissionRationale(Manifest.permission.CAMERA),
            requestAttempted = permissionRequested,
        )
        if (permissionState == CameraPermissionState.CAMERA_PERMISSION_GRANTED) {
            coordinator.startCamera(this, previewView)
        }
    }

    private fun onPermissionAction() {
        when (permissionState) {
            CameraPermissionState.CAMERA_PERMISSION_GRANTED -> coordinator.startCamera(this, previewView)
            CameraPermissionState.CAMERA_PERMISSION_PERMANENTLY_DENIED -> {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:$packageName".toUri()))
            }
            else -> {
                permissionRequested = true
                requestInFlight = true
                permissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun finishWithResult(completion: ProductionDocumentCompletion) {
        intent.getStringExtra(vn.cccd.bacreader.sdk.EXTRA_TOKEN)?.let { token ->
            val accepted = completion.readiness.isReady && completion.documentNumber != null && completion.birthYYMMDD != null && completion.expiryYYMMDD != null &&
                vn.cccd.bacreader.sdk.SdkRuntime.deliverDocument(token, vn.cccd.bacreader.ui.demo.DemoDocumentFields(
                    completion.documentNumber, completion.birthYYMMDD, completion.expiryYYMMDD, completion.fullNameRaw, completion.sex, completion.nationality))
            setResult(if (accepted) RESULT_OK else RESULT_CANCELED)
            finish()
            return
        }
        setResult(
            RESULT_OK,
            Intent().apply {
                putExtra(EXTRA_REQUIRED_FIELDS_READY, completion.readiness.isReady)
                completion.profile?.let { putExtra(EXTRA_CARD_PROFILE, it) }
                completion.documentNumber?.let { putExtra(EXTRA_DOCUMENT_NUMBER, it) }
                completion.birthYYMMDD?.let { putExtra(EXTRA_BIRTH_YYMMDD, it) }
                completion.expiryYYMMDD?.let { putExtra(EXTRA_EXPIRY_YYMMDD, it) }
                completion.fullNameRaw?.let { putExtra(EXTRA_FULL_NAME_RAW, it) }
                completion.sex?.let { putExtra(EXTRA_SEX_RAW, it) }
                completion.nationality?.let { putExtra(EXTRA_NATIONALITY_RAW, it) }
                putExtra(EXTRA_READINESS_STATUS, completion.readiness.status.name)
                putExtra(EXTRA_RECOMMENDED_ACTION, completion.readiness.recommendedAction.name)
                putExtra(EXTRA_DOCUMENT_NUMBER_STATUS, completion.documentNumberStatus.name)
                putExtra(EXTRA_DATE_OF_BIRTH_STATUS, completion.dateOfBirthStatus.name)
                putExtra(EXTRA_DATE_OF_EXPIRY_STATUS, completion.dateOfExpiryStatus.name)
            },
        )
        finish()
    }

    private fun finishCancelled() {
        if (!::coordinator.isInitialized || isFinishing) return
        coordinator.cancel()
        setResult(RESULT_CANCELED)
        finish()
    }

    companion object {
        const val EXTRA_DOCUMENT_NUMBER = DocumentCaptureActivity.EXTRA_DOCUMENT_NUMBER
        const val EXTRA_BIRTH_YYMMDD = DocumentCaptureActivity.EXTRA_BIRTH_YYMMDD
        const val EXTRA_EXPIRY_YYMMDD = DocumentCaptureActivity.EXTRA_EXPIRY_YYMMDD
        const val EXTRA_FULL_NAME_RAW = DocumentCaptureActivity.EXTRA_FULL_NAME_RAW
        const val EXTRA_SEX_RAW = DocumentCaptureActivity.EXTRA_SEX_RAW
        const val EXTRA_NATIONALITY_RAW = DocumentCaptureActivity.EXTRA_NATIONALITY_RAW
        const val EXTRA_REQUIRED_FIELDS_READY = DocumentCaptureActivity.EXTRA_REQUIRED_FIELDS_READY
        const val EXTRA_CARD_PROFILE = DocumentCaptureActivity.EXTRA_CARD_PROFILE
        const val EXTRA_READINESS_STATUS = DocumentCaptureActivity.EXTRA_READINESS_STATUS
        const val EXTRA_RECOMMENDED_ACTION = DocumentCaptureActivity.EXTRA_RECOMMENDED_ACTION
        const val EXTRA_DOCUMENT_NUMBER_STATUS = DocumentCaptureActivity.EXTRA_DOCUMENT_NUMBER_STATUS
        const val EXTRA_DATE_OF_BIRTH_STATUS = DocumentCaptureActivity.EXTRA_DATE_OF_BIRTH_STATUS
        const val EXTRA_DATE_OF_EXPIRY_STATUS = DocumentCaptureActivity.EXTRA_DATE_OF_EXPIRY_STATUS
        private const val KEY_PERMISSION_REQUESTED = "production_document_permission_requested"

        fun createIntent(context: android.content.Context): Intent =
            Intent(context, ProductionDocumentActivity::class.java)
    }
}

@Composable
private fun ProductionDocumentScreen(
    state: ProductionDocumentUiState,
    permissionState: CameraPermissionState,
    previewView: PreviewView,
    cropView: DocumentCropView,
    onCapture: () -> Unit,
    onConfirmCrop: () -> Unit,
    onRetakeCrop: () -> Unit,
    onResetCrop: () -> Unit,
    onPermissionAction: () -> Unit,
    onCancel: () -> Unit,
    showDebugDiagnostics: Boolean,
) {
    vn.cccd.bacreader.ui.demo.EkycScaffold(
        title = "Chụp căn cước", step = 1, onExit = onCancel,
        bottom = {
            when (state.stage) {
                ProductionDocumentStage.CROP -> {
                    vn.cccd.bacreader.ui.demo.PrimaryButton("Dùng ảnh này", onConfirmCrop)
                    vn.cccd.bacreader.ui.demo.SecondaryButton("Chụp lại", onRetakeCrop)
                    vn.cccd.bacreader.ui.demo.SecondaryButton("Đặt lại khung", onResetCrop)
                }
                ProductionDocumentStage.CAPTURE, ProductionDocumentStage.ERROR -> {
                    if (permissionState == CameraPermissionState.CAMERA_PERMISSION_GRANTED) {
                        vn.cccd.bacreader.ui.demo.PrimaryButton("Chụp ảnh", onCapture, state.canCapture)
                    } else {
                        vn.cccd.bacreader.ui.demo.PrimaryButton(
                            if (permissionState == CameraPermissionState.CAMERA_PERMISSION_PERMANENTLY_DENIED) "Mở Cài đặt" else "Cho phép camera",
                            onPermissionAction,
                        )
                    }
                }
                else -> Unit
            }
        },
    ) {
            when (state.stage) {
                ProductionDocumentStage.CROP -> CropContent(state, cropView, onConfirmCrop, onRetakeCrop, onResetCrop)
                ProductionDocumentStage.PROCESSING -> ProcessingContent(state)
                ProductionDocumentStage.COMPLETE,
                ProductionDocumentStage.CANCELLED,
                -> ProcessingContent(state)
                ProductionDocumentStage.CAPTURE,
                ProductionDocumentStage.ERROR,
                -> CaptureContent(
                    state = state,
                    permissionState = permissionState,
                    previewView = previewView,
                    onCapture = onCapture,
                    onPermissionAction = onPermissionAction,
                    onCancel = onCancel,
                    showDebugDiagnostics = showDebugDiagnostics,
                )
            }
    }
}

@Composable
private fun CaptureContent(
    state: ProductionDocumentUiState,
    permissionState: CameraPermissionState,
    previewView: PreviewView,
    onCapture: () -> Unit,
    onPermissionAction: () -> Unit,
    onCancel: () -> Unit,
    showDebugDiagnostics: Boolean,
) {
    Text(
        if (state.side == DocumentSide.FRONT) "Mặt trước CCCD" else "Mặt sau CCCD",
        style = MaterialTheme.typography.titleLarge,
    )
    Text(
        "Đặt toàn bộ thẻ vào khung, giữ điện thoại ổn định và tránh lóa.",
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (permissionState != CameraPermissionState.CAMERA_PERMISSION_GRANTED) {
        PermissionCard(permissionState, onPermissionAction)
    } else {
        Box(modifier = Modifier.fillMaxWidth().height(280.dp)) {
            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize(),
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
                    .border(2.dp, Color.White, RoundedCornerShape(18.dp)),
            )
        }
        if (state.cameraStatus is DocumentCameraStatus.Error) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEDEA))) {
                Column(Modifier.padding(14.dp)) {
                    Text("Không thể mở camera. Vui lòng thử lại.")
                    OutlinedButton(onClick = onPermissionAction) { Text("Thử lại") }
                }
            }
        }
        QualityCard(state)
        state.message?.let { message ->
            Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (showDebugDiagnostics) {
            Text(
                "DEBUG: frames=${state.analyzerFrameCount} · analysis=${state.analysisWidth}×${state.analysisHeight} · rotation=${state.analysisRotationDegrees}° · quality=${state.quality.name} · stable=${state.stableGoodFrames}/${state.requiredStableGoodFrames} · capture=${state.canCapture}",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun PermissionCard(permissionState: CameraPermissionState, onPermissionAction: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4E5))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                when (permissionState) {
                    CameraPermissionState.CAMERA_PERMISSION_PERMANENTLY_DENIED -> "Quyền camera đang bị chặn."
                    CameraPermissionState.CAMERA_PERMISSION_DENIED -> "Cần quyền camera để chụp CCCD."
                    else -> "Cần quyền camera để tiếp tục."
                },
            )
            Button(onClick = onPermissionAction) {
                Text(
                    if (permissionState == CameraPermissionState.CAMERA_PERMISSION_PERMANENTLY_DENIED) {
                        "Mở cài đặt"
                    } else {
                        "Cho phép camera"
                    },
                )
            }
        }
    }
}

@Composable
private fun QualityCard(state: ProductionDocumentUiState) {
    val qualityText = when (state.quality) {
        vn.cccd.bacreader.document.quality.DocumentQualityStatus.NO_DOCUMENT -> "Đưa CCCD vào khung"
        vn.cccd.bacreader.document.quality.DocumentQualityStatus.DOCUMENT_TOO_SMALL -> "Đưa CCCD lại gần hơn"
        vn.cccd.bacreader.document.quality.DocumentQualityStatus.DOCUMENT_OUT_OF_FRAME -> "Giữ đủ bốn góc trong khung"
        vn.cccd.bacreader.document.quality.DocumentQualityStatus.TOO_DARK -> "Di chuyển tới nơi sáng hơn"
        vn.cccd.bacreader.document.quality.DocumentQualityStatus.TOO_BRIGHT -> "Giảm ánh sáng phản chiếu"
        vn.cccd.bacreader.document.quality.DocumentQualityStatus.TOO_BLURRY -> "Giữ điện thoại ổn định"
        vn.cccd.bacreader.document.quality.DocumentQualityStatus.GLARE_DETECTED -> "Tránh lóa trên bề mặt thẻ"
        vn.cccd.bacreader.document.quality.DocumentQualityStatus.UNSTABLE -> "Giữ CCCD yên vài giây"
        vn.cccd.bacreader.document.quality.DocumentQualityStatus.GOOD -> "Có thể chụp"
    }
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(qualityText, style = MaterialTheme.typography.titleMedium)
            LinearProgressIndicator(
                progress = { (state.stableGoodFrames.toFloat() / state.requiredStableGoodFrames).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun CropContent(
    state: ProductionDocumentUiState,
    cropView: DocumentCropView,
    onConfirmCrop: () -> Unit,
    onRetakeCrop: () -> Unit,
    onResetCrop: () -> Unit,
) {
    Text("Căn chỉnh toàn bộ thẻ", style = MaterialTheme.typography.titleLarge)
    Text("Kéo bốn góc bao quanh toàn bộ CCCD rồi xác nhận.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    AndroidView(
        factory = { cropView },
        update = { view ->
            if (view.tag !== state.cropBitmap) {
                view.tag = state.cropBitmap
                view.setBitmap(state.cropBitmap)
            }
        },
        modifier = Modifier.fillMaxWidth().height(280.dp),
    )
}

@Composable
private fun ProcessingContent(state: ProductionDocumentUiState) {
    Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            CircularProgressIndicator()
            Text(state.message ?: "Đang xử lý…")
        }
    }
}
