package vn.cccd.bacreader.biometric.liveness

/** Development-only passive liveness configuration. */
data class LivenessConfig(
    val inputSize: Int = 128,
    val cropExpansionFactor: Double = 1.5,
    val requiredValidFrames: Int = 10,
    val developmentThreshold: Float = 0.0f,
    val inferenceIntervalMillis: Long = 120L,
    val sessionTimeoutMillis: Long = 15_000L,
) {
    init {
        require(inputSize > 0)
        require(cropExpansionFactor > 0.0)
        require(requiredValidFrames > 0)
        require(inferenceIntervalMillis >= 0L)
        require(sessionTimeoutMillis > 0L)
    }
}
