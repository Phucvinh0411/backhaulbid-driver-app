package vn.cccd.bacreader.biometric.recognition

import kotlin.math.max
import kotlin.math.round
import vn.cccd.bacreader.biometric.RgbImage

/** OpenCV SFace-compatible five-point similarity warp to 112x112 RGB. */
internal class FaceAligner {
    internal fun align(image: RgbImage, landmarks: FaceLandmarks): RgbImage {
        require(landmarks.isUsable()) { "landmarks are not finite" }
        val source = landmarks.points
        val target = TARGET
        var sourceMeanX = 0.0
        var sourceMeanY = 0.0
        var targetMeanX = 0.0
        var targetMeanY = 0.0
        source.indices.forEach { i ->
            sourceMeanX += source[i].x
            sourceMeanY += source[i].y
            targetMeanX += target[i].first
            targetMeanY += target[i].second
        }
        sourceMeanX /= source.size
        sourceMeanY /= source.size
        targetMeanX /= source.size
        targetMeanY /= source.size

        var a = 0.0
        var b = 0.0
        var denominator = 0.0
        source.indices.forEach { i ->
            val sx = source[i].x - sourceMeanX
            val sy = source[i].y - sourceMeanY
            val dx = target[i].first - targetMeanX
            val dy = target[i].second - targetMeanY
            a += dx * sx + dy * sy
            b += dy * sx - dx * sy
            denominator += sx * sx + sy * sy
        }
        require(denominator > 1e-9) { "landmarks are degenerate" }
        val c = a / denominator
        val s = b / denominator
        val tx = targetMeanX - (c * sourceMeanX - s * sourceMeanY)
        val ty = targetMeanY - (s * sourceMeanX + c * sourceMeanY)
        val inverseScale = 1.0 / max(c * c + s * s, 1e-12)
        val pixels = ByteArray(OUTPUT_SIZE * OUTPUT_SIZE * RgbImage.CHANNELS)
        for (y in 0 until OUTPUT_SIZE) {
            for (x in 0 until OUTPUT_SIZE) {
                val dx = x - tx
                val dy = y - ty
                val sourceX = (c * dx + s * dy) * inverseScale
                val sourceY = (-s * dx + c * dy) * inverseScale
                val out = (y * OUTPUT_SIZE + x) * RgbImage.CHANNELS
                for (channel in 0 until RgbImage.CHANNELS) {
                    pixels[out + channel] = bilinear(image, sourceX, sourceY, channel).toByte()
                }
            }
        }
        return RgbImage(OUTPUT_SIZE, OUTPUT_SIZE, pixels)
    }

    private fun bilinear(image: RgbImage, x: Double, y: Double, channel: Int): Int {
        if (x < 0.0 || y < 0.0 || x >= image.width || y >= image.height) return 0
        val x0 = x.toInt()
        val y0 = y.toInt()
        val x1 = x0 + 1
        val y1 = y0 + 1
        val fx = (x - x0).coerceIn(0.0, 1.0)
        val fy = (y - y0).coerceIn(0.0, 1.0)
        fun sample(sampleX: Int, sampleY: Int): Int = if (
            sampleX in 0 until image.width && sampleY in 0 until image.height
        ) image.channelAt(sampleX, sampleY, channel) else 0
        val top = sample(x0, y0) * (1 - fx) + sample(x1, y0) * fx
        val bottom = sample(x0, y1) * (1 - fx) + sample(x1, y1) * fx
        return round(top * (1 - fy) + bottom * fy).toInt().coerceIn(0, 255)
    }

    companion object {
        const val OUTPUT_SIZE = 112
        val TARGET = listOf(
            38.2946 to 51.6963,
            73.5318 to 51.5014,
            56.0252 to 71.7366,
            41.5493 to 92.3655,
            70.7299 to 92.2041,
        )
    }
}
