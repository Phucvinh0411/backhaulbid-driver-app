package vn.cccd.bacreader.biometric.camera

/** Rotation helpers shared by camera conversion and face-coordinate consumers. */
internal object ImageRotation {
    fun normalize(rotationDegrees: Int): Int = when (rotationDegrees) {
        0, 90, 180, 270 -> rotationDegrees
        else -> throw IllegalArgumentException("Unsupported image rotation: $rotationDegrees")
    }

    fun uprightWidth(rawWidth: Int, rawHeight: Int, rotationDegrees: Int): Int = when (normalize(rotationDegrees)) {
        90, 270 -> rawHeight
        else -> rawWidth
    }

    fun uprightHeight(rawWidth: Int, rawHeight: Int, rotationDegrees: Int): Int = when (normalize(rotationDegrees)) {
        90, 270 -> rawWidth
        else -> rawHeight
    }

    /** Maps an upright output pixel to its source image coordinate. */
    fun sourceX(uprightX: Int, uprightY: Int, rawWidth: Int, rawHeight: Int, rotationDegrees: Int): Int = when (normalize(rotationDegrees)) {
        0 -> uprightX
        90 -> uprightY
        180 -> rawWidth - 1 - uprightX
        270 -> rawWidth - 1 - uprightY
        else -> error("unreachable")
    }

    fun sourceY(uprightX: Int, uprightY: Int, rawWidth: Int, rawHeight: Int, rotationDegrees: Int): Int = when (normalize(rotationDegrees)) {
        0 -> uprightY
        90 -> rawHeight - 1 - uprightX
        180 -> rawHeight - 1 - uprightY
        270 -> uprightX
        else -> error("unreachable")
    }
}
