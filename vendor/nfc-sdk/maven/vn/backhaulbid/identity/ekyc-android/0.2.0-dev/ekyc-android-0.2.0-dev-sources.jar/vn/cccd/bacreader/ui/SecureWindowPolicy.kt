package vn.cccd.bacreader.ui

import android.app.Activity
import android.view.WindowManager

/** Protect real document and face capture in development and release builds. */
object SecureWindowPolicy {
    @Suppress("UNUSED_PARAMETER")
    fun secureWindowRequired(isDebug: Boolean): Boolean = true

    fun apply(activity: Activity, isDebug: Boolean) {
        if (secureWindowRequired(isDebug)) {
            activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    fun apply(activity: Activity, policy: EkycUiPolicy) {
        if (policy.allowScreenCapture) {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
}
