package vn.cccd.bacreader.sdk

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import vn.cccd.bacreader.biometric.camera.BiometricResult
import vn.cccd.bacreader.biometric.camera.BiometricSessionHandle
import vn.cccd.bacreader.biometric.camera.ProductionBiometricActivity
import vn.cccd.bacreader.document.capture.ProductionDocumentActivity
import vn.cccd.bacreader.domain.FileReadStatus
import vn.cccd.bacreader.domain.IntegrityStatus
import vn.cccd.bacreader.domain.SignatureStatus
import vn.cccd.bacreader.document.crosscheck.CrossCheckStatus
import vn.cccd.bacreader.document.crosscheck.NfcOverallStatus
import vn.cccd.bacreader.ui.MainActivity
import vn.cccd.bacreader.ui.SecureWindowPolicy
import vn.cccd.bacreader.ui.demo.*

private enum class SurfaceStage { CONSENT, DOCUMENT_REVIEW, NFC_GUIDE, FACE_GUIDE, LAUNCHING }

/** SDK route: real adapters only. No fake result injection or development scenario routes. */
internal class EkycCaptureActivity : ComponentActivity() {
    private var attempt: SdkAttempt? = null
    private var surface by mutableStateOf(SurfaceStage.CONSENT)
    private var document: DemoDocumentFields? = null
    private var consent by mutableStateOf(false)
    private var showCancel by mutableStateOf(false)
    private var showOverview by mutableStateOf(false)
    private var launchingChild = false
    private val handler = Handler(Looper.getMainLooper())
    private val expiryCheck = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed) return
            if (attempt?.flow?.isCurrent(attempt?.id.orEmpty()) != true) finishWith(CaptureError.SESSION_EXPIRED)
            else handler.postDelayed(this, 1000)
        }
    }

    private val documentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        launchingChild = false
        if (!acceptCallback()) return@registerForActivityResult
        if (result.resultCode != RESULT_OK) { finishWith(cancelled = true); return@registerForActivityResult }
        val fields = attempt?.documentFields
        if (fields == null) {
            finishWith(CaptureError.DOCUMENT_NOT_READY)
            return@registerForActivityResult
        }
        document = fields
        val current = requireNotNull(attempt)
        if (!current.flow.advance(current.id, CaptureStage.DOCUMENT, CaptureStage.NFC)) {
            finishWith(CaptureError.INTERNAL_ERROR); return@registerForActivityResult
        }
        surface = SurfaceStage.NFC_GUIDE
    }

    private val nfcLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        launchingChild = false
        val session = attempt?.biometricSession
        if (!acceptCallback()) { session?.close(); return@registerForActivityResult }
        if (result.resultCode != RESULT_OK) { session?.close(); finishWith(cancelled = true); return@registerForActivityResult }
        val nfc = attempt?.nfcResult
        val requiredRead = nfc?.overallStatus == NfcOverallStatus.SUCCESS &&
            nfc.reads.dg1 == FileReadStatus.READ && nfc.reads.dg2 == FileReadStatus.READ && nfc.reads.sod == FileReadStatus.READ
        val mismatch = nfc?.crossCheck?.let {
            listOf(it.documentNumber, it.dateOfBirth, it.dateOfExpiry).any { value -> value != CrossCheckStatus.MATCH }
        } != false
        if (!requiredRead || mismatch || session?.cardEvidence?.isComplete != true ||
            nfc?.authenticity?.integrityStatus == IntegrityStatus.DG_HASH_MISMATCH ||
            nfc?.authenticity?.signatureStatus == SignatureStatus.INVALID) {
            session?.close()
            finishWith(CaptureError.REQUIRED_DATA_MISSING)
            return@registerForActivityResult
        }
        if (session.borrowPortrait() == null) { session.close(); finishWith(CaptureError.PORTRAIT_UNAVAILABLE); return@registerForActivityResult }
        val current = requireNotNull(attempt)
        current.biometricSession = session
        if (!current.flow.advance(current.id, CaptureStage.NFC, CaptureStage.FACE)) { finishWith(CaptureError.INTERNAL_ERROR); return@registerForActivityResult }
        surface = SurfaceStage.FACE_GUIDE
    }

    private val faceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        launchingChild = false
        if (!acceptCallback()) return@registerForActivityResult
        val biometric = if (result.resultCode == RESULT_OK) attempt?.faceResult else null
        if (biometric?.isCaptureComplete != true) {
            finishWith(if (biometric == null) null else CaptureError.BIOMETRIC_INCOMPLETE, cancelled = biometric == null)
            return@registerForActivityResult
        }
        val current = requireNotNull(attempt)
        if (!SdkRuntime.capture(current)) { finishWith(CaptureError.REQUIRED_DATA_MISSING); return@registerForActivityResult }
        finishWith()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SecureWindowPolicy.apply(this, isDebug = false)
        attempt = SdkRuntime.find(intent.getStringExtra(EXTRA_TOKEN))
        if (attempt == null) { setResult(RESULT_CANCELED); finish(); return }
        if (savedInstanceState != null) { finishWith(CaptureError.HOST_RECREATED); return }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { showCancel = true }
        })
        setContent { EkycTheme { CaptureSurface() } }
        handler.post(expiryCheck)
    }

    override fun onResume() {
        super.onResume()
        if (attempt != null && !isFinishing && !acceptCallback()) finishWith(CaptureError.SESSION_EXPIRED)
    }

    override fun onStop() {
        if (!launchingChild && !isFinishing && attempt?.flow?.terminal == null) finishWith(cancelled = true)
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacks(expiryCheck)
        document = null
        attempt?.let { current ->
            if (current.flow.terminal == null) SdkRuntime.finish(current, CaptureError.HOST_RECREATED)
        }
        super.onDestroy()
    }

    private fun acceptCallback(): Boolean = attempt?.let { it.flow.isCurrent(it.id) } == true

    private fun launchChild(intent: Intent, launcher: androidx.activity.result.ActivityResultLauncher<Intent>) {
        if (!acceptCallback() || launchingChild) return
        launchingChild = true
        surface = SurfaceStage.LAUNCHING
        runCatching { launcher.launch(intent.putExtra(EXTRA_TOKEN, requireNotNull(attempt).token)) }
            .onFailure { launchingChild = false; finishWith(CaptureError.INTERNAL_ERROR) }
    }

    private fun finishWith(error: CaptureError? = null, cancelled: Boolean = false) {
        if (isFinishing) return
        document = null
        attempt?.let { SdkRuntime.finish(it, error, cancelled) }
        setResult(RESULT_OK) // Typed terminal is held natively; result Intent contains no evidence/PII.
        finish()
    }

    @Composable private fun CaptureSurface() {
        val current = attempt ?: return
        val step = when (surface) {
            SurfaceStage.NFC_GUIDE -> 2
            SurfaceStage.FACE_GUIDE -> 3
            else -> 1
        }
        EkycScaffold("Xác minh danh tính", step, onExit = { showCancel = true }, bottom = {
            when (surface) {
                SurfaceStage.CONSENT -> PrimaryButton("Bắt đầu chụp giấy tờ", {
                    val caps = EkycSdk.capabilities(this@EkycCaptureActivity)
                    if (!caps.nfcSupported || !caps.nfcEnabled) finishWith(CaptureError.NFC_UNAVAILABLE)
                    else launchChild(ProductionDocumentActivity.createIntent(this@EkycCaptureActivity), documentLauncher)
                }, enabled = consent)
                SurfaceStage.DOCUMENT_REVIEW -> {
                    PrimaryButton("Tiếp tục đọc chip", {
                        if (current.flow.advance(current.id, CaptureStage.DOCUMENT, CaptureStage.NFC)) surface = SurfaceStage.NFC_GUIDE
                    })
                    SecondaryButton("Chụp lại hai mặt", {
                        document = null
                        SdkRuntime.resetPhotos(current.token)
                        launchChild(ProductionDocumentActivity.createIntent(this@EkycCaptureActivity), documentLauncher)
                    })
                }
                SurfaceStage.NFC_GUIDE -> PrimaryButton("Sẵn sàng đọc chip", {
                    document?.let { fields ->
                        launchChild(Intent(this@EkycCaptureActivity, ProductionNfcActivity::class.java)
                            .putExtra(MainActivity.EXTRA_PRODUCTION_UI, true).putExtra(MainActivity.EXTRA_DEMO_RETURN, true)
                            .putExtra("sdk_capture_evidence", true), nfcLauncher)
                    } ?: finishWith(CaptureError.DOCUMENT_NOT_READY)
                })
                SurfaceStage.FACE_GUIDE -> PrimaryButton("Mở camera", {
                    if (!EkycSdk.capabilities(this@EkycCaptureActivity).developmentModelsAvailable) finishWith(CaptureError.BIOMETRIC_MODEL_UNAVAILABLE)
                    else launchChild(Intent(this@EkycCaptureActivity, ProductionBiometricActivity::class.java)
                        .putExtra(vn.cccd.bacreader.biometric.camera.CameraActivity.EXTRA_PRODUCTION_UI, true), faceLauncher)
                })
                SurfaceStage.LAUNCHING -> Text("Đang mở bước tiếp theo…")
            }
        }) {
            StatusBadge(if (current.request.role == CaptureRole.SHIPPER) "Chủ hàng" else "Chủ xe", StatusTone.NEUTRAL)
            when (surface) {
                SurfaceStage.CONSENT -> {
                    Text("Xác minh bằng căn cước gắn chip", style = MaterialTheme.typography.headlineSmall)
                    InfoCard("Chuẩn bị căn cước của bạn", "Chụp hai mặt thẻ, đọc chip NFC và làm theo hướng dẫn khuôn mặt.")
                    Text("Cung cấp ảnh giấy tờ, ảnh khuôn mặt và dữ liệu chip cho ứng dụng tích hợp để kiểm tra. Đây là bản phát triển, chưa xác minh danh tính. Luồng BackHaulBid hiện tại hủy ảnh và dữ liệu chip trên máy chủ sau kiểm tra.")
                    Row {
                        Checkbox(consent, onCheckedChange = { consent = it })
                        Text("Tôi đồng ý thu thập và cung cấp bằng chứng giấy tờ, chip và khuôn mặt cho ứng dụng tích hợp trong phiên này.", Modifier.weight(1f).padding(top = 12.dp))
                    }
                }
                SurfaceStage.DOCUMENT_REVIEW -> {
                    Text("Kiểm tra trước khi đọc chip", style = MaterialTheme.typography.headlineSmall)
                    InfoCard("Đã đọc thông tin từ ảnh", "Số căn cước: ••••••••${document?.documentNumber?.takeLast(4).orEmpty()}")
                    Text("Nếu ảnh bị lóa, mờ hoặc không phải giấy tờ của bạn, hãy chụp lại. Thông tin trên chip sẽ được đối chiếu với ảnh.")
                }
                SurfaceStage.NFC_GUIDE -> {
                    Text("Áp thẻ vào lưng điện thoại", style = MaterialTheme.typography.headlineSmall)
                    InfoCard("Giữ thẻ cố định", "Tháo ốp dày và áp thẻ vào vị trí NFC. Giữ yên đến khi ứng dụng báo đã đọc xong.")
                }
                SurfaceStage.FACE_GUIDE -> {
                    Text("Kiểm tra khuôn mặt", style = MaterialTheme.typography.headlineSmall)
                    InfoCard("Chọn nơi đủ sáng", "Nhìn thẳng, chớp mắt và quay đầu theo hướng dẫn. Không dùng ảnh hoặc màn hình.")
                    SecondaryButton("Xem thông tin vừa đọc từ chip", { showOverview = true })
                }
                SurfaceStage.LAUNCHING -> CircularProgressIndicator()
            }
        }
        if (showOverview) AlertDialog(
            onDismissRequest = { showOverview = false },
            title = { Text("Thông tin vừa đọc từ chip") },
            text = {
                // Values just read on this phone, not a verification result; the server decides acceptance.
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val chip = current.nfcResult?.chipIdentity
                    ChipReadPresentation.rows(chip?.fullName, chip?.dateOfBirth, chip?.sex, java.time.LocalDate.now()).forEach { row ->
                        Text(row.label, style = MaterialTheme.typography.labelLarge)
                        Text(row.value)
                    }
                    Text("Kết quả xác thực sẽ được cập nhật sau khi máy chủ kiểm tra.")
                }
            },
            confirmButton = { TextButton(onClick = { showOverview = false }) { Text("Đóng") } },
        )
        if (showCancel) AlertDialog(
            onDismissRequest = { showCancel = false }, title = { Text("Dừng phiên xác minh?") },
            text = { Text("Dữ liệu thu thập trên thiết bị trong phiên này sẽ được giải phóng.") },
            confirmButton = { TextButton(onClick = { showCancel = false; finishWith(cancelled = true) }) { Text("Dừng phiên") } },
            dismissButton = { TextButton(onClick = { showCancel = false }) { Text("Tiếp tục") } },
        )
    }
}
