package vn.cccd.bacreader.document.mrz

import java.text.Normalizer

enum class MrzStatus {
    MRZ_VALID,
    MRZ_INVALID_CHECKSUM,
    MRZ_NOT_FOUND,
    MRZ_UNSUPPORTED_FORMAT,
}

data class MrzResult(
    val status: MrzStatus,
    val documentNumber: String? = null,
    val birthYYMMDD: String? = null,
    val expiryYYMMDD: String? = null,
    val lines: List<String> = emptyList(),
)

object MrzChecksum {
    private val weights = intArrayOf(7, 3, 1)

    fun digit(value: String): Char {
        var sum = 0
        value.forEachIndexed { index, char ->
            sum += valueOf(char) * weights[index % weights.size]
        }
        return ('0'.code + (sum % 10)).toChar()
    }

    fun isValid(value: String, checkDigit: Char): Boolean =
        checkDigit in '0'..'9' && digit(value) == checkDigit

    private fun valueOf(char: Char): Int = when {
        char == '<' -> 0
        char in '0'..'9' -> char - '0'
        char in 'A'..'Z' -> char - 'A' + 10
        else -> throw IllegalArgumentException("Unsupported MRZ character")
    }
}

/** Strict TD1 (three lines, thirty characters) parser for OCR output. */
class MrzParser {
    fun parse(rawText: String): MrzResult {
        val candidates = rawText
            .split('\n', '\r')
            .map(::normalizeLine)
            .filter { it.isNotEmpty() }
        if (candidates.size < 3) return MrzResult(MrzStatus.MRZ_NOT_FOUND)

        val lines = candidates.windowed(3).firstOrNull { window -> window.all { it.length == 30 } }
            ?: return MrzResult(MrzStatus.MRZ_UNSUPPORTED_FORMAT)
        val document = lines[0].substring(5, 14)
        val birth = lines[1].substring(0, 6)
        val expiry = lines[1].substring(8, 14)
        val valid = MrzChecksum.isValid(document, lines[0][14]) &&
            MrzChecksum.isValid(birth, lines[1][6]) &&
            MrzChecksum.isValid(expiry, lines[1][14])
        if (!valid) return MrzResult(MrzStatus.MRZ_INVALID_CHECKSUM, lines = lines)
        return MrzResult(
            status = MrzStatus.MRZ_VALID,
            documentNumber = document.trim('<').ifEmpty { null },
            birthYYMMDD = birth,
            expiryYYMMDD = expiry,
            lines = lines,
        )
    }

    private fun normalizeLine(value: String): String {
        val decomposed = Normalizer.normalize(value.uppercase(), Normalizer.Form.NFD)
            .replace("Đ", "D")
        return decomposed
            .filter { it in 'A'..'Z' || it in '0'..'9' || it == '<' }
    }
}
