package vn.cccd.bacreader.biometric.detection

import vn.cccd.bacreader.biometric.recognition.FaceLandmarks

/** Integer face bounds in the analyzed frame coordinate space. */
data class FaceBounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

/** Detector output only; it contains no image pixels and is safe to pass to quality policy. */
data class DetectedFace(
    val bounds: FaceBounds,
    val trackingId: Int?,
    val headEulerAngleX: Float,
    val headEulerAngleY: Float,
    val headEulerAngleZ: Float,
    val landmarks: FaceLandmarks? = null,
    /** ML Kit classification outputs; null means the detector did not provide a signal. */
    val leftEyeOpenProbability: Float? = null,
    val rightEyeOpenProbability: Float? = null,
)
