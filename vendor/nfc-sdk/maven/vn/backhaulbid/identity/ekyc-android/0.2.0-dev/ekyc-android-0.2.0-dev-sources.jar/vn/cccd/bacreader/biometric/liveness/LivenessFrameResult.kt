package vn.cccd.bacreader.biometric.liveness

enum class LivenessQualityStatus {
    GOOD,
    REJECTED,
}

/** Raw MiniFAS result for one quality-approved frame; not a final identity decision. */
data class LivenessFrameResult(
    val realLogit: Float,
    val spoofLogit: Float,
    val decisionScore: Float,
    val inferenceTimeMs: Long,
    val qualityStatus: LivenessQualityStatus,
    val preprocessTimeMs: Long = 0L,
    val endToEndTimeMs: Long = inferenceTimeMs,
)
