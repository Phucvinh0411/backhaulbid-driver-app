package vn.cccd.bacreader.biometric.camera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.Settings
import java.util.Locale
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.core.view.isVisible
import vn.cccd.bacreader.R
import vn.cccd.bacreader.ui.SecureWindowPolicy
import vn.cccd.bacreader.ui.EkycUiPolicy
import vn.cccd.bacreader.ui.demo.EkycTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import vn.cccd.bacreader.biometric.detection.FaceDetectionFailure
import vn.cccd.bacreader.biometric.detection.FaceDetectionResult
import vn.cccd.bacreader.biometric.detection.MlKitFaceDetector
import vn.cccd.bacreader.biometric.detection.DetectedFace
import vn.cccd.bacreader.biometric.detection.MlKitBitmapFaceDetector
import vn.cccd.bacreader.biometric.active.ActiveLivenessInconclusiveReason
import vn.cccd.bacreader.biometric.active.ActiveChallenge
import vn.cccd.bacreader.biometric.active.ActiveLivenessResult
import vn.cccd.bacreader.biometric.active.ActiveLivenessSession
import vn.cccd.bacreader.biometric.active.ActiveLivenessState
import vn.cccd.bacreader.biometric.active.ActivePipelinePolicy
import vn.cccd.bacreader.biometric.active.YawSignMapping
import vn.cccd.bacreader.biometric.camera.BiometricResult
import vn.cccd.bacreader.biometric.camera.BiometricSessionHandle
import vn.cccd.bacreader.biometric.camera.BiometricStage
import vn.cccd.bacreader.biometric.camera.BiometricStageStatus
import vn.cccd.bacreader.biometric.liveness.LivenessInconclusiveReason
import vn.cccd.bacreader.biometric.liveness.LivenessSessionResult
import vn.cccd.bacreader.biometric.liveness.LivenessSessionState
import vn.cccd.bacreader.biometric.liveness.PassiveLivenessEngine
import vn.cccd.bacreader.biometric.quality.FaceQualityEvaluator
import vn.cccd.bacreader.biometric.quality.FaceQualityResult
import vn.cccd.bacreader.biometric.quality.FaceQualityStatus
import vn.cccd.bacreader.biometric.recognition.FaceRecognitionEngine
import vn.cccd.bacreader.biometric.recognition.FaceRecognitionResult
import vn.cccd.bacreader.biometric.recognition.FaceMatchUiPolicy
import vn.cccd.bacreader.biometric.recognition.FaceMatchUiState
import vn.cccd.bacreader.databinding.ActivityCameraFoundationBinding

/**
 * Biometric camera host. This activity is intentionally independent of the NFC
 * reader: it runs quality, active/passive liveness, and development face matching over
 * ephemeral frames without persisting or exporting camera images.
 */
open class CameraActivity : ComponentActivity() {
    private lateinit var binding: ActivityCameraFoundationBinding
    private lateinit var cameraController: CameraController
    private lateinit var faceDetector: MlKitFaceDetector
    private lateinit var dg2FaceDetector: MlKitBitmapFaceDetector
    private lateinit var activeLiveness: ActiveLivenessSession
    private lateinit var livenessEngine: PassiveLivenessEngine
    private lateinit var recognitionEngine: FaceRecognitionEngine
    private val qualityEvaluator = FaceQualityEvaluator()
    private var permissionRequested = false
    private var requestInFlight = false
    private var permissionState = CameraPermissionState.CAMERA_PERMISSION_UNKNOWN
    private var dg2Bitmap: Bitmap? by mutableStateOf(null)
    private var biometricSessionHandle: BiometricSessionHandle? = null
    private var dg2Face: DetectedFace? = null
    @Volatile private var recognitionSessionId = 0L
    private var matchStarted = false
    @Volatile private var activePassed = false
    private var latestBiometricResult: BiometricResult? = null
    private val uiPolicy = EkycUiPolicy.forBuild(false)
    private val productionMode: Boolean
        get() = intent.getBooleanExtra(EXTRA_PRODUCTION_UI, false)
    private val productionUiState = MutableStateFlow(ProductionBiometricUiState())
    private var productionPreviewView: androidx.camera.view.PreviewView? = null

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        requestInFlight = false
        permissionRequested = true
        refreshPermissionState(grantedOverride = granted)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SecureWindowPolicy.apply(this, uiPolicy)
        if (!vn.cccd.bacreader.sdk.SdkCaptureGuard.attach(this)) return
        binding = ActivityCameraFoundationBinding.inflate(layoutInflater)
        if (productionMode) {
            productionPreviewView = androidx.camera.view.PreviewView(this)
            setContent {
                EkycTheme {
                    val state by productionUiState.asStateFlow().collectAsState()
                    ProductionBiometricHost(
                        state = state,
                        previewView = requireNotNull(productionPreviewView),
                        dg2Portrait = dg2Bitmap,
                        onPermissionAction = ::onPermissionAction,
                        onRetry = ::retryBiometric,
                        onClose = { finishWithResult(latestBiometricResult ?: BiometricResult.cancelled()) },
                    )
                }
            }
        } else {
            setContentView(binding.root)
        }
        if (!uiPolicy.showDebugDiagnostics) {
            binding.cameraFoundationTitle.setText(R.string.camera_user_title)
            binding.cameraFoundationDescription.setText(R.string.camera_user_description)
        }

        permissionRequested = savedInstanceState?.getBoolean(KEY_PERMISSION_REQUESTED) ?: false
        cameraController = CameraController(this)
        faceDetector = MlKitFaceDetector()
        dg2FaceDetector = MlKitBitmapFaceDetector()
        activeLiveness = ActiveLivenessSession()
        livenessEngine = PassiveLivenessEngine(this)
        recognitionEngine = FaceRecognitionEngine(this)
        biometricSessionHandle = readSessionHandle(intent)
        // The production parent owns the session portrait for both the NFC
        // result and final summary. Legacy standalone mode keeps the original
        // one-shot transfer behavior.
        dg2Bitmap = if (productionMode) {
            biometricSessionHandle?.borrowPortrait()
        } else {
            biometricSessionHandle?.takePortrait()
        }
        recognitionSessionId = recognitionEngine.beginSession()

        binding.cameraCloseButton.setOnClickListener {
            finishWithResult(latestBiometricResult ?: BiometricResult.cancelled())
        }
        binding.cameraPermissionButton.setOnClickListener { onPermissionAction() }
        binding.cameraLivenessRetryButton.setOnClickListener {
            retryBiometric()
        }
        renderLiveness(livenessEngine.snapshot())
        renderActive(activeLiveness.snapshot())
        renderMatchWaiting()
        prepareDg2Face()
        refreshPermissionState()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && !requestInFlight) refreshPermissionState()
    }

    override fun onStop() {
        if (::activeLiveness.isInitialized && !isFinishing && !isChangingConfigurations) {
            activePassed = false
            matchStarted = false
            activeLiveness.onCameraInterrupted()
            livenessEngine.reset()
            recognitionSessionId = recognitionEngine.beginSession()
        }
        super.onStop()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean(KEY_PERMISSION_REQUESTED, permissionRequested)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (::cameraController.isInitialized) cameraController.close()
        if (::faceDetector.isInitialized) faceDetector.close()
        if (::dg2FaceDetector.isInitialized) dg2FaceDetector.close()
        if (::livenessEngine.isInitialized) livenessEngine.close()
        if (::recognitionEngine.isInitialized) recognitionEngine.close()
        if (!productionMode) {
            dg2Bitmap?.let { if (!it.isRecycled) it.recycle() }
        }
        dg2Bitmap = null
        if (!productionMode) biometricSessionHandle?.close()
        biometricSessionHandle = null
        super.onDestroy()
    }

    private fun refreshPermissionState(grantedOverride: Boolean? = null) {
        val granted = grantedOverride ?: ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA,
        ) == PackageManager.PERMISSION_GRANTED
        permissionState = CameraPermissionClassifier.classify(
            isGranted = granted,
            shouldShowRationale = shouldShowRequestPermissionRationale(Manifest.permission.CAMERA),
            requestAttempted = permissionRequested,
        )
        if (productionMode) {
            productionUiState.value = productionUiState.value.copy(permission = permissionState)
        }

        when (permissionState) {
            CameraPermissionState.CAMERA_PERMISSION_UNKNOWN -> {
                binding.cameraStatus.setText(R.string.camera_permission_unknown)
                showPermissionAction(R.string.camera_permission_request)
                if (!permissionRequested) {
                    permissionRequested = true
                    requestInFlight = true
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                }
            }
            CameraPermissionState.CAMERA_PERMISSION_GRANTED -> {
                binding.cameraStatus.setText(R.string.camera_permission_granted)
                binding.cameraPermissionButton.isVisible = false
                startCameraIfNeeded()
            }
            CameraPermissionState.CAMERA_PERMISSION_DENIED -> {
                binding.cameraStatus.setText(R.string.camera_permission_denied)
                showPermissionAction(R.string.camera_permission_retry)
                cameraController.stop()
            }
            CameraPermissionState.CAMERA_PERMISSION_PERMANENTLY_DENIED -> {
                binding.cameraStatus.setText(R.string.camera_permission_permanently_denied)
                showPermissionAction(R.string.camera_permission_settings)
                cameraController.stop()
            }
        }
    }

    private fun onPermissionAction() {
        when (permissionState) {
            CameraPermissionState.CAMERA_PERMISSION_PERMANENTLY_DENIED -> openAppSettings()
            CameraPermissionState.CAMERA_PERMISSION_GRANTED -> {
                cameraController.stop()
                startCameraIfNeeded()
            }
            else -> {
                permissionRequested = true
                requestInFlight = true
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun retryBiometric() {
        if (!::activeLiveness.isInitialized || !::livenessEngine.isInitialized || !::recognitionEngine.isInitialized) return
        matchStarted = false
        activePassed = false
        latestBiometricResult = null
        productionUiState.value = ProductionBiometricUiState(
            permission = permissionState,
            camera = cameraController.state,
        )
        binding.cameraCloseButton.setText(R.string.camera_close)
        recognitionSessionId = recognitionEngine.beginSession()
        renderActive(activeLiveness.reset())
        livenessEngine.reset { snapshot -> renderLiveness(snapshot) }
    }

    private fun showPermissionAction(label: Int) {
        binding.cameraPermissionButton.setText(label)
        binding.cameraPermissionButton.isVisible = true
    }

    private fun openAppSettings() {
        startActivity(
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                "package:$packageName".toUri(),
            ),
        )
    }

    private fun startCameraIfNeeded() {
        if (cameraController.state == CameraState.RUNNING ||
            cameraController.state == CameraState.STARTING
        ) return

        matchStarted = false
        activePassed = false
        latestBiometricResult = null
        binding.cameraCloseButton.setText(R.string.camera_close)
        recognitionSessionId = recognitionEngine.beginSession()
        renderActive(activeLiveness.reset())
        livenessEngine.reset { snapshot -> runOnUiThread { renderLiveness(snapshot) } }

        cameraController.start(
            lifecycleOwner = this,
            previewView = productionPreviewView ?: binding.cameraPreview,
            onFrame = { frame ->
                faceDetector.process(frame) { result ->
                    when (result) {
                        is FaceDetectionResult.Success -> {
                            val quality = qualityEvaluator.evaluate(
                                faces = result.faces,
                                frameWidth = result.frameWidth,
                                frameHeight = result.frameHeight,
                            )
                            runOnUiThread { renderDetection(result, quality) }
                            val face = quality.face
                            if (result.faces.size == 1 &&
                                quality.status == FaceQualityStatus.ACCEPTABLE &&
                                face != null
                            ) {
                                val activeResult = activeLiveness.onFace(face)
                                if (ActivePipelinePolicy.canStartPassive(activeResult.state)) activePassed = true
                                runOnUiThread {
                                    renderActive(activeResult)
                                    renderLiveness(livenessEngine.snapshot())
                                }
                                if (activePassed) {
                                    submitPassiveFrame(frame, face)
                                }
                            } else {
                                val activeResult = when {
                                    result.faces.size > 1 -> activeLiveness.onMultipleFaces()
                                    result.faces.isEmpty() -> activeLiveness.onNoFace()
                                    else -> activeLiveness.onQualityRejected()
                                }
                                if (result.faces.size > 1) {
                                    activePassed = false
                                    matchStarted = false
                                    recognitionSessionId = recognitionEngine.beginSession()
                                    livenessEngine.reset()
                                }
                                runOnUiThread {
                                    renderActive(activeResult)
                                    renderLiveness(livenessEngine.snapshot())
                                }
                                if (activePassed) {
                                    val reason = if (result.faces.size > 1) {
                                        LivenessInconclusiveReason.MULTIPLE_FACES
                                    } else if (result.faces.isEmpty()) {
                                        LivenessInconclusiveReason.NO_FACE
                                    } else null
                                    livenessEngine.reject(reason) { snapshot ->
                                        runOnUiThread { renderLiveness(snapshot) }
                                    }
                                }
                            }
                        }
                        is FaceDetectionResult.Failure -> {
                            runOnUiThread { renderDetection(result, null) }
                            val activeResult = activeLiveness.onNoFace()
                            runOnUiThread {
                                renderActive(activeResult)
                                renderLiveness(livenessEngine.snapshot())
                            }
                            if (activePassed) {
                                livenessEngine.reject { snapshot ->
                                    runOnUiThread { renderLiveness(snapshot) }
                                }
                            }
                        }
                    }
                }
            },
            onState = { state -> runOnUiThread { renderCameraState(state) } },
        )
    }

    private fun submitPassiveFrame(frame: CameraFrame, face: DetectedFace) {
        val frameSessionId = recognitionSessionId
        livenessEngine.offerGoodFrame(
            face = face,
            imageProvider = { frame.copyRgb() },
            callback = { snapshot ->
                runOnUiThread { renderLiveness(snapshot) }
            },
            onLiveFrame = { image, acceptedFace ->
                runOnUiThread {
                    if (frameSessionId == recognitionSessionId &&
                        activePassed &&
                        livenessEngine.snapshot().state == LivenessSessionState.LIVE_DEVELOPMENT
                    ) {
                        startRecognition(image, acceptedFace)
                    } else {
                        image.close()
                    }
                }
            },
        )
    }

    private fun renderCameraState(state: CameraState) {
        if (productionMode) productionUiState.value = productionUiState.value.copy(camera = state)
        when (state) {
            CameraState.IDLE -> Unit
            CameraState.STARTING -> {
                binding.cameraPermissionButton.isVisible = false
                binding.cameraStatus.setText(R.string.camera_state_starting)
            }
            CameraState.RUNNING -> {
                binding.cameraPermissionButton.isVisible = false
                binding.cameraStatus.setText(R.string.camera_state_running)
            }
            CameraState.STOPPED -> {
                val activeResult = activeLiveness.onCameraInterrupted()
                livenessEngine.reject(LivenessInconclusiveReason.CAMERA_INTERRUPTED) { snapshot ->
                    renderLiveness(snapshot)
                }
                activePassed = false
                renderActive(activeResult)
                if (permissionState == CameraPermissionState.CAMERA_PERMISSION_GRANTED) {
                    binding.cameraStatus.setText(R.string.camera_state_stopped)
                }
            }
            is CameraState.ERROR -> {
                val activeResult = activeLiveness.onCameraInterrupted()
                livenessEngine.reject(LivenessInconclusiveReason.CAMERA_INTERRUPTED) { snapshot ->
                    renderLiveness(snapshot)
                }
                activePassed = false
                renderActive(activeResult)
                binding.cameraStatus.setText(
                    when (state.error) {
                        CameraError.PERMISSION_REQUIRED -> R.string.camera_permission_denied
                        CameraError.FRONT_CAMERA_UNAVAILABLE -> R.string.camera_state_front_unavailable
                        CameraError.BIND_FAILED -> R.string.camera_state_bind_failed
                        CameraError.ANALYSIS_FAILED -> R.string.camera_state_analysis_failed
                        CameraError.CONTROLLER_CLOSED -> R.string.camera_state_closed
                    },
                )
                if (permissionState == CameraPermissionState.CAMERA_PERMISSION_GRANTED &&
                    state.error != CameraError.PERMISSION_REQUIRED &&
                    state.error != CameraError.CONTROLLER_CLOSED
                ) {
                    showPermissionAction(R.string.camera_retry)
                }
            }
        }
    }

    private fun renderDetection(result: FaceDetectionResult, evaluatedQuality: FaceQualityResult?) {
        when (result) {
            is FaceDetectionResult.Success -> {
                val quality = evaluatedQuality ?: qualityEvaluator.evaluate(
                    faces = result.faces,
                    frameWidth = result.frameWidth,
                    frameHeight = result.frameHeight,
                )
                if (!uiPolicy.showDebugDiagnostics) {
                    binding.cameraQuality.setText(
                        if (result.faces.size == 1 && quality.status == FaceQualityStatus.ACCEPTABLE) {
                            R.string.camera_quality_user_good
                        } else {
                            R.string.camera_quality_user_adjust
                        },
                    )
                    binding.cameraQuality.contentDescription = binding.cameraQuality.text
                } else {
                    binding.cameraQuality.text = getString(
                        R.string.camera_quality_format,
                        result.faces.size,
                        quality.status.name,
                    )
                }
                if (uiPolicy.showDebugDiagnostics && quality.reasons.isEmpty()) {
                    binding.cameraQuality.contentDescription = getString(
                        R.string.camera_quality_format,
                        result.faces.size,
                        quality.status.name,
                    )
                } else if (uiPolicy.showDebugDiagnostics) {
                    binding.cameraQuality.append(
                        "\n" + getString(
                            R.string.camera_quality_reasons,
                            quality.reasons.joinToString { it.name },
                        ),
                    )
                }
            }
            is FaceDetectionResult.Failure -> {
                binding.cameraQuality.setText(
                    if (result.reason == FaceDetectionFailure.DETECTOR_CLOSED) {
                        R.string.camera_state_closed
                    } else if (uiPolicy.showDebugDiagnostics) {
                        R.string.camera_detection_failed
                    } else {
                        R.string.camera_quality_user_failed
                    },
                )
            }
        }
    }

    private fun renderActive(result: ActiveLivenessResult) {
        if (!::binding.isInitialized) return
        if (productionMode) productionUiState.value = productionUiState.value.copy(active = result)
        val challenge = result.currentChallenge
        val label = challenge?.let(::activeChallengeLabel)
        binding.cameraActiveState.text = when (result.state) {
            ActiveLivenessState.WAITING_FOR_FACE -> getString(
                if (uiPolicy.showDebugDiagnostics) R.string.camera_active_waiting_face else R.string.camera_active_user_waiting_face,
            )
            ActiveLivenessState.WAITING_FOR_QUALITY -> getString(
                if (uiPolicy.showDebugDiagnostics) R.string.camera_active_waiting_quality else R.string.camera_active_user_waiting_quality,
            )
            ActiveLivenessState.ESTABLISHING_NEUTRAL -> getString(
                if (uiPolicy.showDebugDiagnostics) R.string.camera_active_look_straight else R.string.camera_active_user_look_straight,
            )
            ActiveLivenessState.CHALLENGE_ACTIVE,
            ActiveLivenessState.ACTION_IN_PROGRESS,
            ActiveLivenessState.RETURN_TO_NEUTRAL,
            ActiveLivenessState.NEXT_CHALLENGE,
            -> if (uiPolicy.showDebugDiagnostics) {
                getString(
                    R.string.camera_active_challenge,
                    label ?: "—",
                    result.actionChallengeNumber,
                    result.totalActionChallenges,
                )
            } else {
                getString(R.string.camera_active_user_challenge)
            }
            ActiveLivenessState.ACTION_CONFIRMED -> if (uiPolicy.showDebugDiagnostics) {
                getString(
                    R.string.camera_active_action_confirmed,
                    result.lastAction?.let(::activeChallengeLabel) ?: "—",
                )
            } else {
                getString(R.string.camera_active_user_action_confirmed)
            }
            ActiveLivenessState.PASSED -> if (uiPolicy.showDebugDiagnostics) {
                getString(R.string.camera_active_pass)
            } else {
                getString(R.string.camera_active_user_pass)
            }
            ActiveLivenessState.FAILED -> if (uiPolicy.showDebugDiagnostics) {
                getString(R.string.camera_active_failed)
            } else {
                getString(R.string.camera_active_user_failed)
            }
            ActiveLivenessState.INCONCLUSIVE -> if (uiPolicy.showDebugDiagnostics) {
                getString(
                    R.string.camera_active_inconclusive,
                    result.reason?.name ?: "UNKNOWN",
                )
            } else {
                getString(R.string.camera_active_user_inconclusive)
            }
        }
        val challengeText = when {
            result.state == ActiveLivenessState.PASSED -> if (uiPolicy.showDebugDiagnostics) {
                getString(R.string.camera_active_metadata_pass)
            } else {
                getString(R.string.camera_active_user_pass)
            }
            result.state == ActiveLivenessState.INCONCLUSIVE -> if (uiPolicy.showDebugDiagnostics) {
                getString(
                    R.string.camera_active_metadata_inconclusive,
                    result.reason?.name ?: "UNKNOWN",
                )
            } else {
                getString(R.string.camera_active_user_inconclusive)
            }
            challenge == ActiveChallenge.LOOK_STRAIGHT -> getString(R.string.camera_active_metadata_look_straight)
            else -> if (uiPolicy.showDebugDiagnostics) {
                getString(
                    R.string.camera_active_metadata_challenge,
                    result.actionChallengeNumber,
                    result.totalActionChallenges,
                    label ?: "—",
                    result.signalStatus?.name ?: "WAITING",
                )
            } else {
                getString(R.string.camera_active_user_challenge)
            }
        }
        val debugText = if (uiPolicy.showDebugDiagnostics) {
            getString(
                R.string.camera_active_metadata_debug,
                label ?: "—",
                result.currentYawDegrees?.let { formatDegrees(it) } ?: "—",
                targetYawText(result),
                result.stableFrames,
                result.requiredStableFrames,
                formatSeconds(result.challengeTimeRemainingMillis),
                formatSeconds(result.overallTimeRemainingMillis),
            )
        } else {
            null
        }
        binding.cameraActiveMetadata.text = if (debugText == null) {
            challengeText
        } else {
            "$challengeText\n$debugText"
        }
        val activeTerminal = result.state == ActiveLivenessState.PASSED ||
            result.state == ActiveLivenessState.FAILED ||
            result.state == ActiveLivenessState.INCONCLUSIVE
        if (result.state == ActiveLivenessState.FAILED || result.state == ActiveLivenessState.INCONCLUSIVE) {
            latestBiometricResult = BiometricResult(
                activeLiveness = BiometricResult.fromActive(result),
                passiveLiveness = BiometricStageStatus.NOT_RUN,
                faceMatch = BiometricStageStatus.NOT_RUN,
                failureStage = BiometricStage.ACTIVE_LIVENESS,
            )
            if (productionMode) {
                productionUiState.value = productionUiState.value.copy(result = latestBiometricResult)
            }
        }
        binding.cameraLivenessRetryButton.isVisible = activeTerminal && !activePassed
        if (!activePassed && dg2Bitmap != null && dg2Face != null) {
            binding.cameraMatchState.setText(
                if (uiPolicy.showDebugDiagnostics) R.string.camera_match_active_required else R.string.camera_match_user_required,
            )
            setMatchMetadata {
                getString(
                    R.string.camera_match_metadata_active_waiting,
                    recognitionEngine.modelInfo.status.name,
                    recognitionEngine.developmentThreshold.toString(),
                )
            }
        }
    }

    private fun activeChallengeLabel(challenge: vn.cccd.bacreader.biometric.active.ActiveChallenge): String =
        when (challenge) {
            vn.cccd.bacreader.biometric.active.ActiveChallenge.LOOK_STRAIGHT -> getString(R.string.camera_active_look_straight_label)
            vn.cccd.bacreader.biometric.active.ActiveChallenge.BLINK -> getString(R.string.camera_active_blink_label)
            vn.cccd.bacreader.biometric.active.ActiveChallenge.TURN_LEFT -> getString(R.string.camera_active_turn_left_label)
            vn.cccd.bacreader.biometric.active.ActiveChallenge.TURN_RIGHT -> getString(R.string.camera_active_turn_right_label)
        }

    private fun targetYawText(result: ActiveLivenessResult): String = when (result.currentChallenge) {
        ActiveChallenge.TURN_LEFT -> signedYawText(
            result,
            positive = result.yawSignMapping == YawSignMapping.POSITIVE_IS_LEFT,
        )
        ActiveChallenge.TURN_RIGHT -> signedYawText(
            result,
            positive = result.yawSignMapping == YawSignMapping.NEGATIVE_IS_LEFT,
        )
        else -> "—"
    }

    private fun signedYawText(result: ActiveLivenessResult, positive: Boolean): String =
        "${if (positive) "+" else "-"}${formatDegrees(result.turnThresholdDegrees)}"

    private fun formatDegrees(value: Float): String = String.format(Locale.US, "%.1f", value)

    private fun formatSeconds(value: Long?): String =
        value?.let { String.format(Locale.US, "%.1fs", it / 1_000.0) } ?: "—"

    private fun renderLiveness(result: LivenessSessionResult) {
        if (!::binding.isInitialized) return
        if (productionMode) productionUiState.value = productionUiState.value.copy(passive = result)
        if (!activePassed) {
            binding.cameraLivenessState.setText(
                if (uiPolicy.showDebugDiagnostics) R.string.camera_liveness_waiting_for_active else R.string.camera_liveness_user_waiting,
            )
            binding.cameraLivenessMetadata.text = if (uiPolicy.showDebugDiagnostics) {
                getString(
                    R.string.camera_liveness_metadata_active_waiting,
                    livenessEngine.modelInfo.status.name,
                )
            } else {
                getString(R.string.camera_liveness_metadata_user)
            }
            val activeState = activeLiveness.snapshot().state
            binding.cameraLivenessRetryButton.isVisible = activeState == ActiveLivenessState.FAILED ||
                activeState == ActiveLivenessState.INCONCLUSIVE
            return
        }
        val required = livenessEngine.requiredValidFrames
        binding.cameraLivenessRetryButton.isVisible = result.state != LivenessSessionState.COLLECTING
        binding.cameraLivenessState.text = when (result.state) {
            LivenessSessionState.COLLECTING -> if (uiPolicy.showDebugDiagnostics) {
                getString(
                    R.string.camera_liveness_collecting,
                    result.validFrameCount,
                    required,
                )
            } else {
                getString(R.string.camera_liveness_user_collecting)
            }
            LivenessSessionState.LIVE_DEVELOPMENT -> if (uiPolicy.showDebugDiagnostics) {
                getString(R.string.camera_liveness_live)
            } else {
                getString(R.string.camera_liveness_user_live)
            }
            LivenessSessionState.SPOOF_DEVELOPMENT -> if (uiPolicy.showDebugDiagnostics) {
                getString(R.string.camera_liveness_spoof)
            } else {
                getString(R.string.camera_liveness_user_spoof)
            }
            LivenessSessionState.INCONCLUSIVE -> if (uiPolicy.showDebugDiagnostics) {
                getString(
                    R.string.camera_liveness_inconclusive,
                    result.inconclusiveReason?.name ?: "UNKNOWN",
                )
            } else {
                getString(R.string.camera_liveness_user_inconclusive)
            }
            LivenessSessionState.MODEL_ERROR -> if (uiPolicy.showDebugDiagnostics) {
                getString(R.string.camera_liveness_model_error)
            } else {
                getString(R.string.camera_liveness_user_error)
            }
        }

        val modelStatus = livenessEngine.modelInfo.status.name
        val latest = result.latestFrame
        binding.cameraLivenessMetadata.text = if (!uiPolicy.showDebugDiagnostics) {
            getString(R.string.camera_liveness_metadata_user)
        } else if (latest == null) {
            getString(R.string.camera_liveness_metadata_waiting, modelStatus, result.validFrameCount)
        } else {
            getString(
                R.string.camera_liveness_metadata_format,
                modelStatus,
                result.validFrameCount,
                result.medianScore?.toString() ?: "—",
                latest.realLogit.toString(),
                latest.spoofLogit.toString(),
                latest.preprocessTimeMs,
                latest.inferenceTimeMs,
                latest.endToEndTimeMs,
            )
        }
        if (!matchStarted) {
            when (FaceMatchUiPolicy.classify(dg2Face != null, result.state, matchStarted)) {
                FaceMatchUiState.WAITING_LIVENESS -> renderMatchWaiting()
                FaceMatchUiState.READY_TO_MATCH -> renderMatchReady()
                FaceMatchUiState.BLOCKED_LIVENESS -> renderMatchBlocked(result.state.name)
                FaceMatchUiState.NO_DG2 -> renderMatchWaiting()
                FaceMatchUiState.MATCHING -> Unit
            }
        }
        if (result.state == LivenessSessionState.SPOOF_DEVELOPMENT ||
            result.state == LivenessSessionState.INCONCLUSIVE ||
            result.state == LivenessSessionState.MODEL_ERROR
        ) {
            latestBiometricResult = BiometricResult(
                activeLiveness = BiometricResult.fromActive(activeLiveness.snapshot()),
                passiveLiveness = BiometricResult.fromPassive(result),
                faceMatch = BiometricStageStatus.NOT_RUN,
                failureStage = BiometricStage.PASSIVE_LIVENESS,
            )
            if (productionMode) {
                productionUiState.value = productionUiState.value.copy(result = latestBiometricResult)
            }
        }
    }

    private fun prepareDg2Face() {
        val bitmap = dg2Bitmap
        if (bitmap == null) {
            binding.cameraMatchState.setText(
                if (uiPolicy.showDebugDiagnostics) R.string.camera_match_no_dg2 else R.string.camera_match_user_no_dg2,
            )
            setMatchMetadata {
                getString(
                    R.string.camera_match_metadata_waiting,
                    recognitionEngine.modelInfo.status.name,
                    recognitionEngine.developmentThreshold.toString(),
                )
            }
            return
        }
        binding.cameraMatchState.setText(
            if (uiPolicy.showDebugDiagnostics) R.string.camera_match_dg2_detecting else R.string.camera_match_user_detecting,
        )
        dg2FaceDetector.detect(bitmap) { faces ->
            runOnUiThread {
                when {
                    faces == null -> {
                        dg2Face = null
                        binding.cameraMatchState.setText(
                            if (uiPolicy.showDebugDiagnostics) R.string.camera_match_dg2_not_found else R.string.camera_match_user_not_found,
                        )
                    }
                    faces.isEmpty() -> {
                        dg2Face = null
                        binding.cameraMatchState.setText(
                            if (uiPolicy.showDebugDiagnostics) R.string.camera_match_dg2_not_found else R.string.camera_match_user_not_found,
                        )
                    }
                    faces.size > 1 -> {
                        dg2Face = null
                        binding.cameraMatchState.setText(
                            if (uiPolicy.showDebugDiagnostics) R.string.camera_match_dg2_multiple else R.string.camera_match_user_multiple,
                        )
                    }
                    faces.single().landmarks == null -> {
                        dg2Face = null
                        binding.cameraMatchState.setText(
                            if (uiPolicy.showDebugDiagnostics) R.string.camera_match_dg2_landmarks else R.string.camera_match_user_landmarks,
                        )
                    }
                    else -> {
                        dg2Face = faces.single()
                        renderMatchWaiting()
                    }
                }
            }
        }
    }

    private fun startRecognition(image: vn.cccd.bacreader.biometric.RgbImage, liveFace: DetectedFace) {
        if (isFinishing || isDestroyed || matchStarted) {
            image.close()
            return
        }
        matchStarted = true
        val bitmap = dg2Bitmap
        val face = dg2Face
        if (bitmap == null || face == null) {
            image.close()
            binding.cameraMatchState.setText(
                if (uiPolicy.showDebugDiagnostics) R.string.camera_match_no_dg2 else R.string.camera_match_user_no_dg2,
            )
            return
        }
        binding.cameraMatchState.setText(
            if (uiPolicy.showDebugDiagnostics) R.string.camera_match_in_progress else R.string.camera_match_user_progress,
        )
        // Publish MATCHING when the comparison actually starts.  The terminal
        // result renderer must not emit MATCHING first, otherwise Compose can
        // briefly keep the progress copy while the retry action is already
        // visible for a failed comparison.
        if (productionMode) {
            productionUiState.value = productionUiState.value.copy(
                match = ProductionMatchState.MATCHING,
                result = null,
            )
        }
        val comparisonSessionId = recognitionSessionId
        intent.getStringExtra(vn.cccd.bacreader.sdk.EXTRA_TOKEN)?.let { token ->
            vn.cccd.bacreader.sdk.SdkRuntime.recordSelfie(token, image)
        }
        recognitionEngine.match(
            sessionId = comparisonSessionId,
            livenessState = LivenessSessionState.LIVE_DEVELOPMENT,
            dg2Bitmap = bitmap,
            dg2Face = face,
            liveImage = image,
            liveFace = liveFace,
        ) { result ->
            runOnUiThread {
                // A retry starts a new recognition session. Do not let a late
                // callback from the previous comparison repaint the retry UI.
                if (comparisonSessionId == recognitionSessionId && matchStarted) {
                    renderRecognition(result)
                }
            }
        }
    }

    private fun renderMatchWaiting() {
        if (!::binding.isInitialized || !::recognitionEngine.isInitialized) return
        if (productionMode) productionUiState.value = productionUiState.value.copy(match = ProductionMatchState.WAITING)
        if (dg2Bitmap == null) {
            binding.cameraMatchState.setText(
                if (uiPolicy.showDebugDiagnostics) R.string.camera_match_no_dg2 else R.string.camera_match_user_no_dg2,
            )
        } else if (dg2Face == null) {
            binding.cameraMatchState.setText(
                if (uiPolicy.showDebugDiagnostics) R.string.camera_match_dg2_detecting else R.string.camera_match_user_detecting,
            )
        } else {
            binding.cameraMatchState.setText(
                if (uiPolicy.showDebugDiagnostics) R.string.camera_match_waiting else R.string.camera_match_user_waiting,
            )
        }
        setMatchMetadata {
            getString(
                R.string.camera_match_metadata_waiting,
                recognitionEngine.modelInfo.status.name,
                recognitionEngine.developmentThreshold.toString(),
            )
        }
    }

    private fun renderMatchReady() {
        if (productionMode) productionUiState.value = productionUiState.value.copy(match = ProductionMatchState.READY)
        binding.cameraMatchState.setText(
            if (uiPolicy.showDebugDiagnostics) R.string.camera_match_liveness_passed else R.string.camera_match_user_progress,
        )
        setMatchMetadata {
            getString(
                R.string.camera_match_metadata_waiting,
                recognitionEngine.modelInfo.status.name,
                recognitionEngine.developmentThreshold.toString(),
            )
        }
    }

    private fun renderMatchBlocked(reason: String) {
        if (productionMode) productionUiState.value = productionUiState.value.copy(match = ProductionMatchState.WAITING)
        if (dg2Face == null) {
            renderMatchWaiting()
            return
        }
        binding.cameraMatchState.setText(
            if (uiPolicy.showDebugDiagnostics) R.string.camera_match_liveness_required else R.string.camera_match_user_required,
        )
        setMatchMetadata {
            getString(
                R.string.camera_match_metadata_failure,
                recognitionEngine.modelInfo.status.name,
                reason,
                recognitionEngine.developmentThreshold.toString(),
            )
        }
    }

    private fun setMatchMetadata(debugText: () -> String) {
        binding.cameraMatchMetadata.text = if (uiPolicy.showDebugDiagnostics) {
            debugText()
        } else {
            getString(R.string.camera_match_metadata_user)
        }
    }

    private fun renderRecognition(result: FaceRecognitionResult) {
        when (result) {
            is FaceRecognitionResult.Success -> {
                val match = result.match
                latestBiometricResult = BiometricResult(
                    activeLiveness = BiometricResult.fromActive(activeLiveness.snapshot()),
                    passiveLiveness = BiometricResult.fromPassive(livenessEngine.snapshot()),
                    faceMatch = BiometricResult.fromFaceMatch(match),
                    failureStage = BiometricStage.FACE_MATCH,
                )
                if (productionMode) productionUiState.value = productionUiState.value.copy(
                    match = if (match.state == vn.cccd.bacreader.biometric.recognition.FaceMatchState.MATCH_DEVELOPMENT) {
                        ProductionMatchState.SUCCESS
                    } else {
                        ProductionMatchState.FAILED
                    },
                    result = latestBiometricResult,
                )
                if (productionMode && latestBiometricResult?.isCaptureComplete == true) {
                    // Give the user a brief success acknowledgement, then return
                    // automatically to the parent eKYC summary. The parent owns
                    // the session portrait and receives only the result contract.
                    window.decorView.postDelayed({
                        if (!isFinishing && !isDestroyed) {
                            finishWithResult(requireNotNull(latestBiometricResult))
                        }
                    }, PRODUCTION_AUTO_SUMMARY_DELAY_MILLIS)
                }
                val stateLabel = if (match.state == vn.cccd.bacreader.biometric.recognition.FaceMatchState.MATCH_DEVELOPMENT) {
                    "BIOMETRIC_MATCHED_DEVELOPMENT"
                } else {
                    match.state.name
                }
                binding.cameraMatchState.text = if (uiPolicy.showDebugDiagnostics) {
                    getString(R.string.camera_match_result, stateLabel)
                } else {
                    getString(
                        R.string.camera_match_user_result,
                        if (match.state == vn.cccd.bacreader.biometric.recognition.FaceMatchState.MATCH_DEVELOPMENT) "Khớp" else "Cần kiểm tra lại",
                    )
                }
                setMatchMetadata {
                    getString(
                        R.string.camera_match_metadata_result,
                        match.similarity?.toString() ?: "—",
                        match.developmentThreshold.toString(),
                        result.dg2AlignmentMs,
                        result.dg2EmbeddingMs,
                        result.liveAlignmentMs,
                        result.liveEmbeddingMs,
                        result.cosineMs,
                    )
                }
                binding.cameraCloseButton.setText(R.string.camera_continue)
            }
            is FaceRecognitionResult.Failure -> {
                latestBiometricResult = BiometricResult(
                    activeLiveness = BiometricResult.fromActive(activeLiveness.snapshot()),
                    passiveLiveness = BiometricResult.fromPassive(livenessEngine.snapshot()),
                    faceMatch = if (result.reason == vn.cccd.bacreader.biometric.recognition.FaceRecognitionFailure.MODEL_ERROR) {
                        BiometricStageStatus.ERROR
                    } else {
                        BiometricStageStatus.INCONCLUSIVE
                    },
                    failureStage = BiometricStage.FACE_MATCH,
                )
                if (productionMode) productionUiState.value = productionUiState.value.copy(
                    match = ProductionMatchState.FAILED,
                    result = latestBiometricResult,
                )
                val state = if (result.reason == vn.cccd.bacreader.biometric.recognition.FaceRecognitionFailure.MODEL_ERROR) {
                    "MODEL_ERROR"
                } else {
                    "INCONCLUSIVE"
                }
                binding.cameraMatchState.text = if (uiPolicy.showDebugDiagnostics) {
                    getString(R.string.camera_match_result, state)
                } else {
                    getString(R.string.camera_match_user_result, "Cần kiểm tra lại")
                }
                setMatchMetadata {
                    getString(
                        R.string.camera_match_metadata_failure,
                        recognitionEngine.modelInfo.status.name,
                        result.reason.name,
                        recognitionEngine.developmentThreshold.toString(),
                    )
                }
                binding.cameraCloseButton.setText(R.string.camera_continue)
            }
        }
    }

    private fun readSessionHandle(source: Intent): BiometricSessionHandle? =
        vn.cccd.bacreader.sdk.SdkRuntime.find(source.getStringExtra(vn.cccd.bacreader.sdk.EXTRA_TOKEN))?.biometricSession
            ?: (source.extras?.getBinder(EXTRA_BIOMETRIC_SESSION) as? BiometricSessionHandle)

    private fun finishWithResult(result: BiometricResult) {
        intent.getStringExtra(vn.cccd.bacreader.sdk.EXTRA_TOKEN)?.let { token ->
            vn.cccd.bacreader.sdk.SdkRuntime.deliverFace(token, result)
            setResult(RESULT_OK); finish(); return
        }
        setResult(
            RESULT_OK,
            Intent().apply {
                putExtra(EXTRA_BIOMETRIC_ACTIVE, result.activeLiveness.name)
                putExtra(EXTRA_BIOMETRIC_PASSIVE, result.passiveLiveness.name)
                putExtra(EXTRA_BIOMETRIC_FACE_MATCH, result.faceMatch.name)
                putExtra(EXTRA_BIOMETRIC_FAILURE_STAGE, result.failureStage?.name)
            },
        )
        finish()
    }

    companion object {
        const val KEY_PERMISSION_REQUESTED = "camera_permission_requested"
        const val EXTRA_BIOMETRIC_SESSION = "biometric_session_handle"
        const val EXTRA_PRODUCTION_UI = "production_ui_host"
        const val EXTRA_BIOMETRIC_ACTIVE = "biometric_active_status"
        const val EXTRA_BIOMETRIC_PASSIVE = "biometric_passive_status"
        const val EXTRA_BIOMETRIC_FACE_MATCH = "biometric_face_match_status"
        const val EXTRA_BIOMETRIC_FAILURE_STAGE = "biometric_failure_stage"
        const val PRODUCTION_AUTO_SUMMARY_DELAY_MILLIS = 700L

        fun createIntent(context: android.content.Context, session: BiometricSessionHandle?): Intent =
            Intent(context, CameraActivity::class.java).apply {
                session?.let { putExtras(Bundle().apply { putBinder(EXTRA_BIOMETRIC_SESSION, it) }) }
            }

        fun createProductionIntent(context: android.content.Context, session: BiometricSessionHandle?): Intent =
            Intent(context, ProductionBiometricActivity::class.java).apply {
                putExtra(EXTRA_PRODUCTION_UI, true)
                session?.let { putExtras(Bundle().apply { putBinder(EXTRA_BIOMETRIC_SESSION, it) }) }
            }
    }
}
