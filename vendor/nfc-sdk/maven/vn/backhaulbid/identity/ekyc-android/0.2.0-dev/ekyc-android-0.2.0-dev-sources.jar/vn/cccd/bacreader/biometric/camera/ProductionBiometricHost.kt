package vn.cccd.bacreader.biometric.camera

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import vn.cccd.bacreader.biometric.active.ActiveChallenge
import vn.cccd.bacreader.biometric.active.ActiveLivenessResult
import vn.cccd.bacreader.biometric.active.ActiveLivenessState
import vn.cccd.bacreader.biometric.liveness.LivenessSessionResult
import vn.cccd.bacreader.biometric.liveness.LivenessSessionState
import vn.cccd.bacreader.ui.demo.InfoCard
import vn.cccd.bacreader.ui.demo.SecondaryButton
import vn.cccd.bacreader.ui.demo.StatusBadge
import vn.cccd.bacreader.ui.demo.StatusTone
import vn.cccd.bacreader.ui.demo.EkycScaffold
import vn.cccd.bacreader.ui.demo.EkycColors

data class ProductionBiometricUiState(
    val permission: CameraPermissionState = CameraPermissionState.CAMERA_PERMISSION_UNKNOWN,
    val camera: CameraState = CameraState.IDLE,
    val active: ActiveLivenessResult? = null,
    val passive: LivenessSessionResult? = null,
    val match: ProductionMatchState = ProductionMatchState.WAITING,
    val result: BiometricResult? = null,
)

enum class ProductionMatchState { WAITING, READY, MATCHING, SUCCESS, FAILED }

/** Production biometric surface: real camera state with concise user guidance. */
@Composable
fun ProductionBiometricHost(
    state: ProductionBiometricUiState,
    previewView: androidx.camera.view.PreviewView,
    dg2Portrait: Bitmap?,
    onPermissionAction: () -> Unit,
    onRetry: () -> Unit,
    onClose: () -> Unit,
) {
    val stage = stageNumber(state)
    val terminal = state.result?.isCaptureComplete == true
    EkycScaffold(
        title = "Khuôn mặt", step = 3, onExit = onClose,
        bottom = {
            if (state.result != null && !terminal || state.camera is CameraState.ERROR) SecondaryButton("Thử lại camera", onRetry)
            SecondaryButton("Hủy kiểm tra", onClose)
        },
    ) {
        Text("Làm theo hướng dẫn", style = MaterialTheme.typography.headlineSmall)
        Text("Đặt điện thoại ngang tầm mắt ở nơi đủ sáng.", color = EkycColors.Muted)
        StageIndicator(stage)
        CameraPreview(previewView = previewView, terminal = terminal)
        // The reference portrait stays in the native matcher; no additional PII preview.
        when (state.permission) {
            CameraPermissionState.CAMERA_PERMISSION_GRANTED -> Unit
            CameraPermissionState.CAMERA_PERMISSION_UNKNOWN -> {
                Text("Cần quyền camera để tiếp tục.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                SecondaryButton("Cho phép camera", onPermissionAction)
            }
            CameraPermissionState.CAMERA_PERMISSION_DENIED -> {
                Text("Quyền camera đang bị từ chối.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                SecondaryButton("Thử lại quyền camera", onPermissionAction)
            }
            CameraPermissionState.CAMERA_PERMISSION_PERMANENTLY_DENIED -> {
                Text("Hãy bật quyền camera trong Cài đặt để tiếp tục.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                SecondaryButton("Mở Cài đặt", onPermissionAction)
            }
        }
        GuidanceCard(state)
        when {
            state.result?.isCaptureComplete == true -> {
                InfoCard("Đã thu thập dữ liệu khuôn mặt", "Kết quả cần được hệ thống kiểm tra.", Icons.Outlined.CheckCircle)
            }
            state.result != null -> {
                val faceMatchFailed = state.result?.faceMatch == BiometricStageStatus.FAIL
                InfoCard(
                    if (faceMatchFailed) "Khuôn mặt không khớp" else "Chưa hoàn tất kiểm tra",
                    if (faceMatchFailed) {
                        "Khuôn mặt hiện tại không khớp với ảnh trên chip CCCD. Vui lòng thử lại."
                    } else {
                        "Vui lòng thử lại theo hướng dẫn."
                    },
                    Icons.Outlined.WarningAmber,
                )
            }
            state.camera is CameraState.ERROR -> Text("Không thể mở camera. Hãy thử lại.")
        }
    }
}

@Composable
private fun FaceMatchPortraitPreview(portrait: Bitmap) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF2FB)),
        shape = RoundedCornerShape(18.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(
                bitmap = portrait.asImageBitmap(),
                contentDescription = "Ảnh chân dung DG2 dùng để so khớp",
                modifier = Modifier.size(76.dp).clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop,
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Ảnh trên chip CCCD", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Khuôn mặt hiện tại sẽ được so khớp với ảnh này.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
private fun CameraPreview(previewView: androidx.camera.view.PreviewView, terminal: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth().height(360.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101923)),
        shape = RoundedCornerShape(24.dp),
    ) {
        Box(Modifier.fillMaxSize()) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(width = 210.dp, height = 270.dp)
                    .border(
                        width = 3.dp,
                        color = if (terminal) Color(0xFF63D391) else Color.White,
                        shape = RoundedCornerShape(50),
                    ),
            )
        }
    }
}

@Composable
private fun StageIndicator(current: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        listOf("Người thật", "Chống giả mạo", "So khớp").forEachIndexed { index, label ->
            val completed = index + 1 < current
            val selected = index + 1 == current
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .border(
                            width = 2.dp,
                            color = if (completed || selected) Color(0xFF24558A) else Color(0xFFC7D0DA),
                            shape = CircleShape,
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(if (completed) "✓" else (index + 1).toString(), color = if (completed || selected) Color(0xFF24558A) else Color(0xFF697583))
                }
                Text(label, style = MaterialTheme.typography.labelSmall, color = if (selected) Color(0xFF24558A) else Color(0xFF697583))
            }
        }
    }
}

@Composable
private fun GuidanceCard(state: ProductionBiometricUiState) {
    val (title, description, icon, tone) = guidance(state)
    InfoCard(title, description, icon)
    if (tone != null) StatusBadge(tone.first, tone.second)
    if (state.permission == CameraPermissionState.CAMERA_PERMISSION_GRANTED && state.result == null) {
        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
    }
}

private data class Guidance(
    val title: String,
    val description: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val tone: Pair<String, StatusTone>?,
)

private fun guidance(state: ProductionBiometricUiState): Guidance {
    state.result?.let { result ->
        return if (result.isCaptureComplete) {
            Guidance("Đã thu thập khuôn mặt", "Kết quả cần được hệ thống kiểm tra.", Icons.Outlined.CheckCircle, "Đã thu thập" to StatusTone.NEUTRAL)
        } else if (result.faceMatch == BiometricStageStatus.FAIL) {
            Guidance(
                "Khuôn mặt không khớp",
                "Khuôn mặt hiện tại không khớp với ảnh trên chip CCCD. Vui lòng thử lại.",
                Icons.Outlined.WarningAmber,
                "Cần thử lại" to StatusTone.WARNING,
            )
        } else {
            Guidance("Chưa thể hoàn tất", "Giữ khuôn mặt trong khung và thử lại.", Icons.Outlined.WarningAmber, "Cần thử lại" to StatusTone.WARNING)
        }
    }
    if (state.match == ProductionMatchState.MATCHING) {
        return Guidance("Đang so khớp khuôn mặt", "Đang so sánh khuôn mặt hiện tại với ảnh trên chip CCCD.", Icons.Outlined.Face, null)
    }
    if (state.passive?.state == LivenessSessionState.LIVE_DEVELOPMENT) {
        return Guidance("Đang kiểm tra tĩnh", "Giữ khuôn mặt trong khung trong giây lát.", Icons.Outlined.Security, "Đang kiểm tra" to StatusTone.NEUTRAL)
    }
    if (state.passive?.state == LivenessSessionState.SPOOF_DEVELOPMENT) {
        return Guidance("Không đạt kiểm tra chống giả mạo", "Hãy dùng khuôn mặt thật, không dùng ảnh hoặc màn hình.", Icons.Outlined.WarningAmber, "Thử lại" to StatusTone.ERROR)
    }
    val active = state.active
    if (active != null) {
        when (active.state) {
            ActiveLivenessState.WAITING_FOR_FACE -> return Guidance("Đưa khuôn mặt vào khung", "Đảm bảo khuôn mặt nhìn rõ và không có người khác trong khung.", Icons.Outlined.Face, null)
            ActiveLivenessState.WAITING_FOR_QUALITY -> return Guidance("Điều chỉnh khuôn mặt", "Đưa điện thoại ngang tầm mắt và chọn nơi đủ sáng.", Icons.Outlined.Face, null)
            ActiveLivenessState.ESTABLISHING_NEUTRAL -> return Guidance("Nhìn thẳng vào camera", "Giữ đầu thẳng và đứng yên trong giây lát.", Icons.Outlined.Face, null)
            ActiveLivenessState.CHALLENGE_ACTIVE,
            ActiveLivenessState.ACTION_IN_PROGRESS,
            ActiveLivenessState.RETURN_TO_NEUTRAL,
            ActiveLivenessState.NEXT_CHALLENGE,
            -> return Guidance(activeChallengeTitle(active.currentChallenge), "Làm theo hướng dẫn, sau đó trở về nhìn thẳng.", Icons.Outlined.Face, null)
            ActiveLivenessState.ACTION_CONFIRMED -> return Guidance("Đã nhận diện", "Chuẩn bị cho bước tiếp theo.", Icons.Outlined.CheckCircle, "Đã nhận diện" to StatusTone.SUCCESS)
            ActiveLivenessState.PASSED -> return Guidance("Đã kiểm tra người thật", "Giữ khuôn mặt ổn định để tiếp tục.", Icons.Outlined.CheckCircle, "Đạt" to StatusTone.SUCCESS)
            ActiveLivenessState.FAILED,
            ActiveLivenessState.INCONCLUSIVE,
            -> return Guidance("Chưa thể kiểm tra người thật", "Hãy giữ khuôn mặt trong khung và thử lại.", Icons.Outlined.WarningAmber, "Thử lại" to StatusTone.WARNING)
        }
    }
    return Guidance("Chuẩn bị camera", "Đưa toàn bộ khuôn mặt vào khung và nhìn thẳng vào camera.", Icons.Outlined.Face, null)
}

private fun activeChallengeTitle(challenge: ActiveChallenge?): String = when (challenge) {
    ActiveChallenge.LOOK_STRAIGHT, null -> "Nhìn thẳng vào camera"
    ActiveChallenge.BLINK -> "Chớp mắt"
    ActiveChallenge.TURN_LEFT -> "Quay đầu sang trái"
    ActiveChallenge.TURN_RIGHT -> "Quay đầu sang phải"
}

private fun stageNumber(state: ProductionBiometricUiState): Int = when {
    state.match != ProductionMatchState.WAITING -> 3
    state.passive != null && state.active?.state == ActiveLivenessState.PASSED -> 2
    else -> 1
}
