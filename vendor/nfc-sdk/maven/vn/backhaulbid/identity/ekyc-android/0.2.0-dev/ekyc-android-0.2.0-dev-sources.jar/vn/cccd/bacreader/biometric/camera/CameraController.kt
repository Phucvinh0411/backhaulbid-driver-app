package vn.cccd.bacreader.biometric.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Isolated CameraX foundation. It owns only preview/analysis binding and never touches NFC.
 * A frame callback receives ownership of each [CameraFrame] and must close it, directly or
 * through an asynchronous detector's completion callback.
 */
class CameraController(
    context: Context,
) : AutoCloseable {
    private val appContext = context.applicationContext
    private val mainExecutor = ContextCompat.getMainExecutor(appContext)
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null
    private var stateListener: ((CameraState) -> Unit)? = null
    private var closed = false

    var state: CameraState = CameraState.IDLE
        private set

    fun start(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView,
        onFrame: (CameraFrame) -> Unit,
        onState: (CameraState) -> Unit = {},
    ) {
        stateListener = onState
        if (closed) {
            publish(CameraState.ERROR(CameraError.CONTROLLER_CLOSED))
            return
        }
        publish(CameraState.STARTING)
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.CAMERA) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            publish(CameraState.ERROR(CameraError.PERMISSION_REQUIRED))
            return
        }

        val providerFuture = ProcessCameraProvider.getInstance(appContext)
        providerFuture.addListener({
            if (closed) return@addListener
            try {
                val cameraProvider = providerFuture.get()
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                imageAnalysis.setAnalyzer(analysisExecutor) { imageProxy ->
                    val frame = CameraFrame(imageProxy)
                    try {
                        onFrame(frame)
                    } catch (_: Exception) {
                        frame.close()
                        publish(CameraState.ERROR(CameraError.ANALYSIS_FAILED))
                    }
                }
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    preview,
                    imageAnalysis,
                )
                provider = cameraProvider
                analysis = imageAnalysis
                publish(CameraState.RUNNING)
            } catch (_: IllegalArgumentException) {
                publish(CameraState.ERROR(CameraError.FRONT_CAMERA_UNAVAILABLE))
            } catch (_: Exception) {
                publish(CameraState.ERROR(CameraError.BIND_FAILED))
            }
        }, mainExecutor)
    }

    fun stop() {
        analysis?.clearAnalyzer()
        analysis = null
        provider?.unbindAll()
        provider = null
        if (!closed) publish(CameraState.STOPPED)
    }

    override fun close() {
        if (closed) return
        closed = true
        analysis?.clearAnalyzer()
        analysis = null
        provider?.unbindAll()
        provider = null
        analysisExecutor.shutdownNow()
        publish(CameraState.STOPPED)
    }

    private fun publish(next: CameraState) {
        state = next
        stateListener?.invoke(next)
    }
}
