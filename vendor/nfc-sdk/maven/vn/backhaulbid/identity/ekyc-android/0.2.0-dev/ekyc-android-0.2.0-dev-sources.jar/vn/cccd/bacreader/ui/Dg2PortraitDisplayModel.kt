package vn.cccd.bacreader.ui

import vn.cccd.bacreader.domain.Dg2ImageFormat
import vn.cccd.bacreader.domain.ReadResult

/** Visible development-only state for the short-lived DG2 portrait preview. */
internal enum class Dg2PortraitDisplayState {
    DG2_PORTRAIT_READY,
    DG2_PORTRAIT_DECODE_FAILED,
}

/**
 * Safe metadata for the portrait preview. FAC dimensions are kept separate from decoded
 * dimensions because the two values describe different boundaries and must not be overwritten.
 */
internal data class Dg2PortraitDisplayModel(
    val state: Dg2PortraitDisplayState,
    val format: Dg2ImageFormat,
    val encodedLength: Int,
    val facWidth: Int?,
    val facHeight: Int?,
    val decodedWidth: Int? = null,
    val decodedHeight: Int? = null,
)

/** Result of preparing the short-lived portrait before publishing a scan result. */
internal data class PortraitDisplayCompletion(
    val accepted: Boolean,
    val model: Dg2PortraitDisplayModel?,
)

/**
 * Keeps the portrait model ready before the new result state can be rendered by the UI state
 * collector. A rejected result clears any retained bitmap so a stale portrait cannot survive.
 */
internal fun preparePortraitBeforeResult(
    outcome: ReadResult,
    prepareSuccess: (ReadResult.Success) -> Dg2PortraitDisplayModel?,
    clear: () -> Unit,
    finish: (ReadResult) -> Boolean,
): PortraitDisplayCompletion {
    val model = when (outcome) {
        is ReadResult.Success -> prepareSuccess(outcome)
        is ReadResult.Failure -> {
            clear()
            null
        }
    }
    val accepted = finish(outcome)
    if (!accepted) clear()
    return PortraitDisplayCompletion(accepted = accepted, model = model)
}
