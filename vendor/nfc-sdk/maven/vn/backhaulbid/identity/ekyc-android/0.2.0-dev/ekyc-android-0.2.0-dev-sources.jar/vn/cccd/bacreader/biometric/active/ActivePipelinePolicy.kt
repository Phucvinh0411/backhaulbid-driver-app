package vn.cccd.bacreader.biometric.active

/** Gate F ordering policy: passive inference cannot start before active PASS. */
object ActivePipelinePolicy {
    fun canStartPassive(activeState: ActiveLivenessState): Boolean =
        activeState == ActiveLivenessState.PASSED
}
