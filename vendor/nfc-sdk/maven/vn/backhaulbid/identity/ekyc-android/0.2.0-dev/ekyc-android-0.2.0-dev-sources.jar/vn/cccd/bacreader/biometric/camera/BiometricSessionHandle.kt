package vn.cccd.bacreader.biometric.camera

import android.graphics.Bitmap
import android.os.Binder
import vn.cccd.bacreader.domain.LdsEvidence

/**
 * A process-local hand-off for the lifecycle-owned biometric session. Only this
 * lightweight Binder reference crosses an Activity boundary; the portrait itself
 * never travels through an Intent or navigation arguments. The parent retains
 * ownership and the biometric Activity only borrows the portrait in production.
 */
class BiometricSessionHandle(
    portrait: Bitmap?,
    val cardEvidence: LdsEvidence? = null,
) : Binder(), AutoCloseable {
    private var ownedPortrait: Bitmap? = portrait

    @Synchronized
    fun takePortrait(): Bitmap? {
        val value = ownedPortrait
        ownedPortrait = null
        return value
    }

    /** Returns the session-owned portrait without transferring or releasing it. */
    @Synchronized
    fun borrowPortrait(): Bitmap? = ownedPortrait?.takeUnless { it.isRecycled }

    @Synchronized
    override fun close() {
        cardEvidence?.close()
        ownedPortrait?.let { bitmap ->
            if (!bitmap.isRecycled) bitmap.recycle()
        }
        ownedPortrait = null
    }
}
