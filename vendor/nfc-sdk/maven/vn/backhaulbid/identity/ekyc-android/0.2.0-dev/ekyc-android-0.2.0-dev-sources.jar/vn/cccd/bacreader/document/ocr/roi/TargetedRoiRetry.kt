package vn.cccd.bacreader.document.ocr.roi

import vn.cccd.bacreader.document.capture.DocumentSide
import vn.cccd.bacreader.document.readiness.DocumentCaptureReadiness
import vn.cccd.bacreader.document.readiness.RequiredFieldIssueType
import vn.cccd.bacreader.document.readiness.RequiredVisualField
import vn.cccd.bacreader.document.resolver.DocumentField
import vn.cccd.bacreader.document.resolver.NormalizedRect
import vn.cccd.bacreader.document.resolver.VietnamCardProfile
import vn.cccd.bacreader.document.resolver.VietnamCccdFieldProfiles
import vn.cccd.bacreader.document.resolver.VisualDocumentResolution

/** Stable key used to enforce one targeted retry per required field and side. */
data class RoiRetryKey(
    val field: RequiredVisualField,
    val side: DocumentSide,
)

data class TargetedRoiRequest(
    val key: RoiRetryKey,
    val field: RequiredVisualField,
    val side: DocumentSide,
    val region: NormalizedRect,
)

/** Plans at most one broad, profile-aware ROI retry for each unresolved required field. */
class TargetedRoiRetryPlanner {
    fun plan(
        resolution: VisualDocumentResolution,
        readiness: DocumentCaptureReadiness,
        attempted: Set<RoiRetryKey>,
    ): List<TargetedRoiRequest> = readiness.issues.filter {
        it.issue == RequiredFieldIssueType.MISSING || it.issue == RequiredFieldIssueType.INVALID
    }.flatMap { issue ->
        val field = issue.field.toDocumentField()
        val profile = VietnamCccdFieldProfiles.forField(field)
        retrySides(resolution, field, issue.preferredRetakeSide, profile.allowedSides)
            .mapNotNull { side ->
                val key = RoiRetryKey(issue.field, side)
                if (key in attempted) return@mapNotNull null
                TargetedRoiRequest(
                    key = key,
                    field = issue.field,
                    side = side,
                    region = profile.roiRegion(resolution.profile),
                )
            }
    }

    private fun retrySides(
        resolution: VisualDocumentResolution,
        field: DocumentField,
        preferredSide: DocumentSide?,
        allowedSides: Set<DocumentSide>,
    ): List<DocumentSide> {
        val configured = VietnamCccdFieldProfiles.forField(field).preferredSideByCardProfile[resolution.profile]
        return when {
            configured != null && configured in allowedSides -> listOf(configured)
            resolution.profile == VietnamCardProfile.UNKNOWN -> {
                val observed = resolution.field(field).sourceSide
                listOfNotNull(observed).ifEmpty { allowedSides.sortedBy(DocumentSide::ordinal) }
            }
            preferredSide != null && preferredSide in allowedSides -> listOf(preferredSide)
            else -> allowedSides.sortedBy(DocumentSide::ordinal)
        }.distinct()
    }

    private fun RequiredVisualField.toDocumentField(): DocumentField = when (this) {
        RequiredVisualField.DOCUMENT_NUMBER -> DocumentField.DOCUMENT_NUMBER
        RequiredVisualField.DATE_OF_BIRTH -> DocumentField.DATE_OF_BIRTH
        RequiredVisualField.DATE_OF_EXPIRY -> DocumentField.DATE_OF_EXPIRY
    }

    private fun vn.cccd.bacreader.document.resolver.FieldProfile.roiRegion(profile: VietnamCardProfile): NormalizedRect =
        roiRegions[profile] ?: expectedRegions[profile] ?: NormalizedRect(0.0, 0.0, 1.0, 1.0)
}
