package vn.cccd.bacreader.document.ocr

import vn.cccd.bacreader.document.capture.DocumentSide
import vn.cccd.bacreader.document.ocr.preprocess.PreprocessedOcr
import vn.cccd.bacreader.document.readiness.DocumentCaptureReadiness

/** Dimensions captured at the document-camera boundary before OCR starts. */
data class OcrInputMetadata(
    val analysisWidth: Int,
    val analysisHeight: Int,
    val analysisRotationDegrees: Int,
    val ocrBitmapWidth: Int,
    val ocrBitmapHeight: Int,
    val ocrRotationDegrees: Int,
    val cropWidth: Int? = null,
    val cropHeight: Int? = null,
    val stillWidth: Int? = null,
    val stillHeight: Int? = null,
    val stillRotationDegrees: Int? = null,
    val uprightSourceWidth: Int? = null,
    val uprightSourceHeight: Int? = null,
    val sourceKind: OcrSourceKind = OcrSourceKind.WHOLE_CARD,
    val roiField: String? = null,
) {
    val cropApplied: Boolean get() = cropWidth != null && cropHeight != null
}

enum class OcrSourceKind { WHOLE_CARD, TARGETED_ROI }

/** Safe, session-scoped OCR inspection record. The optional snapshot is never logged or persisted. */
data class OcrInspection(
    val side: DocumentSide,
    val source: OcrInputMetadata,
    val status: DocumentTextRecognitionStatus,
    val blockCount: Int,
    val lineCount: Int,
    val elementCount: Int,
    val snapshot: OcrSnapshot? = null,
)

object OcrInspectionFactory {
    fun from(
        side: DocumentSide,
        source: OcrInputMetadata,
        recognition: DocumentTextRecognitionResult,
    ): OcrInspection {
        val snapshot = recognition.snapshot
        return OcrInspection(
            side = side,
            source = source,
            status = recognition.status,
            blockCount = snapshot?.blocks?.size ?: 0,
            lineCount = snapshot?.blocks?.sumOf { it.lines.size } ?: 0,
            elementCount = snapshot?.blocks?.sumOf { block -> block.lines.sumOf { it.elements.size } } ?: 0,
            snapshot = snapshot,
        )
    }
}

/** Formats an explicitly requested DEBUG-only on-device inspector. */
object OcrInspectorFormatter {
    fun format(entries: Iterable<OcrInspection>): String = buildString {
        entries.sortedBy { it.side.ordinal }.forEachIndexed { index, entry ->
            if (index > 0) append("\n\n")
            append(entry.side.name).append('\n')
            append("Analysis frame: ")
                .append(entry.source.analysisWidth).append('×').append(entry.source.analysisHeight).append('\n')
            append("Analysis rotation: ").append(entry.source.analysisRotationDegrees).append("°\n")
            append("ImageCapture still: ")
                .append(entry.source.stillWidth?.toString() ?: "—")
                .append('×')
                .append(entry.source.stillHeight?.toString() ?: "—")
                .append('\n')
            append("Still rotation: ").append(entry.source.stillRotationDegrees?.toString() ?: "—").append("°\n")
            append("Upright source: ")
                .append(entry.source.uprightSourceWidth?.toString() ?: "—")
                .append('×')
                .append(entry.source.uprightSourceHeight?.toString() ?: "—")
                .append('\n')
            append("Crop output: ")
            if (entry.source.cropApplied) {
                append(entry.source.cropWidth).append('×').append(entry.source.cropHeight)
            } else {
                append("none")
            }
            append('\n')
            append("OCR bitmap: ")
                .append(entry.source.ocrBitmapWidth).append('×').append(entry.source.ocrBitmapHeight).append('\n')
            append("OCR input: ")
                .append(entry.source.ocrBitmapWidth).append('×').append(entry.source.ocrBitmapHeight).append('\n')
            append("OCR rotation argument: ").append(entry.source.ocrRotationDegrees).append("°\n")
            append("OCR source: ").append(entry.source.sourceKind.name)
            entry.source.roiField?.let { append(" (").append(it).append(')') }
            append('\n')
            append("Status: ").append(entry.status.name).append('\n')
            append("Blocks: ").append(entry.blockCount).append('\n')
            append("Lines: ").append(entry.lineCount).append('\n')
            append("Elements: ").append(entry.elementCount)
            entry.snapshot?.let { snapshot ->
                append("\n\nFull OCR text:\n").append(snapshot.fullText)
            }
        }
    }

    /** Formats derived text only for the explicitly requested DEBUG inspector. */
    fun formatPreprocessed(
        preprocessed: PreprocessedOcr?,
        resolution: vn.cccd.bacreader.document.resolver.VisualDocumentResolution?,
        readiness: vn.cccd.bacreader.document.readiness.DocumentCaptureReadiness?,
    ): String {
        if (preprocessed == null) return "Preprocessed OCR: unavailable"
        return buildString {
            append("PREPROCESSED OCR\n")
            preprocessed.lines.forEach { line ->
                append(line.side.name).append(" #").append(line.lineIndex + 1).append(": ")
                    .append(line.matchingText)
                    .append(" [source=").append(line.sourceKind.name)
                    .append(line.retryTargetField?.let { ",retryTarget=${it.name}" } ?: "")
                    .append(",geometry=")
                    .append(line.bounds?.let { "${it.left},${it.top},${it.right},${it.bottom}" } ?: "—")
                    .append("]\n")
            }
            append("\nSEGMENTS\n")
            if (preprocessed.segments.isEmpty()) {
                append("none\n")
            } else {
                preprocessed.segments.forEach { segment ->
                    append(segment.field.name)
                        .append(" -> ").append(segment.rawValue.ifBlank { "<empty>" })
                        .append(" [").append(segment.labelMatch.name).append("]")
                        .append(" transforms=")
                        .append(segment.transformations.joinToString(",") { it.name }.ifBlank { "none" })
                        .append(" source=").append(segment.sourceKind.name)
                        .append(segment.retryTargetField?.let { ",retryTarget=${it.name}" } ?: "")
                        .append(" geometry=")
                        .append(segment.valueBounds?.let { "${it.left},${it.top},${it.right},${it.bottom}" } ?: "—")
                        .append('\n')
                }
            }
            resolution?.let {
                append("\nRESOLVED FIELDS\n")
                DocumentFieldOrder.values().forEach { field ->
                    val resolved = it.field(field.field)
                    append(field.field.name).append(" = ").append(resolved.status.name)
                        .append(" score=").append(resolved.bestScore?.toString() ?: "—")
                        .append(" evidence=").append(resolved.evidence.joinToString(",") { it.name }.ifBlank { "—" })
                        .append('\n')
                    resolved.candidates.forEachIndexed { index, candidate ->
                        append("  candidate#").append(index + 1)
                            .append(" raw=").append(candidate.rawValue.ifBlank { "<empty>" })
                            .append(" canonical=").append(candidate.canonicalValue)
                            .append(" source=").append(candidate.sourceKinds.joinToString("+") { it.name })
                            .append(" retryTarget=")
                            .append(candidate.retryTargetFields.joinToString("+") { it.name }.ifBlank { "—" })
                            .append(" dedupGroup=").append(candidate.dedupGroupId)
                            .append(" transform=")
                            .append(candidate.transformations.joinToString(",") { it.name }.ifBlank { "none" })
                            .append(" evidence=")
                            .append(candidate.evidence.joinToString(",") { it.name }.ifBlank { "none" })
                            .append(" score=").append(candidate.score)
                            .append(" valid=").append(candidate.valid)
                            .append('\n')
                    }
                }
            }
            val roiSegments = preprocessed.segments.filter { it.sourceKind == OcrSourceKind.TARGETED_ROI }
            if (roiSegments.isNotEmpty()) {
                append("\nROI CANDIDATE DIAGNOSTICS\n")
                roiSegments.groupBy { it.retryTargetField }.forEach { (target, segments) ->
                    val targetName = target?.name ?: "—"
                    val merged = resolution?.let { resolved ->
                        resolvedFields().sumOf { field ->
                            resolved.field(field).candidates.count { candidate ->
                                candidate.sourceKinds.contains(OcrSourceKind.TARGETED_ROI) &&
                                    candidate.retryTargetFields.contains(field) &&
                                    candidate.retryTargetFields.contains(target)
                            }
                        }
                    } ?: 0
                    val discarded = segments.count { it.retryTargetField != null && it.field != it.retryTargetField }
                    append("retryTarget=").append(targetName)
                        .append(" candidatesDetected=").append(segments.size)
                        .append(" candidatesMerged=").append(merged)
                        .append(" unrelatedDiscarded=").append(discarded)
                        .append('\n')
                }
            }
            readiness?.let {
                append("\nREADINESS\n").append(it.status.name).append('\n')
                it.issues.forEach { issue ->
                    append(issue.field.name).append("/").append(issue.issue.name).append('\n')
                }
            }
        }
    }

    private fun resolvedFields(): List<vn.cccd.bacreader.document.resolver.DocumentField> = listOf(
        vn.cccd.bacreader.document.resolver.DocumentField.DOCUMENT_NUMBER,
        vn.cccd.bacreader.document.resolver.DocumentField.FULL_NAME,
        vn.cccd.bacreader.document.resolver.DocumentField.DATE_OF_BIRTH,
        vn.cccd.bacreader.document.resolver.DocumentField.SEX,
        vn.cccd.bacreader.document.resolver.DocumentField.NATIONALITY,
        vn.cccd.bacreader.document.resolver.DocumentField.DATE_OF_EXPIRY,
    )

    private enum class DocumentFieldOrder(val field: vn.cccd.bacreader.document.resolver.DocumentField) {
        DOCUMENT_NUMBER(vn.cccd.bacreader.document.resolver.DocumentField.DOCUMENT_NUMBER),
        FULL_NAME(vn.cccd.bacreader.document.resolver.DocumentField.FULL_NAME),
        DATE_OF_BIRTH(vn.cccd.bacreader.document.resolver.DocumentField.DATE_OF_BIRTH),
        SEX(vn.cccd.bacreader.document.resolver.DocumentField.SEX),
        NATIONALITY(vn.cccd.bacreader.document.resolver.DocumentField.NATIONALITY),
        DATE_OF_EXPIRY(vn.cccd.bacreader.document.resolver.DocumentField.DATE_OF_EXPIRY),
    }
}
