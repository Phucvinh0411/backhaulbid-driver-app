package vn.cccd.bacreader.biometric

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import vn.cccd.bacreader.domain.Dg2ImageFormat
import vn.cccd.bacreader.domain.Dg2Portrait

enum class Dg2DecodeFailure {
    PORTRAIT_CLOSED,
    JPEG_DECODE_FAILED,
    JPEG2000_UNSUPPORTED,
}

sealed interface Dg2DecodeResult {
    data class Success(val bitmap: Bitmap) : Dg2DecodeResult

    data class Failure(val reason: Dg2DecodeFailure) : Dg2DecodeResult
}

/** Decodes the exact payload extracted by [Dg2Portrait] without retaining card bytes. */
fun interface Dg2PortraitDecoder {
    fun decode(portrait: Dg2Portrait): Dg2DecodeResult
}

/**
 * Platform decoder boundary for Gate B.
 *
 * Android's [BitmapFactory] is used for JPEG. JPEG2000 is reported explicitly as unsupported
 * until a separately reviewed decoder and license are approved; it is never handed to an
 * unspecified fallback. The temporary copy is wiped after the platform call. Bitmap memory is
 * owned by the caller and may not be fully zeroized by the platform.
 */
class AndroidDg2PortraitDecoder : Dg2PortraitDecoder {
    override fun decode(portrait: Dg2Portrait): Dg2DecodeResult {
        if (portrait.format == Dg2ImageFormat.JPEG2000) {
            return Dg2DecodeResult.Failure(Dg2DecodeFailure.JPEG2000_UNSUPPORTED)
        }
        val bytes = try {
            portrait.copyEncodedImage()
        } catch (_: IllegalStateException) {
            return Dg2DecodeResult.Failure(Dg2DecodeFailure.PORTRAIT_CLOSED)
        }
        return try {
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (bitmap == null || bitmap.width <= 0 || bitmap.height <= 0) {
                bitmap?.recycle()
                Dg2DecodeResult.Failure(Dg2DecodeFailure.JPEG_DECODE_FAILED)
            } else {
                Dg2DecodeResult.Success(bitmap)
            }
        } finally {
            bytes.fill(0)
        }
    }
}
