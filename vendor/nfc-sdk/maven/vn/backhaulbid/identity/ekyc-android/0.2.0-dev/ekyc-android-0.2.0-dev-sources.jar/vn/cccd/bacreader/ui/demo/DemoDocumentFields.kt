package vn.cccd.bacreader.ui.demo

/** Legacy private-Activity hand-off; kept native, never a public SDK result. */
data class DemoDocumentFields(
    val documentNumber: String,
    val birthYYMMDD: String,
    val expiryYYMMDD: String,
    val fullNameRaw: String?,
    val sex: String? = null,
    val nationality: String? = null,
)
