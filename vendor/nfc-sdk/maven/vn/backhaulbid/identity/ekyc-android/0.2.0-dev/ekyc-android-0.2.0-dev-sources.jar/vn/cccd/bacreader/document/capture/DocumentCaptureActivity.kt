package vn.cccd.bacreader.document.capture

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.core.view.isVisible
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import vn.cccd.bacreader.R
import vn.cccd.bacreader.biometric.camera.CameraPermissionClassifier
import vn.cccd.bacreader.biometric.camera.CameraPermissionState
import vn.cccd.bacreader.databinding.ActivityDocumentCaptureBinding
import vn.cccd.bacreader.document.crosscheck.DocumentInput
import vn.cccd.bacreader.document.display.normalizeFullNameForDisplay
import vn.cccd.bacreader.document.ocr.CccdBackParser
import vn.cccd.bacreader.document.ocr.CccdFrontParser
import vn.cccd.bacreader.document.ocr.DocumentTextRecognitionCallback
import vn.cccd.bacreader.document.ocr.DocumentTextRecognitionResult
import vn.cccd.bacreader.document.ocr.DocumentTextRecognitionStatus
import vn.cccd.bacreader.document.ocr.DocumentOcrSession
import vn.cccd.bacreader.document.ocr.MlKitDocumentTextRecognizer
import vn.cccd.bacreader.document.ocr.OcrAttemptToken
import vn.cccd.bacreader.document.ocr.OcrInputMetadata
import vn.cccd.bacreader.document.ocr.OcrInspection
import vn.cccd.bacreader.document.ocr.OcrInspectionFactory
import vn.cccd.bacreader.document.ocr.OcrInspectorFormatter
import vn.cccd.bacreader.document.ocr.OcrSnapshot
import vn.cccd.bacreader.document.ocr.OcrSnapshotMerger
import vn.cccd.bacreader.document.ocr.OcrSourceKind
import vn.cccd.bacreader.document.ocr.withSource
import vn.cccd.bacreader.document.ocr.processing.DocumentOcrProcessor
import vn.cccd.bacreader.document.ocr.roi.RoiRetryKey
import vn.cccd.bacreader.document.ocr.roi.TargetedRoiRequest
import vn.cccd.bacreader.document.ocr.roi.TargetedRoiRetryPlanner
import vn.cccd.bacreader.document.quality.DocumentFrameMetrics
import vn.cccd.bacreader.document.quality.DocumentQualityConfig
import vn.cccd.bacreader.document.quality.DocumentQualityEvaluator
import vn.cccd.bacreader.document.quality.DocumentQualityResult
import vn.cccd.bacreader.document.quality.DocumentQualityStatus
import vn.cccd.bacreader.document.ocr.preprocess.PreprocessedOcr
import vn.cccd.bacreader.document.readiness.DocumentCaptureReadiness
import vn.cccd.bacreader.document.readiness.DocumentReadinessStatus
import vn.cccd.bacreader.document.readiness.RequiredVisualField
import vn.cccd.bacreader.ui.SecureWindowPolicy
import vn.cccd.bacreader.ui.EkycUiPolicy
import vn.cccd.bacreader.document.resolver.DocumentField
import vn.cccd.bacreader.document.resolver.VisualDocumentResolution
import vn.cccd.bacreader.document.resolver.NormalizedRect

class DocumentCaptureActivity : ComponentActivity() {
    private lateinit var binding: ActivityDocumentCaptureBinding
    private lateinit var cameraController: DocumentCameraController
    private lateinit var textRecognizer: MlKitDocumentTextRecognizer
    private val qualityConfig = DocumentQualityConfig()
    private val qualityEvaluator = DocumentQualityEvaluator(qualityConfig)
    private val captureMode = DocumentCaptureMode.MANUAL
    private val captureSession = DocumentCaptureSession(
        DocumentCaptureConfig(qualityConfig.stableGoodFrames, mode = captureMode),
    )
    private val ocrSession = DocumentOcrSession()
    private var permissionRequested = false
    private var requestInFlight = false
    private var permissionState = CameraPermissionState.CAMERA_PERMISSION_UNKNOWN
    private var frontBitmap: Bitmap? = null
    private var backBitmap: Bitmap? = null
    private var frontResult: vn.cccd.bacreader.document.ocr.CccdFrontResult? = null
    private var backResult: vn.cccd.bacreader.document.ocr.CccdBackResult? = null
    private var documentInput: DocumentInput? = null
    private var visualResolution: VisualDocumentResolution? = null
    private var preprocessedOcr: PreprocessedOcr? = null
    private var documentReadiness: DocumentCaptureReadiness? = null
    private var latestQuality: DocumentQualityResult? = null
    private var frontOcrComplete = false
    private var backOcrComplete = false
    private val captureInFlight = AtomicBoolean(false)
    private val cropExecutor = Executors.newSingleThreadExecutor()
    /** Keeps large bitmap copies and resolver/readiness work off the UI thread. */
    private val ocrExecutor = Executors.newSingleThreadExecutor()
    private val ocrProcessor = DocumentOcrProcessor()
    private val processingInFlight = AtomicBoolean(false)
    private val ocrBitmaps = ConcurrentHashMap<OcrAttemptToken, Bitmap>()
    private val ocrInspections = linkedMapOf<DocumentSide, OcrInspection>()
    private val roiInspections = linkedMapOf<RoiRetryKey, OcrInspection>()
    private val roiAttempts = linkedSetOf<RoiRetryKey>()
    private val roiSnapshots = linkedMapOf<RoiRetryKey, RoiSnapshotRecord>()
    private val roiPlanner = TargetedRoiRetryPlanner()
    private val roiBitmaps = ConcurrentHashMap<RoiRetryKey, Bitmap>()
    private var roiInFlightKey: RoiRetryKey? = null
    @Volatile private var latestAnalysisMetadata: OcrInputMetadata? = null
    private var pendingStill: DocumentStill? = null
    private var pendingSide: DocumentSide? = null
    private var pendingStillSource: OcrInputMetadata? = null
    private val uiPolicy = EkycUiPolicy.forBuild(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        requestInFlight = false
        permissionRequested = true
        refreshPermissionState(granted)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SecureWindowPolicy.apply(this, uiPolicy)
        binding = ActivityDocumentCaptureBinding.inflate(layoutInflater)
        setContentView(binding.root)
        permissionRequested = savedInstanceState?.getBoolean(KEY_PERMISSION_REQUESTED) ?: false
        cameraController = DocumentCameraController(this)
        textRecognizer = MlKitDocumentTextRecognizer()

        binding.documentCloseButton.setOnClickListener { finish() }
        binding.documentPermissionButton.setOnClickListener { onPermissionAction() }
        binding.documentCaptureButton.setOnClickListener { requestManualCapture() }
        binding.documentCropConfirmButton.setOnClickListener { confirmCrop() }
        binding.documentCropRetakeButton.setOnClickListener { retakeCrop() }
        binding.documentCropResetButton.setOnClickListener { binding.documentCropView.resetQuad() }
        binding.documentRetryFrontButton.setOnClickListener { retryFront() }
        binding.documentRetryBackButton.setOnClickListener { retryBack() }
        binding.documentContinueButton.setOnClickListener { continueWithInput() }
        binding.documentDebugOcrButton.isVisible = uiPolicy.showDebugDiagnostics
        binding.documentDebugOcrButton.setOnClickListener { toggleOcrInspector() }
        binding.documentGuide.setAspectRatio(qualityConfig.guideAspectRatio)
        binding.documentDebug.isVisible = uiPolicy.showDebugDiagnostics
        binding.documentCaptureButton.isVisible = captureMode == DocumentCaptureMode.MANUAL
        renderCaptureState(captureSession.snapshot())
        refreshPermissionState()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && !requestInFlight) refreshPermissionState()
    }

    override fun onPause() {
        if (::cameraController.isInitialized) cameraController.stop()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean(KEY_PERMISSION_REQUESTED, permissionRequested)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (::cameraController.isInitialized) cameraController.close()
        if (::textRecognizer.isInitialized) textRecognizer.close()
        captureInFlight.set(false)
        ocrSession.close()
        visualResolution = null
        preprocessedOcr = null
        documentReadiness = null
        ocrInspections.clear()
        clearRoiState()
        ocrBitmaps.values.forEach(::releaseBitmap)
        ocrBitmaps.clear()
        clearReviewImages()
        releaseBitmap(frontBitmap)
        releaseBitmap(backBitmap)
        pendingStill?.close()
        pendingStill = null
        pendingSide = null
        pendingStillSource = null
        binding.documentCropView.clear()
        cropExecutor.shutdownNow()
        ocrExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun refreshPermissionState(grantedOverride: Boolean? = null) {
        val granted = grantedOverride ?: ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        permissionState = CameraPermissionClassifier.classify(
            isGranted = granted,
            shouldShowRationale = shouldShowRequestPermissionRationale(Manifest.permission.CAMERA),
            requestAttempted = permissionRequested,
        )
        when (permissionState) {
            CameraPermissionState.CAMERA_PERMISSION_GRANTED -> {
                binding.documentPermissionButton.isVisible = false
                startCameraIfNeeded()
            }
            CameraPermissionState.CAMERA_PERMISSION_PERMANENTLY_DENIED -> {
                binding.documentPermissionButton.setText(R.string.document_permission_settings)
                binding.documentPermissionButton.isVisible = true
                binding.documentStatus.setText(R.string.document_permission_permanently_denied)
            }
            CameraPermissionState.CAMERA_PERMISSION_DENIED -> {
                binding.documentPermissionButton.setText(R.string.document_permission_request)
                binding.documentPermissionButton.isVisible = true
                binding.documentStatus.setText(R.string.document_permission_denied)
            }
            CameraPermissionState.CAMERA_PERMISSION_UNKNOWN -> {
                binding.documentPermissionButton.setText(R.string.document_permission_request)
                binding.documentPermissionButton.isVisible = true
                binding.documentStatus.setText(R.string.document_permission_unknown)
            }
        }
    }

    private fun onPermissionAction() {
        when (permissionState) {
            CameraPermissionState.CAMERA_PERMISSION_GRANTED -> startCameraIfNeeded()
            CameraPermissionState.CAMERA_PERMISSION_PERMANENTLY_DENIED -> {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:$packageName".toUri()))
            }
            else -> {
                permissionRequested = true
                requestInFlight = true
                permissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun startCameraIfNeeded() {
        if (binding.documentReview.isVisible || binding.documentCropPanel.isVisible) return
        if (cameraController.state == DocumentCameraState.RUNNING || cameraController.state == DocumentCameraState.STARTING) return
        cameraController.start(
            lifecycleOwner = this,
            previewView = binding.documentPreview,
            onFrame = { frame ->
                try {
                    val snapshot = captureSession.snapshot()
                    latestAnalysisMetadata = OcrInputMetadata(
                        analysisWidth = frame.width,
                        analysisHeight = frame.height,
                        analysisRotationDegrees = frame.rotationDegrees,
                        ocrBitmapWidth = 0,
                        ocrBitmapHeight = 0,
                        ocrRotationDegrees = 0,
                    )
                    val metrics = frame.analyze(qualityConfig, snapshot.goodFrameCount)
                    val safeMetrics = metrics ?: noDocumentMetrics(frame.width, frame.height)
                    val baseQuality = qualityEvaluator.evaluate(
                        safeMetrics,
                        stableGoodFrames = qualityConfig.stableGoodFrames,
                    )
                    val decision = captureSession.onQuality(baseQuality.status)
                    val quality = if (baseQuality.status == DocumentQualityStatus.GOOD) {
                        qualityEvaluator.evaluate(safeMetrics, decision.goodFrameCount)
                    } else {
                        baseQuality.copy(stableGoodFrames = decision.goodFrameCount)
                    }
                    runOnUiThread {
                        latestQuality = quality
                        renderQuality(quality)
                        renderCaptureState(captureSession.snapshot())
                    }
                } finally {
                    frame.close()
                }
            },
            onStatus = { status -> runOnUiThread { renderCameraStatus(status) } },
        )
    }

    private fun requestManualCapture() {
        if (captureMode != DocumentCaptureMode.MANUAL || captureInFlight.get()) return
        val quality = latestQuality ?: return
        val decision = captureSession.requestCapture(quality.status)
        if (!decision.shouldCapture) {
            binding.documentStatus.setText(R.string.document_capture_quality_required)
            renderCaptureState(captureSession.snapshot())
            return
        }
        if (!captureInFlight.compareAndSet(false, true)) return
        val side = decision.side
        binding.documentCaptureButton.isEnabled = false
        binding.documentStatus.setText(R.string.document_capture_in_progress)
        renderCaptureState(captureSession.snapshot())
        cameraController.captureStill(
            onSuccess = { still -> runOnUiThread { onStillCaptured(side, still) } },
            onError = { error -> runOnUiThread { onStillCaptureFailed(error) } },
        )
    }

    private fun onStillCaptureFailed(error: DocumentStillFailure) {
        if (isFinishing || isDestroyed) return
        captureInFlight.set(false)
        captureSession.onCaptureCompleted(false)
        latestQuality = null
        binding.documentStatus.text = getString(R.string.document_capture_still_failed, error.name)
        renderCaptureState(captureSession.snapshot())
    }

    private fun onStillCaptured(side: DocumentSide, still: DocumentStill) {
        if (isFinishing || isDestroyed) {
            still.close()
            return
        }
        captureInFlight.set(false)
        cameraController.stop()
        pendingStill?.close()
        pendingStill = still
        pendingSide = side
        pendingStillSource = latestAnalysisMetadata ?: OcrInputMetadata(0, 0, 0, 0, 0, 0)
        captureSession.onStillCaptured()
        binding.documentCapturePanel.isVisible = false
        binding.documentCropPanel.isVisible = true
        binding.documentCropInstruction.setText(
            if (side == DocumentSide.FRONT) R.string.document_crop_front_instruction else R.string.document_crop_back_instruction,
        )
        binding.documentCropView.setBitmap(still.bitmap)
        binding.documentCropConfirmButton.isEnabled = true
        binding.documentCropRetakeButton.isEnabled = true
        binding.documentCropResetButton.isEnabled = true
        binding.documentStatus.setText(R.string.document_crop_adjust_instruction)
    }

    private fun confirmCrop() {
        val still = pendingStill ?: return
        val side = pendingSide ?: return
        val quad = binding.documentCropView.currentQuad()
        if (quad == null || !CropGeometry.isValid(quad, still.uprightWidth, still.uprightHeight)) {
            binding.documentStatus.setText(R.string.document_crop_invalid)
            return
        }
        binding.documentCropConfirmButton.isEnabled = false
        binding.documentCropRetakeButton.isEnabled = false
        binding.documentCropResetButton.isEnabled = false
        captureSession.onCropProcessing()
        binding.documentStatus.setText(R.string.document_crop_processing)
        val source = pendingStillSource ?: OcrInputMetadata(0, 0, 0, 0, 0, 0)
        cropExecutor.execute {
            val started = System.nanoTime()
            val cropped = DocumentPerspectiveCropper.crop(still.bitmap, quad)
            val elapsed = (System.nanoTime() - started) / 1_000_000L
            runOnUiThread { onCropFinished(side, still, source, cropped, elapsed) }
        }
    }

    private fun onCropFinished(
        side: DocumentSide,
        still: DocumentStill,
        source: OcrInputMetadata,
        cropped: Bitmap?,
        elapsedMs: Long,
    ) {
        if (pendingStill !== still || pendingSide != side || isFinishing || isDestroyed) {
            releaseBitmap(cropped)
            return
        }
        if (cropped == null) {
            captureSession.onCropFailed()
            binding.documentCropConfirmButton.isEnabled = true
            binding.documentCropRetakeButton.isEnabled = true
            binding.documentCropResetButton.isEnabled = true
            binding.documentStatus.setText(R.string.document_crop_failed)
            return
        }
        val stillCaptureWidth = still.captureWidth
        val stillCaptureHeight = still.captureHeight
        val stillRotation = still.rotationDegrees
        val uprightWidth = still.uprightWidth
        val uprightHeight = still.uprightHeight
        pendingStill = null
        pendingSide = null
        pendingStillSource = null
        still.close()
        binding.documentCropView.clear()
        binding.documentCropPanel.isVisible = false
        binding.documentCapturePanel.isVisible = true
        captureSession.onCropReadyForOcr()
        val metadata = source.copy(
            stillWidth = stillCaptureWidth,
            stillHeight = stillCaptureHeight,
            stillRotationDegrees = stillRotation,
            uprightSourceWidth = uprightWidth,
            uprightSourceHeight = uprightHeight,
            cropWidth = cropped.width,
            cropHeight = cropped.height,
            ocrBitmapWidth = cropped.width,
            ocrBitmapHeight = cropped.height,
            ocrRotationDegrees = 0,
        )
        binding.documentStatus.text = getString(R.string.document_crop_complete, elapsedMs)
        if (side == DocumentSide.FRONT) {
            releaseBitmap(frontBitmap)
            frontBitmap = cropped
            frontOcrComplete = false
        } else {
            releaseBitmap(backBitmap)
            backBitmap = cropped
            backOcrComplete = false
        }
        startOcrForSide(side, cropped, metadata)
    }

    private fun retakeCrop() {
        val side = pendingSide ?: return
        pendingStill?.close()
        pendingStill = null
        pendingSide = null
        pendingStillSource = null
        binding.documentCropView.clear()
        captureSession.retry(side)
        latestQuality = null
        binding.documentCropPanel.isVisible = false
        binding.documentCapturePanel.isVisible = true
        binding.documentStatus.setText(R.string.document_capture_quality_required)
        renderCaptureState(captureSession.snapshot())
        startCameraIfNeeded()
    }

    private fun startOcrForSide(side: DocumentSide, capturedBitmap: Bitmap, source: OcrInputMetadata) {
        val token = ocrSession.beginAttempt(side)
        binding.documentStatus.setText(R.string.document_processing)
        ocrExecutor.execute {
            if (isFinishing || isDestroyed) return@execute
            // A high-resolution crop can be tens of megabytes in ARGB_8888;
            // copying it here avoids blocking the capture/result UI.
            val ocrBitmap = runCatching {
                capturedBitmap.takeIf { !it.isRecycled }?.copy(Bitmap.Config.ARGB_8888, false)
            }.getOrNull()
            if (ocrBitmap == null) {
                if (ocrSession.complete(token, null)) {
                    runOnUiThread {
                        onOcrCompleted(
                            side,
                            token,
                            DocumentTextRecognitionResult(DocumentTextRecognitionStatus.FAILED),
                            source,
                        )
                    }
                }
                return@execute
            }
            if (isFinishing || isDestroyed) {
                releaseBitmap(ocrBitmap)
                return@execute
            }
            ocrBitmaps[token] = ocrBitmap
            // onDestroy() may race with worker registration; avoid leaving a
            // bitmap in the map after the Activity has released its session.
            if (isFinishing || isDestroyed) {
                ocrBitmaps.remove(token)?.let(::releaseBitmap)
                return@execute
            }
            textRecognizer.recognize(
                bitmap = ocrBitmap,
                documentSide = side,
                rotationDegrees = 0,
                callback = DocumentTextRecognitionCallback { result ->
                    val accepted = ocrSession.complete(token, result.snapshot)
                    if (!accepted) {
                        ocrBitmaps.remove(token)?.let(::releaseBitmap)
                        return@DocumentTextRecognitionCallback
                    }
                    // Recycle the temporary high-resolution OCR bitmap before
                    // returning to the UI thread; the immutable snapshot is
                    // all the result pipeline needs from this point onward.
                    ocrBitmaps.remove(token)?.let(::releaseBitmap)
                    runOnUiThread { onOcrCompleted(side, token, result, source) }
                },
            )
        }
    }

    private fun onOcrCompleted(
        side: DocumentSide,
        token: OcrAttemptToken,
        result: DocumentTextRecognitionResult,
        source: OcrInputMetadata,
    ) {
        ocrBitmaps.remove(token)?.let(::releaseBitmap)
        ocrInspections[side] = OcrInspectionFactory.from(side, source, result)
        val text = result.snapshot?.fullText.orEmpty()
        runOnUiThread {
            visualResolution = null
            when (side) {
                DocumentSide.FRONT -> {
                    frontResult = CccdFrontParser().parse(text)
                    frontOcrComplete = true
                    captureSession.onCaptureCompleted(true)
                    val next = captureSession.advance()
                    binding.documentCapturePanel.isVisible = true
                    binding.documentCropPanel.isVisible = false
                    binding.documentStatus.setText(R.string.document_front_captured)
                    renderCaptureState(next)
                    startCameraIfNeeded()
                }
                DocumentSide.BACK -> {
                    backResult = CccdBackParser().parse(text)
                    backOcrComplete = true
                    captureSession.onCaptureCompleted(true)
                }
            }
            finishOcrIfReady()
        }
    }

    private fun finishOcrIfReady() {
        if (!frontOcrComplete || !backOcrComplete) return
        if (!processingInFlight.compareAndSet(false, true)) return
        val effectiveFront = effectiveSnapshot(DocumentSide.FRONT)
        val effectiveBack = effectiveSnapshot(DocumentSide.BACK)
        ocrExecutor.execute {
            val processed = runCatching {
                ocrProcessor.process(front = effectiveFront, back = effectiveBack)
            }.getOrNull()
            runOnUiThread {
                processingInFlight.set(false)
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (processed == null) {
                    binding.documentStatus.text = "OCR processing failed. Please capture again."
                    binding.documentContinueButton.isEnabled = false
                    return@runOnUiThread
                }
                preprocessedOcr = processed.preprocessed
                visualResolution = processed.resolution
                documentReadiness = processed.readiness
                if (startTargetedRoiRetry()) return@runOnUiThread
                val front = frontResult ?: CccdFrontParser().parse("")
                val back = backResult ?: CccdBackParser().parse("")
                documentInput = DocumentInput.fromVisualResolution(processed.resolution, front, back)
                captureSession.markReview()
                showReview()
            }
        }
    }

    private fun showReview() {
        binding.documentCapturePanel.isVisible = false
        binding.documentCropPanel.isVisible = false
        binding.documentReview.isVisible = true
        binding.documentDebugOcrButton.isVisible = uiPolicy.showDebugDiagnostics
        binding.documentDebugOcrInspector.isVisible = false
        binding.documentDebugOcrInspector.text = null
        binding.documentReviewFront.setImageBitmap(frontBitmap)
        binding.documentReviewBack.setImageBitmap(backBitmap)
        val input = documentInput
        binding.documentReviewFields.text = buildReviewText(input, visualResolution, documentReadiness)
        binding.documentContinueButton.isEnabled = documentReadiness?.isReady == true
    }

    /** Runs one broad, profile-aware OCR retry for an unresolved required field. */
    private fun startTargetedRoiRetry(): Boolean {
        val resolution = visualResolution ?: return false
        val readiness = documentReadiness ?: return false
        if (readiness.isReady || roiInFlightKey != null) return roiInFlightKey != null
        val request = roiPlanner.plan(resolution, readiness, roiAttempts)
            .firstOrNull { roiBitmapFor(it) != null }
            ?: return false
        val sourceBitmap = bitmapForSide(request.side) ?: return false
        val rect = request.region.toPixelRect(sourceBitmap.width, sourceBitmap.height) ?: return false
        val roiBitmap = runCatching {
            Bitmap.createBitmap(sourceBitmap, rect.left, rect.top, rect.width(), rect.height())
        }.getOrNull() ?: return false
        roiAttempts += request.key
        roiInFlightKey = request.key
        roiBitmaps[request.key] = roiBitmap
        binding.documentStatus.text = getString(R.string.document_roi_retrying, request.field.name, request.side.name)
        val metadata = OcrInputMetadata(
            analysisWidth = sourceBitmap.width,
            analysisHeight = sourceBitmap.height,
            analysisRotationDegrees = 0,
            ocrBitmapWidth = roiBitmap.width,
            ocrBitmapHeight = roiBitmap.height,
            ocrRotationDegrees = 0,
            cropWidth = roiBitmap.width,
            cropHeight = roiBitmap.height,
            sourceKind = OcrSourceKind.TARGETED_ROI,
            roiField = request.field.name,
        )
        textRecognizer.recognize(
            bitmap = roiBitmap,
            documentSide = request.side,
            rotationDegrees = 0,
            callback = DocumentTextRecognitionCallback { result ->
                roiBitmaps.remove(request.key)?.let(::releaseBitmap)
                runOnUiThread {
                    if (isFinishing || isDestroyed || roiInFlightKey != request.key) return@runOnUiThread
                    roiInFlightKey = null
                    roiInspections[request.key] = OcrInspectionFactory.from(request.side, metadata, result)
                    result.snapshot?.let { snapshot ->
                        roiSnapshots[request.key] = RoiSnapshotRecord(
                            snapshot.withSource(
                                sourceKind = OcrSourceKind.TARGETED_ROI,
                                retryTargetField = request.field.toDocumentField(),
                            ),
                            rect.left,
                            rect.top,
                        )
                    }
                    if (result.status != DocumentTextRecognitionStatus.SUCCESS) {
                        binding.documentStatus.setText(R.string.document_roi_retry_failed)
                    }
                    finishOcrIfReady()
                }
            },
        )
        return true
    }

    private fun roiBitmapFor(request: TargetedRoiRequest): Bitmap? = bitmapForSide(request.side)?.let { bitmap ->
        request.region.toPixelRect(bitmap.width, bitmap.height)?.takeIf { it.width() >= 8 && it.height() >= 8 }?.let { bitmap }
    }

    private fun bitmapForSide(side: DocumentSide): Bitmap? = when (side) {
        DocumentSide.FRONT -> frontBitmap
        DocumentSide.BACK -> backBitmap
    }?.takeIf { !it.isRecycled }

    private fun effectiveSnapshot(side: DocumentSide): OcrSnapshot? {
        var current = when (side) {
            DocumentSide.FRONT -> ocrSession.frontSnapshot
            DocumentSide.BACK -> ocrSession.backSnapshot
        }
        roiSnapshots.filterValues { it.snapshot.documentSide == side }.values.forEach { record ->
            current = if (current == null) record.snapshot else OcrSnapshotMerger.merge(
                current!!,
                record.snapshot,
                record.left,
                record.top,
            )
        }
        return current
    }

    private fun NormalizedRect.toPixelRect(width: Int, height: Int): Rect? {
        val left = (left * width).toInt().coerceIn(0, width)
        val top = (top * height).toInt().coerceIn(0, height)
        val right = (right * width).toInt().coerceIn(left, width)
        val bottom = (bottom * height).toInt().coerceIn(top, height)
        return Rect(left, top, right, bottom).takeIf { it.width() > 0 && it.height() > 0 }
    }

    private fun buildReviewText(
        input: DocumentInput?,
        resolution: VisualDocumentResolution?,
        readiness: DocumentCaptureReadiness? = null,
    ): String {
        if (resolution == null) {
            return if (input == null) getString(R.string.document_review_no_fields) else getString(
                R.string.document_review_fields,
                maskDocumentNumber(input.documentNumber),
                input.birthYYMMDD ?: "not found",
                input.expiryYYMMDD ?: "not found",
                input.crossCheck.documentNumber.name,
                input.crossCheck.dateOfBirth.name,
                backResult?.mrz?.status?.name ?: "UNKNOWN",
            )
        }
        val lines = StringBuilder(getString(R.string.document_review_v2_title))
            .append("\n")
            .append(getString(R.string.document_review_v2_profile, resolution.profile.name))
        listOf(
            DocumentField.DOCUMENT_NUMBER,
            DocumentField.FULL_NAME,
            DocumentField.DATE_OF_BIRTH,
            DocumentField.SEX,
            DocumentField.NATIONALITY,
            DocumentField.DATE_OF_EXPIRY,
        ).forEach { field ->
            val resolved = resolution.field(field)
            val visibleValue = when (field) {
                DocumentField.DOCUMENT_NUMBER -> maskDocumentNumber(resolved.value)
                DocumentField.FULL_NAME -> resolved.value?.let(::normalizeFullNameForDisplay) ?: "—"
                else -> resolved.value ?: "—"
            }
            lines.append("\n").append(
                getString(
                    R.string.document_review_v2_field,
                    fieldLabel(field),
                    visibleValue,
                    resolved.status.name,
                ),
            )
            if (uiPolicy.showDebugDiagnostics) {
                lines.append("\n").append(
                    getString(
                        R.string.document_review_v2_debug,
                        resolved.sourceSide?.name ?: "—",
                        resolved.evidence.joinToString(", ") { it.name }.ifEmpty { "—" },
                        resolved.candidateCount,
                    ),
                )
                if (field == DocumentField.DATE_OF_EXPIRY) {
                    lines.append("\n").append(
                        getString(
                            R.string.document_review_v2_expiry_diagnostics,
                            resolved.diagnostics.frontLabelCandidates,
                            resolved.diagnostics.backLabelCandidates,
                            resolved.diagnostics.frontValueCandidatesNearLabel,
                            resolved.diagnostics.backValueCandidatesNearLabel,
                        ),
                    )
                }
            }
        }
        readiness?.let { ready ->
            lines.append("\n\n").append(readinessText(ready))
        }
        return lines.toString()
    }

    private fun readinessText(readiness: DocumentCaptureReadiness): String {
        if (readiness.isReady) return getString(R.string.document_readiness_ready)
        val fields = readiness.issues.joinToString(", ") { issue ->
            when (issue.field) {
                RequiredVisualField.DOCUMENT_NUMBER -> getString(R.string.document_review_v2_document_number)
                RequiredVisualField.DATE_OF_BIRTH -> getString(R.string.document_review_v2_date_of_birth)
                RequiredVisualField.DATE_OF_EXPIRY -> getString(R.string.document_review_v2_date_of_expiry)
            }
        }
        val message = when (readiness.status) {
            DocumentReadinessStatus.MISSING_REQUIRED_FIELDS -> getString(R.string.document_readiness_missing, fields)
            DocumentReadinessStatus.INVALID_REQUIRED_FIELDS -> getString(R.string.document_readiness_invalid, fields)
            DocumentReadinessStatus.AMBIGUOUS_REQUIRED_FIELDS -> getString(R.string.document_readiness_ambiguous, fields)
            DocumentReadinessStatus.MULTIPLE_REQUIRED_FIELD_ERRORS -> getString(R.string.document_readiness_multiple, fields)
            DocumentReadinessStatus.READY -> getString(R.string.document_readiness_ready)
        }
        val action = when (readiness.recommendedAction) {
            vn.cccd.bacreader.document.readiness.DocumentRecoveryAction.RETAKE_FRONT -> getString(R.string.document_readiness_retake_front)
            vn.cccd.bacreader.document.readiness.DocumentRecoveryAction.RETAKE_BACK -> getString(R.string.document_readiness_retake_back)
            vn.cccd.bacreader.document.readiness.DocumentRecoveryAction.RETAKE_DOCUMENT_SIDE -> getString(R.string.document_readiness_retake_side)
            vn.cccd.bacreader.document.readiness.DocumentRecoveryAction.NONE -> ""
        }
        return if (action.isBlank()) message else "$message\n$action"
    }

    private fun fieldLabel(field: DocumentField): String = when (field) {
        DocumentField.DOCUMENT_NUMBER -> getString(R.string.document_review_v2_document_number)
        DocumentField.FULL_NAME -> getString(R.string.document_review_v2_full_name)
        DocumentField.DATE_OF_BIRTH -> getString(R.string.document_review_v2_date_of_birth)
        DocumentField.SEX -> getString(R.string.document_review_v2_sex)
        DocumentField.NATIONALITY -> getString(R.string.document_review_v2_nationality)
        DocumentField.DATE_OF_EXPIRY -> getString(R.string.document_review_v2_date_of_expiry)
    }

    private fun retryFront() {
        captureInFlight.set(false)
        ocrSession.newSession()
        clearReviewImages()
        pendingStill?.close()
        pendingStill = null
        pendingSide = null
        pendingStillSource = null
        binding.documentCropView.clear()
        releaseBitmap(frontBitmap)
        releaseBitmap(backBitmap)
        frontBitmap = null
        backBitmap = null
        frontResult = null
        backResult = null
        documentInput = null
        visualResolution = null
        preprocessedOcr = null
        documentReadiness = null
        ocrInspections.clear()
        clearRoiState()
        binding.documentDebugOcrInspector.isVisible = false
        binding.documentDebugOcrInspector.text = null
        frontOcrComplete = false
        backOcrComplete = false
        latestQuality = null
        captureSession.retry(DocumentSide.FRONT)
        binding.documentReview.isVisible = false
        binding.documentCapturePanel.isVisible = true
        renderCaptureState(captureSession.snapshot())
        startCameraIfNeeded()
    }

    private fun retryBack() {
        captureInFlight.set(false)
        ocrSession.retake(DocumentSide.BACK)
        clearReviewImages()
        pendingStill?.close()
        pendingStill = null
        pendingSide = null
        pendingStillSource = null
        binding.documentCropView.clear()
        releaseBitmap(backBitmap)
        backBitmap = null
        backResult = null
        documentInput = null
        visualResolution = null
        preprocessedOcr = null
        documentReadiness = null
        ocrInspections.remove(DocumentSide.BACK)
        clearRoiState(DocumentSide.BACK)
        binding.documentDebugOcrInspector.isVisible = false
        binding.documentDebugOcrInspector.text = null
        backOcrComplete = false
        latestQuality = null
        captureSession.retry(DocumentSide.BACK)
        binding.documentReview.isVisible = false
        binding.documentCapturePanel.isVisible = true
        renderCaptureState(captureSession.snapshot())
        startCameraIfNeeded()
    }

    private fun continueWithInput() {
        if (documentReadiness?.isReady != true) {
            binding.documentStatus.setText(R.string.document_readiness_continue_blocked)
            return
        }
        val input = documentInput
        ocrSession.close()
        captureSession.markInputReady()
        setResult(
            RESULT_OK,
            Intent().apply {
                if (input != null) {
                    putExtra(EXTRA_DOCUMENT_NUMBER, input.documentNumber)
                    putExtra(EXTRA_BIRTH_YYMMDD, input.birthYYMMDD)
                    putExtra(EXTRA_EXPIRY_YYMMDD, input.expiryYYMMDD)
                }
                putExtra(EXTRA_REQUIRED_FIELDS_READY, documentReadiness?.isReady == true)
                visualResolution?.profile?.name?.let { putExtra(EXTRA_CARD_PROFILE, it) }
                documentReadiness?.status?.name?.let { putExtra(EXTRA_READINESS_STATUS, it) }
                documentReadiness?.recommendedAction?.name?.let { putExtra(EXTRA_RECOMMENDED_ACTION, it) }
                visualResolution?.documentNumber?.status?.name?.let {
                    putExtra(EXTRA_DOCUMENT_NUMBER_STATUS, it)
                }
                visualResolution?.dateOfBirth?.status?.name?.let {
                    putExtra(EXTRA_DATE_OF_BIRTH_STATUS, it)
                }
                visualResolution?.dateOfExpiry?.status?.name?.let {
                    putExtra(EXTRA_DATE_OF_EXPIRY_STATUS, it)
                }
                visualResolution?.fullName?.value?.let { putExtra(EXTRA_FULL_NAME_RAW, it) }
                visualResolution?.sex?.value?.let { putExtra(EXTRA_SEX_RAW, it) }
                visualResolution?.nationality?.value?.let { putExtra(EXTRA_NATIONALITY_RAW, it) }
            },
        )
        finish()
    }

    private fun toggleOcrInspector() {
        if (!uiPolicy.showDebugDiagnostics) return
        if (binding.documentDebugOcrInspector.isVisible) {
            binding.documentDebugOcrInspector.isVisible = false
            binding.documentDebugOcrInspector.text = null
        } else {
            binding.documentDebugOcrInspector.text = buildString {
                append(OcrInspectorFormatter.format(ocrInspections.values))
                append("\n\n")
                append(OcrInspectorFormatter.formatPreprocessed(preprocessedOcr, visualResolution, documentReadiness))
                if (roiInspections.isNotEmpty()) {
                    append("\n\nROI RETRIES\n")
                    roiInspections.values.forEach { inspection ->
                        append(inspection.side.name).append(" ")
                            .append(inspection.source.sourceKind.name).append(" ")
                            .append(inspection.source.roiField ?: "—").append(" = ")
                            .append(inspection.status.name).append('\n')
                    }
                }
            }
            binding.documentDebugOcrInspector.isVisible = true
        }
    }

    private fun renderCaptureState(snapshot: DocumentCaptureSnapshot) {
        if (!::binding.isInitialized || binding.documentReview.isVisible) return
        val instruction = when (snapshot.state) {
            DocumentCaptureState.CAPTURE_FRONT,
            DocumentCaptureState.FRONT_ALIGNING,
            DocumentCaptureState.FRONT_READY,
            DocumentCaptureState.FRONT_CAPTURING,
            DocumentCaptureState.FRONT_CROP_REVIEW,
            DocumentCaptureState.FRONT_PROCESSING_CROP,
            DocumentCaptureState.FRONT_PROCESSING_OCR,
            -> getString(R.string.document_front_instruction)
            DocumentCaptureState.CAPTURE_BACK,
            DocumentCaptureState.BACK_ALIGNING,
            DocumentCaptureState.BACK_READY,
            DocumentCaptureState.BACK_CAPTURING,
            DocumentCaptureState.BACK_CROP_REVIEW,
            DocumentCaptureState.BACK_PROCESSING_CROP,
            DocumentCaptureState.BACK_PROCESSING_OCR,
            -> getString(R.string.document_back_instruction)
            DocumentCaptureState.FRONT_ACCEPTED -> getString(R.string.document_front_captured)
            DocumentCaptureState.BACK_ACCEPTED -> getString(R.string.document_back_captured)
            DocumentCaptureState.PROCESSING_DOCUMENT -> getString(R.string.document_processing)
            DocumentCaptureState.REVIEW_IF_NEEDED,
            DocumentCaptureState.DOCUMENT_INPUT_READY,
            DocumentCaptureState.ERROR,
            -> getString(R.string.document_front_instruction)
        }
        binding.documentInstruction.text = instruction
        val captureReady = captureMode == DocumentCaptureMode.MANUAL &&
            latestQuality?.status == DocumentQualityStatus.GOOD &&
            snapshot.state in setOf(DocumentCaptureState.FRONT_READY, DocumentCaptureState.BACK_READY) &&
            !captureInFlight.get()
        binding.documentCaptureButton.isEnabled = captureReady
    }

    private fun renderQuality(result: DocumentQualityResult) {
        binding.documentQuality.text = when (result.status) {
            DocumentQualityStatus.NO_DOCUMENT -> getString(R.string.document_quality_no_document)
            DocumentQualityStatus.DOCUMENT_TOO_SMALL -> getString(R.string.document_quality_too_small)
            DocumentQualityStatus.DOCUMENT_OUT_OF_FRAME -> getString(R.string.document_quality_out_of_frame)
            DocumentQualityStatus.TOO_DARK -> getString(R.string.document_quality_too_dark)
            DocumentQualityStatus.TOO_BRIGHT -> getString(R.string.document_quality_too_bright)
            DocumentQualityStatus.TOO_BLURRY -> getString(R.string.document_quality_too_blurry)
            DocumentQualityStatus.GLARE_DETECTED -> getString(R.string.document_quality_glare)
            DocumentQualityStatus.UNSTABLE -> getString(R.string.document_quality_unstable)
            DocumentQualityStatus.GOOD -> getString(R.string.document_quality_good)
        }
        if (uiPolicy.showDebugDiagnostics) {
            binding.documentDebug.text = getString(
                R.string.document_quality_debug,
                result.metrics.meanLuminance,
                result.metrics.blurScore,
                result.metrics.glareRatio,
                result.stableGoodFrames,
                qualityConfig.stableGoodFrames,
            )
        }
    }

    private fun renderCameraStatus(status: DocumentCameraStatus) {
        binding.documentStatus.setText(
            when (status) {
                DocumentCameraStatus.Idle -> R.string.document_permission_unknown
                DocumentCameraStatus.Starting -> R.string.document_camera_starting
                DocumentCameraStatus.Running -> R.string.document_camera_running
                DocumentCameraStatus.Stopped -> R.string.document_camera_stopped
                is DocumentCameraStatus.Error -> when (status.error) {
                    DocumentCameraError.PERMISSION_REQUIRED -> R.string.document_permission_unknown
                    DocumentCameraError.BACK_CAMERA_UNAVAILABLE -> R.string.document_back_camera_unavailable
                    DocumentCameraError.BIND_FAILED -> R.string.document_camera_bind_failed
                    DocumentCameraError.ANALYSIS_FAILED -> R.string.document_camera_analysis_failed
                    DocumentCameraError.CONTROLLER_CLOSED -> R.string.document_camera_stopped
                }
            },
        )
    }

    private fun noDocumentMetrics(width: Int, height: Int): DocumentFrameMetrics = DocumentFrameMetrics(
        frameWidth = width,
        frameHeight = height,
        documentBounds = null,
        guideBounds = DocumentRectForUi.guide(qualityConfig),
        meanLuminance = 0.0,
        blurScore = 0.0,
        glareRatio = 0.0,
    )

    private fun maskDocumentNumber(value: String?): String = when {
        value == null -> "not found"
        value.length <= 4 -> "••••"
        else -> "••••••••${value.takeLast(4)}"
    }

    private fun releaseBitmap(bitmap: Bitmap?) {
        if (bitmap != null && !bitmap.isRecycled) bitmap.recycle()
    }

    private fun clearRoiState(side: DocumentSide? = null) {
        val keys = (roiAttempts + roiBitmaps.keys + roiInspections.keys + roiSnapshots.keys)
            .filter { side == null || it.side == side }
            .toSet()
        keys.forEach { key ->
            roiBitmaps.remove(key)?.let(::releaseBitmap)
            roiInspections.remove(key)
            roiSnapshots.remove(key)
            roiAttempts.remove(key)
        }
        if (side == null || roiInFlightKey?.side == side) roiInFlightKey = null
    }

    private data class RoiSnapshotRecord(
        val snapshot: OcrSnapshot,
        val left: Int,
        val top: Int,
    )

    private fun RequiredVisualField.toDocumentField(): DocumentField = when (this) {
        RequiredVisualField.DOCUMENT_NUMBER -> DocumentField.DOCUMENT_NUMBER
        RequiredVisualField.DATE_OF_BIRTH -> DocumentField.DATE_OF_BIRTH
        RequiredVisualField.DATE_OF_EXPIRY -> DocumentField.DATE_OF_EXPIRY
    }

    private fun clearReviewImages() {
        if (!::binding.isInitialized) return
        binding.documentReviewFront.setImageDrawable(null)
        binding.documentReviewBack.setImageDrawable(null)
    }

    companion object {
        const val EXTRA_DOCUMENT_NUMBER = "document_number"
        const val EXTRA_BIRTH_YYMMDD = "birth_yymmdd"
        const val EXTRA_EXPIRY_YYMMDD = "expiry_yymmdd"
        const val EXTRA_FULL_NAME_RAW = "full_name_raw"
        const val EXTRA_SEX_RAW = "sex_raw"
        const val EXTRA_NATIONALITY_RAW = "nationality_raw"
        const val EXTRA_REQUIRED_FIELDS_READY = "required_fields_ready"
        const val EXTRA_CARD_PROFILE = "card_profile"
        const val EXTRA_READINESS_STATUS = "readiness_status"
        const val EXTRA_RECOMMENDED_ACTION = "recommended_action"
        const val EXTRA_DOCUMENT_NUMBER_STATUS = "document_number_status"
        const val EXTRA_DATE_OF_BIRTH_STATUS = "date_of_birth_status"
        const val EXTRA_DATE_OF_EXPIRY_STATUS = "date_of_expiry_status"
        const val EXTRA_FAILURE_REASON = "failure_reason"
        private const val KEY_PERMISSION_REQUESTED = "document_permission_requested"

        fun createIntent(context: Context): Intent = Intent(context, DocumentCaptureActivity::class.java)
    }
}

private object DocumentRectForUi {
    fun guide(config: DocumentQualityConfig) = vn.cccd.bacreader.document.quality.DocumentRect(
        left = (1.0 - config.guideWidthFraction) / 2.0,
        top = (1.0 - config.guideWidthFraction / config.guideAspectRatio) / 2.0,
        right = (1.0 + config.guideWidthFraction) / 2.0,
        bottom = (1.0 + config.guideWidthFraction / config.guideAspectRatio) / 2.0,
    )
}
