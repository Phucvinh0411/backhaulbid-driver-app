package vn.cccd.bacreader.ui

import android.content.Intent
import android.graphics.Bitmap
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import vn.cccd.bacreader.R
import vn.cccd.bacreader.biometric.AndroidDg2PortraitDecoder
import vn.cccd.bacreader.biometric.Dg2DecodeFailure
import vn.cccd.bacreader.biometric.Dg2DecodeResult
import vn.cccd.bacreader.biometric.camera.CameraActivity
import vn.cccd.bacreader.biometric.camera.BiometricSessionHandle
import vn.cccd.bacreader.document.capture.DocumentCaptureActivity
import vn.cccd.bacreader.document.crosscheck.ChipDocumentCrossCheckResult
import vn.cccd.bacreader.document.crosscheck.ChipDocumentCrossChecker
import vn.cccd.bacreader.document.crosscheck.NfcDocumentResult
import vn.cccd.bacreader.document.crosscheck.NfcDocumentResultMapper
import vn.cccd.bacreader.document.crosscheck.VisualDocumentData
import vn.cccd.bacreader.crypto.MrzAccessData
import vn.cccd.bacreader.databinding.ActivityMainBinding
import vn.cccd.bacreader.domain.AccessInput
import vn.cccd.bacreader.domain.ExtendedFile
import vn.cccd.bacreader.domain.Dg2Portrait
import vn.cccd.bacreader.domain.InputValidationError
import vn.cccd.bacreader.domain.InputValidationException
import vn.cccd.bacreader.domain.ReadResult
import vn.cccd.bacreader.domain.ReaderOptions
import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.domain.ScanStep
import vn.cccd.bacreader.logging.SafeScanLogger
import vn.cccd.bacreader.nfc.IsoDepTransport
import vn.cccd.bacreader.nfc.NfcSessionOwner
import vn.cccd.bacreader.nfc.ReaderModeController
import vn.cccd.bacreader.protocol.CardReader
import vn.cccd.bacreader.ui.demo.EkycTheme
import vn.cccd.bacreader.ui.demo.ProductionNfcHost
import vn.cccd.bacreader.ui.demo.ProductionNfcPhase
import vn.cccd.bacreader.ui.demo.ProductionNfcUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Hosts the input, scanning, and result panes. Reader Mode is active only for
 * a user-started scan; all ISO-DEP I/O runs outside the main thread.
 */
open class MainActivity : ComponentActivity() {
    private val viewModel: ReaderViewModel by viewModels()
    private val sessionOwner = NfcSessionOwner()
    private val activeScan = AtomicReference<ActiveScan?>(null)
    private val cardReader = CardReader()
    private val safeLogger = SafeScanLogger()
    private val dg2PortraitDecoder = AndroidDg2PortraitDecoder()
    private val documentCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == RESULT_OK) applyDocumentInput(result.data)
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var readerMode: ReaderModeController
    private var lastResultPresentation: ResultScreenModel? = null
    private var dg2PortraitBitmap: Bitmap? = null
    private var dg2PortraitForDisplay: Dg2Portrait? = null
    private var dg2PortraitDisplayModel: Dg2PortraitDisplayModel? = null
    private var pendingVisualDocument: VisualDocumentData? = null
    private var activeVisualDocument: VisualDocumentData? = null
    private var lastNfcDocumentResult: NfcDocumentResult? = null
    private var demoResultDelivered = false
    private val uiPolicy = EkycUiPolicy.forBuild(false)
    private val productionUiState = MutableStateFlow(ProductionNfcUiState())
    private val productionMode: Boolean
        get() = intent.getBooleanExtra(EXTRA_PRODUCTION_UI, false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SecureWindowPolicy.apply(this, uiPolicy)
        if (!vn.cccd.bacreader.sdk.SdkCaptureGuard.attach(this)) return

        binding = ActivityMainBinding.inflate(layoutInflater)
        if (productionMode) {
            setContent {
                EkycTheme {
                    val state by productionUiState.asStateFlow().collectAsState()
                    ProductionNfcHost(
                        state = state,
                        onRetry = { startScan() },
                        onClose = ::finishProductionCancelled,
                    )
                }
            }
        } else {
            setContentView(binding.root)
        }
        readerMode = ReaderModeController(
            activity = this,
            adapter = NfcAdapter.getDefaultAdapter(this),
            onTag = ::onTagDiscovered,
        )

        // A standard ViewModel survives rotation. Deliberately discard both a
        // pending derived MRZ and a displayed DG1 result instead of restoring it.
        if (savedInstanceState != null) viewModel.discardForHostRecreation()

        binding.startScanButton.setOnClickListener { startScan() }
        binding.startDocumentCaptureButton.setOnClickListener {
            documentCaptureLauncher.launch(DocumentCaptureActivity.createIntent(this))
        }
        binding.openCameraFoundationButton.setOnClickListener {
            startCameraWithSession()
        }
        binding.openCameraMatchButton.setOnClickListener {
            startCameraWithSession()
        }
        binding.cancelScanButton.setOnClickListener { cancelActiveScan(discardState = false) }
        binding.newScanButton.setOnClickListener {
            clearDg2PortraitDisplay()
            cancelActiveScan(discardState = true)
            clearInputFields()
            clearInputError()
        }
        binding.showSensitiveCheckbox.setOnCheckedChangeListener { _, checked ->
            lastResultPresentation?.let { renderDg1Details(it, checked) }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collect(::render)
            }
        }

        if (isDemoReturnLaunch()) {
            // The production host renders Compose instead of attaching the legacy
            // binding root. Posting on that unattached root would queue forever and
            // leave the NFC screen idle; use the always-attached decor view here.
            window.decorView.post { startDemoScanIfReady() }
        }
    }

    override fun onPause() {
        // Closing through the owner unblocks an in-flight IsoDep transceive.
        cancelActiveScan(discardState = isChangingConfigurations)
        super.onPause()
    }

    override fun onDestroy() {
        clearDg2PortraitDisplay()
        super.onDestroy()
    }

    private fun startScan() {
        if (!vn.cccd.bacreader.sdk.SdkCaptureGuard.isValid(this)) {
            finishProductionCancelled()
            return
        }
        if (productionMode) {
            productionUiState.value = ProductionNfcUiState(phase = ProductionNfcPhase.WAITING_FOR_TAG)
        }
        clearDg2PortraitDisplay()
        clearInputError()
        val access = try {
            AccessInput.create(
                cardNumber12 = binding.cardNumberInput.text.toString(),
                birthYYMMDD = binding.birthDateInput.text.toString(),
                expiryYYMMDD = binding.expiryDateInput.text.toString(),
            )
        } catch (error: InputValidationException) {
            showInputError(error.error)
            return
        }
        activeVisualDocument = pendingVisualDocument
        pendingVisualDocument = null

        val mrzAccess = MrzAccessData.from(access)
        // Do not leave the values in editable widgets after the scan starts.
        clearInputFields()
        val options = ReaderOptions(
            readDg13 = binding.readDg13Checkbox.isChecked,
            readDg2 = binding.readDg2Checkbox.isChecked,
            captureEvidence = intent.getBooleanExtra("sdk_capture_evidence", false),
        )
        val scanId = viewModel.begin(mrzAccess)
        val handle = ActiveScan(scanId = scanId, generation = sessionOwner.begin(), options = options)
        activeScan.set(handle)

        val readerModeEnabled = try {
            readerMode.start()
        } catch (_: IllegalStateException) {
            false
        } catch (_: SecurityException) {
            false
        }
        if (!readerModeEnabled) {
            completeOnMain(
                handle,
                ReadResult.Failure(
                    step = ScanStep.IDLE,
                    error = ReaderError.NFC_UNAVAILABLE,
                    elapsedMillis = 0,
                ),
            )
        }
    }

    private fun finishProductionCancelled() {
        cancelActiveScan(discardState = true)
        setResult(RESULT_CANCELED)
        finish()
    }

    private fun startDemoScanIfReady() {
        if (!isDemoReturnLaunch() || activeScan.get() != null) return
        val fields = vn.cccd.bacreader.sdk.SdkRuntime.find(intent.getStringExtra(vn.cccd.bacreader.sdk.EXTRA_TOKEN))?.documentFields
        val documentNumber = fields?.documentNumber ?: intent.getStringExtra(EXTRA_DEMO_DOCUMENT_NUMBER)
        val birth = fields?.birthYYMMDD ?: intent.getStringExtra(EXTRA_DEMO_BIRTH_YYMMDD)
        val expiry = fields?.expiryYYMMDD ?: intent.getStringExtra(EXTRA_DEMO_EXPIRY_YYMMDD)
        binding.cardNumberInput.setText(documentNumber.orEmpty())
        binding.birthDateInput.setText(birth.orEmpty())
        binding.expiryDateInput.setText(expiry.orEmpty())
        pendingVisualDocument = VisualDocumentData(
            documentNumber, birth, expiry,
        )
        binding.readDg2Checkbox.isChecked = true
        binding.readDg13Checkbox.isChecked = false
        startScan()
    }

    private fun applyDocumentInput(data: Intent?) {
        val result = data ?: return
        val documentNumber = result.getStringExtra(DocumentCaptureActivity.EXTRA_DOCUMENT_NUMBER)
        val birthYYMMDD = result.getStringExtra(DocumentCaptureActivity.EXTRA_BIRTH_YYMMDD)
        val expiryYYMMDD = result.getStringExtra(DocumentCaptureActivity.EXTRA_EXPIRY_YYMMDD)
        pendingVisualDocument = VisualDocumentData(documentNumber, birthYYMMDD, expiryYYMMDD)
        binding.cardNumberInput.setText(documentNumber.orEmpty())
        binding.birthDateInput.setText(birthYYMMDD.orEmpty())
        binding.expiryDateInput.setText(expiryYYMMDD.orEmpty())
        clearInputError()
        val hasAllFields = !binding.cardNumberInput.text.isNullOrBlank() &&
            !binding.birthDateInput.text.isNullOrBlank() &&
            !binding.expiryDateInput.text.isNullOrBlank()
        if (hasAllFields) startScan()
    }

    /** Reader Mode invokes this off the UI thread. Never inspect or log the tag UID. */
    private fun onTagDiscovered(tag: Tag) {
        val handle = activeScan.get() ?: return
        if (!sessionOwner.claimTagCallback(handle.generation)) return

        val isoDep = IsoDep.get(tag)
        if (isoDep == null) {
            runOnUiThread {
                completeOnMain(
                    handle,
                    ReadResult.Failure(
                        step = ScanStep.TAG_DISCOVERED,
                        error = ReaderError.NOT_ISO_DEP,
                        elapsedMillis = 0,
                    ),
                )
            }
            return
        }

        val transport = IsoDepTransport(isoDep)
        if (!sessionOwner.attach(handle.generation, transport)) return

        lifecycleScope.launch(Dispatchers.IO) {
            var mrzInformation: ByteArray? = null
            val outcome = try {
                mrzInformation = viewModel.takeMrzInformation(handle.scanId)
                if (mrzInformation == null) {
                    ReadResult.Failure(
                        step = ScanStep.TAG_DISCOVERED,
                        error = ReaderError.CANCELLED,
                        elapsedMillis = 0,
                    )
                } else {
                    cardReader.read(transport, mrzInformation, onStep = { step ->
                        if (sessionOwner.isCurrent(handle.generation) &&
                            viewModel.updateStep(handle.scanId, step)
                        ) {
                            safeLogger.record(handle.scanId, step)
                        }
                    }, options = handle.options)
                }
            } catch (_: Exception) {
                ReadResult.Failure(
                    step = ScanStep.ERROR,
                    error = ReaderError.INTERNAL_ERROR,
                    elapsedMillis = 0,
                )
            } finally {
                mrzInformation?.fill(0)
            }
            withContext(Dispatchers.Main.immediate) {
                completeOnMain(handle, outcome)
            }
        }
    }

    /** Must run on the main thread so Reader Mode and the displayed state end together. */
    private fun completeOnMain(handle: ActiveScan, outcome: ReadResult) {
        if (!sessionOwner.isCurrent(handle.generation)) {
            outcome.close()
            return
        }

        // Prepare the portrait before publishing Result. StateFlow collectors may render the
        // new state immediately, so publishing first would hide the ImageView while its model
        // is still null and no later state change would trigger another render.
        val portraitCompletion = preparePortraitBeforeResult(
            outcome = outcome,
            prepareSuccess = ::prepareDg2PortraitDisplay,
            clear = ::clearDg2PortraitDisplay,
            finish = { result -> viewModel.finish(handle.scanId, result) },
        )
        if (!portraitCompletion.accepted) return

        readerMode.stop()
        sessionOwner.end(handle.generation)
        activeScan.compareAndSet(handle, null)
        logOutcome(handle.scanId, outcome, portraitCompletion.model)
    }

    private fun cancelActiveScan(discardState: Boolean) {
        val handle = activeScan.getAndSet(null)
        readerMode.stop()
        sessionOwner.cancel()
        if (discardState) {
            viewModel.returnToInput()
            return
        }
        val cancelled = if (handle == null) viewModel.cancel() else viewModel.cancel(handle.scanId)
        if (cancelled && handle != null) {
            safeLogger.record(handle.scanId, ScanStep.ERROR, error = ReaderError.CANCELLED)
        }
    }

    private fun render(state: ReaderUiState) {
        if (productionMode) {
            productionUiState.value = when (state) {
                ReaderUiState.Input -> ProductionNfcUiState(phase = ProductionNfcPhase.PREPARING)
                is ReaderUiState.Scanning -> ProductionNfcUiState(
                    phase = ProductionNfcPhase.READING,
                    step = state.step,
                )
                is ReaderUiState.Result -> productionUiState.value.copy(phase = ProductionNfcPhase.RESULT)
            }
        }
        when (state) {
            ReaderUiState.Input -> {
                lastResultPresentation = null
                pendingVisualDocument = null
                activeVisualDocument = null
                clearDg2PortraitDisplay()
                showScreen(INPUT_SCREEN)
            }
            is ReaderUiState.Scanning -> {
                lastResultPresentation = null
                clearDg2PortraitDisplay()
                showScreen(SCAN_SCREEN)
                binding.scanStep.text = getString(R.string.scan_step_format, state.step.name)
            }
            is ReaderUiState.Result -> renderResult(state.outcome)
        }
    }

    private fun renderResult(outcome: ReadResult) {
        showScreen(RESULT_SCREEN)
        lastNfcDocumentResult = NfcDocumentResultMapper.from(outcome, activeVisualDocument)
        if (productionMode) {
            productionUiState.value = ProductionNfcUiState(
                phase = ProductionNfcPhase.RESULT,
                result = lastNfcDocumentResult,
                step = (outcome as? ReadResult.Failure)?.step,
            )
        }
        val presentation = ResultScreenModelMapper.map(outcome)
        lastResultPresentation = presentation
        binding.resultStep.text = getString(R.string.result_step_format, presentation.step.name)
        binding.resultCode.text = getString(R.string.result_code_format, presentation.code)
        binding.resultSw.text = presentation.statusWord?.let { getString(R.string.result_sw_format, it) }
            ?: getString(R.string.result_sw_none)

        if (presentation.isSuccess) {
            binding.resultSummary.setTextColor(getColor(R.color.color_success))
            binding.resultSummary.setText(R.string.result_success)
            binding.resultMetrics.text = getString(
                R.string.result_success_metrics,
                requireNotNull(presentation.efComBytes),
                requireNotNull(presentation.dg1Bytes),
                presentation.elapsedMillis,
            )
            binding.resultMrz.text = getString(
                R.string.result_mrz_format,
                requireNotNull(presentation.dg1Mrz),
            )
            binding.showSensitiveCheckbox.setOnCheckedChangeListener(null)
            binding.showSensitiveCheckbox.isChecked = false
            binding.showSensitiveCheckbox.setOnCheckedChangeListener { _, checked ->
                lastResultPresentation?.let { renderDg1Details(it, checked) }
            }
            renderDg1Details(presentation, revealSensitive = false)
            renderDg2PortraitDisplay()
            binding.openCameraMatchButton.isVisible =
                dg2PortraitDisplayModel?.state == Dg2PortraitDisplayState.DG2_PORTRAIT_READY &&
                    dg2PortraitBitmap != null
            val chipCrossCheck = activeVisualDocument?.let { visual ->
                ChipDocumentCrossChecker().compare(
                    visual = visual,
                    chipMrzText = presentation.dg1Mrz,
                )
            }
            if (uiPolicy.showDebugDiagnostics) {
                binding.resultExtended.text = formatExtended(presentation, chipCrossCheck)
                binding.resultExtended.isVisible = true
            } else {
                binding.resultExtended.text = ""
                binding.resultExtended.isVisible = false
            }
        } else {
            binding.resultSummary.setTextColor(getColor(R.color.color_error))
            binding.resultSummary.setText(R.string.result_failure)
            binding.resultMetrics.text = getString(
                R.string.result_failure_metrics,
                presentation.bytesRead,
                presentation.elapsedMillis,
            )
            binding.resultMrz.text = ""
            binding.resultMrz.isVisible = false
            binding.resultDg1Fields.text = ""
            binding.resultDg1Fields.isVisible = false
            binding.resultDg1Heading.isVisible = false
            binding.showSensitiveCheckbox.isChecked = false
            binding.showSensitiveCheckbox.isVisible = false
            clearDg2PortraitDisplay()
            activeVisualDocument = null
            binding.openCameraMatchButton.isVisible = false
            binding.resultExtended.text = ""
            binding.resultExtended.isVisible = false
        }
        deliverDemoResultIfNeeded(outcome)
    }

    private fun deliverDemoResultIfNeeded(outcome: ReadResult) {
        if (!isDemoReturnLaunch() || demoResultDelivered) return
        demoResultDelivered = true
        // Production mode renders Compose without attaching binding.root to the
        // window. Schedule delivery on the attached decor view so the callback
        // always runs after NFC completes and the parent can receive the result.
        window.decorView.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            intent.getStringExtra(vn.cccd.bacreader.sdk.EXTRA_TOKEN)?.let { token ->
                vn.cccd.bacreader.sdk.SdkRuntime.deliverNfc(token, lastNfcDocumentResult,
                    if (outcome is ReadResult.Success) takeBiometricSessionHandle() else null)
                setResult(RESULT_OK)
                finish()
                return@postDelayed
            }
            setResult(
                RESULT_OK,
                Intent().apply {
                    val structured = lastNfcDocumentResult
                    putExtra(EXTRA_DEMO_NFC_SUCCESS, outcome is ReadResult.Success)
                    if (structured != null) putStructuredNfcResult(structured)
                    if (outcome is ReadResult.Success) {
                        takeBiometricSessionHandle()?.let {
                            putExtras(Bundle().apply { putBinder(EXTRA_DEMO_BIOMETRIC_SESSION, it) })
                        }
                    }
                },
            )
            finish()
        }, DEMO_RESULT_DELAY_MILLIS)
    }

    private fun isDemoReturnLaunch(): Boolean = intent.getBooleanExtra(EXTRA_DEMO_RETURN, false)

    private fun startCameraWithSession() {
        val bitmap = dg2PortraitBitmap ?: return
        dg2PortraitBitmap = null
        dg2PortraitForDisplay?.close()
        dg2PortraitForDisplay = null
        dg2PortraitDisplayModel = null
        val session = BiometricSessionHandle(bitmap)
        runCatching {
            startActivity(CameraActivity.createIntent(this, session))
        }.onFailure {
            session.close()
        }
    }

    /** Transfers portrait ownership to the demo biometric Activity without serializing pixels. */
    private fun takeBiometricSessionHandle(): BiometricSessionHandle? {
        val bitmap = dg2PortraitBitmap ?: return null
        dg2PortraitBitmap = null
        dg2PortraitForDisplay?.close()
        dg2PortraitForDisplay = null
        dg2PortraitDisplayModel = null
        val evidence = (viewModel.state.value as? ReaderUiState.Result)?.outcome
            ?.let { it as? ReadResult.Success }?.evidence?.transfer()
        return BiometricSessionHandle(bitmap, evidence)
    }

    private fun Intent.putStructuredNfcResult(result: NfcDocumentResult) {
        putExtra(EXTRA_DEMO_NFC_OVERALL_STATUS, result.overallStatus.name)
        putExtra(EXTRA_DEMO_NFC_TAG_DETECTED, result.session.tagDetected)
        putExtra(EXTRA_DEMO_NFC_BAC_ESTABLISHED, result.session.bacEstablished)
        putExtra(EXTRA_DEMO_NFC_SM_ESTABLISHED, result.session.secureMessagingEstablished)
        putExtra(EXTRA_DEMO_NFC_DG1_STATUS, result.reads.dg1.name)
        putExtra(EXTRA_DEMO_NFC_DG2_STATUS, result.reads.dg2.name)
        putExtra(EXTRA_DEMO_NFC_SOD_STATUS, result.reads.sod.name)
        putExtra(EXTRA_DEMO_NFC_MRZ_STATUS, result.mrzStatus.name)
        result.chipIdentity?.let { chip ->
            putExtra(EXTRA_DEMO_NFC_CHIP_DOCUMENT_NUMBER, chip.documentNumber)
            putExtra(EXTRA_DEMO_NFC_CHIP_FULL_NAME, chip.fullName)
            putExtra(EXTRA_DEMO_NFC_CHIP_BIRTH, chip.dateOfBirth)
            putExtra(EXTRA_DEMO_NFC_CHIP_SEX, chip.sex)
            putExtra(EXTRA_DEMO_NFC_CHIP_NATIONALITY, chip.nationality)
            putExtra(EXTRA_DEMO_NFC_CHIP_EXPIRY, chip.dateOfExpiry)
        }
        putExtra(EXTRA_DEMO_NFC_CROSS_NUMBER, result.crossCheck.documentNumber.name)
        putExtra(EXTRA_DEMO_NFC_CROSS_BIRTH, result.crossCheck.dateOfBirth.name)
        putExtra(EXTRA_DEMO_NFC_CROSS_EXPIRY, result.crossCheck.dateOfExpiry.name)
        putExtra(EXTRA_DEMO_NFC_SOD_READ_STATUS, result.authenticity.sodStatus.name)
        putExtra(EXTRA_DEMO_NFC_INTEGRITY_STATUS, result.authenticity.integrityStatus.name)
        putExtra(EXTRA_DEMO_NFC_SIGNATURE_STATUS, result.authenticity.signatureStatus.name)
        putExtra(EXTRA_DEMO_NFC_TRUST_STATUS, result.authenticity.issuerTrustStatus.name)
        putExtra(EXTRA_DEMO_NFC_FAILURE_STAGE, result.failureStage?.name)
        putExtra(EXTRA_DEMO_NFC_FAILURE_REASON, result.failureReason?.name)
    }

    private fun renderDg1Details(presentation: ResultScreenModel, revealSensitive: Boolean) {
        val details = presentation.dg1Details ?: return
        binding.resultDg1Heading.isVisible = true
        binding.showSensitiveCheckbox.isVisible = true
        binding.resultDg1Fields.text = if (details.isStructured) {
            details.fields.joinToString(separator = "\n") { field ->
                val value = if (revealSensitive || !field.sensitive) field.value else field.maskedValue
                "${field.label}: $value"
            }
        } else {
            getString(R.string.result_dg1_unstructured)
        }
        binding.resultDg1Fields.isVisible = true
        binding.resultMrz.isVisible = revealSensitive
    }

    private fun formatExtended(
        presentation: ResultScreenModel,
        chipCrossCheck: ChipDocumentCrossCheckResult? = null,
    ): String = buildString {
        presentation.optionalFiles.forEach { report ->
            append(report.file.name).append(": ").append(report.status.name)
            report.error?.let { append(" (").append(it.name).append(")") }
            report.sw?.let { append(" SW=").append(it) }
            if (report.bytesRead > 0) append(" — ").append(report.bytesRead).append(" byte")
            report.sodStatus?.let { append(" sod=").append(it.name) }
            report.metadata?.let { metadata ->
                append(" raw=").append(metadata.rawLength)
                    .append(" tag=").append(metadata.firstTag?.toString(16)?.uppercase() ?: "none")
                    .append(" chunks=").append(metadata.chunkCount)
                    .append(" layout=").append(metadata.readStatus.name)
            }
            report.dg2Diagnostic?.let { diagnostic ->
                append(" source=").append(diagnostic.source.name)
                    .append(" stage=").append(diagnostic.stage.name)
                    .append(" bytes=").append(diagnostic.bytesRead)
                    .append(" raw=").append(diagnostic.rawLength ?: "none")
                    .append(" chunks=").append(diagnostic.chunkCount ?: "none")
                    .append(" firstTag=").append(diagnostic.firstTag?.toString(16)?.uppercase() ?: "none")
                    .append(" declared=").append(diagnostic.declaredLength ?: "none")
                    .append(" reader=").append(diagnostic.readerStatus?.name ?: "none")
                    .append(" failureStage=").append(diagnostic.failureStage?.name ?: "none")
                    .append(" failureField=").append(diagnostic.failureField ?: "none")
                    .append(" failureOffset=").append(diagnostic.failureOffset ?: "none")
                    .append(" remaining=").append(diagnostic.remainingBytes ?: "none")
                    .append(" jpeg=").append(diagnostic.jpegMarkerFound ?: "none")
                    .append(" jp2=").append(diagnostic.jpeg2000MarkerFound ?: "none")
                    .append(" markerOffset=").append(diagnostic.markerOffset ?: "none")
                    .append(" markerRemaining=").append(diagnostic.bytesRemainingAfterMarker ?: "none")
                    .append(" maxPlainChunk=").append(diagnostic.maxPlainChunk ?: "none")
                    .append(" smOverhead=").append(diagnostic.secureMessagingOverhead ?: "none")
                    .append(" effectiveMax=").append(diagnostic.effectiveTransceiveMaximum ?: "none")
                    .append(" failureType=").append(diagnostic.failureType?.name ?: "none")
                    .append(" parserAccepted=").append(diagnostic.parserAccepted ?: "none")
                    .append(" facRecordLength=").append(diagnostic.facRecordLength ?: "none")
                    .append(" facialRecordCount=").append(diagnostic.facialRecordCount ?: "none")
                    .append(" recordStart=").append(diagnostic.recordStart ?: "none")
                    .append(" recordLength=").append(diagnostic.recordLength ?: "none")
                    .append(" featurePointCount=").append(diagnostic.featurePointCount ?: "none")
                    .append(" imageInfoStart=").append(diagnostic.imageInfoStart ?: "none")
                    .append(" imageStart=").append(diagnostic.imageStart ?: "none")
                    .append(" imageLength=").append(diagnostic.calculatedImageLength ?: "none")
                    .append(" imageDataType=").append(diagnostic.imageDataType ?: "none")
                    .append(" imageWidth=").append(diagnostic.imageWidth ?: "none")
                    .append(" imageHeight=").append(diagnostic.imageHeight ?: "none")
                    .append(" structuralImageOffsetMatch=").append(diagnostic.structuralImageOffsetMatch ?: "none")
                    .append(" interpretation=").append(diagnostic.interpretation.name)
                diagnostic.chunkTrace.forEach { chunk ->
                    append("\n  chunk#").append(chunk.chunkIndex)
                        .append(" offset=").append(chunk.fileOffset)
                        .append(" req=").append(chunk.requestedPlainLength)
                        .append(" recv=").append(chunk.receivedPlainLength ?: "none")
                        .append(" cmd=").append(chunk.encodedCommandLength ?: "none")
                        .append(" durationMs=").append(chunk.transceiveDurationMillis ?: "none")
                        .append(" sw=").append(chunk.statusWord?.toString(16)?.uppercase() ?: "none")
                        .append(" connected=").append(chunk.isoDepConnected ?: "none")
                        .append(" timeoutMs=").append(chunk.isoDepTimeoutMillis ?: "none")
                        .append(" maxTransceive=").append(chunk.isoDepMaxTransceiveLength ?: "none")
                        .append(" failure=").append(chunk.failureType?.name ?: "none")
                }
            }
            append('\n')
        }
        presentation.dg13Fields.forEach { field ->
            append(field.label).append(": ").append(field.value).append('\n')
        }
        presentation.dg2?.let {
            append("DG2 image: ").append(it.format.name).append(" — ").append(it.imageBytes).append(" byte\n")
        }
        presentation.sod?.let {
            append("EF.SOD: CMS envelope present; signature ").append(it.signatureStatus.name).append('\n')
        }
        val authenticity = presentation.authenticity
        append("NFC_PROTOCOL_OK; ACCESS_BAC_OK; DATA_READ_OK; ")
            .append(if (presentation.sod?.cmsEnvelopePresent == true) "STRUCTURE_VALID" else "STRUCTURE_PARTIAL")
            .append("; ")
            .append(if (authenticity.integrityStatus.name == "DG_HASH_MATCH") "INTEGRITY_VERIFIED" else "INTEGRITY_NOT_VERIFIED")
            .append("; ")
            .append(if (authenticity.issuerTrustStatus.name == "TRUST_ESTABLISHED") "ISSUER_TRUST_ESTABLISHED" else "TRUST_NOT_ESTABLISHED")
            .append('\n')
        append("AUTHENTICITY: SOD=").append(authenticity.sodStatus.name)
            .append("; integrity=").append(authenticity.integrityStatus.name)
            .append("; dg1=").append(authenticity.dg1Digest.name)
            .append("; dg2=").append(authenticity.dg2Digest.name)
            .append("; signature=").append(authenticity.signatureStatus.name)
            .append("; dsCert=").append(authenticity.dsCertificateStatus.name)
            .append("; trust=").append(authenticity.issuerTrustStatus.name)
            .append("; passive=").append(authenticity.passiveAuthenticationStatus.name)
        chipCrossCheck?.let {
            append('\n')
            append("DOCUMENT_CHIP_CROSS_CHECK: MRZ=").append(it.mrzStatus.name)
                .append("; number=").append(it.documentNumber.name)
                .append("; birth=").append(it.dateOfBirth.name)
                .append("; expiry=").append(it.dateOfExpiry.name)
        }
    }.trimEnd()

    private fun prepareDg2PortraitDisplay(outcome: ReadResult.Success): Dg2PortraitDisplayModel? {
        clearDg2PortraitDisplay()
        val portrait = outcome.dg2Portrait ?: return null
        val diagnostic = outcome.optionalFiles
            .firstOrNull { it.file == ExtendedFile.DG2 }
            ?.dg2Diagnostic
        val format = portrait.format
        val encodedLength = try {
            portrait.encodedLength
        } catch (_: IllegalStateException) {
            val failed = Dg2PortraitDisplayModel(
                state = Dg2PortraitDisplayState.DG2_PORTRAIT_DECODE_FAILED,
                format = format,
                encodedLength = outcome.dg2?.imageBytes ?: 0,
                facWidth = diagnostic?.imageWidth,
                facHeight = diagnostic?.imageHeight,
            )
            dg2PortraitDisplayModel = failed
            portrait.close()
            return failed
        }

        var retainPortraitForDisplay = false
        return try {
            val decoded = try {
                dg2PortraitDecoder.decode(portrait)
            } catch (_: RuntimeException) {
                Dg2DecodeResult.Failure(Dg2DecodeFailure.JPEG_DECODE_FAILED)
            }
            when (decoded) {
                is Dg2DecodeResult.Success -> {
                    dg2PortraitBitmap = decoded.bitmap
                    dg2PortraitForDisplay = portrait
                    retainPortraitForDisplay = true
                    Dg2PortraitDisplayModel(
                        state = Dg2PortraitDisplayState.DG2_PORTRAIT_READY,
                        format = format,
                        encodedLength = encodedLength,
                        facWidth = diagnostic?.imageWidth,
                        facHeight = diagnostic?.imageHeight,
                        decodedWidth = decoded.bitmap.width,
                        decodedHeight = decoded.bitmap.height,
                    ).also { dg2PortraitDisplayModel = it }
                }
                is Dg2DecodeResult.Failure -> Dg2PortraitDisplayModel(
                    state = Dg2PortraitDisplayState.DG2_PORTRAIT_DECODE_FAILED,
                    format = format,
                    encodedLength = encodedLength,
                    facWidth = diagnostic?.imageWidth,
                    facHeight = diagnostic?.imageHeight,
                ).also { dg2PortraitDisplayModel = it }
            }
        } finally {
            if (!retainPortraitForDisplay) {
                portrait.close()
            }
        }
    }

    private fun renderDg2PortraitDisplay() {
        val model = dg2PortraitDisplayModel
        if (model == null) {
            binding.resultDg2Portrait.setImageDrawable(null)
            binding.resultDg2Portrait.isVisible = false
            binding.resultDg2PortraitState.isVisible = false
            binding.resultDg2PortraitMetadata.isVisible = false
            return
        }
        binding.resultDg2PortraitState.text = model.state.name
        binding.resultDg2PortraitState.setTextColor(
            getColor(
                if (model.state == Dg2PortraitDisplayState.DG2_PORTRAIT_READY) {
                    R.color.color_success
                } else {
                    R.color.color_error
                },
            ),
        )
        binding.resultDg2PortraitState.isVisible = true
        binding.resultDg2PortraitMetadata.text = buildString {
            append("format=").append(model.format.name)
                .append(" encodedLength=").append(model.encodedLength)
                .append(" facWidth=").append(model.facWidth ?: "none")
                .append(" facHeight=").append(model.facHeight ?: "none")
                .append(" decodedWidth=").append(model.decodedWidth ?: "none")
                .append(" decodedHeight=").append(model.decodedHeight ?: "none")
        }
        binding.resultDg2PortraitMetadata.isVisible = true
        binding.resultDg2Portrait.setImageBitmap(dg2PortraitBitmap)
        binding.resultDg2Portrait.isVisible = dg2PortraitBitmap != null
    }

    private fun clearDg2PortraitDisplay() {
        if (!::binding.isInitialized) return
        binding.resultDg2Portrait.setImageDrawable(null)
        dg2PortraitBitmap?.let { bitmap ->
            if (!bitmap.isRecycled) bitmap.recycle()
        }
        dg2PortraitBitmap = null
        dg2PortraitForDisplay?.close()
        dg2PortraitForDisplay = null
        dg2PortraitDisplayModel = null
        binding.resultDg2Portrait.isVisible = false
        binding.resultDg2PortraitState.isVisible = false
        binding.resultDg2PortraitMetadata.isVisible = false
        binding.openCameraMatchButton.isVisible = false
    }

    private fun logOutcome(
        scanId: String,
        outcome: ReadResult,
        portraitDisplay: Dg2PortraitDisplayModel? = null,
    ) {
        when (outcome) {
            is ReadResult.Success -> safeLogger.record(
                scanId = scanId,
                step = ScanStep.COMPLETE,
                bytesRead = outcome.efComBytes + outcome.dg1Bytes,
                elapsedMillis = outcome.elapsedMillis,
                authenticity = outcome.authenticity,
            ).also {
                portraitDisplay?.let { display ->
                    safeLogger.recordDg2PortraitDecode(
                        scanId = scanId,
                        format = display.format,
                        encodedLength = display.encodedLength,
                        decodeStatus = if (display.state == Dg2PortraitDisplayState.DG2_PORTRAIT_READY) {
                            "SUCCESS"
                        } else {
                            display.state.name
                        },
                        decodedWidth = display.decodedWidth,
                        decodedHeight = display.decodedHeight,
                    )
                }
                outcome.optionalFiles.forEach { report ->
                    safeLogger.record(
                        scanId = scanId,
                        step = report.step,
                        error = report.error,
                        sw = report.sw,
                        bytesRead = report.bytesRead,
                        file = report.file,
                        status = report.status,
                        sodStatus = report.sodStatus,
                        metadata = report.metadata,
                        dg2Diagnostic = report.dg2Diagnostic,
                    )
                }
            }
            is ReadResult.Failure -> safeLogger.record(
                scanId = scanId,
                step = outcome.step,
                error = outcome.error,
                sw = outcome.sw,
                bytesRead = outcome.bytesRead,
                elapsedMillis = outcome.elapsedMillis,
            )
        }
    }

    private fun showScreen(index: Int) {
        if (binding.screenFlipper.displayedChild != index) binding.screenFlipper.displayedChild = index
    }

    private fun clearInputFields() {
        binding.cardNumberInput.text?.clear()
        binding.birthDateInput.text?.clear()
        binding.expiryDateInput.text?.clear()
    }

    private fun clearInputError() {
        binding.inputError.text = ""
        binding.inputError.visibility = View.GONE
    }

    private fun showInputError(error: InputValidationError) {
        binding.inputError.setText(
            when (error) {
                InputValidationError.INVALID_CARD_NUMBER -> R.string.error_invalid_card_number
                InputValidationError.INVALID_BIRTH_DATE -> R.string.error_invalid_birth_date
                InputValidationError.INVALID_EXPIRY_DATE -> R.string.error_invalid_expiry_date
            },
        )
        binding.inputError.visibility = View.VISIBLE
    }

    private data class ActiveScan(
        val scanId: String,
        val generation: Long,
        val options: ReaderOptions,
    )

    companion object {
        const val INPUT_SCREEN = 0
        const val SCAN_SCREEN = 1
        const val RESULT_SCREEN = 2
        const val EXTRA_DEMO_RETURN = "demo_return_to_caller"
        const val EXTRA_PRODUCTION_UI = "production_ui_host"
        const val EXTRA_DEMO_DOCUMENT_NUMBER = "demo_document_number"
        const val EXTRA_DEMO_BIRTH_YYMMDD = "demo_birth_yymmdd"
        const val EXTRA_DEMO_EXPIRY_YYMMDD = "demo_expiry_yymmdd"
        const val EXTRA_DEMO_NFC_SUCCESS = "demo_nfc_success"
        const val EXTRA_DEMO_BIOMETRIC_SESSION = "demo_biometric_session"
        const val EXTRA_DEMO_NFC_OVERALL_STATUS = "demo_nfc_overall_status"
        const val EXTRA_DEMO_NFC_TAG_DETECTED = "demo_nfc_tag_detected"
        const val EXTRA_DEMO_NFC_BAC_ESTABLISHED = "demo_nfc_bac_established"
        const val EXTRA_DEMO_NFC_SM_ESTABLISHED = "demo_nfc_sm_established"
        const val EXTRA_DEMO_NFC_DG1_STATUS = "demo_nfc_dg1_status"
        const val EXTRA_DEMO_NFC_DG2_STATUS = "demo_nfc_dg2_status"
        const val EXTRA_DEMO_NFC_SOD_STATUS = "demo_nfc_sod_status"
        const val EXTRA_DEMO_NFC_MRZ_STATUS = "demo_nfc_mrz_status"
        const val EXTRA_DEMO_NFC_CHIP_DOCUMENT_NUMBER = "demo_nfc_chip_document_number"
        const val EXTRA_DEMO_NFC_CHIP_FULL_NAME = "demo_nfc_chip_full_name"
        const val EXTRA_DEMO_NFC_CHIP_BIRTH = "demo_nfc_chip_birth"
        const val EXTRA_DEMO_NFC_CHIP_SEX = "demo_nfc_chip_sex"
        const val EXTRA_DEMO_NFC_CHIP_NATIONALITY = "demo_nfc_chip_nationality"
        const val EXTRA_DEMO_NFC_CHIP_EXPIRY = "demo_nfc_chip_expiry"
        const val EXTRA_DEMO_NFC_CROSS_NUMBER = "demo_nfc_cross_number"
        const val EXTRA_DEMO_NFC_CROSS_BIRTH = "demo_nfc_cross_birth"
        const val EXTRA_DEMO_NFC_CROSS_EXPIRY = "demo_nfc_cross_expiry"
        const val EXTRA_DEMO_NFC_SOD_READ_STATUS = "demo_nfc_sod_read_status"
        const val EXTRA_DEMO_NFC_INTEGRITY_STATUS = "demo_nfc_integrity_status"
        const val EXTRA_DEMO_NFC_SIGNATURE_STATUS = "demo_nfc_signature_status"
        const val EXTRA_DEMO_NFC_TRUST_STATUS = "demo_nfc_trust_status"
        const val EXTRA_DEMO_NFC_FAILURE_STAGE = "demo_nfc_failure_stage"
        const val EXTRA_DEMO_NFC_FAILURE_REASON = "demo_nfc_failure_reason"
        const val DEMO_RESULT_DELAY_MILLIS = 350L

        fun createDemoIntent(
            context: android.content.Context,
            documentNumber: String,
            birthYYMMDD: String,
            expiryYYMMDD: String,
        ): Intent = Intent(context, MainActivity::class.java).apply {
            putExtra(EXTRA_DEMO_RETURN, true)
            putExtra(EXTRA_DEMO_DOCUMENT_NUMBER, documentNumber)
            putExtra(EXTRA_DEMO_BIRTH_YYMMDD, birthYYMMDD)
            putExtra(EXTRA_DEMO_EXPIRY_YYMMDD, expiryYYMMDD)
        }
    }
}
