package vn.cccd.bacreader.document.crosscheck

import vn.cccd.bacreader.document.mrz.MrzStatus
import vn.cccd.bacreader.document.mrz.MrzParser
import vn.cccd.bacreader.domain.AuthenticityResult
import vn.cccd.bacreader.domain.ExtendedFile
import vn.cccd.bacreader.domain.FileReadStatus
import vn.cccd.bacreader.domain.ReadResult
import vn.cccd.bacreader.domain.ReaderError
import vn.cccd.bacreader.domain.ScanStep

enum class NfcOverallStatus { SUCCESS, FAILURE }

data class NfcSessionSummary(
    val tagDetected: Boolean,
    val bacEstablished: Boolean,
    val secureMessagingEstablished: Boolean,
)

data class NfcReadSummary(
    val dg1: FileReadStatus,
    val dg2: FileReadStatus,
    val sod: FileReadStatus,
)

/** Lightweight NFC result contract for UI; no MRZ, DG bytes, keys, or images are retained. */
data class NfcDocumentResult(
    val overallStatus: NfcOverallStatus,
    val session: NfcSessionSummary,
    val reads: NfcReadSummary,
    val mrzStatus: MrzStatus,
    /** Parsed chip identity used by the post-NFC UI; never populated from OCR. */
    val chipIdentity: ChipIdentityData? = null,
    val crossCheck: ChipDocumentCrossCheckResult,
    val authenticity: AuthenticityResult,
    val failureStage: ScanStep? = null,
    val failureReason: ReaderError? = null,
)

object NfcDocumentResultMapper {
    fun from(outcome: ReadResult, visual: VisualDocumentData?): NfcDocumentResult = when (outcome) {
        is ReadResult.Success -> {
            val dg2Report = outcome.optionalFiles.firstOrNull { it.file == ExtendedFile.DG2 }
            val sodReport = outcome.optionalFiles.firstOrNull { it.file == ExtendedFile.EF_SOD }
            val mrz = MrzParser().parse(outcome.dg1Mrz)
            NfcDocumentResult(
                overallStatus = NfcOverallStatus.SUCCESS,
                session = NfcSessionSummary(true, true, true),
                reads = NfcReadSummary(
                    dg1 = FileReadStatus.READ,
                    dg2 = dg2Report?.status ?: FileReadStatus.NOT_PRESENT,
                    sod = sodReport?.status ?: FileReadStatus.NOT_ATTEMPTED,
                ),
                mrzStatus = mrz.status,
                chipIdentity = ChipIdentityMapper.from(mrz),
                crossCheck = visual?.let {
                    ChipDocumentCrossChecker().compare(it, outcome.dg1Mrz)
                } ?: unavailableCrossCheck(mrz.status),
                authenticity = outcome.authenticity,
            )
        }
        is ReadResult.Failure -> NfcDocumentResult(
            overallStatus = NfcOverallStatus.FAILURE,
            session = NfcSessionSummary(
                tagDetected = outcome.step.ordinal >= ScanStep.TAG_DISCOVERED.ordinal,
                bacEstablished = outcome.step.ordinal >= ScanStep.SECURE_MESSAGING_READY.ordinal,
                secureMessagingEstablished = outcome.step.ordinal >= ScanStep.SECURE_MESSAGING_READY.ordinal,
            ),
            reads = NfcReadSummary(
                dg1 = FileReadStatus.NOT_ATTEMPTED,
                dg2 = FileReadStatus.NOT_ATTEMPTED,
                sod = FileReadStatus.NOT_ATTEMPTED,
            ),
            mrzStatus = MrzStatus.MRZ_NOT_FOUND,
            crossCheck = unavailableCrossCheck(MrzStatus.MRZ_NOT_FOUND),
            authenticity = AuthenticityResult(),
            failureStage = outcome.step,
            failureReason = outcome.error,
        )
    }

    private fun unavailableCrossCheck(status: MrzStatus) = ChipDocumentCrossCheckResult(
        documentNumber = CrossCheckStatus.NOT_AVAILABLE,
        dateOfBirth = CrossCheckStatus.NOT_AVAILABLE,
        dateOfExpiry = CrossCheckStatus.NOT_AVAILABLE,
        mrzStatus = status,
    )
}
