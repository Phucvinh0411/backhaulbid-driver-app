package vn.cccd.bacreader.biometric.detection

import vn.cccd.bacreader.biometric.camera.CameraFrame

enum class FaceDetectionFailure {
    NO_MEDIA_IMAGE,
    PROCESSING_FAILED,
    DETECTOR_CLOSED,
}

sealed interface FaceDetectionResult {
    data class Success(
        val faces: List<DetectedFace>,
        val frameWidth: Int,
        val frameHeight: Int,
    ) : FaceDetectionResult

    data class Failure(val reason: FaceDetectionFailure) : FaceDetectionResult
}

interface FaceDetector : AutoCloseable {
    /** Takes ownership of [frame] and closes it when asynchronous processing completes. */
    fun process(frame: CameraFrame, onResult: (FaceDetectionResult) -> Unit)
}
