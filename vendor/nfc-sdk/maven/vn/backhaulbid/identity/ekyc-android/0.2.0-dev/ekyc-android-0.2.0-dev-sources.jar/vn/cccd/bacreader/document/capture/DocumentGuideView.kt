package vn.cccd.bacreader.document.capture

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Visual alignment guide only; it does not assert that the object is a genuine CCCD. */
class DocumentGuideView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {
    private val scrimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66000000 }
    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f * resources.displayMetrics.density
        color = Color.WHITE
    }
    private var aspectRatio = 85.60 / 53.98

    fun setAspectRatio(value: Double) {
        require(value > 1.0)
        aspectRatio = value
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val width = width.toFloat()
        val height = height.toFloat()
        val guideWidth = width * 0.90f
        val guideHeight = (guideWidth / aspectRatio.toFloat()).coerceAtMost(height * 0.75f)
        val left = (width - guideWidth) / 2f
        val top = (height - guideHeight) / 2f
        val right = left + guideWidth
        val bottom = top + guideHeight
        canvas.drawRect(0f, 0f, width, top, scrimPaint)
        canvas.drawRect(0f, top, left, bottom, scrimPaint)
        canvas.drawRect(right, top, width, bottom, scrimPaint)
        canvas.drawRect(0f, bottom, width, height, scrimPaint)
        canvas.drawRoundRect(left, top, right, bottom, 12f, 12f, guidePaint)
    }
}
