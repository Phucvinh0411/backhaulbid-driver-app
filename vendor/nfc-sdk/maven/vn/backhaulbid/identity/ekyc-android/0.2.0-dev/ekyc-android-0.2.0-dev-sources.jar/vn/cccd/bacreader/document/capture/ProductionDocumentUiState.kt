package vn.cccd.bacreader.document.capture

import android.graphics.Bitmap
import vn.cccd.bacreader.document.quality.DocumentQualityStatus
import vn.cccd.bacreader.document.readiness.DocumentCaptureReadiness
import vn.cccd.bacreader.document.resolver.ParsedFieldStatus

/** User-facing phase of the production document capture host. */
enum class ProductionDocumentStage {
    CAPTURE,
    CROP,
    PROCESSING,
    COMPLETE,
    ERROR,
    CANCELLED,
}

/**
 * Presentation state for the production document screen.
 *
 * The bitmap is owned by the active Activity/coordinator only. It is never
 * placed in navigation arguments, SavedStateHandle, or an Activity result.
 */
data class ProductionDocumentUiState(
    val stage: ProductionDocumentStage = ProductionDocumentStage.CAPTURE,
    val side: DocumentSide = DocumentSide.FRONT,
    val captureState: DocumentCaptureState = DocumentCaptureState.CAPTURE_FRONT,
    val quality: DocumentQualityStatus = DocumentQualityStatus.NO_DOCUMENT,
    val stableGoodFrames: Int = 0,
    val requiredStableGoodFrames: Int = 5,
    val captureInFlight: Boolean = false,
    val cropBitmap: Bitmap? = null,
    val cameraStatus: DocumentCameraStatus = DocumentCameraStatus.Idle,
    val analyzerFrameCount: Long = 0,
    val analysisWidth: Int = 0,
    val analysisHeight: Int = 0,
    val analysisRotationDegrees: Int = 0,
    val message: String? = null,
    val error: DocumentCaptureUiError? = null,
) {
    val canCapture: Boolean
        get() = stage == ProductionDocumentStage.CAPTURE &&
            quality == DocumentQualityStatus.GOOD &&
            stableGoodFrames >= requiredStableGoodFrames &&
            captureState in setOf(DocumentCaptureState.FRONT_READY, DocumentCaptureState.BACK_READY) &&
            !captureInFlight
}

enum class DocumentCaptureUiError {
    PERMISSION_REQUIRED,
    CAMERA_UNAVAILABLE,
    STILL_CAPTURE_FAILED,
    CROP_FAILED,
    OCR_FAILED,
}

/** Small result returned by the production document host; no image/OCR graph crosses the boundary. */
data class ProductionDocumentCompletion(
    val profile: String?,
    val documentNumber: String?,
    val birthYYMMDD: String?,
    val expiryYYMMDD: String?,
    val fullNameRaw: String?,
    val sex: String?,
    val nationality: String?,
    val documentNumberStatus: ParsedFieldStatus,
    val dateOfBirthStatus: ParsedFieldStatus,
    val dateOfExpiryStatus: ParsedFieldStatus,
    val readiness: DocumentCaptureReadiness,
)
