package vn.cccd.bacreader.biometric.camera

import android.content.Context
import android.content.Intent

/** Production-facing biometric host; CameraActivity remains available for compatibility. */
class ProductionBiometricActivity : CameraActivity() {
    companion object {
        fun createIntent(context: Context, session: BiometricSessionHandle?): Intent =
            CameraActivity.createProductionIntent(context, session)
    }
}
