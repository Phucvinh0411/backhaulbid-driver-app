package vn.cccd.bacreader.document.readiness

import vn.cccd.bacreader.document.capture.DocumentSide
import vn.cccd.bacreader.document.resolver.DocumentField
import vn.cccd.bacreader.document.resolver.ParsedFieldStatus
import vn.cccd.bacreader.document.resolver.VisualDocumentResolution

enum class DocumentReadinessStatus {
    READY,
    MISSING_REQUIRED_FIELDS,
    AMBIGUOUS_REQUIRED_FIELDS,
    INVALID_REQUIRED_FIELDS,
    MULTIPLE_REQUIRED_FIELD_ERRORS,
}

enum class RequiredVisualField {
    DOCUMENT_NUMBER,
    DATE_OF_BIRTH,
    DATE_OF_EXPIRY,
}

enum class RequiredFieldIssueType { MISSING, AMBIGUOUS, INVALID }

enum class DocumentRecoveryAction {
    NONE,
    RETAKE_FRONT,
    RETAKE_BACK,
    RETAKE_DOCUMENT_SIDE,
}

data class RequiredFieldIssue(
    val field: RequiredVisualField,
    val issue: RequiredFieldIssueType,
    val preferredRetakeSide: DocumentSide?,
)

data class DocumentCaptureReadiness(
    val status: DocumentReadinessStatus,
    val issues: List<RequiredFieldIssue>,
    val recommendedAction: DocumentRecoveryAction,
) {
    val isReady: Boolean get() = status == DocumentReadinessStatus.READY
}

/** Validates visual OCR readiness only; it does not parse OCR or create BAC input. */
class RequiredVisualFieldsValidator {
    fun evaluate(result: VisualDocumentResolution): DocumentCaptureReadiness {
        val issues = listOfNotNull(
            issue(RequiredVisualField.DOCUMENT_NUMBER, result.field(DocumentField.DOCUMENT_NUMBER), DocumentSide.FRONT),
            issue(RequiredVisualField.DATE_OF_BIRTH, result.field(DocumentField.DATE_OF_BIRTH), DocumentSide.FRONT),
            issue(RequiredVisualField.DATE_OF_EXPIRY, result.field(DocumentField.DATE_OF_EXPIRY), expirySide(result)),
        )
        if (issues.isEmpty()) {
            return DocumentCaptureReadiness(DocumentReadinessStatus.READY, emptyList(), DocumentRecoveryAction.NONE)
        }
        val distinctTypes = issues.map { it.issue }.distinct()
        val status = when {
            issues.size > 1 -> DocumentReadinessStatus.MULTIPLE_REQUIRED_FIELD_ERRORS
            distinctTypes.single() == RequiredFieldIssueType.MISSING -> DocumentReadinessStatus.MISSING_REQUIRED_FIELDS
            distinctTypes.single() == RequiredFieldIssueType.AMBIGUOUS -> DocumentReadinessStatus.AMBIGUOUS_REQUIRED_FIELDS
            else -> DocumentReadinessStatus.INVALID_REQUIRED_FIELDS
        }
        return DocumentCaptureReadiness(status, issues, recoveryAction(issues))
    }

    private fun issue(
        field: RequiredVisualField,
        resolved: vn.cccd.bacreader.document.resolver.ResolvedField<String>,
        side: DocumentSide?,
    ): RequiredFieldIssue? {
        val type = when (resolved.status) {
            ParsedFieldStatus.FOUND -> return null
            ParsedFieldStatus.NOT_FOUND -> RequiredFieldIssueType.MISSING
            ParsedFieldStatus.AMBIGUOUS -> RequiredFieldIssueType.AMBIGUOUS
            ParsedFieldStatus.INVALID -> RequiredFieldIssueType.INVALID
        }
        return RequiredFieldIssue(field, type, side)
    }

    private fun expirySide(result: VisualDocumentResolution): DocumentSide? = when (result.profile) {
        vn.cccd.bacreader.document.resolver.VietnamCardProfile.CCCD_2021 -> DocumentSide.FRONT
        vn.cccd.bacreader.document.resolver.VietnamCardProfile.IDENTITY_CARD_2024 -> DocumentSide.BACK
        vn.cccd.bacreader.document.resolver.VietnamCardProfile.UNKNOWN ->
            result.dateOfExpiry.sourceSide
    }

    private fun recoveryAction(issues: List<RequiredFieldIssue>): DocumentRecoveryAction {
        val sides = issues.mapNotNull { it.preferredRetakeSide }.distinct()
        return when {
            sides.size == 1 && sides.single() == DocumentSide.FRONT -> DocumentRecoveryAction.RETAKE_FRONT
            sides.size == 1 && sides.single() == DocumentSide.BACK -> DocumentRecoveryAction.RETAKE_BACK
            else -> DocumentRecoveryAction.RETAKE_DOCUMENT_SIDE
        }
    }
}
