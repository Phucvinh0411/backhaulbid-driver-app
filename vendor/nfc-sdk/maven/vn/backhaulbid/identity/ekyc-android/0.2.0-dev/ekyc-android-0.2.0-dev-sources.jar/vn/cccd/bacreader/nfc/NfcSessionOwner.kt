package vn.cccd.bacreader.nfc

import java.util.concurrent.atomic.AtomicLong

/**
 * Owns the one active scan generation. Stale Reader Mode callbacks cannot
 * publish results after a new scan, pause, cancellation, or tag loss.
 */
class NfcSessionOwner {
    private val nextGeneration = AtomicLong(0)
    private val lock = Any()
    private var activeTransport: AutoCloseable? = null
    private var activeGeneration = 0L
    private var tagClaimed = false

    fun begin(): Long = synchronized(lock) {
        closeActiveLocked()
        activeGeneration = nextGeneration.incrementAndGet()
        tagClaimed = false
        activeGeneration
    }

    fun attach(generation: Long, transport: AutoCloseable): Boolean = synchronized(lock) {
        if (generation != activeGeneration || activeTransport != null) {
            transport.close()
            return@synchronized false
        }
        activeTransport = transport
        true
    }

    fun isCurrent(generation: Long): Boolean = synchronized(lock) {
        generation != 0L && generation == activeGeneration
    }

    /** Allows only the first Reader Mode tag callback for a scan generation. */
    fun claimTagCallback(generation: Long): Boolean = synchronized(lock) {
        if (generation == 0L || generation != activeGeneration || tagClaimed) return false
        tagClaimed = true
        true
    }

    fun end(generation: Long) = synchronized(lock) {
        if (generation == activeGeneration) {
            closeActiveLocked()
            activeGeneration = 0L
            tagClaimed = false
        }
    }

    fun cancel() = synchronized(lock) {
        closeActiveLocked()
        activeGeneration = 0L
        tagClaimed = false
        nextGeneration.incrementAndGet()
    }

    private fun closeActiveLocked() {
        activeTransport?.runCatching { close() }
        activeTransport = null
    }
}
