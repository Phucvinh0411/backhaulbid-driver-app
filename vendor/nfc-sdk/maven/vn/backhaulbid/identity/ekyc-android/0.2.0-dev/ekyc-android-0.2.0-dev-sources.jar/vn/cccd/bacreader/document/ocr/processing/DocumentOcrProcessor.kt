package vn.cccd.bacreader.document.ocr.processing

import vn.cccd.bacreader.document.ocr.OcrSnapshot
import vn.cccd.bacreader.document.ocr.preprocess.OcrTextPreprocessor
import vn.cccd.bacreader.document.ocr.preprocess.PreprocessedOcr
import vn.cccd.bacreader.document.readiness.DocumentCaptureReadiness
import vn.cccd.bacreader.document.readiness.RequiredVisualFieldsValidator
import vn.cccd.bacreader.document.resolver.DocumentFieldResolver
import vn.cccd.bacreader.document.resolver.VisualDocumentResolution

/**
 * Pure, session-scoped OCR post-processing pipeline.
 *
 * The snapshots are immutable and the work does not touch Android UI state,
 * which lets callers run it on a background executor without changing the
 * approved resolver/readiness rules.
 */
data class DocumentOcrProcessingResult(
    val preprocessed: PreprocessedOcr,
    val resolution: VisualDocumentResolution,
    val readiness: DocumentCaptureReadiness,
)

class DocumentOcrProcessor(
    private val preprocessor: OcrTextPreprocessor = OcrTextPreprocessor(),
    private val resolver: DocumentFieldResolver = DocumentFieldResolver(),
    private val readinessValidator: RequiredVisualFieldsValidator = RequiredVisualFieldsValidator(),
) {
    fun process(front: OcrSnapshot?, back: OcrSnapshot?): DocumentOcrProcessingResult {
        val preprocessed = preprocessor.process(front = front, back = back)
        val resolution = resolver.resolve(preprocessed)
        val readiness = readinessValidator.evaluate(resolution)
        return DocumentOcrProcessingResult(preprocessed, resolution, readiness)
    }
}
