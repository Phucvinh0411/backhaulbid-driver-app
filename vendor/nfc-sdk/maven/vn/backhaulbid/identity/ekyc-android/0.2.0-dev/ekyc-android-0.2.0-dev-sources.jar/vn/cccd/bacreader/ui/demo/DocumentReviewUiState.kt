package vn.cccd.bacreader.ui.demo

import vn.cccd.bacreader.document.display.normalizeFullNameForDisplay
import vn.cccd.bacreader.document.resolver.ParsedFieldStatus

/** Required fields shown by the document review gate. */
enum class ReviewRequiredField {
    DOCUMENT_NUMBER,
    DATE_OF_BIRTH,
    DATE_OF_EXPIRY,
}

data class ReviewRequiredIssue(
    val field: ReviewRequiredField,
    val status: ParsedFieldStatus,
)

/**
 * Presentation-only document review state.
 *
 * The existing DocumentCaptureActivity/readiness validator remains the source of truth.
 * This type only maps its result to safe display values and never re-validates OCR.
 */
data class DocumentReviewUiState(
    val profile: String?,
    val documentNumberDisplay: String,
    val dateOfBirthDisplay: String,
    val dateOfExpiryDisplay: String,
    val fullNameDisplay: String?,
    val sexDisplay: String?,
    val nationalityDisplay: String?,
    val flowState: DocumentCaptureFlowState,
    val readinessStatus: String?,
    val requiredIssues: List<ReviewRequiredIssue>,
    val recommendedRetakeAction: String?,
    val canContinue: Boolean,
) {
    companion object {
        fun from(result: DocumentCaptureBridgeResult): DocumentReviewUiState {
            val document = result.document
            val statuses = result.fieldStatuses
            val issues = if (result.state == DocumentCaptureFlowState.BLOCKED) {
                listOfNotNull(
                    statuses.documentNumber.toIssue(ReviewRequiredField.DOCUMENT_NUMBER),
                    statuses.dateOfBirth.toIssue(ReviewRequiredField.DATE_OF_BIRTH),
                    statuses.dateOfExpiry.toIssue(ReviewRequiredField.DATE_OF_EXPIRY),
                )
            } else {
                emptyList()
            }
            return DocumentReviewUiState(
                profile = result.profile,
                documentNumberDisplay = document?.documentNumber?.let(::maskDocumentNumberForDisplay) ?: "—",
                dateOfBirthDisplay = document?.birthYYMMDD?.let(::formatDocumentDateForDisplay) ?: "—",
                dateOfExpiryDisplay = document?.expiryYYMMDD?.let(::formatDocumentDateForDisplay) ?: "—",
                fullNameDisplay = document?.fullNameRaw?.let(::normalizeFullNameForDisplay),
                sexDisplay = document?.sex,
                nationalityDisplay = document?.nationality,
                flowState = result.state,
                readinessStatus = result.readinessStatus,
                requiredIssues = issues,
                recommendedRetakeAction = result.recommendedAction,
                canContinue = result.state == DocumentCaptureFlowState.READY,
            )
        }

        private fun ParsedFieldStatus.toIssue(field: ReviewRequiredField): ReviewRequiredIssue? =
            takeIf { it != ParsedFieldStatus.FOUND }?.let { ReviewRequiredIssue(field, it) }
    }
}

/** Masks all but the last four characters for normal review UI. */
fun maskDocumentNumberForDisplay(value: String): String {
    if (value.length <= 4) return value
    return "•".repeat(value.length - 4) + value.takeLast(4)
}

/** Converts the existing resolver YYMMDD value to a user-facing date without changing source data. */
fun formatDocumentDateForDisplay(value: String): String {
    if (value.length != 6) return value
    return "${value.substring(4, 6)}/${value.substring(2, 4)}/20${value.substring(0, 2)}"
}
