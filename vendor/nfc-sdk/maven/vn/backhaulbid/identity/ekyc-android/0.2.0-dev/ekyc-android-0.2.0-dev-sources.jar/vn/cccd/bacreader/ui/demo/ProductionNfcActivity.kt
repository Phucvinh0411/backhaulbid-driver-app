package vn.cccd.bacreader.ui.demo

import android.content.Context
import android.content.Intent
import vn.cccd.bacreader.ui.MainActivity

/** Production NFC route. MainActivity remains the compatibility/engine adapter. */
class ProductionNfcActivity : MainActivity() {
    companion object {
        fun createIntent(
            context: Context,
            documentNumber: String,
            birthYYMMDD: String,
            expiryYYMMDD: String,
        ): Intent = Intent(context, ProductionNfcActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_PRODUCTION_UI, true)
            putExtra(MainActivity.EXTRA_DEMO_RETURN, true)
            putExtra(MainActivity.EXTRA_DEMO_DOCUMENT_NUMBER, documentNumber)
            putExtra(MainActivity.EXTRA_DEMO_BIRTH_YYMMDD, birthYYMMDD)
            putExtra(MainActivity.EXTRA_DEMO_EXPIRY_YYMMDD, expiryYYMMDD)
        }
    }
}
