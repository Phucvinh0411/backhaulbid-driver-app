package vn.cccd.bacreader.document.ocr.preprocess

import java.text.Normalizer
import java.time.DateTimeException
import java.time.LocalDate
import java.util.Locale
import kotlin.math.max
import vn.cccd.bacreader.document.capture.DocumentSide
import vn.cccd.bacreader.document.ocr.OcrBounds
import vn.cccd.bacreader.document.ocr.OcrSnapshot
import vn.cccd.bacreader.document.ocr.OcrSourceKind
import vn.cccd.bacreader.document.resolver.DocumentField
import vn.cccd.bacreader.document.resolver.VietnamCccdFieldProfiles

/** Transformations applied to derived OCR representations, never to the raw snapshot. */
enum class TextTransformation {
    COLLAPSE_WHITESPACE,
    TRIM_SAFE_PUNCTUATION,
    ACCENT_INSENSITIVE_LABEL_MATCH,
    FUZZY_LABEL_MATCH,
    JOIN_ADJACENT_DIGIT_TOKENS,
    REMOVE_SAFE_DATE_WHITESPACE,
    NORMALIZE_DATE_SEPARATOR,
    MULTI_LABEL_LINE_SPLIT,
    SPLIT_LABEL_MATCH,
    SAME_LINE_VALUE_EXTRACT,
    ELEMENT_GEOMETRY_ASSOCIATION,
    OCR_O_TO_ZERO_IN_NUMERIC_DATE,
}

/** Matching copy only. It is never used as the value returned to the user. */
object OcrTextNormalizer {
    fun matching(value: String): String = normalize(value, stripAccents = false)

    fun accentInsensitive(value: String): String = normalize(value, stripAccents = true)

    fun normalizeLabel(value: String): String = accentInsensitive(value)

    fun normalizeValue(value: String): String = matching(value)

    fun tokens(value: String): List<String> = matching(value).split(' ').filter(String::isNotEmpty)

    private fun normalize(value: String, stripAccents: Boolean): String {
        var normalized = Normalizer.normalize(
            value,
            if (stripAccents) Normalizer.Form.NFD else Normalizer.Form.NFC,
        )
            .replace('\u0110'.toString(), "D")
            .replace('\u0111'.toString(), "d")
        if (stripAccents) normalized = normalized.replace(Regex("\\p{M}+"), "")
        return normalized
            .uppercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{Nd}]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
    }

    /** Conservative value-only cleanup; accents and token identity remain intact. */
    fun valueText(value: String): String = value
        .trim { it.isWhitespace() || it == ':' || it == '-' }
        .replace(Regex("\\s+"), " ")
}

data class ReconstructedText(
    val rawText: String,
    val normalizedText: String,
    val transformations: Set<TextTransformation>,
    val sourceBounds: OcrBounds? = null,
)

data class PreprocessedElement(
    val index: Int,
    val rawText: String,
    val bounds: OcrBounds?,
)

data class PreprocessedLine(
    val side: DocumentSide,
    val blockIndex: Int,
    val lineIndex: Int,
    val rawText: String,
    val matchingText: String,
    val bounds: OcrBounds?,
    val imageWidth: Int,
    val imageHeight: Int,
    val elements: List<PreprocessedElement>,
    val sourceKind: OcrSourceKind = OcrSourceKind.WHOLE_CARD,
    val retryTargetField: DocumentField? = null,
)

enum class LabelMatchKind { EXACT, ACCENT_INSENSITIVE, FUZZY, SPLIT }

data class OcrFieldSegment(
    val field: DocumentField,
    val rawLabel: String,
    val rawValue: String,
    val normalizedValue: String,
    val labelMatch: LabelMatchKind,
    val transformations: Set<TextTransformation>,
    val side: DocumentSide,
    val blockIndex: Int,
    val lineIndex: Int,
    val sourceLineIndexes: List<Int>,
    val labelBounds: OcrBounds?,
    val valueBounds: OcrBounds?,
    val sourceElementIndexes: List<Int>,
    val sourceKind: OcrSourceKind = OcrSourceKind.WHOLE_CARD,
    val retryTargetField: DocumentField? = null,
)

data class PreprocessedOcr(
    val front: OcrSnapshot?,
    val back: OcrSnapshot?,
    val lines: List<PreprocessedLine>,
    val segments: List<OcrFieldSegment>,
)

data class DateCandidate(
    val rawText: String,
    val normalizedText: String,
    val transformations: Set<TextTransformation>,
    val date: LocalDate,
)

/** Reconstructs only whitespace/separator variants of an otherwise numeric date. */
object DateCandidateAssembler {
    private val dateShape = Regex(
        "(?<![\\p{L}\\p{Nd}])" +
            "\\d(?:\\s*\\d)?\\s*[/.-]\\s*\\d(?:\\s*\\d)?\\s*[/.-]\\s*" +
            "\\d(?:\\s*\\d){3}(?![\\p{L}\\p{Nd}])",
    )

    /** A bounded shape for one OCR O/0 confusion in a structured date. */
    private val recoverableDateShape = Regex(
        "(?<![\\p{L}\\p{Nd}])" +
            "[0-9O](?:\\s*[0-9O])?\\s*[/.-]\\s*" +
            "[0-9O](?:\\s*[0-9O])?\\s*[/.-]\\s*" +
            "[0-9O](?:\\s*[0-9O]){3}(?![\\p{L}\\p{Nd}])",
        RegexOption.IGNORE_CASE,
    )

    fun candidates(text: String, allowOToZero: Boolean = false): List<DateCandidate> {
        val strict = dateShape.findAll(text).mapNotNull { reconstruct(it.value) }
        if (!allowOToZero) return strict.toList()
        val recovered = recoverableDateShape.findAll(text)
            .mapNotNull { reconstruct(it.value, allowOToZero = true) }
        return (strict + recovered).distinctBy { it.rawText to it.normalizedText }.toList()
    }

    fun reconstruct(text: String, allowOToZero: Boolean = false): DateCandidate? {
        val raw = text.trim()
        val oCount = raw.count { it == 'O' || it == 'o' }
        if (oCount > 0 && (!allowOToZero || oCount != 1)) return null
        val recoveredRaw = if (oCount == 1) {
            raw.map { if (it == 'O' || it == 'o') '0' else it }.joinToString("")
        } else {
            raw
        }
        val normalizedSeparators = recoveredRaw.replace(Regex("\\s*[-.]\\s*"), "/")
        val parts = normalizedSeparators.split('/')
        if (parts.size != 3) return null
        val day = parts[0].replace(Regex("\\s+"), "")
        val month = parts[1].replace(Regex("\\s+"), "")
        val year = parts[2].replace(Regex("\\s+"), "")
        if (day.length !in 1..2 || month.length !in 1..2 || year.length != 4) return null
        val date = runCatching { LocalDate.of(year.toInt(), month.toInt(), day.toInt()) }
            .getOrElse { return null }
        val canonical = "%02d/%02d/%04d".format(Locale.ROOT, date.dayOfMonth, date.monthValue, date.year)
        val transformations = buildSet {
            if (raw != raw.replace(Regex("\\s+"), "")) add(TextTransformation.REMOVE_SAFE_DATE_WHITESPACE)
            if (raw.contains('-') || raw.contains('.')) add(TextTransformation.NORMALIZE_DATE_SEPARATOR)
            if (oCount == 1) add(TextTransformation.OCR_O_TO_ZERO_IN_NUMERIC_DATE)
        }
        return DateCandidate(raw, canonical, transformations, date)
    }
}

/**
 * Copies the immutable OCR hierarchy into a derived, layout-aware representation.
 * ML Kit objects and image pixels are intentionally not retained here.
 */
class OcrTextPreprocessor {
    fun process(front: OcrSnapshot?, back: OcrSnapshot?): PreprocessedOcr {
        val lines = buildList {
            front?.let { addAll(flatten(it, DocumentSide.FRONT)) }
            back?.let { addAll(flatten(it, DocumentSide.BACK)) }
        }
        return PreprocessedOcr(
            front = front,
            back = back,
            lines = lines,
            segments = lines.flatMap(::segmentsForLine),
        )
    }

    private fun flatten(snapshot: OcrSnapshot, side: DocumentSide): List<PreprocessedLine> = buildList {
        var lineIndex = 0
        snapshot.blocks.forEachIndexed { blockIndex, block ->
            if (block.lines.isEmpty()) {
                add(
                    PreprocessedLine(
                        side, blockIndex, lineIndex++, block.text, OcrTextNormalizer.normalizeLabel(block.text),
                        block.bounds, snapshot.imageWidth, snapshot.imageHeight, emptyList(),
                        OcrSourceKind.WHOLE_CARD, null,
                    ),
                )
            } else {
                block.lines.forEach { line ->
                    add(
                        PreprocessedLine(
                            side = side,
                            blockIndex = blockIndex,
                            lineIndex = lineIndex++,
                            rawText = line.text,
                            matchingText = OcrTextNormalizer.normalizeLabel(line.text),
                            bounds = line.bounds,
                            imageWidth = snapshot.imageWidth,
                            imageHeight = snapshot.imageHeight,
                            elements = line.elements.mapIndexed { index, element ->
                                PreprocessedElement(index, element.text, element.bounds)
                            },
                            sourceKind = line.sourceKind,
                            retryTargetField = line.retryTargetField,
                        ),
                    )
                }
            }
        }
    }

    private fun segmentsForLine(line: PreprocessedLine): List<OcrFieldSegment> {
        val occurrences = findLabelOccurrences(line)
        if (occurrences.isEmpty()) return emptyList()
        val semanticLabels = deduplicateBilingualLabels(occurrences)
        val multiLabel = semanticLabels.size > 1
        return semanticLabels.mapIndexed { index, label ->
            val next = semanticLabels.getOrNull(index + 1)
            val valueStart = label.rawEnd
            val valueEnd = next?.rawStart ?: line.rawText.length
            val rawValue = line.rawText.substring(valueStart.coerceAtMost(valueEnd), valueEnd)
                .trimStart { it.isWhitespace() || it == ':' || it == '-' }
                .trimEnd()
            val transforms = buildSet {
                if (multiLabel) add(TextTransformation.MULTI_LABEL_LINE_SPLIT)
                if (rawValue.isNotBlank()) add(TextTransformation.SAME_LINE_VALUE_EXTRACT)
                if (label.kind == LabelMatchKind.ACCENT_INSENSITIVE) add(TextTransformation.ACCENT_INSENSITIVE_LABEL_MATCH)
                if (label.kind == LabelMatchKind.FUZZY) add(TextTransformation.FUZZY_LABEL_MATCH)
                if (label.kind == LabelMatchKind.SPLIT) add(TextTransformation.SPLIT_LABEL_MATCH)
                if (rawValue != OcrTextNormalizer.valueText(rawValue)) add(TextTransformation.COLLAPSE_WHITESPACE)
            }
            OcrFieldSegment(
                field = label.field,
                rawLabel = line.rawText.substring(label.rawStart, label.rawEnd),
                rawValue = rawValue,
                normalizedValue = OcrTextNormalizer.normalizeValue(rawValue),
                labelMatch = label.kind,
                transformations = transforms,
                side = line.side,
                blockIndex = line.blockIndex,
                lineIndex = line.lineIndex,
                sourceLineIndexes = listOf(line.lineIndex),
                labelBounds = label.bounds,
                valueBounds = valueBounds(line, valueStart, valueEnd),
                sourceElementIndexes = elementIndexes(line, valueStart, valueEnd),
                sourceKind = line.sourceKind,
                retryTargetField = line.retryTargetField,
            )
        }
    }

    private fun findLabelOccurrences(line: PreprocessedLine): List<LabelOccurrence> {
        val tokens = tokenize(line.rawText)
        return DocumentField.values().flatMap { field ->
            val aliases = VietnamCccdFieldProfiles.forField(field).aliases
            aliases.flatMap { alias -> findAliasMatches(field, alias, line, tokens) }
        }.sortedWith(compareBy<LabelOccurrence> { it.rawStart }.thenByDescending { it.rawEnd - it.rawStart })
    }

    private fun findAliasMatches(
        field: DocumentField,
        alias: String,
        line: PreprocessedLine,
        tokens: List<RawToken>,
    ): List<LabelOccurrence> {
        val aliasTokens = OcrTextNormalizer.tokens(alias)
        if (aliasTokens.isEmpty() || tokens.size < aliasTokens.size) return emptyList()
        return tokens.windowed(aliasTokens.size).mapIndexedNotNull { start, window ->
            val normalized = window.map { OcrTextNormalizer.accentInsensitive(it.text) }
            val exact = normalized == aliasTokens.map(OcrTextNormalizer::accentInsensitive)
            val matching = window.map { OcrTextNormalizer.matching(it.text) }
            val aliasMatching = aliasTokens.map(OcrTextNormalizer::matching)
            val accentExact = normalized == aliasMatching
            val distance = window.zip(aliasTokens).sumOf { (token, expected) ->
                levenshtein(OcrTextNormalizer.accentInsensitive(token.text), OcrTextNormalizer.accentInsensitive(expected))
            }
            val fuzzyAllowed = aliasTokens.sumOf(String::length) >= 5
            val maxDistance = max(1, aliasTokens.sumOf(String::length) / 8)
            val kind = when {
                matching == aliasMatching -> LabelMatchKind.EXACT
                accentExact || exact -> LabelMatchKind.ACCENT_INSENSITIVE
                fuzzyAllowed && distance in 1..maxDistance -> LabelMatchKind.FUZZY
                else -> return@mapIndexedNotNull null
            }
            LabelOccurrence(
                field = field,
                alias = alias,
                kind = kind,
                tokenStart = start,
                tokenEnd = start + window.size,
                rawStart = window.first().start,
                rawEnd = window.last().end,
                bounds = unionBounds(line.bounds, window.mapNotNull { tokenBounds(line, it) }),
            )
        }
    }

    private fun deduplicateBilingualLabels(occurrences: List<LabelOccurrence>): List<LabelOccurrence> {
        val sorted = occurrences.sortedWith(compareBy<LabelOccurrence> { it.rawStart }.thenByDescending { it.rawEnd - it.rawStart })
        val kept = mutableListOf<LabelOccurrence>()
        sorted.forEach { candidate ->
            val previous = kept.lastOrNull()
            if (previous != null && previous.field == candidate.field &&
                candidate.rawStart <= previous.rawEnd + 4 &&
                lineBetweenLabelsIsOnlyConnector(previous, candidate)
            ) {
                val stronger = if (matchStrength(candidate.kind) > matchStrength(previous.kind)) candidate else previous
                kept[kept.lastIndex] = previous.copy(
                    rawEnd = max(previous.rawEnd, candidate.rawEnd),
                    tokenEnd = max(previous.tokenEnd, candidate.tokenEnd),
                    kind = stronger.kind,
                    bounds = unionBounds(null, listOfNotNull(previous.bounds, candidate.bounds)),
                )
            } else if (kept.none { overlaps(it, candidate) || sameFieldConnector(it, candidate) }) {
                kept += candidate
            }
        }
        return kept.sortedBy { it.rawStart }
    }

    private fun lineBetweenLabelsIsOnlyConnector(first: LabelOccurrence, second: LabelOccurrence): Boolean =
        second.rawStart - first.rawEnd <= 8

    private fun sameFieldConnector(first: LabelOccurrence, second: LabelOccurrence): Boolean =
        first.field == second.field && second.rawStart - first.rawEnd <= 4

    private fun overlaps(first: LabelOccurrence, second: LabelOccurrence): Boolean =
        first.field == second.field && first.rawStart < second.rawEnd && second.rawStart < first.rawEnd

    private fun valueBounds(line: PreprocessedLine, start: Int, end: Int): OcrBounds? =
        unionBounds(null, tokenize(line.rawText).filter { it.start >= start && it.end <= end }.mapNotNull { tokenBounds(line, it) })

    private fun elementIndexes(line: PreprocessedLine, start: Int, end: Int): List<Int> =
        if (line.elements.isEmpty()) emptyList() else elementRanges(line).filter { (_, elementStart, elementEnd) ->
            elementStart < end && elementEnd > start
        }.map { (index, _, _) -> index }

    private fun tokenBounds(line: PreprocessedLine, token: RawToken): OcrBounds? {
        val elements = line.elements
        if (elements.isEmpty()) return null
        return elementRanges(line).firstOrNull { (_, start, end) ->
            token.start < end && token.end > start
        }?.let { (index, _, _) -> elements[index].bounds }
    }

    /** Maps duplicate OCR element text by reading order, not the first string occurrence. */
    private fun elementRanges(line: PreprocessedLine): List<ElementRange> {
        var searchStart = 0
        return line.elements.map { element ->
            val start = line.rawText.indexOf(element.rawText, searchStart).takeIf { it >= 0 }
                ?: line.rawText.indexOf(element.rawText).takeIf { it >= 0 }
                ?: searchStart
            val end = (start + element.rawText.length).coerceAtMost(line.rawText.length)
            searchStart = end
            ElementRange(element.index, start, end)
        }
    }

    private fun tokenize(text: String): List<RawToken> = Regex("[\\p{L}\\p{Nd}]+")
        .findAll(text)
        .map { RawToken(it.value, it.range.first, it.range.last + 1) }
        .toList()

    private fun unionBounds(ignored: OcrBounds?, bounds: List<OcrBounds>): OcrBounds? {
        if (bounds.isEmpty()) return ignored
        return OcrBounds(
            bounds.minOf { it.left },
            bounds.minOf { it.top },
            bounds.maxOf { it.right },
            bounds.maxOf { it.bottom },
        )
    }

    private fun matchStrength(kind: LabelMatchKind): Int = when (kind) {
        LabelMatchKind.EXACT -> 4
        LabelMatchKind.ACCENT_INSENSITIVE -> 3
        LabelMatchKind.SPLIT -> 2
        LabelMatchKind.FUZZY -> 1
    }

    private fun levenshtein(first: String, second: String): Int {
        if (first == second) return 0
        if (first.isEmpty()) return second.length
        if (second.isEmpty()) return first.length
        var previous = IntArray(second.length + 1) { it }
        for (i in first.indices) {
            val current = IntArray(second.length + 1)
            current[0] = i + 1
            for (j in second.indices) {
                current[j + 1] = minOf(
                    current[j] + 1,
                    previous[j + 1] + 1,
                    previous[j] + if (first[i] == second[j]) 0 else 1,
                )
            }
            previous = current
        }
        return previous.last()
    }

    private data class RawToken(val text: String, val start: Int, val end: Int)

    private data class ElementRange(val index: Int, val start: Int, val end: Int)

    private data class LabelOccurrence(
        val field: DocumentField,
        val alias: String,
        val kind: LabelMatchKind,
        val tokenStart: Int,
        val tokenEnd: Int,
        val rawStart: Int,
        val rawEnd: Int,
        val bounds: OcrBounds?,
    )
}
