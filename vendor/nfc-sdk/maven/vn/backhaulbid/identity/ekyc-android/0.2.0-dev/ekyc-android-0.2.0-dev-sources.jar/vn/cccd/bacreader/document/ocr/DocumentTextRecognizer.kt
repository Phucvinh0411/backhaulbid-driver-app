package vn.cccd.bacreader.document.ocr

import android.graphics.Bitmap
import android.graphics.Point
import android.graphics.Rect
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.Executors
import vn.cccd.bacreader.document.capture.DocumentSide

enum class DocumentTextRecognitionStatus {
    SUCCESS,
    FAILED,
    CLOSED,
}

data class DocumentTextRecognitionResult(
    val status: DocumentTextRecognitionStatus,
    val snapshot: OcrSnapshot? = null,
) {
    /** Compatibility accessor for the existing V1 parser; raw text is session-scoped. */
    val text: String get() = snapshot?.fullText.orEmpty()
}

fun interface DocumentTextRecognitionCallback {
    fun onResult(result: DocumentTextRecognitionResult)
}

interface DocumentTextRecognizer : AutoCloseable {
    fun recognize(
        bitmap: Bitmap,
        documentSide: DocumentSide,
        rotationDegrees: Int = 0,
        callback: DocumentTextRecognitionCallback,
    )
}

/** Bundled ML Kit Latin OCR. It is invoked only after a side has been accepted. */
class MlKitDocumentTextRecognizer : DocumentTextRecognizer {
    private val closed = AtomicBoolean(false)
    private val recognizer: TextRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    /** ML Kit Task callbacks otherwise default to the main executor. */
    private val callbackExecutor = Executors.newSingleThreadExecutor()

    override fun recognize(
        bitmap: Bitmap,
        documentSide: DocumentSide,
        rotationDegrees: Int,
        callback: DocumentTextRecognitionCallback,
    ) {
        val delivered = AtomicBoolean(false)
        fun deliver(result: DocumentTextRecognitionResult) {
            if (delivered.compareAndSet(false, true)) callback.onResult(result)
        }
        if (closed.get()) {
            deliver(DocumentTextRecognitionResult(DocumentTextRecognitionStatus.CLOSED))
            return
        }
        try {
            recognizer.process(InputImage.fromBitmap(bitmap, rotationDegrees))
                .addOnSuccessListener(callbackExecutor) { result ->
                    val snapshot = runCatching {
                        OcrSnapshotFactory.copy(
                            fullText = result.text,
                            blocks = result.textBlocks.map { block ->
                                OcrBlockInput(
                                    text = block.getText(),
                                    bounds = block.getBoundingBox().toOcrBounds(),
                                    cornerPoints = block.getCornerPoints().toOcrPoints(),
                                            // ML Kit exposes confidence for lines/elements; preserve it as nullable
                                            // engine metadata and never synthesize a value for blocks.
                                            confidence = null,
                                            lines = block.getLines().map { line ->
                                                OcrLineInput(
                                            text = line.getText(),
                                            bounds = line.getBoundingBox().toOcrBounds(),
                                            cornerPoints = line.getCornerPoints().toOcrPoints(),
                                            confidence = line.getConfidence().toNullableConfidence(),
                                            elements = line.getElements().map { element ->
                                                OcrElementInput(
                                                    text = element.getText(),
                                                    bounds = element.getBoundingBox().toOcrBounds(),
                                                    cornerPoints = element.getCornerPoints().toOcrPoints(),
                                                    confidence = element.getConfidence().toNullableConfidence(),
                                                )
                                            },
                                        )
                                    },
                                )
                            },
                            imageWidth = bitmap.width,
                            imageHeight = bitmap.height,
                            rotationDegrees = rotationDegrees,
                            documentSide = documentSide,
                        )
                    }.getOrNull()
                    if (snapshot == null) {
                        deliver(DocumentTextRecognitionResult(DocumentTextRecognitionStatus.FAILED))
                    } else {
                        deliver(DocumentTextRecognitionResult(DocumentTextRecognitionStatus.SUCCESS, snapshot))
                    }
                }
                .addOnFailureListener(callbackExecutor) {
                    deliver(DocumentTextRecognitionResult(DocumentTextRecognitionStatus.FAILED))
                }
        } catch (_: RuntimeException) {
            deliver(DocumentTextRecognitionResult(DocumentTextRecognitionStatus.FAILED))
        }
    }

    override fun close() {
        if (closed.compareAndSet(false, true)) {
            recognizer.close()
            callbackExecutor.shutdownNow()
        }
    }
}

private fun Rect?.toOcrBounds(): OcrBounds? = this?.let { OcrBounds(it.left, it.top, it.right, it.bottom) }

private fun Array<Point>?.toOcrPoints(): List<OcrPoint> =
    this?.map { OcrPoint(it.x, it.y) }.orEmpty()

private fun Float.toNullableConfidence(): Float? =
    takeIf { isFinite() && it >= 0f }
