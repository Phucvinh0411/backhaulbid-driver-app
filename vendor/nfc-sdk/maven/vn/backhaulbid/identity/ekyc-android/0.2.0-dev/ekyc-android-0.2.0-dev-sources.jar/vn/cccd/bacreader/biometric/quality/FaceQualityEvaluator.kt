package vn.cccd.bacreader.biometric.quality

import kotlin.math.abs
import vn.cccd.bacreader.biometric.detection.DetectedFace

data class FaceQualityConfig(
    val minFaceWidthPx: Int = 120,
    val minFaceHeightPx: Int = 120,
    val minFaceAreaRatio: Double = 0.08,
    val centerTolerance: Double = 0.25,
) {
    init {
        require(minFaceWidthPx > 0)
        require(minFaceHeightPx > 0)
        require(minFaceAreaRatio in 0.0..1.0)
        require(centerTolerance in 0.0..0.5)
    }
}

enum class FaceQualityStatus {
    ACCEPTABLE,
    REJECTED,
}

enum class FaceQualityReason {
    NO_FACE,
    MULTIPLE_FACES,
    INVALID_FRAME,
    INVALID_FACE_BOUNDS,
    FACE_TOO_SMALL,
    FACE_OFF_CENTER,
}

data class FaceQualityResult(
    val status: FaceQualityStatus,
    val reasons: Set<FaceQualityReason>,
    val face: DetectedFace? = null,
)

/** Conservative, deterministic acquisition policy; this is not liveness or face matching. */
class FaceQualityEvaluator(
    private val config: FaceQualityConfig = FaceQualityConfig(),
) {
    fun evaluate(
        faces: List<DetectedFace>,
        frameWidth: Int,
        frameHeight: Int,
    ): FaceQualityResult {
        if (frameWidth <= 0 || frameHeight <= 0) {
            return rejected(FaceQualityReason.INVALID_FRAME)
        }
        if (faces.isEmpty()) return rejected(FaceQualityReason.NO_FACE)
        if (faces.size > 1) return rejected(FaceQualityReason.MULTIPLE_FACES)

        val face = faces.single()
        val bounds = face.bounds
        if (bounds.width <= 0 || bounds.height <= 0) {
            return FaceQualityResult(FaceQualityStatus.REJECTED, setOf(FaceQualityReason.INVALID_FACE_BOUNDS), face)
        }

        val reasons = LinkedHashSet<FaceQualityReason>()
        val frameArea = frameWidth.toDouble() * frameHeight.toDouble()
        val faceArea = bounds.width.toDouble() * bounds.height.toDouble()
        if (bounds.width < config.minFaceWidthPx ||
            bounds.height < config.minFaceHeightPx ||
            faceArea / frameArea < config.minFaceAreaRatio
        ) {
            reasons += FaceQualityReason.FACE_TOO_SMALL
        }

        val centerX = (bounds.left + bounds.right) / 2.0 / frameWidth
        val centerY = (bounds.top + bounds.bottom) / 2.0 / frameHeight
        if (abs(centerX - 0.5) > config.centerTolerance ||
            abs(centerY - 0.5) > config.centerTolerance
        ) {
            reasons += FaceQualityReason.FACE_OFF_CENTER
        }

        return FaceQualityResult(
            status = if (reasons.isEmpty()) FaceQualityStatus.ACCEPTABLE else FaceQualityStatus.REJECTED,
            reasons = reasons,
            face = face,
        )
    }

    private fun rejected(reason: FaceQualityReason): FaceQualityResult =
        FaceQualityResult(FaceQualityStatus.REJECTED, setOf(reason))
}
