package vn.cccd.bacreader.document.resolver

import vn.cccd.bacreader.document.ocr.preprocess.OcrTextNormalizer as PreprocessTextNormalizer
import vn.cccd.bacreader.document.ocr.OcrSourceKind
import vn.cccd.bacreader.document.ocr.preprocess.TextTransformation
import vn.cccd.bacreader.document.capture.DocumentSide

enum class DocumentField {
    DOCUMENT_NUMBER,
    FULL_NAME,
    DATE_OF_BIRTH,
    SEX,
    NATIONALITY,
    DATE_OF_EXPIRY,
}

enum class VietnamCardProfile {
    CCCD_2021,
    IDENTITY_CARD_2024,
    UNKNOWN,
}

enum class ParsedFieldStatus {
    FOUND,
    AMBIGUOUS,
    NOT_FOUND,
    INVALID,
}

enum class FieldConfidence {
    HIGH,
    MEDIUM,
    LOW,
}

enum class FieldEvidence {
    EXACT_LABEL,
    ACCENT_INSENSITIVE_LABEL,
    FUZZY_LABEL,
    SPLIT_LABEL_MATCH,
    SAME_LINE,
    SAME_LINE_RIGHT,
    BELOW_LABEL,
    NEAR_BELOW,
    NEAR_RIGHT,
    LOCAL_REGION,
    EXPECTED_REGION,
    PREFERRED_SIDE,
    FORMAT_VALID,
    TOKEN_RECONSTRUCTED,
    UNIQUE_CANDIDATE,
    ISSUE_DATE_CONTEXT,
    COMPETING_CANDIDATE,
    OUTSIDE_EXPECTED_REGION,
}

/** Deterministic ranking weights; values are ranking points, never probabilities. */
data class EvidenceScoreWeights(
    val exactLabel: Int = 40,
    val fuzzyLabel: Int = 25,
    val expectedRegion: Int = 20,
    val preferredSide: Int = 15,
    val sameLineRight: Int = 20,
    val nearRight: Int = 12,
    val belowLabel: Int = 10,
    val formatValid: Int = 30,
    val tokenReconstructed: Int = 8,
    val uniqueCandidate: Int = 15,
    val issueDateContext: Int = -60,
    val competingCandidate: Int = -30,
    val outsideExpectedRegion: Int = -20,
)

object EvidenceScorer {
    val defaultWeights = EvidenceScoreWeights()

    fun score(
        evidence: Set<FieldEvidence>,
        weights: EvidenceScoreWeights = defaultWeights,
    ): Int = evidence.sumOf { item ->
        when (item) {
            FieldEvidence.EXACT_LABEL -> weights.exactLabel
            FieldEvidence.ACCENT_INSENSITIVE_LABEL -> weights.exactLabel
            FieldEvidence.FUZZY_LABEL -> weights.fuzzyLabel
            FieldEvidence.SPLIT_LABEL_MATCH -> weights.fuzzyLabel
            FieldEvidence.EXPECTED_REGION -> weights.expectedRegion
            FieldEvidence.PREFERRED_SIDE -> weights.preferredSide
            FieldEvidence.SAME_LINE,
            FieldEvidence.SAME_LINE_RIGHT,
            -> weights.sameLineRight
            FieldEvidence.NEAR_RIGHT -> weights.nearRight
            FieldEvidence.BELOW_LABEL,
            FieldEvidence.NEAR_BELOW,
            FieldEvidence.LOCAL_REGION,
            -> weights.belowLabel
            FieldEvidence.FORMAT_VALID -> weights.formatValid
            FieldEvidence.TOKEN_RECONSTRUCTED -> weights.tokenReconstructed
            FieldEvidence.UNIQUE_CANDIDATE -> weights.uniqueCandidate
            FieldEvidence.ISSUE_DATE_CONTEXT -> weights.issueDateContext
            FieldEvidence.COMPETING_CANDIDATE -> weights.competingCandidate
            FieldEvidence.OUTSIDE_EXPECTED_REGION -> weights.outsideExpectedRegion
        }
    }
}

enum class SpatialRelation {
    SAME_LINE_RIGHT,
    BELOW,
    NEAR_BELOW,
    NEAR_RIGHT,
    LOCAL_REGION,
    EXPECTED_REGION,
}

enum class FieldFormat {
    DOCUMENT_NUMBER_12_DIGITS,
    PERSON_NAME,
    DATE_DD_MM_YYYY,
    SEX,
    NATIONALITY,
}

data class NormalizedRect(
    val left: Double,
    val top: Double,
    val right: Double,
    val bottom: Double,
) {
    init {
        require(left in 0.0..1.0 && right in 0.0..1.0 && top in 0.0..1.0 && bottom in 0.0..1.0)
        require(left <= right && top <= bottom)
    }

    fun contains(x: Double, y: Double): Boolean = x in left..right && y in top..bottom
}

data class FieldProfile(
    val field: DocumentField,
    val aliases: List<String>,
    val allowedSides: Set<DocumentSide>,
    val preferredSideByCardProfile: Map<VietnamCardProfile, DocumentSide>,
    val expectedRegions: Map<VietnamCardProfile, NormalizedRect>,
    val roiRegions: Map<VietnamCardProfile, NormalizedRect> = emptyMap(),
    val expectedFormat: FieldFormat,
    val allowedRelations: Set<SpatialRelation>,
)

data class FieldDiagnostics(
    val frontLabelCandidates: Int,
    val backLabelCandidates: Int,
    val valueCandidatesNearLabel: Int,
    val profile: VietnamCardProfile,
    val frontValueCandidatesNearLabel: Int = 0,
    val backValueCandidatesNearLabel: Int = 0,
)

data class ResolvedField<T>(
    val value: T? = null,
    val status: ParsedFieldStatus = ParsedFieldStatus.NOT_FOUND,
    val confidence: FieldConfidence? = null,
    val sourceSide: DocumentSide? = null,
    val evidence: Set<FieldEvidence> = emptySet(),
    val candidateCount: Int = 0,
    val diagnostics: FieldDiagnostics = FieldDiagnostics(0, 0, 0, VietnamCardProfile.UNKNOWN),
    val bestScore: Int? = null,
    val candidates: List<ResolvedCandidateDiagnostic> = emptyList(),
)

/** Safe, explicitly requested DEBUG metadata for resolver candidates. */
data class ResolvedCandidateDiagnostic(
    val rawValue: String,
    val canonicalValue: String,
    val sourceKinds: Set<OcrSourceKind>,
    val retryTargetFields: Set<DocumentField>,
    val dedupGroupId: Int,
    val transformations: Set<TextTransformation>,
    val evidence: Set<FieldEvidence> = emptySet(),
    val score: Int,
    val valid: Boolean,
)

data class VisualDocumentResolution(
    val profile: VietnamCardProfile,
    val documentNumber: ResolvedField<String>,
    val fullName: ResolvedField<String>,
    val dateOfBirth: ResolvedField<String>,
    val sex: ResolvedField<String>,
    val nationality: ResolvedField<String>,
    val dateOfExpiry: ResolvedField<String>,
) {
    fun field(field: DocumentField): ResolvedField<String> = when (field) {
        DocumentField.DOCUMENT_NUMBER -> documentNumber
        DocumentField.FULL_NAME -> fullName
        DocumentField.DATE_OF_BIRTH -> dateOfBirth
        DocumentField.SEX -> sex
        DocumentField.NATIONALITY -> nationality
        DocumentField.DATE_OF_EXPIRY -> dateOfExpiry
    }
}

/** Matching-only normalization. The recognized value itself is never rewritten. */
object OcrTextNormalizer {
    fun matching(value: String): String = PreprocessTextNormalizer.matching(value)

    fun accentInsensitive(value: String): String = PreprocessTextNormalizer.accentInsensitive(value)

    /** Label matching may use accent-insensitive text as a deliberate fallback. */
    fun normalizeLabel(value: String): String = PreprocessTextNormalizer.normalizeLabel(value)

    /** Values retain accent distinctions; this only normalizes case/separators. */
    fun normalizeValue(value: String): String = PreprocessTextNormalizer.normalizeValue(value)

    fun tokens(value: String): List<String> = PreprocessTextNormalizer.tokens(value)
}

object VietnamCccdFieldProfiles {
    private val bothSides = setOf(DocumentSide.FRONT, DocumentSide.BACK)
    private val identityPreferred = mapOf(
        VietnamCardProfile.CCCD_2021 to DocumentSide.FRONT,
        VietnamCardProfile.IDENTITY_CARD_2024 to DocumentSide.FRONT,
    )
    private val expiryPreferred = mapOf(
        VietnamCardProfile.CCCD_2021 to DocumentSide.FRONT,
        VietnamCardProfile.IDENTITY_CARD_2024 to DocumentSide.BACK,
    )

    private val frontIdentityRegion = NormalizedRect(0.0, 0.0, 1.0, 0.82)
    private val frontExpiryRegion = NormalizedRect(0.0, 0.20, 1.0, 0.98)
    private val backExpiryRegion = NormalizedRect(0.0, 0.0, 1.0, 0.98)
    private val frontIdentityRoi = NormalizedRect(0.0, 0.0, 1.0, 0.82)
    private val frontExpiryRoi = NormalizedRect(0.0, 0.0, 0.82, 0.50)
    private val backExpiryRoi = NormalizedRect(0.0, 0.0, 1.0, 0.72)

    private val profiles = listOf(
        FieldProfile(
            field = DocumentField.DOCUMENT_NUMBER,
            aliases = listOf("SỐ CCCD", "SO CCCD", "SỐ CĂN CƯỚC", "SO CAN CUOC", "CCCD ID", "DOCUMENT NUMBER", "ID NO", "SỐ", "SO", "NO"),
            allowedSides = bothSides,
            preferredSideByCardProfile = identityPreferred,
            expectedRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontIdentityRegion,
                VietnamCardProfile.IDENTITY_CARD_2024 to frontIdentityRegion,
            ),
            roiRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontIdentityRoi,
                VietnamCardProfile.IDENTITY_CARD_2024 to frontIdentityRoi,
            ),
            expectedFormat = FieldFormat.DOCUMENT_NUMBER_12_DIGITS,
            allowedRelations = setOf(SpatialRelation.SAME_LINE_RIGHT, SpatialRelation.BELOW, SpatialRelation.NEAR_BELOW, SpatialRelation.LOCAL_REGION),
        ),
        FieldProfile(
            field = DocumentField.FULL_NAME,
            aliases = listOf("HỌ VÀ TÊN", "HO VA TEN", "FULL NAME"),
            allowedSides = bothSides,
            preferredSideByCardProfile = identityPreferred,
            expectedRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontIdentityRegion,
                VietnamCardProfile.IDENTITY_CARD_2024 to frontIdentityRegion,
            ),
            roiRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontIdentityRoi,
                VietnamCardProfile.IDENTITY_CARD_2024 to frontIdentityRoi,
            ),
            expectedFormat = FieldFormat.PERSON_NAME,
            allowedRelations = setOf(SpatialRelation.SAME_LINE_RIGHT, SpatialRelation.BELOW, SpatialRelation.NEAR_BELOW, SpatialRelation.LOCAL_REGION),
        ),
        FieldProfile(
            field = DocumentField.DATE_OF_BIRTH,
            aliases = listOf("NGÀY SINH", "NGAY SINH", "DATE OF BIRTH", "DOB"),
            allowedSides = bothSides,
            preferredSideByCardProfile = identityPreferred,
            expectedRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontIdentityRegion,
                VietnamCardProfile.IDENTITY_CARD_2024 to frontIdentityRegion,
            ),
            roiRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontIdentityRoi,
                VietnamCardProfile.IDENTITY_CARD_2024 to frontIdentityRoi,
            ),
            expectedFormat = FieldFormat.DATE_DD_MM_YYYY,
            allowedRelations = setOf(SpatialRelation.SAME_LINE_RIGHT, SpatialRelation.BELOW, SpatialRelation.NEAR_BELOW, SpatialRelation.LOCAL_REGION),
        ),
        FieldProfile(
            field = DocumentField.SEX,
            aliases = listOf("GIỚI TÍNH", "GIOI TINH", "SEX"),
            allowedSides = bothSides,
            preferredSideByCardProfile = identityPreferred,
            expectedRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontIdentityRegion,
                VietnamCardProfile.IDENTITY_CARD_2024 to frontIdentityRegion,
            ),
            roiRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontIdentityRoi,
                VietnamCardProfile.IDENTITY_CARD_2024 to frontIdentityRoi,
            ),
            expectedFormat = FieldFormat.SEX,
            allowedRelations = setOf(SpatialRelation.SAME_LINE_RIGHT, SpatialRelation.BELOW, SpatialRelation.NEAR_BELOW, SpatialRelation.LOCAL_REGION),
        ),
        FieldProfile(
            field = DocumentField.NATIONALITY,
            aliases = listOf("QUỐC TỊCH", "QUOC TICH", "NATIONALITY"),
            allowedSides = bothSides,
            preferredSideByCardProfile = identityPreferred,
            expectedRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontIdentityRegion,
                VietnamCardProfile.IDENTITY_CARD_2024 to frontIdentityRegion,
            ),
            roiRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontIdentityRoi,
                VietnamCardProfile.IDENTITY_CARD_2024 to frontIdentityRoi,
            ),
            expectedFormat = FieldFormat.NATIONALITY,
            allowedRelations = setOf(SpatialRelation.SAME_LINE_RIGHT, SpatialRelation.BELOW, SpatialRelation.NEAR_BELOW, SpatialRelation.LOCAL_REGION),
        ),
        FieldProfile(
            field = DocumentField.DATE_OF_EXPIRY,
            aliases = listOf(
                "CÓ GIÁ TRỊ ĐẾN", "CO GIA TRI DEN", "NGÀY, THÁNG, NĂM HẾT HẠN",
                "NGAY THANG NAM HET HAN", "NGÀY HẾT HẠN", "NGAY HET HAN",
                "DATE OF EXPIRY", "DATE OF EXPIRATION",
            ),
            allowedSides = bothSides,
            preferredSideByCardProfile = expiryPreferred,
            expectedRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontExpiryRegion,
                VietnamCardProfile.IDENTITY_CARD_2024 to backExpiryRegion,
            ),
            roiRegions = mapOf(
                VietnamCardProfile.CCCD_2021 to frontExpiryRoi,
                VietnamCardProfile.IDENTITY_CARD_2024 to backExpiryRoi,
            ),
            expectedFormat = FieldFormat.DATE_DD_MM_YYYY,
            allowedRelations = setOf(SpatialRelation.SAME_LINE_RIGHT, SpatialRelation.BELOW, SpatialRelation.NEAR_BELOW, SpatialRelation.NEAR_RIGHT, SpatialRelation.LOCAL_REGION),
        ),
    )

    fun forField(field: DocumentField): FieldProfile = profiles.first { it.field == field }
}
