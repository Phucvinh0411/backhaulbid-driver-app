package vn.cccd.bacreader.ui.demo

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * BackHaulBid design tokens. Values mirror `constants/theme.js` in the driver app and `src/theme/theme.jsx` in the
 * web portal. Change a token there first, then here.
 */
object EkycColors {
    val Ink = Color(0xFF0F1E2E)
    val Muted = Color(0xFF4A5B6C)
    val Subtle = Color(0xFF5E6A77)
    val Canvas = Color(0xFFF4F6F8)
    val Surface = Color(0xFFFFFFFF)
    val SurfaceSunken = Color(0xFFEDF0F4)
    val Line = Color(0xFFDFE4EA)
    val LineStrong = Color(0xFFC3CCD6)
    val Brand = Color(0xFF1B4965)
    val BrandPressed = Color(0xFF143A51)
    val BrandSoft = Color(0xFFE6EEF4)
    val Band = Color(0xFF102F44)
    val BandPressed = Color(0xFF1A3D55)
    val OnBandSoft = Color(0xFFB7C6D3)
    val Focus = Color(0xFF2B7BB9)
    val Success = Color(0xFF0E7C3A)
    val SuccessSoft = Color(0xFFE3F3E8)
    val Warning = Color(0xFF8A5300)
    val WarningSoft = Color(0xFFFBEFD9)
    val Danger = Color(0xFFC0262D)
    val DangerSoft = Color(0xFFFBE7E7)
    val Info = Color(0xFF1F5FBF)
    val InfoSoft = Color(0xFFE6EEFA)
}

/** Spacing scale in dp. The page gutter is [Lg] on phones. */
object EkycSpacing {
    val Xs = 4.dp
    val Sm = 8.dp
    val Md = 12.dp
    val Lg = 16.dp
    val Xl = 24.dp
    val Xxl = 32.dp
}

/** Corner radii. Cards use 16dp; every button, chip and badge is a pill. */
object EkycShapes {
    val Sm = RoundedCornerShape(6.dp)
    val Md = RoundedCornerShape(8.dp)
    val Card = RoundedCornerShape(16.dp)
    val Pill = RoundedCornerShape(percent = 50)
}

/** Minimum touch target for every control. */
val EkycTouchTarget = 48.dp

/**
 * Be Vietnam Pro is not bundled in this module (no font files exist in the repository), so the platform sans-serif
 * is used. Replace it with bundled font families when the files are available.
 */
private val EkycFont = FontFamily.SansSerif

private val EkycLightColors = lightColorScheme(
    primary = EkycColors.Brand, onPrimary = EkycColors.Surface,
    primaryContainer = EkycColors.BrandSoft, onPrimaryContainer = EkycColors.Brand,
    secondary = EkycColors.Brand, onSecondary = EkycColors.Surface,
    secondaryContainer = EkycColors.BrandSoft, onSecondaryContainer = EkycColors.Ink,
    background = EkycColors.Canvas, onBackground = EkycColors.Ink,
    surface = EkycColors.Surface, onSurface = EkycColors.Ink,
    surfaceVariant = EkycColors.SurfaceSunken, onSurfaceVariant = EkycColors.Muted,
    outline = EkycColors.LineStrong, outlineVariant = EkycColors.Line,
    error = EkycColors.Danger, onError = EkycColors.Surface,
    errorContainer = EkycColors.DangerSoft, onErrorContainer = EkycColors.Danger,
)

/** Token typography: title 20 bold, heading 16 bold, body 15, secondary 14, caption 13. */
private val EkycTypography = Typography(
    headlineMedium = TextStyle(fontFamily = EkycFont, fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontFamily = EkycFont, fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontFamily = EkycFont, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontFamily = EkycFont, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold),
    bodyLarge = TextStyle(fontFamily = EkycFont, fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontFamily = EkycFont, fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal),
    bodySmall = TextStyle(fontFamily = EkycFont, fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontFamily = EkycFont, fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    labelSmall = TextStyle(fontFamily = EkycFont, fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun EkycTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = EkycLightColors,
        typography = EkycTypography,
        content = content,
    )
}
