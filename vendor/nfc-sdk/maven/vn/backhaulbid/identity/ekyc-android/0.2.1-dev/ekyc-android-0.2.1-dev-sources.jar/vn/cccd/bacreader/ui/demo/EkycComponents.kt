package vn.cccd.bacreader.ui.demo

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.BorderStroke

/** Tone of a status chip. Each tone maps to one token pair (soft background, text), both above 4.5:1. */
enum class StatusTone { SUCCESS, WARNING, ERROR, NEUTRAL }

@Composable
fun EkycTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    onExit: (() -> Unit)? = null,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(EkycTouchTarget)
                        .semantics { contentDescription = "Quay lại" },
                ) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = null, tint = EkycColors.Ink)
                }
                Spacer(Modifier.width(EkycSpacing.Xs))
            }
            Column(Modifier.weight(1f).padding(vertical = EkycSpacing.Md)) {
                Text(title, style = MaterialTheme.typography.headlineSmall, color = EkycColors.Ink)
                Text(
                    "BackHaulBid · Xác minh danh tính",
                    style = MaterialTheme.typography.bodySmall,
                    color = EkycColors.Muted,
                )
            }
        }
        if (onExit != null) {
            IconButton(
                onClick = onExit,
                modifier = Modifier
                    .size(EkycTouchTarget)
                    .semantics { contentDescription = "Thoát phiên" },
            ) {
                Icon(Icons.Outlined.Close, contentDescription = null, tint = EkycColors.Ink)
            }
        }
    }
}

@Composable
fun EkycProgressStepper(current: Int, total: Int = 4) {
    val labels = listOf("Giấy tờ", "Đọc chip", "Khuôn mặt", "Kết quả")
    Row(
        modifier = Modifier.fillMaxWidth().semantics(mergeDescendants = true) {
            contentDescription = "Bước $current trên $total: ${labels.getOrElse(current - 1) { "Xác minh" }}"
            progressBarRangeInfo = ProgressBarRangeInfo(current.toFloat(), 0f..total.toFloat(), total - 1)
        },
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(EkycSpacing.Sm),
    ) {
        repeat(total) { index ->
            val selected = index < current
            Column(Modifier.weight(1f)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(EkycShapes.Pill)
                        .background(if (selected) EkycColors.Brand else EkycColors.Line),
                )
                Text(
                    labels.getOrElse(index) { "Bước ${index + 1}" },
                    Modifier.padding(top = EkycSpacing.Sm),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (selected) EkycColors.Brand else EkycColors.Subtle,
                )
            }
        }
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = EkycTouchTarget),
        shape = EkycShapes.Pill,
        colors = ButtonDefaults.buttonColors(
            containerColor = EkycColors.Brand,
            contentColor = EkycColors.Surface,
            disabledContainerColor = EkycColors.Line,
            disabledContentColor = EkycColors.Subtle,
        ),
    ) {
        Text(text, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.width(EkycSpacing.Sm))
        Icon(Icons.AutoMirrored.Outlined.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
    }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = EkycTouchTarget),
        shape = EkycShapes.Pill,
        border = BorderStroke(1.dp, EkycColors.LineStrong),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = EkycColors.Brand),
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
fun StatusBadge(label: String, tone: StatusTone) {
    val (container, content) = when (tone) {
        StatusTone.SUCCESS -> EkycColors.SuccessSoft to EkycColors.Success
        StatusTone.WARNING -> EkycColors.WarningSoft to EkycColors.Warning
        StatusTone.ERROR -> EkycColors.DangerSoft to EkycColors.Danger
        StatusTone.NEUTRAL -> EkycColors.SurfaceSunken to EkycColors.Muted
    }
    Surface(color = container, shape = EkycShapes.Pill) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = EkycSpacing.Md, vertical = EkycSpacing.Xs),
            color = content,
            style = MaterialTheme.typography.labelSmall,
        )
    }
}

@Composable
fun InfoCard(
    title: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    content: @Composable (() -> Unit)? = null,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = EkycShapes.Card,
        colors = CardDefaults.cardColors(containerColor = EkycColors.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, EkycColors.Line),
    ) {
        Column(modifier = Modifier.padding(EkycSpacing.Lg)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Icon(icon, contentDescription = null, tint = EkycColors.Brand, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(EkycSpacing.Sm))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, color = EkycColors.Ink)
                    if (subtitle != null) {
                        Spacer(Modifier.height(EkycSpacing.Xs))
                        Text(subtitle, color = EkycColors.Muted, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (content != null) {
                Spacer(Modifier.height(EkycSpacing.Md))
                content()
            }
        }
    }
}

@Composable
fun ResultFieldRow(label: String, value: String, status: String, tone: StatusTone = StatusTone.SUCCESS) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(EkycSpacing.Sm),
    ) {
        Column {
            Text(label, color = EkycColors.Muted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(EkycSpacing.Xs))
            Text(
                value,
                color = EkycColors.Ink,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
            )
        }
        StatusBadge(status, tone)
    }
}

@Composable
fun StepCard(number: Int, title: String, subtitle: String, icon: ImageVector) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = EkycShapes.Card,
        colors = CardDefaults.cardColors(containerColor = EkycColors.Surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, EkycColors.Line),
    ) {
        Row(
            modifier = Modifier.padding(EkycSpacing.Md),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(EkycColors.BrandSoft),
                contentAlignment = Alignment.Center,
            ) {
                Text(number.toString(), color = EkycColors.Brand, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.width(EkycSpacing.Md))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = EkycColors.Ink)
                Text(subtitle, color = EkycColors.Muted, style = MaterialTheme.typography.bodySmall)
            }
            Icon(icon, contentDescription = null, tint = EkycColors.Brand, modifier = Modifier.size(22.dp))
        }
    }
}
